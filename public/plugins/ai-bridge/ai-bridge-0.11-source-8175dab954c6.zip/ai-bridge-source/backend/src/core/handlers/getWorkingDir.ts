import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { MessageType } from '../../shared';

export async function getWorkingDirHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  // Single-process mode: no default workingDir.
  // Clients must provide workingDir via URL params or project selection.
  await connections.sendTo(connectionId, MessageType.ACK, {
    requestId: message.requestId,
    workingDir: null,
  });
}
