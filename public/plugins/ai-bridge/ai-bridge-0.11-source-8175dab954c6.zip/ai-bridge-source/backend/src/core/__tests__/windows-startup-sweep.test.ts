import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { mkdtempSync, mkdirSync, writeFileSync, existsSync, rmSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
const { execFile, execFileSync, state } = vi.hoisted(() => ({
  execFile: vi.fn(), execFileSync: vi.fn(), state: { home: '' },
}));
vi.mock('child_process', () => ({ execFile, execFileSync }));
vi.mock('os', async (original) => ({ ...await original<typeof import('os')>(), homedir: () => state.home }));
import { sweepOrphanCliProcesses, killRegisteredCli, findLiveCliForSession, type CliRegistryEntry } from '../cli-registry';
import { readWindowsProcessSnapshot, terminateWindowsTree } from '../windows-processes';
const originalPlatform = process.platform;
let rows: { ProcessId: number; CommandLine: string | null }[];
let alive: Set<number>;
const pathFor = (pid: number) => join(state.home, '.ai-bridge/cli-registry', `${pid}.json`);
function entry(pid: number, ownerPid = 9000): CliRegistryEntry {
  return { pid, sessionId: `session-${pid}`, workingDir: 'C:\\project', startedAt: '', owner: { pid: ownerPid, argv1: 'backend.mjs' }, mcpContainers: [`container-${pid}`] };
}
function persist(record: CliRegistryEntry) { writeFileSync(pathFor(record.pid), JSON.stringify(record)); }
beforeEach(() => {
  Object.defineProperty(process, 'platform', { value: 'win32', configurable: true });
  state.home = mkdtempSync(join(tmpdir(), 'ai-bridge-windows-sweep-'));
  mkdirSync(join(state.home, '.ai-bridge/cli-registry'), { recursive: true });
  rows = [];
  alive = new Set();
  vi.spyOn(process, 'kill').mockImplementation((pid) => {
    if (alive.has(pid)) return true;
    throw Object.assign(new Error('gone'), { code: 'ESRCH' });
  });
  execFile.mockReset();
  execFileSync.mockReset();
  execFile.mockImplementation((command, args, _options, callback) => {
    if (command === 'powershell.exe') queueMicrotask(() => callback(null, JSON.stringify(rows), ''));
    else {
      alive.delete(Number(args[3]));
      queueMicrotask(() => callback(null, '', ''));
    }
    return {};
  });
});
afterEach(() => {
  vi.restoreAllMocks();
  Object.defineProperty(process, 'platform', { value: originalPlatform, configurable: true });
  rmSync(state.home, { recursive: true, force: true });
});
describe('Windows startup registry sweep (simulated Windows commands)', () => {
  it('uses one asynchronous CIM scan for 100 live records instead of per-record shell launches', async () => {
    alive.add(9000);
    rows.push({ ProcessId: 9000, CommandLine: 'node backend.mjs' });
    for (let pid = 10000; pid < 10100; pid++) {
      persist(entry(pid)); alive.add(pid);
      rows.push({ ProcessId: pid, CommandLine: `claude --session-id session-${pid}` });
    }
    let finish!: () => void;
    execFile.mockImplementationOnce((_command, _args, _options, callback) => {
      finish = () => callback(null, JSON.stringify(rows), ''); return {};
    });
    const sweep = sweepOrphanCliProcesses();
    let heartbeat = false;
    await new Promise<void>(resolve => setImmediate(() => { heartbeat = true; resolve(); }));
    expect(heartbeat).toBe(true);
    expect(execFileSync).not.toHaveBeenCalled();
    finish();
    expect(await sweep).toEqual({ killed: 0, skipped: 100, mcpContainers: [] });
    expect(execFile).toHaveBeenCalledTimes(1);
    expect(execFile.mock.calls[0][2]).toMatchObject({ timeout: 5000, windowsHide: true });
  });
  it('does no process discovery for an empty registry', async () => {
    expect(await sweepOrphanCliProcesses()).toEqual({ killed: 0, skipped: 0, mcpContainers: [] });
    expect(execFile).not.toHaveBeenCalled();
  });
  it('retains unknown records and containers on a CIM failure', async () => {
    persist(entry(12001));
    execFile.mockImplementationOnce((_c, _a, _o, cb) => cb(new Error('timeout'), '', ''));
    expect(await sweepOrphanCliProcesses()).toEqual({ killed: 0, skipped: 1, mcpContainers: [] });
    expect(existsSync(pathFor(12001))).toBe(true);
  });
  it('retains a live stored PID whose command line is unreadable', async () => {
    persist(entry(12002)); alive.add(12002);
    rows = [{ ProcessId: 12002, CommandLine: null }];
    expect((await sweepOrphanCliProcesses()).skipped).toBe(1);
    expect(existsSync(pathFor(12002))).toBe(true);
    expect(execFile).toHaveBeenCalledTimes(1);
  });
  it('removes dead records using a single successful empty snapshot', async () => {
    persist(entry(12003));
    expect(await sweepOrphanCliProcesses()).toEqual({ killed: 0, skipped: 0, mcpContainers: ['container-12003'] });
    expect(existsSync(pathFor(12003))).toBe(false);
  });
  it('refreshes identity before killing an orphan and awaits asynchronous taskkill', async () => {
    persist(entry(12004)); alive.add(12004);
    rows = [{ ProcessId: 12004, CommandLine: 'claude --resume session-12004' }];
    expect(await sweepOrphanCliProcesses()).toEqual({ killed: 1, skipped: 0, mcpContainers: ['container-12004'] });
    expect(execFile.mock.calls.map(call => call[0])).toEqual(['powershell.exe', 'powershell.exe', 'taskkill']);
    expect(existsSync(pathFor(12004))).toBe(false);
    expect(execFileSync).not.toHaveBeenCalled();
  });
  it('preserves the record and rejects takeover when a fresh identity query fails', async () => {
    const record = entry(12005); persist(record);
    execFile.mockImplementationOnce((_c, _a, _o, cb) => cb(new Error('timeout'), '', ''));
    await expect(killRegisteredCli(record)).rejects.toThrow('refusing a second writer');
    expect(existsSync(pathFor(12005))).toBe(true);
  });
  it('does not kill a child PID reused after the preceding tree kill completes', async () => {
    const record = entry(13000); persist(record);
    alive.add(13000); alive.add(13001);
    rows = [
      { ProcessId: 13000, CommandLine: 'cmd /c claude --resume session-13000' },
      { ProcessId: 13001, CommandLine: 'claude --resume session-13000' },
    ];
    execFile.mockImplementation((command, args, _options, callback) => {
      if (command === 'powershell.exe') queueMicrotask(() => callback(null, JSON.stringify(rows), ''));
      else {
        expect(Number(args[3])).toBe(13000);
        // taskkill /T reaps both original processes. A different app starts
        // under the child's numeric PID before the callback returns.
        alive.delete(13000);
        rows = [{ ProcessId: 13001, CommandLine: 'unrelated-editor.exe' }];
        queueMicrotask(() => callback(null, '', ''));
      }
      return {};
    });
    await killRegisteredCli(record);
    expect(execFile.mock.calls.filter(call => call[0] === 'taskkill')).toHaveLength(1);
    expect(alive.has(13001)).toBe(true);
    expect(existsSync(pathFor(13000))).toBe(false);
  });
  it('retains the registry when a later child identity becomes unreadable', async () => {
    const record = entry(13010); persist(record);
    alive.add(13010); alive.add(13011);
    rows = [
      { ProcessId: 13010, CommandLine: 'cmd /c claude --resume session-13010' },
      { ProcessId: 13011, CommandLine: 'claude --resume session-13010' },
    ];
    execFile.mockImplementation((command, _args, _options, callback) => {
      if (command === 'powershell.exe') queueMicrotask(() => callback(null, JSON.stringify(rows), ''));
      else {
        alive.delete(13010);
        rows = [{ ProcessId: 13011, CommandLine: null }];
        queueMicrotask(() => callback(null, '', ''));
      }
      return {};
    });
    await expect(killRegisteredCli(record)).rejects.toThrow('refusing a second writer');
    expect(execFile.mock.calls.filter(call => call[0] === 'taskkill')).toHaveLength(1);
    expect(existsSync(pathFor(13010))).toBe(true);
  });
  it.each(['EPERM', 'EACCES', 'UNKNOWN'])('does not treat a failed %s liveness probe as proof of termination', async (code) => {
    execFile.mockImplementationOnce((_command, _args, _options, callback) => {
      callback(new Error('taskkill failed'), '', ''); return {};
    });
    vi.mocked(process.kill).mockImplementationOnce(() => {
      throw Object.assign(new Error('cannot inspect'), { code });
    });
    expect(await terminateWindowsTree(13020)).toBe(false);
  });
  it('accepts ESRCH after taskkill reports an already-exited process', async () => {
    execFile.mockImplementationOnce((_command, _args, _options, callback) => {
      callback(new Error('not found'), '', ''); return {};
    });
    expect(await terminateWindowsTree(13021)).toBe(true);
  });
  it('preserves records and lets startup settle when process discovery throws synchronously', async () => {
    persist(entry(13030));
    execFile.mockImplementationOnce(() => { throw new Error('cannot spawn powershell'); });
    expect(await sweepOrphanCliProcesses()).toEqual({ killed: 0, skipped: 1, mcpContainers: [] });
    expect(existsSync(pathFor(13030))).toBe(true);
  });
  it('retains the record when taskkill throws synchronously', async () => {
    const record = entry(13040); persist(record); alive.add(13040);
    rows = [{ ProcessId: 13040, CommandLine: 'claude --resume session-13040' }];
    execFile.mockImplementation((command, _args, _options, callback) => {
      if (command === 'powershell.exe') queueMicrotask(() => callback(null, JSON.stringify(rows), ''));
      else throw new Error('cannot spawn taskkill');
      return {};
    });
    await expect(killRegisteredCli(record)).rejects.toThrow('refusing a second writer');
    expect(existsSync(pathFor(13040))).toBe(true);
  });
  it('accepts the single-object CIM response and rejects malformed snapshots', async () => {
    execFile.mockImplementationOnce((_c, _a, _o, cb) => cb(null, '\uFEFF{"ProcessId":9,"CommandLine":"node"}', ''));
    expect(await readWindowsProcessSnapshot()).toEqual(new Map([[9, 'node']]));
    execFile.mockImplementationOnce((_c, _a, _o, cb) => cb(null, '[{"ProcessId":"oops"}]', ''));
    expect(await readWindowsProcessSnapshot()).toBeNull();
  });
});
describe('Windows conflict check before a chat starts (simulated Windows commands)', () => {
  it('finds an orphan of the session from one asynchronous scan', async () => {
    persist(entry(14000)); alive.add(14000);
    persist(entry(14001));
    rows = [{ ProcessId: 14000, CommandLine: 'cmd /c claude --resume session-14000' }];
    expect(await findLiveCliForSession('session-14000')).toMatchObject({ entry: { pid: 14000 }, ownerAlive: false });
    expect(execFile.mock.calls.map(call => call[0])).toEqual(['powershell.exe']);
    expect(execFileSync).not.toHaveBeenCalled();
    // Another session's record is not this check's to collect.
    expect(existsSync(pathFor(14001))).toBe(true);
  });
  it('finds the CLI that outlived the shell the record names', async () => {
    persist(entry(14010)); alive.add(14011);
    rows = [{ ProcessId: 14011, CommandLine: 'claude --resume session-14010' }];
    expect(await findLiveCliForSession('session-14010')).toMatchObject({ entry: { pid: 14010 }, ownerAlive: false });
  });
  it('reads the owner from the same scan, assuming it alive when its command line is unreadable', async () => {
    persist(entry(14020)); alive.add(14020); alive.add(9000);
    rows = [{ ProcessId: 14020, CommandLine: 'claude --resume session-14020' }, { ProcessId: 9000, CommandLine: 'node backend.mjs' }];
    expect((await findLiveCliForSession('session-14020'))?.ownerAlive).toBe(true);
    rows[1] = { ProcessId: 9000, CommandLine: null };
    expect((await findLiveCliForSession('session-14020'))?.ownerAlive).toBe(true);
    rows[1] = { ProcessId: 9000, CommandLine: 'notepad.exe' };
    expect((await findLiveCliForSession('session-14020'))?.ownerAlive).toBe(false);
    expect(execFile).toHaveBeenCalledTimes(3);
  });
  it('collects a record whose pid now runs something else', async () => {
    persist(entry(14030)); alive.add(14030);
    rows = [{ ProcessId: 14030, CommandLine: 'notepad.exe' }];
    expect(await findLiveCliForSession('session-14030')).toBeNull();
    expect(existsSync(pathFor(14030))).toBe(false);
  });
  it('does no process discovery when the session has no record', async () => {
    persist(entry(14040));
    expect(await findLiveCliForSession('session-other')).toBeNull();
    expect(execFile).not.toHaveBeenCalled();
  });
  it('collects the record when no program can scan, as a failed argv read does', async () => {
    persist(entry(14050)); alive.add(14050);
    execFile.mockImplementationOnce((_c, _a, _o, cb) => cb(new Error('timeout'), '', ''));
    expect(await findLiveCliForSession('session-14050')).toBeNull();
    expect(existsSync(pathFor(14050))).toBe(false);
  });
});
