import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { disableSleepGuard } from '../features/sleep-guard';
import { MessageType } from '../../shared';

export async function sleepGuardDisableHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  try {
    await disableSleepGuard();
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'ok',
    });
    await connections.broadcastToAll(MessageType.SLEEP_GUARD_STATUS, { enabled: false });
  } catch (err) {
    const error = err instanceof Error ? err.message : String(err);
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'error',
      error,
    });
  }
}
