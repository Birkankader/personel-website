import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { generateSessionId } from '../features/generateSessionId';
import { ensureClaudeProcess, sendInterruptToProcess, sendMessageToProcess, validateSteeringMessage } from '../claude-process';
import { trackEvent } from '../features/telemetry';
import { MessageType, type QueuedPrompt } from '../../shared';
import { runtimeTasks } from '../features/runtime-tasks';
import { reportBackendError } from '../features/telemetry';
import { StartDeclined } from '../start-declined';
import { randomUUID } from 'crypto';

export async function sendMessageHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  bridge: Bridge,
): Promise<void> {
  const content = typeof message.payload?.content === 'string' ? message.payload.content : '';
  const workingDir = message.payload?.workingDir as string | undefined;
  const msgSessionId = message.payload?.sessionId as string | undefined;

  if (!workingDir) {
    await connections.sendTo(connectionId, MessageType.ERROR, {
      requestId: message.requestId,
      error: 'workingDir is required',
    });
    return;
  }
  // Absent means nothing has established a mode for this session yet — the CLI
  // then reads its own `permissions.defaultMode` rather than being handed one.
  const inputMode = message.payload?.inputMode as string | undefined;
  const model = message.payload?.model as string | undefined;
  const userMessageId = typeof message.payload?.userMessageId === 'string' && message.payload.userMessageId
    ? message.payload.userMessageId : randomUUID();
  // The webview decides whether this is a new session and says so in the payload. It pre-generates
  // a sessionId for new sessions too (ChatStreamContext), so the backend cannot tell from its presence.
  const isNewSession = message.payload?.isNewSession === true;
  const resolvedSessionId = msgSessionId || generateSessionId();
  const attachments = message.payload?.attachments as Array<
    | { type: 'image'; fileName: string; mimeType: string; base64: string }
    | { type: 'file'; fileName: string; absolutePath: string }
    | { type: 'folder'; folderName: string; absolutePath: string }
  > | undefined;

  try {
    if (content || (attachments && attachments.length > 0)) {
      // Subscribe and ensure process is running (waits for spawn)
      // The directory goes with it: the session is what later answers
      // "which project is this?", and per-project settings depend on it.
      connections.subscribe(connectionId, resolvedSessionId, workingDir);
      const manager = runtimeTasks(connections);
      await manager.ready;
      const prompt: QueuedPrompt = { content, attachments, inputMode, model };
      const echo = () => ({ ...prompt, content: prompt.content.trim(), sessionId: resolvedSessionId, userMessageId });
      const broadcastQueued = (queueUpdated = false) => connections.broadcastToSession(resolvedSessionId, MessageType.USER_MESSAGE_BROADCAST,
        { ...echo(), deliveryState: 'queued', ...(queueUpdated ? { queueUpdated: true } : {}) });
      const task = manager.limiter.enqueueUser(resolvedSessionId, workingDir, async (isCancelled) => {
        if (!(await ensureClaudeProcess(connections, connectionId, workingDir, resolvedSessionId, inputMode, bridge, model, true))) {
          throw new StartDeclined();
        }
        if (isCancelled()) {
          // No prompt was written. Retain the ready, idle CLI just like an idle
          // session after a normal turn; killing it here would race a resend.
          return false;
        }
        // Admission, not submission, starts a new transcript turn. Echo before
        // stdin.write so even a synchronous CLI result follows the correct send.
        await connections.broadcastToSession(resolvedSessionId, MessageType.USER_MESSAGE_BROADCAST, { ...echo(), deliveryState: 'sent' });
        if (!(await sendMessageToProcess(connections, resolvedSessionId, prompt.content, prompt.attachments))) {
          throw new Error('Claude could not accept the queued message.');
        }
        // A Stop that came while the prompt was being prepared (a text-only
        // model has its images described first) interrupted the CLI before the
        // prompt reached it, which changes nothing. Interrupt the turn now. If
        // the Stop came after the write, this second interrupt changes nothing.
        if (isCancelled()) sendInterruptToProcess(connections, resolvedSessionId);
        if (manager.limiter.get(task.id)) await connections.broadcastToSession(resolvedSessionId, MessageType.STREAM_START);
        return true;
      }, async (error) => {
        if (error instanceof StartDeclined) return;
        await connections.broadcastToSession(resolvedSessionId, MessageType.SERVICE_ERROR, {
          error: error instanceof Error ? error.message : String(error),
        });
        await connections.broadcastToSession(resolvedSessionId, MessageType.STREAM_END);
        reportBackendError(error instanceof Error ? error : new Error(String(error)), { phase: 'task_admission' });
      }, userMessageId, {
        validate: () => validateSteeringMessage(connections, resolvedSessionId, prompt.content),
        write: (cliMessageId) => sendMessageToProcess(connections, resolvedSessionId, prompt.content, prompt.attachments, false, cliMessageId),
        accepted: async () => {
          await connections.broadcastToSession(resolvedSessionId, MessageType.USER_MESSAGE_BROADCAST, { ...echo(), deliveryState: 'sent', steering: true });
          await connections.broadcastToSession(resolvedSessionId, MessageType.STREAM_START);
        },
      }, { prompt, updated: () => broadcastQueued(true) });

      if (task.state === 'queued') {
        await broadcastQueued();
      }

      // Send the active/usage signal only when a new session started (consent only; gated inside).
      // trackEvent adds the common fields (OS, version, etc.) itself.
      if (isNewSession) {
        trackEvent('session_started');
      }
      await connections.sendTo(connectionId, MessageType.ACK, {
        requestId: message.requestId, queued: task.state === 'queued', taskId: task.id,
      });
      return;
    }
  } catch (err) {
    // ensureClaudeProcess already broadcasts SERVICE_ERROR to the session, so the
    // user-facing error response is preserved. Telemetry reporting is intentionally
    // NOT done here — it is unified at the ws-server handler boundary. Send the ACK
    // first (the request is acknowledged regardless of outcome), then rethrow so the
    // single backend error boundary reports it via reportBackendError.
    console.error('[node-backend]', 'sendMessage failed:', err);
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId, status: 'error', error: err instanceof Error ? err.message : String(err),
    });
    throw err;
  }
  // ACK on the success path. (The catch path ACKs before rethrowing.)
  await connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId });
}
