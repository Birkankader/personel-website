import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { MessageType } from '../../shared';

export const UNSUPPORTED_SERVICE = 'This optional service is not available in AI Bridge.';

const responses: Partial<Record<MessageType, Record<string, unknown>>> = {
  [MessageType.GET_TELEMETRY_CONSENT]: { consentStatus: 'denied', decidedAt: null },
  [MessageType.SET_TELEMETRY_CONSENT]: { consentStatus: 'denied', decidedAt: null },
  [MessageType.GET_ANNOUNCEMENTS]: { schemaVersion: 1, announcements: [], dismissedIds: [] },
  [MessageType.DISMISS_ANNOUNCEMENT]: { dismissedIds: [] },
  [MessageType.GET_ANNOUNCEMENTS_ENABLED]: {},
  [MessageType.SET_ANNOUNCEMENTS_ENABLED]: {},
  [MessageType.GET_SPONSOR_URL]: { url: null },
  [MessageType.GET_SPONSOR_STATUS]: { isSponsor: false, licenseKey: null, licenseStatus: 'unsupported', cancellable: false },
  [MessageType.CHECK_SPONSOR]: { isSponsor: false, licenseKey: null, licenseStatus: 'unsupported' },
  [MessageType.VERIFY_LICENSE]: { valid: false, licenseStatus: 'unsupported' },
  [MessageType.DEACTIVATE_LICENSE]: { isSponsor: false },
  [MessageType.GET_SPONSOR_DEVICES]: { devices: [] },
  [MessageType.REMOVE_SPONSOR_DEVICE]: { ok: false },
  [MessageType.GET_SPONSOR_INVOICES]: { invoices: [] },
  [MessageType.CANCEL_SPONSOR_SUBSCRIPTION]: { ok: false },
  [MessageType.GET_PLUGIN_UPDATES]: { updates: [] },
  [MessageType.UPDATE_PLUGIN]: { error: 'Install AI Bridge updates from a local plugin ZIP.' },
  [MessageType.INSTALL_CCB]: { installed: false },
  [MessageType.UNINSTALL_CCB]: { removed: false },
  [MessageType.GET_CCB_INSTALL_HINT]: { command: null, shells: [] },
  [MessageType.GET_EXTEND_KIT_INFO]: { installedVersion: null, latestVersion: null, available: false },
  [MessageType.GET_DICTATION_AVAILABILITY]: { available: false, reason: 'unsupported' },
  [MessageType.START_DICTATION]: { available: false, reason: 'unsupported' },
  [MessageType.SEND_DICTATION_AUDIO]: {},
  [MessageType.STOP_DICTATION]: {},
  [MessageType.GET_VOICE_PROMPT]: { prompt: { status: 'declined', askedAt: null, decidedAt: null } },
  [MessageType.SET_VOICE_PROMPT]: { prompt: { status: 'declined', askedAt: null, decidedAt: null } },
  [MessageType.GET_USAGE]: { usage: null, error_kind: 'unsupported' },
  [MessageType.GET_ALL_USAGE]: { accounts: [], usage: null, error_kind: 'unsupported' },
};

export function isUnsupportedService(type: string): boolean { return Object.prototype.hasOwnProperty.call(responses, type); }

/** Legacy protocol calls remain explicit refusals; no network, auth, installs or writes. */
export async function unsupportedServiceHandler(
  connectionId: string, message: IPCMessage, connections: ConnectionManager, _bridge?: Bridge,
): Promise<void> {
  await connections.sendTo(connectionId, MessageType.ACK, {
    requestId: message.requestId, status: 'unsupported', supported: false, enabled: false,
    success: false, error: UNSUPPORTED_SERVICE, ...responses[message.type as MessageType],
  });
}
