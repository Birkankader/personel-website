import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { MessageType } from '../../shared';

export async function sessionChangeHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const sessionId = message.payload?.sessionId as string | undefined;
  if (sessionId) {
    connections.subscribe(connectionId, sessionId);
  }
  await connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId });
}
