import { EventEmitter } from 'node:events';
import type { ChildProcess, SpawnOptions } from 'node:child_process';
import { mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { Bridge } from '../../bridge/bridge-interface';
import { MessageType } from '../../shared';
import { ConnectionManager } from '../../ws/connection-manager';
import { TaskLimiter } from '../features/task-limiter';
import { saveSettingsHandler } from '../handlers/saveSettings';
import { sendMessageHandler } from '../handlers/sendMessage';
import { readMergedSettings } from '../features/settings';
import { ensureClaudeProcess, restartClaudeSessionProcess } from '../claude-process';
import { Claude } from '../claude';

const state = vi.hoisted(() => ({
  home: `/tmp/ai-bridge-reasoning-${Date.now()}-${Math.random().toString(36).slice(2)}`,
  manager: null as unknown,
}));
vi.mock('os', async (original) => ({ ...await original<typeof import('os')>(), homedir: () => state.home }));
vi.mock('../claude', () => ({ Claude: { command: 'claude', applyConfigDir: vi.fn(async () => {}), spawnAuthed: vi.fn(), killTree: vi.fn() } }));
vi.mock('../features/runtime-tasks', () => ({ runtimeTasks: () => state.manager }));
vi.mock('../features/scheduled-messages', () => ({ restoreSchedulesForSession: vi.fn(async () => {}) }));
vi.mock('../features/lastRecordedSend', () => ({ readLastRecordedSend: vi.fn(async () => null) }));
vi.mock('../cli-registry', () => ({ findLiveCliForSession: vi.fn(() => null), registerCliProcess: vi.fn(), unregisterCliProcess: vi.fn() }));
vi.mock('../features/workflow-tracker', () => ({ WorkflowProgressTracker: { create: () => ({ handleEvent: vi.fn(), stopSession: vi.fn(), hasRunning: () => false }) } }));
vi.mock('../features/telemetry', () => ({ trackEvent: vi.fn(), reportBackendError: vi.fn() }));

function fakeProcess(pid: number) {
  return Object.assign(new EventEmitter(), {
    pid, exitCode: null as number | null, signalCode: null as string | null,
    stdout: new EventEmitter(), stderr: new EventEmitter(),
    stdin: Object.assign(new EventEmitter(), { writable: true, write: vi.fn((_text: string, callback?: (error?: Error | null) => void) => { callback?.(); return true; }) }),
  });
}
type FakeProcess = ReturnType<typeof fakeProcess>;
const project = join(state.home, 'project');
const providerFile = join(state.home, 'provider', 'settings.json');
const providerOriginal = JSON.stringify({ effortLevel: 'medium', unrelated: 'preserve' });
const bridge = {} as Bridge;
let sessionCounter = 0;

describe('saved reasoning preference → admitted Claude process', () => {
  let connections: ConnectionManager;
  let limiter: TaskLimiter;
  let session: string;
  let launches: { proc: FakeProcess; args: string[]; options?: SpawnOptions }[];

  beforeEach(async () => {
    vi.clearAllMocks();
    vi.stubEnv('CLAUDE_CONFIG_DIR', join(state.home, 'provider'));
    vi.stubEnv('CLAUDE_CODE_EFFORT_LEVEL', 'low');
    await mkdir(join(state.home, 'provider'), { recursive: true });
    await mkdir(project, { recursive: true });
    await writeFile(providerFile, providerOriginal);
    connections = new ConnectionManager(true);
    vi.spyOn(connections, 'sendTo');
    vi.spyOn(connections, 'broadcastToAll');
    vi.spyOn(connections, 'broadcastToSession');
    limiter = new TaskLimiter(1);
    state.manager = { limiter, ready: Promise.resolve() };
    session = `reasoning-${++sessionCounter}`;
    connections.getOrCreateSession(session, project);
    launches = [];
    vi.mocked(Claude.spawnAuthed).mockImplementation(async (args, _workingDir, options) => {
      const proc = fakeProcess(23000 + launches.length);
      launches.push({ proc, args, options });
      setImmediate(() => proc.emit('spawn'));
      return proc as unknown as ChildProcess;
    });
    vi.mocked(Claude.killTree).mockImplementation((child) => {
      const proc = child as unknown as FakeProcess;
      proc.exitCode = 0;
      proc.emit('close', 0);
    });
  });
  afterEach(async () => {
    limiter.shutdown();
    for (const { proc } of launches) {
      if (proc.exitCode === null) { proc.exitCode = 0; proc.emit('close', 0); }
    }
    vi.useRealTimers();
    vi.unstubAllEnvs();
    await rm(state.home, { recursive: true, force: true });
  });

  async function save(value: unknown, scope: 'global' | 'project' = 'project') {
    await saveSettingsHandler('client', {
      type: MessageType.SAVE_SETTINGS, requestId: 'save', timestamp: Date.now(),
      payload: { key: 'reasoningEffort', value, scope, workingDir: project },
    }, connections, bridge);
  }
  async function send(text: string) {
    await sendMessageHandler('client', {
      type: MessageType.SEND_MESSAGE, requestId: text, timestamp: Date.now(),
      payload: { sessionId: session, workingDir: project, content: text, model: 'opus' },
    }, connections, bridge);
  }
  async function delivered(index: number) {
    await vi.waitFor(() => expect(launches[index]?.proc.stdin.write).toHaveBeenCalled());
    return launches[index];
  }
  function finish(proc: FakeProcess) {
    proc.stdout.emit('data', Buffer.from(JSON.stringify({ type: 'result', session_id: session, is_error: false }) + '\n'));
  }

  it('keeps explicit project auto under global high, and null restores the global preference', async () => {
    await save('high', 'global');
    await save('auto');
    const privateFile = join(project, '.ai-bridge', 'settings.json');
    expect(JSON.parse(await readFile(privateFile, 'utf8')).reasoningEffort).toBe('auto');
    expect((await readMergedSettings(project)).settings.reasoningEffort).toBe('auto');
    expect(connections.broadcastToAll).toHaveBeenLastCalledWith(MessageType.SETTINGS_CHANGED,
      expect.objectContaining({ workingDir: project, settings: expect.objectContaining({ reasoningEffort: 'auto' }) }));
    await send('first');
    const first = await delivered(0);
    expect(first.args).not.toContain('--effort');
    expect(first.options?.env).not.toHaveProperty('CLAUDE_CODE_EFFORT_LEVEL');
    finish(first.proc);
    await save(null);
    expect((await readMergedSettings(project)).settings.reasoningEffort).toBe('high');
    await send('second');
    const second = await delivered(1);
    expect(second.args).toEqual(expect.arrayContaining(['--resume', session, '--effort', 'high']));
    expect(await readFile(providerFile, 'utf8')).toBe(providerOriginal);
  });

  it('launches max from the private setting with matching env despite inherited low', async () => {
    await save('max');
    await send('maximum');
    const launch = await delivered(0);
    expect(launch.args.slice(-2)).toEqual(['--effort', 'max']);
    expect(launch.options?.env?.CLAUDE_CODE_EFFORT_LEVEL).toBe('max');
    expect(process.env.CLAUDE_CODE_EFFORT_LEVEL).toBe('low');
    expect(await readFile(providerFile, 'utf8')).toBe(providerOriginal);
  });

  it('does not interrupt an active turn; the queued next prompt resumes once at high, then reuses, then returns to auto', async () => {
    await save('low');
    await send('first');
    const first = await delivered(0);
    await save('high');
    // Warm-session attachment is not a send boundary either.
    await ensureClaudeProcess(connections, 'client', project, session, undefined, bridge);
    await send('second');
    expect(Claude.killTree).not.toHaveBeenCalled();
    expect(launches).toHaveLength(1);
    expect(limiter.snapshot().tasks.map((t) => t.state)).toEqual(['running', 'queued']);
    finish(first.proc);
    const second = await delivered(1);
    expect(Claude.killTree).toHaveBeenCalledTimes(1);
    expect(second.args).toEqual(expect.arrayContaining(['--resume', session, '--effort', 'high']));
    expect(first.proc.stdin.write).toHaveBeenCalledTimes(1);
    expect(second.proc.stdin.write).toHaveBeenCalledTimes(1);
    expect(String(second.proc.stdin.write.mock.calls[0][0])).toContain('second');
    finish(second.proc);
    await send('third');
    await vi.waitFor(() => expect(second.proc.stdin.write).toHaveBeenCalledTimes(2));
    expect(launches).toHaveLength(2);
    finish(second.proc);
    await save('auto');
    await send('fourth');
    const third = await delivered(2);
    expect(third.args).not.toContain('--effort');
    expect(third.options?.env).not.toHaveProperty('CLAUDE_CODE_EFFORT_LEVEL');
    expect(third.proc.stdin.write).toHaveBeenCalledTimes(1);
  });

  it('restarts auto at the next send when provider effort, workflows or effort environment changes', async () => {
    await save('auto');
    await send('first');
    let previous = await delivered(0);
    const variants = [
      { effortLevel: 'high' },
      { effortLevel: 'high', ultracode: true },
      { effortLevel: 'high', ultracode: true, env: { CLAUDE_CODE_EFFORT_LEVEL: 'medium' } },
    ];
    for (const [index, settings] of variants.entries()) {
      finish(previous.proc);
      await writeFile(providerFile, JSON.stringify(settings));
      await send(`provider-${index}`);
      previous = await delivered(index + 1);
      expect(previous.args).not.toContain('--effort');
    }
    finish(previous.proc);
    vi.stubEnv('CLAUDE_CODE_EFFORT_LEVEL', 'xhigh');
    await send('new-inherited-env');
    const last = await delivered(4);
    expect(last.args).not.toContain('--effort');
    expect(Claude.killTree).toHaveBeenCalledTimes(4);
  });

  it('applies workflow changes even when the explicit xhigh effort is unchanged', async () => {
    await save('xhigh');
    await send('first');
    const first = await delivered(0);
    finish(first.proc);
    await writeFile(providerFile, JSON.stringify({ effortLevel: 'medium', ultracode: true }));
    await send('with-workflows');
    const second = await delivered(1);
    expect(second.args.slice(-2)).toEqual(['--effort', 'xhigh']);
    expect(Claude.killTree).toHaveBeenCalledTimes(1);
    finish(second.proc);
    await writeFile(providerFile, JSON.stringify({ effortLevel: 'medium', ultracode: true, disableWorkflows: true }));
    await send('workflows-disabled');
    await delivered(2);
    expect(Claude.killTree).toHaveBeenCalledTimes(2);
  });

  it('rejects invalid preferences without rewriting files or reporting a successful save', async () => {
    await save('high');
    const file = join(project, '.ai-bridge', 'settings.json');
    const original = await readFile(file, 'utf8');
    await save('super-max');
    expect(connections.sendTo).toHaveBeenLastCalledWith('client', MessageType.ACK,
      expect.objectContaining({ requestId: 'save', status: 'error' }));
    expect(await readFile(file, 'utf8')).toBe(original);
    expect(Claude.killTree).not.toHaveBeenCalled();
  });

  it('reports launch failure and releases admission without writing a prompt', async () => {
    await save('high');
    vi.mocked(Claude.spawnAuthed).mockRejectedValueOnce(new Error('launch failed'));
    await send('first');
    await vi.waitFor(() => expect(connections.broadcastToSession).toHaveBeenCalledWith(session,
      MessageType.SERVICE_ERROR, { error: 'launch failed' }));
    expect(limiter.snapshot().tasks).toEqual([]);
    expect(launches).toEqual([]);
  });

  it('refuses a second writer if the existing process cannot stop, and clears both deadline timers', async () => {
    vi.useFakeTimers();
    const proc = fakeProcess(23999);
    connections.setProcess(session, proc as unknown as ChildProcess);
    vi.mocked(Claude.killTree).mockImplementation(() => {});
    const restarting = restartClaudeSessionProcess(connections, session, proc as unknown as ChildProcess);
    const assertion = expect(restarting).rejects.toThrow('refusing to start a second process');
    await vi.advanceTimersByTimeAsync(6_000);
    await assertion;
    expect(connections.getSession(session)?.process).toBe(proc);
    expect(vi.getTimerCount()).toBe(0);
    expect(Claude.spawnAuthed).not.toHaveBeenCalled();
  });
});
