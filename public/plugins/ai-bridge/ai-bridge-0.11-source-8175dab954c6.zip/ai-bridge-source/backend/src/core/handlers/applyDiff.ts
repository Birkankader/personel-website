import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { MessageType } from '../../shared';

export async function applyDiffHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  bridge: Bridge,
): Promise<void> {
  const filePath = message.payload?.filePath as string;
  const newContent = message.payload?.newContent as string;
  const toolUseId = message.payload?.toolUseId as string | undefined;

  try {
    const result = await bridge.applyDiff({ filePath, newContent, toolUseId });
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'ok',
      applied: result.applied,
    });
  } catch (err) {
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'error',
      error: err instanceof Error ? err.message : String(err),
    });
  }
}
