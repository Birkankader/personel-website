import { EventEmitter } from 'node:events';
import type { ChildProcess, SpawnOptions } from 'node:child_process';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { Bridge } from '../../bridge/bridge-interface';
import { ConnectionManager } from '../../ws/connection-manager';
import { MessageType } from '../../shared';
import { TaskLimiter } from '../features/task-limiter';
import { sendMessageHandler } from '../handlers/sendMessage';
import { stopGenerationHandler } from '../handlers/stopGeneration';
import { Claude } from '../claude';
import { readFile } from 'node:fs/promises';
import { AUTO_CONTINUE_PROMPT, ErrorCode } from '../../shared';
import { findLiveCliForSession } from '../cli-registry';
import { reportBackendError } from '../features/telemetry';

const state = vi.hoisted(() => ({ manager: null as unknown }));
vi.mock('../claude', () => ({ Claude: { command: 'claude', applyConfigDir: vi.fn(async () => {}), spawnAuthed: vi.fn(), killTree: vi.fn() } }));
vi.mock('../features/runtime-tasks', () => ({ runtimeTasks: () => state.manager }));
vi.mock('../features/settings', () => ({ readMergedSettings: vi.fn(async () => ({ settings: {} })) }));
vi.mock('../features/claude-settings', () => ({
  readMergedClaudeSettings: vi.fn(async () => ({ settings: { env: { ANTHROPIC_BASE_URL: 'https://gateway.example' } } })),
  readJsonFileSafe: vi.fn(async () => ({})),
}));
vi.mock('../features/atomic-json', () => ({ updateJsonFile: vi.fn(async () => ({ status: 'ok' })) }));
vi.mock('../features/scheduled-messages', () => ({ restoreSchedulesForSession: vi.fn(async () => {}) }));
vi.mock('../features/lastRecordedSend', () => ({ readLastRecordedSend: vi.fn(async () => null) }));
vi.mock('../cli-registry', () => ({ findLiveCliForSession: vi.fn(() => null), registerCliProcess: vi.fn(), unregisterCliProcess: vi.fn() }));
vi.mock('../features/workflow-tracker', () => ({ WorkflowProgressTracker: { create: () => ({ handleEvent: vi.fn(), stopSession: vi.fn(), hasRunning: () => false }) } }));
vi.mock('../features/telemetry', () => ({ trackEvent: vi.fn(), reportBackendError: vi.fn() }));
vi.mock('../features/auth-diagnosis', () => ({ diagnoseAuthError: vi.fn(async () => {}) }));

function fakeProcess(pid: number) {
  return Object.assign(new EventEmitter(), {
    pid, exitCode: null as number | null, signalCode: null as string | null,
    stdout: new EventEmitter(), stderr: new EventEmitter(),
    stdin: Object.assign(new EventEmitter(), { writable: true, write: vi.fn((_text: string, callback?: () => void) => { callback?.(); return true; }) }),
  });
}
type FakeProcess = ReturnType<typeof fakeProcess>;
const bridge = {} as Bridge;
// No numeric limit to learn, so the CLI is not restarted between attempts.
const CONTEXT_ERROR = 'API Error:400 prompt is too long';
const SOCKET_ERROR = 'API Error: The socket connection was closed unexpectedly. For more information, pass `verbose: true` in the second argument to fetch()';
let counter = 0;

describe('API recovery through task admission and CLI stdin', () => {
  let connections: ConnectionManager;
  let limiter: TaskLimiter;
  let session: string;
  let launches: { proc: FakeProcess; args: string[]; options?: SpawnOptions }[];
  beforeEach(() => {
    vi.clearAllMocks();
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout', 'Date'] });
    connections = new ConnectionManager(true);
    vi.spyOn(connections, 'sendTo');
    vi.spyOn(connections, 'broadcastToAll');
    vi.spyOn(connections, 'broadcastToSession');
    limiter = new TaskLimiter(1);
    state.manager = { limiter, ready: Promise.resolve() };
    session = `api-recovery-${++counter}`;
    connections.getOrCreateSession(session, '/project');
    vi.spyOn(connections, 'getClient').mockReturnValue({ subscribedSessionId: session } as never);
    launches = [];
    vi.mocked(Claude.spawnAuthed).mockImplementation(async (args, _cwd, options) => {
      const proc = fakeProcess(25000 + launches.length);
      launches.push({ proc, args, options });
      setImmediate(() => proc.emit('spawn'));
      return proc as unknown as ChildProcess;
    });
    vi.mocked(Claude.killTree).mockImplementation((child) => {
      const proc = child as unknown as FakeProcess;
      proc.exitCode = 0;
      proc.emit('close', 0);
    });
  });
  afterEach(() => {
    stopGenerationHandler('client', { type: MessageType.STOP_GENERATION, timestamp: Date.now() }, connections, bridge);
    limiter.shutdown();
    for (const { proc } of launches) if (proc.exitCode === null) { proc.exitCode = 0; proc.emit('close', 0); }
    vi.useRealTimers();
  });
  async function settle() { for (let i = 0; i < 20; i++) await new Promise<void>(resolve => setImmediate(resolve)); }
  async function send(content: string) {
    await sendMessageHandler('client', { type: MessageType.SEND_MESSAGE, timestamp: Date.now(), payload: { content, sessionId: session, workingDir: '/project', model: 'gateway-model' } }, connections, bridge);
    // Startup now includes real asynchronous settings-file I/O. A fixed count
    // of microtasks is not proof that the original prompt reached the CLI.
    await vi.waitFor(() => expect(limiter.snapshot().tasks.some(task => task.state === 'starting')).toBe(false));
    await settle();
  }
  function event(proc: FakeProcess, payload: Record<string, unknown>) {
    proc.stdout.emit('data', Buffer.from(JSON.stringify(payload) + '\n'));
  }
  function failure(proc: FakeProcess, text = 'API Error:500 internal server error') {
    event(proc, { type: 'assistant', is_api_error_message: true, message: { content: [{ type: 'text', text }] } });
    event(proc, { type: 'result', is_error: true });
  }
  function prompts(proc: FakeProcess) {
    return proc.stdin.write.mock.calls.map(([text]) => JSON.parse(text)).filter(m => m.type === 'user').map(m => m.message.content);
  }

  it('keeps all user messages behind a complete resume → compact → continue cycle', async () => {
    await send('original task');
    const proc = launches[0].proc;
    await send('first queued task');
    failure(proc, CONTEXT_ERROR);
    expect(limiter.snapshot().tasks.map(t => t.state)).toEqual(['running', 'queued']);
    await vi.advanceTimersByTimeAsync(5000); await settle();
    expect(prompts(proc)).toEqual(['original task', 'continue']);
    failure(proc, CONTEXT_ERROR);
    await vi.advanceTimersByTimeAsync(10000); await settle();
    expect(prompts(proc)).toEqual(['original task', 'continue', '/compact']);
    await send('queued next task');
    expect(limiter.snapshot().tasks).toHaveLength(3);
    event(proc, { type: 'system', subtype: 'compact_boundary' });
    expect(prompts(proc)).toHaveLength(3);
    event(proc, { type: 'result', is_error: false });
    await vi.advanceTimersByTimeAsync(0); await settle();
    expect(prompts(proc)).toEqual(['original task', 'continue', '/compact', 'continue']);
    event(proc, { type: 'result', is_error: false }); await settle();
    expect(prompts(proc)).toEqual(['original task', 'continue', '/compact', 'continue', 'first queued task']);
    event(proc, { type: 'result', is_error: false }); await settle();
    expect(prompts(proc)).toEqual(['original task', 'continue', '/compact', 'continue', 'first queued task', 'queued next task']);
  });
  it('learns a gateway context limit, restarts with --resume and a fitting output budget, and forwards the original error unchanged', async () => {
    await send('work');
    const original = launches[0].proc;
    event(original, { type: 'system', subtype: 'init', model: 'gateway-model' });
    const text = "API Error:400 This model's maximum context length is 126000 tokens. Your prompt contains at least 101011 input tokens.";
    const raw = { type: 'assistant', is_api_error_message: true, message: { content: [{ type: 'text', text }] } };
    event(original, raw);
    event(original, { type: 'result', is_error: true });
    await vi.advanceTimersByTimeAsync(2000); await settle();
    await vi.waitFor(() => expect(launches).toHaveLength(2));
    expect(launches[1].args).toEqual(expect.arrayContaining(['--resume', session, '--model', 'gateway-model']));
    expect(launches[1].options?.env).toMatchObject({ CLAUDE_CODE_MAX_OUTPUT_TOKENS: '12600', CLAUDE_CODE_AUTO_COMPACT_WINDOW: '126000' });
    for (const launch of launches.slice(1)) {
      const settingsArg = launch.args[launch.args.indexOf('--settings') + 1];
      expect(settingsArg).not.toContain('{');
      const settingsFile = launch.options?.env?.AI_BRIDGE_CLI_SETTINGS_FILE || settingsArg;
      expect(JSON.parse(await readFile(settingsFile, 'utf8')).env).toMatchObject({
        CLAUDE_CODE_MAX_OUTPUT_TOKENS: '12600', CLAUDE_CODE_AUTO_COMPACT_WINDOW: '126000',
      });
    }
    expect(101011 + Number(launches[1].options?.env?.CLAUDE_CODE_MAX_OUTPUT_TOKENS)).toBeLessThan(126000);
    await vi.waitFor(() => expect(prompts(launches[1].proc)).toEqual(['continue']));
    expect(connections.broadcastToSession).toHaveBeenCalledWith(session, MessageType.CLI_EVENT, raw);
    expect(limiter.snapshot().tasks).toHaveLength(1);
  });
  it('Stop during retry backoff clears the timer and releases the task without sending continue', async () => {
    await send('work');
    const proc = launches[0].proc;
    failure(proc);
    stopGenerationHandler('client', { type: MessageType.STOP_GENERATION, timestamp: Date.now() }, connections, bridge);
    await vi.advanceTimersByTimeAsync(60000); await settle();
    expect(prompts(proc)).toEqual(['work']);
    expect(limiter.snapshot().tasks).toEqual([]);
  });
  it('recovers an API error emitted only on stderr followed by process exit', async () => {
    await send('work');
    const original = launches[0].proc;
    original.stderr.emit('data', Buffer.from('API Error:500 internal server error'));
    original.exitCode = 1;
    original.emit('close', 1);
    expect(limiter.snapshot().tasks).toHaveLength(1);
    await vi.advanceTimersByTimeAsync(5000); await settle();
    await vi.waitFor(() => {
      expect(launches).toHaveLength(2);
      expect(prompts(launches[1].proc)).toEqual([AUTO_CONTINUE_PROMPT]);
    });
  });
  it('does not lose a scheduled retry when the CLI exits after its error result', async () => {
    await send('work');
    const original = launches[0].proc;
    failure(original);
    original.exitCode = 1; original.emit('close', 1);
    expect(limiter.snapshot().tasks).toHaveLength(1);
    await vi.advanceTimersByTimeAsync(5000); await settle();
    await vi.waitFor(() => {
      expect(launches).toHaveLength(2);
      expect(prompts(launches[1].proc)).toEqual([AUTO_CONTINUE_PROMPT]);
    });
  });

  it('stops when the restart for a retry is declined, without a generic error over its reason', async () => {
    await send('work');
    const original = launches[0].proc;
    failure(original);
    original.exitCode = 1; original.emit('close', 1); await settle();
    // The session was opened under another backend while the retry waited.
    vi.mocked(findLiveCliForSession).mockResolvedValueOnce({
      entry: { pid: 7, sessionId: session, workingDir: '/project', startedAt: '', owner: { pid: 8, argv1: 'backend.mjs' } },
      ownerAlive: true,
    });
    const release = vi.spyOn(limiter, 'release');
    const streaming = vi.spyOn(connections, 'setStreaming');
    vi.mocked(connections.broadcastToSession).mockClear();
    await vi.advanceTimersByTimeAsync(5000); await settle();
    const sent = (type: MessageType) => vi.mocked(connections.broadcastToSession).mock.calls
      .filter(([, sentType]) => sentType === type).map(([, , payload]) => payload);
    expect(launches).toHaveLength(1);
    expect(sent(MessageType.SERVICE_ERROR)).toEqual([expect.objectContaining({
      type: MessageType.SPAWN_ERROR, reason: expect.stringContaining('already active under another backend'),
    })]);
    expect(sent(MessageType.STREAM_END)).toHaveLength(1);
    expect(sent(MessageType.USER_MESSAGE_BROADCAST)).toEqual([]);
    expect(sent(MessageType.API_RECOVERY_STATUS).at(-1)).toMatchObject({ phase: 'failed' });
    expect(release).toHaveBeenCalledWith(session, 'failed', expect.any(String));
    expect(streaming).toHaveBeenLastCalledWith(session, false);
    expect(limiter.snapshot().tasks).toEqual([]);
    expect(reportBackendError).not.toHaveBeenCalled();
    await vi.advanceTimersByTimeAsync(60000); await settle();
    expect(launches).toHaveLength(1);
  });

  it('does not restart streaming when a recovery write callback arrives after its result', async () => {
    await send('work');
    const proc = launches[0].proc;
    let accept: (() => void) | undefined;
    proc.stdin.write.mockImplementationOnce((_text, callback) => { accept = callback; return false; });
    failure(proc);
    await vi.advanceTimersByTimeAsync(5000); await settle();
    expect(accept).toBeDefined();
    // The result must be handled before the late write callback arrives.
    event(proc, { type: 'result', is_error: false }); await settle();
    vi.mocked(connections.broadcastToSession).mockClear();
    accept?.(); await settle();
    expect(limiter.snapshot().tasks).toEqual([]);
    expect(connections.broadcastToSession).not.toHaveBeenCalledWith(session, MessageType.STREAM_START);
  });

  it('continues after a dropped socket in the same CLI and keeps queued messages behind the retries', async () => {
    await send('original task');
    const proc = launches[0].proc;
    await send('queued task');
    failure(proc, SOCKET_ERROR); await settle();
    expect(limiter.snapshot().tasks.map(t => t.state)).toEqual(['running', 'queued']);
    expect(connections.broadcastToSession).toHaveBeenCalledWith(session, MessageType.API_RECOVERY_STATUS,
      expect.objectContaining({ phase: 'waiting', kind: 'network', attempt: 1, maxAttempts: 8 }));
    await vi.advanceTimersByTimeAsync(2000); await settle();
    expect(prompts(proc)).toEqual(['original task', AUTO_CONTINUE_PROMPT]);
    failure(proc, SOCKET_ERROR);
    await vi.advanceTimersByTimeAsync(4000); await settle();
    expect(prompts(proc)).toEqual(['original task', AUTO_CONTINUE_PROMPT, AUTO_CONTINUE_PROMPT]);
    expect(launches).toHaveLength(1);
    event(proc, { type: 'assistant', message: { content: [{ type: 'text', text: 'done' }] } });
    event(proc, { type: 'result', is_error: false }); await settle();
    expect(prompts(proc)).toEqual(['original task', AUTO_CONTINUE_PROMPT, AUTO_CONTINUE_PROMPT, 'queued task']);
    expect(connections.broadcastToSession).not.toHaveBeenCalledWith(session, MessageType.SERVICE_ERROR, expect.anything());
  });

  it('a CLI that dies on a connection reset is respawned without an error banner while the retry is pending', async () => {
    await send('work');
    const original = launches[0].proc;
    original.stderr.emit('data', Buffer.from('Error: read ECONNRESET'));
    original.exitCode = 1;
    original.emit('close', 1);
    expect(connections.broadcastToSession).not.toHaveBeenCalledWith(session, MessageType.SERVICE_ERROR, expect.anything());
    expect(limiter.snapshot().tasks).toHaveLength(1);
    await vi.advanceTimersByTimeAsync(2000); await settle();
    await vi.waitFor(() => {
      expect(launches).toHaveLength(2);
      expect(prompts(launches[1].proc)).toEqual([AUTO_CONTINUE_PROMPT]);
    });
  });

  it('reports exhausted retries with a structured code, releases the task and keeps the conversation', async () => {
    await send('work');
    const proc = launches[0].proc;
    for (let attempt = 0; attempt < 8; attempt++) {
      failure(proc, SOCKET_ERROR);
      await vi.advanceTimersByTimeAsync(30000); await settle();
    }
    expect(prompts(proc)).toHaveLength(9);
    failure(proc, SOCKET_ERROR); await settle();
    expect(connections.broadcastToSession).toHaveBeenCalledWith(session, MessageType.SERVICE_ERROR,
      expect.objectContaining({ errorCode: ErrorCode.API_RECOVERY_STOPPED, kind: 'network' }));
    expect(limiter.snapshot().tasks).toEqual([]);
    await vi.advanceTimersByTimeAsync(60000); await settle();
    expect(prompts(proc)).toHaveLength(9);
  });
});
