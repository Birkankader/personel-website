import { afterEach, describe, expect, it, vi } from 'vitest';
import { existsSync } from 'fs';
import { join } from 'path';
import { tmpdir } from 'os';
import { fileURLToPath } from 'url';

// The built helper's process scan against PowerShell's, on this machine's real
// processes. Other processes' command lines can hold secrets, so a failure reports
// counts and PIDs only, never a command line.
const builtHelper = fileURLToPath(new URL('../../../dist/ai-bridge-job.exe', import.meta.url));

const { helper } = vi.hoisted(() => ({ helper: { path: '' } }));
vi.mock('../win-job', () => ({ jobHelperPath: () => helper.path }));

async function scanThrough(path: string) {
  helper.path = path;
  vi.resetModules();
  const { readWindowsProcessSnapshot } = await import('../windows-processes');
  return readWindowsProcessSnapshot();
}

describe.skipIf(process.platform !== 'win32' || !existsSync(builtHelper))('process scan through the built helper', () => {
  afterEach(() => { vi.restoreAllMocks(); });

  it('reads every command line the PowerShell scan reads', async () => {
    const native = await scanThrough(builtHelper);
    const powershell = await scanThrough(join(tmpdir(), 'ccg-not-shipped', 'ai-bridge-job.exe'));
    const after = await scanThrough(builtHelper);
    expect(native).not.toBeNull();
    expect(powershell).not.toBeNull();
    expect(after).not.toBeNull();
    const shared = [...powershell!.keys()].filter(pid => native!.has(pid));
    // Processes come and go between the two scans; nearly all are in both.
    expect(shared.length).toBeGreaterThan(powershell!.size * 0.9);
    // On a busy machine (a build starting processes) a PID can change hands
    // between the scans, or be caught while its process is still being created,
    // before it has a command line. So only PIDs the helper read the same on both
    // sides of the PowerShell scan are compared.
    const steady = shared.filter(pid => after!.has(pid) && after!.get(pid) === native!.get(pid));
    expect(steady.length).toBeGreaterThan(shared.length * 0.9);
    // The helper may read more (QUERY_LIMITED reaches elevated processes WMI does
    // not), but never less, and never a different text.
    const missed = steady.filter(pid => powershell!.get(pid) !== null && native!.get(pid) !== powershell!.get(pid));
    expect(missed, 'PIDs whose command line the helper did not read the same').toEqual([]);
    expect(native!.get(process.pid)?.includes('vitest'), 'the scan reads this test process').toBe(true);
  }, 30_000);
});
