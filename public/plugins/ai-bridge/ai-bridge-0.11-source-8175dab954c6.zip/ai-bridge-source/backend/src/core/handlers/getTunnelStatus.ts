import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { getTunnelStatus, validateTunnelStatus } from '../features/tunnel-manager';
import { getSleepGuardStatus } from '../features/sleep-guard';
import { MessageType } from '../../shared';

export async function getTunnelStatusHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  try {
    // Detect stale state (e.g. restored process that died)
    const stateChanged = validateTunnelStatus();

    const tunnel = getTunnelStatus();
    const sleepGuard = getSleepGuardStatus();
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'ok',
      tunnel,
      sleepGuard,
    });

    // Broadcast corrected status so all subscribers (e.g. TunnelButton) update
    if (stateChanged) {
      await connections.broadcastToAll(MessageType.TUNNEL_STATUS, { enabled: tunnel.enabled, url: tunnel.url });
    }
  } catch (err) {
    const error = err instanceof Error ? err.message : String(err);
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'error',
      error,
    });
  }
}
