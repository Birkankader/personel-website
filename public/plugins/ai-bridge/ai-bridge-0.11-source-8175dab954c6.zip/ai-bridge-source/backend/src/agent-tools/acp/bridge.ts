import { spawn as cpSpawn, type ChildProcess, type SpawnOptions } from 'child_process';
import { randomUUID } from 'crypto';
import type { Readable, Writable } from 'stream';
import { StringDecoder } from 'string_decoder';
import { JsonRpcPeer, METHOD_NOT_FOUND, RpcRequestError } from './json-rpc';
import { HarnessTranscript } from './transcript';
import {
  findOption,
  harnessApiError,
  isCommandPrompt,
  joinPrompts,
  mergeToolCall,
  normalizeMode,
  optionValues,
  pickEffortValue,
  pickerModels,
  pickModeValue,
  planToTodos,
  sameJson,
  toAcpPrompt,
  toClaudeTool,
  toolCallReady,
  toolResultText,
  type AcpContentBlock,
  type AcpToolCall,
  type BridgeArgs,
  type ClaudeMode,
  type ConfigOption,
  type HarnessApiError,
} from './translate';
import { buildUserDeclinedContent, HARNESS_INSTALL_HINTS, HARNESS_LABELS, type AcpHarnessId } from '../../shared';
import { isTextOnlyModel } from '../../core/features/text-only-models';
import { summarizeImages, type ImageAttachment } from '../../core/features/image-summary';

/**
 * The ACP bridge: runs a harness that speaks the Agent Client Protocol and
 * presents it to the backend as a Claude CLI in `-p --input-format stream-json
 * --output-format stream-json` mode.
 *
 * The backend spawns this in place of `claude` with the very same flags, writes
 * the same stdin messages (user turns, control requests, permission answers)
 * and reads the same stdout events. Process supervision, permission prompts,
 * steering, the task limiter and the whole webview therefore work unchanged; the
 * harness-specific knowledge lives here and nowhere else.
 */

const PROTOCOL_VERSION = 1;
const BRIDGE_VERSION = '1';

export interface BridgeOptions {
  harness: AcpHarnessId;
  agentCommand: readonly string[];
  cwd: string;
  args: BridgeArgs;
  input: Readable;
  output: Writable;
  /** MCP servers handed to the harness session (ACP `McpServer[]`). */
  mcpServers?: unknown[];
  /** The textOnlyModels setting: models whose images go as a text description. */
  textOnlyModels?: unknown;
  /** Test seam: describe images in text (image-summary.ts). */
  describeImages?: (images: ImageAttachment[]) => Promise<string[]>;
  /** Test seam: start the agent process. */
  spawnAgent?: (command: string, args: string[], cwd: string) => ChildProcess;
  /** Test seam: called instead of process.exit. */
  exit?: (code: number) => void;
}

interface ToolState {
  call: AcpToolCall;
  emitted: boolean;
  resulted: boolean;
  name: string;
  input: Record<string, unknown>;
  /** Shown instead of the harness's own result text when the user declined the call. */
  declineNote?: string;
}

interface TurnState {
  startedAt: number;
  messageId: string | null;
  messageHasToolUse: boolean;
  blockIndex: number;
  openBlock: { kind: 'text' | 'thinking'; index: number; text: string } | null;
  tools: Map<string, ToolState>;
  lastText: string;
  numTurns: number;
  cancelled: boolean;
}

interface QueuedPrompt {
  content: unknown;
  uuid?: string;
}

interface PendingPermission {
  resolve: (answer: Record<string, unknown> | null) => void;
}

interface PermissionOption {
  optionId: string;
  name?: string;
  kind: string;
}

export class AcpBridge {
  private readonly label: string;
  private readonly sessionId: string;
  private readonly transcript: HarnessTranscript;
  private agent: ChildProcess | null = null;
  private peer: JsonRpcPeer | null = null;
  private agentInfo: Record<string, unknown> = {};
  private agentCaps: Record<string, unknown> = {};
  private agentSessionId: string | null = null;
  private sessionPromise: Promise<void> | null = null;
  private configOptions: ConfigOption[] = [];
  private initialModel: string | undefined;
  private baseModeValue: string | undefined;
  private commands: Array<{ name: string; description?: string; input?: { hint?: string } | null }> = [];
  private mode: ClaudeMode;
  private requestedModel: string | undefined;
  private readonly effort: string | undefined;
  private suppressUpdates = false;
  private turn: TurnState | null = null;
  private turnRunning = false;
  /**
   * How many queued prompts a Stop covered while their turn was still opening
   * its session, before it had any state. Prompts sent after the Stop are not
   * covered: as with the CLI, they start the next turn.
   */
  private stoppedWhileOpening = 0;
  private readonly queue: QueuedPrompt[] = [];
  private readonly pendingPermissions = new Map<string, PendingPermission>();
  private usage: { used?: number; size?: number; cost?: number } = {};
  private agentStderr = '';
  /** Set when the agent's stdout ended, which is how a dying agent first shows. */
  private agentOutputClosed = false;
  private agentExit: Promise<{ code: number | null; signal: NodeJS.Signals | null }> = new Promise(() => {});
  private shuttingDown = false;
  private readonly ready: Promise<void>;
  private stdinChain: Promise<void> = Promise.resolve();

  constructor(private readonly options: BridgeOptions) {
    this.label = HARNESS_LABELS[options.harness];
    this.sessionId = options.args.sessionId ?? randomUUID();
    this.transcript = new HarnessTranscript(options.harness, this.sessionId, options.cwd, options.args.noPersistence);
    this.mode = normalizeMode(options.args.permissionMode);
    this.requestedModel = options.args.model;
    this.effort = options.args.effort;
    this.ready = this.startAgent();
    this.ready.catch(() => {});
    this.listenToBackend();
  }

  // ─── Output to the backend ───────────────────────────────────────────────

  private emit(event: Record<string, unknown>): void {
    try {
      this.options.output.write(JSON.stringify(event) + '\n');
    } catch {
      // Backend gone; the stdin end handler shuts us down.
    }
  }

  private emitStream(event: Record<string, unknown>): void {
    this.emit({ type: 'stream_event', event, session_id: this.sessionId, parent_tool_use_id: null, uuid: randomUUID() });
  }

  private log(message: string): void {
    process.stderr.write(`[acp-bridge] ${message}\n`);
  }

  private get currentModel(): string {
    const model = findOption(this.configOptions, 'model');
    return model?.currentValue ?? this.initialModel ?? 'default';
  }

  // ─── Agent lifecycle ─────────────────────────────────────────────────────

  private async startAgent(): Promise<void> {
    const [command, ...args] = this.options.agentCommand;
    const spawnAgent = this.options.spawnAgent ?? defaultSpawn;
    const agent = spawnAgent(command, args, this.options.cwd);
    this.agent = agent;
    const decoder = new StringDecoder('utf8');
    agent.stderr?.on('data', (chunk: Buffer) => {
      const text = decoder.write(chunk);
      this.agentStderr = (this.agentStderr + text).slice(-8000);
      process.stderr.write(text);
    });
    let spawnError: Error | null = null;
    const spawnFailed = new Promise<never>((_, reject) => {
      agent.once('error', (error) => {
        spawnError = new Error(this.notFoundMessage(error.message));
        reject(spawnError);
      });
    });
    this.agentExit = new Promise((resolve) => agent.once('exit', (code, signal) => resolve({ code, signal })));
    agent.on('exit', (code, signal) => this.onAgentExit(code, signal));
    agent.stdout?.once('end', () => { this.agentOutputClosed = true; });
    this.peer = new JsonRpcPeer(
      agent.stdout!,
      agent.stdin!,
      (method, params) => this.onAgentRequest(method, params),
      (method, params) => this.onAgentNotification(method, params),
      (message) => this.log(message),
    );
    agent.stdin?.on('error', () => {});
    const initialized = this.peer.request<Record<string, unknown>>('initialize', {
      protocolVersion: PROTOCOL_VERSION,
      clientCapabilities: { fs: { readTextFile: false, writeTextFile: false }, terminal: false },
      clientInfo: { name: 'ai-bridge', title: 'AI Bridge', version: BRIDGE_VERSION },
    });
    let result: Record<string, unknown>;
    try {
      result = await Promise.race([initialized, spawnFailed]);
    } catch (error) {
      throw spawnError ?? await this.explainAgentFailure(error);
    }
    this.agentInfo = (result.agentInfo as Record<string, unknown>) ?? {};
    this.agentCaps = (result.agentCapabilities as Record<string, unknown>) ?? {};
  }

  private notFoundMessage(detail: string): string {
    const command = this.options.agentCommand.join(' ');
    return `${this.label} could not be started (\`${command}\`): ${detail}. ` +
      `Install it from Settings → Connection (or run \`${HARNESS_INSTALL_HINTS[this.options.harness]}\`), ` +
      'enter where it lives there, or switch the harness back to Claude Code.';
  }

  /** Why the agent stopped, from its exit code and the error in its stderr. */
  private exitMessage(code: number | null, signal: NodeJS.Signals | null): string {
    const detail = stderrSummary(this.agentStderr);
    // A missing command's text comes from the shell in the console's code page
    // (localized, and mis-decoded on a Turkish Windows), so the exit code decides.
    if (isCommandNotFound(code, this.agentStderr)) return this.notFoundMessage('command not found');
    return `${this.label} stopped with exit code ${signal ?? code}${detail ? `:\n${detail}` : ''}`;
  }

  /**
   * The reason to report when a request to the agent failed. A dying agent
   * closes its output before it exits, so the JSON-RPC error alone ("The agent
   * closed its output.") says nothing; once that has happened, wait briefly for
   * the exit and report its code and stderr instead.
   */
  private async explainAgentFailure(error: unknown): Promise<Error> {
    const original = error instanceof Error ? error : new Error(describe(error));
    const exited = typeof this.agent?.exitCode === 'number' || typeof this.agent?.signalCode === 'string';
    if (!this.agentOutputClosed && !exited) return original;
    const exit = await Promise.race([this.agentExit, delay(2000).then(() => null)]);
    return exit ? new Error(this.exitMessage(exit.code, exit.signal)) : original;
  }

  private onAgentExit(code: number | null, signal: NodeJS.Signals | null): void {
    this.peer?.close(new Error(`${this.label} exited (${signal ?? code}).`));
    if (this.shuttingDown) return;
    const detail = stderrSummary(this.agentStderr);
    // A stopped agent cannot continue the conversation; the backend respawns us
    // on the next message. Exiting non-zero during a turn surfaces the reason.
    const failed = this.turnRunning || code !== 0;
    if (failed) {
      const command = this.options.agentCommand.join(' ');
      this.log(isCommandNotFound(code, this.agentStderr)
        ? this.notFoundMessage('command not found')
        : `${this.label} (\`${command}\`) exited with ${signal ?? code}${detail ? `:\n${detail}` : ''}`);
    }
    // Let a turn in flight write its error result before leaving.
    setTimeout(() => this.finish(failed ? 1 : 0), 50);
  }

  private finish(code: number): void {
    if (this.shuttingDown && code === 0) {
      (this.options.exit ?? process.exit)(0);
      return;
    }
    this.shuttingDown = true;
    try { this.agent?.kill(); } catch { /* already gone */ }
    (this.options.exit ?? process.exit)(code);
  }

  private shutdown(): void {
    if (this.shuttingDown) return;
    this.shuttingDown = true;
    for (const pending of this.pendingPermissions.values()) pending.resolve(null);
    this.pendingPermissions.clear();
    try { this.agent?.kill(); } catch { /* already gone */ }
    (this.options.exit ?? process.exit)(0);
  }

  // ─── Session ─────────────────────────────────────────────────────────────

  private ensureSession(): Promise<void> {
    if (!this.sessionPromise) {
      this.sessionPromise = this.openSession().catch((error) => {
        this.sessionPromise = null;
        throw error;
      });
    }
    return this.sessionPromise;
  }

  private async openSession(): Promise<void> {
    await this.ready;
    const peer = this.peer!;
    const params = { cwd: this.options.cwd, mcpServers: this.options.mcpServers ?? [] };
    const caps = (this.agentCaps.sessionCapabilities as Record<string, unknown> | undefined) ?? {};
    const previous = this.transcript.agentSessionId;
    let result: Record<string, unknown> | null = null;

    if (previous) {
      try {
        if (caps.resume) {
          result = await peer.request('session/resume', { ...params, sessionId: previous });
        } else if (this.agentCaps.loadSession) {
          // session/load replays the whole history as updates; the chat already has it.
          this.suppressUpdates = true;
          try {
            result = await peer.request('session/load', { ...params, sessionId: previous });
          } finally {
            this.suppressUpdates = false;
          }
        }
        if (result) this.agentSessionId = previous;
      } catch (error) {
        this.log(`could not resume ${this.label} session ${previous}: ${describe(error)}; starting a new one`);
        result = null;
      }
      if (!result) this.log(`${this.label} keeps no context from the earlier part of this conversation`);
    }

    if (!result) {
      result = await peer.request<Record<string, unknown>>('session/new', params);
      this.agentSessionId = String(result.sessionId);
    }
    this.adoptConfig(result ?? {});
    this.initialModel = findOption(this.configOptions, 'model')?.currentValue;
    this.baseModeValue = findOption(this.configOptions, 'mode')?.currentValue;
    if (!this.options.args.noPersistence) this.transcript.recordAgentSession(this.agentSessionId!);
    await this.applyPreferences();
  }

  /** Read config from a session/new|load|resume result (or a set_config_option answer). */
  private adoptConfig(result: Record<string, unknown>): void {
    if (Array.isArray(result.configOptions)) {
      this.configOptions = result.configOptions as ConfigOption[];
      return;
    }
    // Older agents expose models and modes as separate lists instead.
    const synthesized: ConfigOption[] = [];
    const models = result.models as { currentModelId?: string; availableModels?: Array<Record<string, string>> } | undefined;
    if (models?.availableModels) {
      synthesized.push({
        id: '__model', category: 'model', currentValue: models.currentModelId,
        options: models.availableModels.map(m => ({ value: m.modelId, name: m.name, description: m.description })),
      });
    }
    const modes = result.modes as { currentModeId?: string; availableModes?: Array<Record<string, string>> } | undefined;
    if (modes?.availableModes) {
      synthesized.push({
        id: '__mode', category: 'mode', currentValue: modes.currentModeId,
        options: modes.availableModes.map(m => ({ value: m.id, name: m.name, description: m.description })),
      });
    }
    if (synthesized.length > 0) this.configOptions = synthesized;
  }

  private async setConfig(option: ConfigOption, value: string): Promise<void> {
    if (option.currentValue === value) return;
    const peer = this.peer!;
    const sessionId = this.agentSessionId!;
    if (option.id === '__model') {
      await peer.request('session/set_model', { sessionId, modelId: value });
      option.currentValue = value;
      return;
    }
    if (option.id === '__mode') {
      await peer.request('session/set_mode', { sessionId, modeId: value });
      option.currentValue = value;
      return;
    }
    const result = await peer.request<Record<string, unknown>>('session/set_config_option', {
      sessionId, configId: option.id, value,
    });
    if (result && Array.isArray(result.configOptions)) this.configOptions = result.configOptions as ConfigOption[];
    else option.currentValue = value;
  }

  /** Bring the harness session in line with the requested model, effort and mode. */
  private async applyPreferences(): Promise<void> {
    await this.applyModel();
    await this.applyEffort();
    await this.applyMode();
  }

  private async applyModel(): Promise<void> {
    const option = findOption(this.configOptions, 'model');
    if (!option) return;
    const wanted = !this.requestedModel || this.requestedModel === 'default' ? this.initialModel : this.requestedModel;
    if (!wanted) return;
    if (!optionValues(option).some(v => v.value === wanted)) {
      this.log(`${this.label} does not offer model ${wanted}; keeping ${option.currentValue}`);
      return;
    }
    try {
      await this.setConfig(option, wanted);
    } catch (error) {
      this.log(`could not select model ${wanted}: ${describe(error)}`);
    }
  }

  private async applyEffort(): Promise<void> {
    const option = findOption(this.configOptions, 'thought_level');
    const value = pickEffortValue(this.effort, option);
    if (!option || !value) return;
    try {
      await this.setConfig(option, value);
    } catch (error) {
      this.log(`could not set reasoning effort ${value}: ${describe(error)}`);
    }
  }

  private async applyMode(): Promise<void> {
    const option = findOption(this.configOptions, 'mode');
    const value = pickModeValue(this.mode, option, this.baseModeValue);
    if (!option || !value) return;
    try {
      await this.setConfig(option, value);
    } catch (error) {
      this.log(`could not switch mode to ${value}: ${describe(error)}`);
    }
  }

  /** The permission mode actually in effect, as the CLI would report it. */
  private get reportedMode(): ClaudeMode {
    if (this.mode !== 'plan') return this.mode;
    const option = findOption(this.configOptions, 'mode');
    return option?.currentValue === 'plan' ? 'plan' : 'default';
  }

  // ─── Input from the backend ──────────────────────────────────────────────

  private listenToBackend(): void {
    const decoder = new StringDecoder('utf8');
    let buffer = '';
    this.options.input.on('data', (chunk: Buffer) => {
      buffer += decoder.write(chunk);
      let newline: number;
      while ((newline = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, newline).trim();
        buffer = buffer.slice(newline + 1);
        if (!line) continue;
        let message: Record<string, unknown>;
        try {
          message = JSON.parse(line) as Record<string, unknown>;
        } catch {
          this.log(`ignoring non-JSON input: ${line.slice(0, 120)}`);
          continue;
        }
        this.stdinChain = this.stdinChain
          .then(() => this.onBackendMessage(message))
          .catch((error) => this.log(`input handling failed: ${describe(error)}`));
      }
    });
    this.options.input.on('end', () => {
      void this.stdinChain.then(() => this.shutdown());
    });
  }

  private async onBackendMessage(message: Record<string, unknown>): Promise<void> {
    switch (message.type) {
      case 'user':
        return this.onUserMessage(message);
      case 'control_request':
        return this.onControlRequest(message);
      case 'control_response':
        return this.onControlResponse(message);
      default:
        return;
    }
  }

  private onUserMessage(message: Record<string, unknown>): void {
    const content = (message.message as Record<string, unknown> | undefined)?.content;
    // A bare tool_result is the legacy permission path; harnesses never ask that way.
    if (Array.isArray(content) && content.every(b => (b as Record<string, unknown>)?.type === 'tool_result')) return;
    this.queue.push({ content, uuid: typeof message.uuid === 'string' ? message.uuid : undefined });
    if (!this.turnRunning) void this.runTurns();
  }

  private async onControlRequest(message: Record<string, unknown>): Promise<void> {
    const requestId = String(message.request_id ?? '');
    const request = (message.request as Record<string, unknown> | undefined) ?? {};
    try {
      switch (request.subtype) {
        case 'initialize':
          this.respond(requestId, await this.catalog());
          return;
        case 'interrupt':
          this.interrupt();
          this.respond(requestId);
          return;
        case 'set_model':
          this.requestedModel = typeof request.model === 'string' ? request.model : undefined;
          if (this.agentSessionId) {
            await this.applyModel();
            await this.applyEffort();
          }
          this.respond(requestId);
          return;
        case 'set_permission_mode':
          this.mode = normalizeMode(typeof request.mode === 'string' ? request.mode : undefined);
          if (this.agentSessionId) await this.applyMode();
          this.respond(requestId);
          this.emit({ type: 'system', subtype: 'status', permissionMode: this.reportedMode, session_id: this.sessionId, uuid: randomUUID() });
          return;
        default:
          this.respondError(requestId, `${this.label} does not support "${String(request.subtype)}".`);
      }
    } catch (error) {
      this.respondError(requestId, describe(error));
    }
  }

  private respond(requestId: string, response: Record<string, unknown> = {}): void {
    this.emit({ type: 'control_response', response: { subtype: 'success', request_id: requestId, response } });
  }

  private respondError(requestId: string, error: string): void {
    this.emit({ type: 'control_response', response: { subtype: 'error', request_id: requestId, error } });
  }

  private onControlResponse(message: Record<string, unknown>): void {
    const response = (message.response as Record<string, unknown> | undefined) ?? {};
    const requestId = String(response.request_id ?? '');
    const pending = this.pendingPermissions.get(requestId);
    if (!pending) return;
    this.pendingPermissions.delete(requestId);
    pending.resolve(response.subtype === 'success'
      ? ((response.response as Record<string, unknown> | undefined) ?? {})
      : { behavior: 'deny', message: String(response.error ?? '') });
  }

  /** The `initialize` answer: the same catalogue shape the Claude CLI returns. */
  private async catalog(): Promise<Record<string, unknown>> {
    await this.ensureSession();
    // Commands arrive as an update right after the session opens.
    for (let i = 0; i < 6 && this.commands.length === 0; i++) await delay(50);
    const catalog = {
      commands: this.commands.map(c => ({
        name: c.name, description: c.description ?? '', argumentHint: c.input?.hint ?? '',
      })),
      agents: [],
      output_style: 'default',
      available_output_styles: ['default'],
      models: pickerModels(this.configOptions, this.label),
      account: {},
      pid: process.pid,
      harness: this.options.harness,
      harness_agent: this.agentInfo,
    };
    if (this.options.args.noPersistence) await this.discardProbeSession();
    return catalog;
  }

  /** A catalogue probe must not leave an empty conversation in the harness's history. */
  private async discardProbeSession(): Promise<void> {
    const caps = (this.agentCaps.sessionCapabilities as Record<string, unknown> | undefined) ?? {};
    const method = caps.delete ? 'session/delete' : caps.close ? 'session/close' : null;
    if (!method || !this.agentSessionId) return;
    try {
      await Promise.race([this.peer!.request(method, { sessionId: this.agentSessionId }), delay(2000)]);
    } catch {
      // best effort
    }
  }

  // ─── Turns ───────────────────────────────────────────────────────────────

  private async runTurns(): Promise<void> {
    if (this.turnRunning) return;
    this.turnRunning = true;
    try {
      while (this.queue.length > 0 && !this.shuttingDown) {
        await this.runTurn();
      }
    } finally {
      this.turnRunning = false;
      this.stoppedWhileOpening = 0;
    }
  }

  /**
   * One user turn. Messages that arrive while the harness is working (steering)
   * are held and sent as the next prompt of the same turn, the moment the
   * harness finishes — acknowledged with a replay exactly as the CLI does, and
   * closed with a single `result`.
   */
  private async runTurn(): Promise<void> {
    const turn: TurnState = {
      startedAt: Date.now(), messageId: null, messageHasToolUse: false, blockIndex: 0,
      openBlock: null, tools: new Map(), lastText: '', numTurns: 0, cancelled: false,
    };
    let stopReason = 'end_turn';
    let failure: string | null = null;
    let apiError: HarnessApiError | null = null;
    let promptUsage: Record<string, number> = {};
    // A `/compact` the harness offers is confirmed as the CLI confirms its own,
    // which is what automatic recovery waits for before it sends anything else.
    let compacting = false;
    const tokensBefore = this.usage.used ?? 0;
    try {
      await this.ensureSession();
    } catch (error) {
      this.queue.splice(0);
      this.stoppedWhileOpening = 0;
      this.turn = turn;
      this.emitError(`${this.label} could not open a session: ${describe(await this.explainAgentFailure(error))}`);
      this.emitResult(turn, 'error', true, {});
      this.turn = null;
      return;
    }
    this.turn = turn;
    const stopped = this.stoppedWhileOpening;
    this.stoppedWhileOpening = 0;
    if (stopped > 0) turn.cancelled = true;
    this.emitInit();
    let first = true;
    while (this.queue.length > 0) {
      const batch = this.queue.splice(0, first && stopped > 0 ? stopped : this.queue.length);
      if (first) {
        compacting = batch.length === 1 && isCommandPrompt(batch[0].content, 'compact') &&
          this.commands.some(command => command.name === 'compact');
      }
      const prompts: AcpContentBlock[][] = [];
      for (const queued of batch) {
        if (!first || queued.uuid) {
          // A steering message is consumed here; the replay is the CLI's acknowledgement.
          this.emit({
            type: 'user', isReplay: true, uuid: queued.uuid ?? randomUUID(), session_id: this.sessionId,
            message: { role: 'user', content: queued.content }, parent_tool_use_id: null,
          });
        }
        this.transcript.record({
          type: 'user',
          message: { role: 'user', content: queued.content },
          permissionMode: this.reportedMode,
          ...(queued.uuid ? { uuid: queued.uuid } : {}),
        });
        prompts.push(toAcpPrompt(await this.describeImagesForModel(queued.content), this.acceptsImages));
      }
      first = false;
      // Stopped before the prompt left — while the session was opening or the
      // images were being described. Like the CLI, keep the prompt in the
      // transcript but never send it.
      if (turn.cancelled) {
        stopReason = 'cancelled';
        break;
      }
      try {
        const response = await this.peer!.request<Record<string, unknown>>('session/prompt', {
          sessionId: this.agentSessionId, prompt: joinPrompts(prompts),
        });
        stopReason = String(response?.stopReason ?? 'end_turn');
        promptUsage = (response?.usage as Record<string, number> | undefined) ?? {};
      } catch (error) {
        failure = describe(error);
        if (error instanceof RpcRequestError) apiError = harnessApiError(error.error, this.label);
        break;
      }
      this.closeOpenBlock();
      if (stopReason === 'cancelled' || turn.cancelled) break;
    }

    this.closeOpenBlock();
    this.settleOpenTools(turn.cancelled || stopReason === 'cancelled');
    this.finishMessage(stopReason === 'max_tokens' ? 'max_tokens' : 'end_turn');
    if (turn.cancelled || stopReason === 'cancelled') {
      const entry = this.transcript.record({
        type: 'user', message: { role: 'user', content: [{ type: 'text', text: '[Request interrupted by user]' }] },
      });
      this.emit({ ...liveFields(entry), type: 'user', message: entry.message, session_id: this.sessionId, parent_tool_use_id: null });
    }
    if (apiError) {
      this.emitApiError(apiError);
    } else if (failure) {
      this.emitError(`${this.label}: ${failure}`);
      this.finishMessage('end_turn');
    }
    const cancelled = turn.cancelled || stopReason === 'cancelled';
    if (compacting && !failure && !cancelled) this.emitCompactBoundary(tokensBefore);
    const isError = failure !== null || stopReason === 'refusal';
    this.emitResult(turn, failure ? 'error' : stopReason, isError, promptUsage, apiError?.text);
    this.turn = null;
  }

  /**
   * The backend already describes images for a text-only model it knows of, but
   * before the first turn it may not know which model the harness runs. Here the
   * model is certain, so any image still in a message for such a model becomes
   * its description; the harness never sees an image block it would fail on.
   */
  private async describeImagesForModel(content: unknown): Promise<unknown> {
    if (!Array.isArray(content) || !content.some(block => block?.type === 'image')) return content;
    if (!isTextOnlyModel(this.options.textOnlyModels, [this.currentModel])) return content;
    const blocks = content as Array<Record<string, unknown>>;
    const images = blocks.flatMap((block) => {
      const source = block.source as Record<string, unknown> | undefined;
      return block.type === 'image' && source?.type === 'base64' && typeof source.data === 'string'
        ? [{ fileName: 'image', mimeType: String(source.media_type ?? 'image/png'), base64: source.data }]
        : [];
    });
    let summaries: string[] = [];
    try {
      summaries = await (this.options.describeImages ?? summarizeImages)(images);
    } catch (error) {
      this.log(`could not describe images: ${describe(error)}`);
    }
    let next = 0;
    return blocks.map((block) => {
      if (block.type !== 'image') return block;
      const source = block.source as Record<string, unknown> | undefined;
      const summary = source?.type === 'base64' ? summaries[next++] : undefined;
      return { type: 'text', text: summary ?? '[An attached image was left out: the current model does not read images.]' };
    });
  }

  private get acceptsImages(): boolean {
    const prompt = this.agentCaps.promptCapabilities as Record<string, unknown> | undefined;
    return prompt?.image === true;
  }

  private interrupt(): void {
    for (const [requestId, pending] of this.pendingPermissions) {
      pending.resolve(null);
      this.emit({ type: 'control_cancel_request', request_id: requestId });
    }
    this.pendingPermissions.clear();
    // Opening a session takes as long as starting the harness. A Stop pressed
    // then used to find no turn and was lost, and the prompt ran to the end.
    if (!this.turn) {
      if (this.turnRunning) this.stoppedWhileOpening = this.queue.length;
      return;
    }
    this.turn.cancelled = true;
    if (this.agentSessionId) this.peer?.notify('session/cancel', { sessionId: this.agentSessionId });
  }

  private emitInit(): void {
    this.emit({
      type: 'system',
      subtype: 'init',
      cwd: this.options.cwd,
      session_id: this.sessionId,
      tools: [],
      mcp_servers: [],
      model: this.currentModel,
      permissionMode: this.reportedMode,
      slash_commands: this.commands.map(c => c.name),
      apiKeySource: 'none',
      output_style: 'default',
      agents: [],
      skills: [],
      plugins: [],
      uuid: randomUUID(),
      harness: this.options.harness,
      harness_agent: this.agentInfo,
    });
  }

  private emitResult(
    turn: TurnState, stopReason: string, isError: boolean, promptUsage: Record<string, number>, resultText = turn.lastText,
  ): void {
    const model = this.currentModel;
    const inputTokens = promptUsage.inputTokens ?? 0;
    const outputTokens = promptUsage.outputTokens ?? 0;
    const cacheRead = promptUsage.cachedReadTokens ?? 0;
    const elapsed = Date.now() - turn.startedAt;
    this.emit({
      type: 'result',
      subtype: isError ? 'error_during_execution' : 'success',
      is_error: isError,
      duration_ms: elapsed,
      duration_api_ms: elapsed,
      num_turns: Math.max(1, turn.numTurns),
      result: resultText,
      stop_reason: stopReason,
      session_id: this.sessionId,
      total_cost_usd: this.usage.cost ?? 0,
      usage: {
        input_tokens: inputTokens,
        output_tokens: outputTokens,
        cache_read_input_tokens: cacheRead,
        cache_creation_input_tokens: 0,
      },
      modelUsage: {
        [model]: {
          inputTokens, outputTokens, cacheReadInputTokens: cacheRead, cacheCreationInputTokens: 0,
          costUSD: this.usage.cost ?? 0,
          contextWindow: this.usage.size ?? 0,
          maxOutputTokens: 0,
        },
      },
      permission_denials: [],
      uuid: randomUUID(),
      harness: this.options.harness,
    });
  }

  /** An error the harness reported, shown in the chat as Claude's own errors are: as text. */
  private emitError(text: string): void {
    this.closeOpenBlock();
    this.ensureMessage();
    const index = this.turn!.blockIndex++;
    this.emitStream({ type: 'content_block_start', index, content_block: { type: 'text', text: '' } });
    this.emitStream({ type: 'content_block_delta', index, delta: { type: 'text_delta', text } });
    this.emitAssistant({ type: 'text', text });
    this.emitStream({ type: 'content_block_stop', index });
  }

  /**
   * A temporary provider failure, as the Claude CLI reports its own: a synthetic
   * assistant entry with the error markers, unstreamed. Automatic recovery
   * retries it and the chat folds it into a one-line notice.
   */
  private emitApiError(failure: HarnessApiError): void {
    const message = {
      id: randomUUID(), type: 'message', role: 'assistant', model: '<synthetic>',
      content: [{ type: 'text', text: failure.text }], stop_reason: 'stop_sequence', stop_sequence: '',
      usage: { input_tokens: 0, output_tokens: 0, cache_read_input_tokens: 0, cache_creation_input_tokens: 0 },
    };
    const status = failure.status;
    // The CLI writes the markers in camelCase to its transcript and in snake_case to stdout.
    const entry = this.transcript.record({
      type: 'assistant', message, isApiErrorMessage: true, error: failure.error, ...(status ? { apiErrorStatus: status } : {}),
    });
    this.emit({
      ...liveFields(entry), type: 'assistant', message, parent_tool_use_id: null, session_id: this.sessionId,
      is_api_error_message: true, error: failure.error, ...(status ? { api_error_status: status } : {}),
    });
  }

  private emitCompactBoundary(preTokens: number): void {
    this.emit({
      type: 'system', subtype: 'compact_boundary', session_id: this.sessionId, uuid: randomUUID(),
      compact_metadata: { trigger: 'manual', pre_tokens: preTokens },
    });
  }

  // ─── Assistant content ───────────────────────────────────────────────────

  private ensureMessage(): void {
    const turn = this.turn!;
    if (turn.messageId) return;
    turn.messageId = `msg_${this.options.harness}_${randomUUID().replace(/-/g, '').slice(0, 24)}`;
    turn.messageHasToolUse = false;
    turn.blockIndex = 0;
    turn.numTurns++;
    this.emitStream({
      type: 'message_start',
      message: {
        id: turn.messageId, type: 'message', role: 'assistant', model: this.currentModel,
        content: [], stop_reason: null, stop_sequence: null, usage: this.messageUsage(),
      },
    });
  }

  private finishMessage(stopReason: string): void {
    const turn = this.turn;
    if (!turn?.messageId) return;
    this.closeOpenBlock();
    this.emitStream({
      type: 'message_delta',
      delta: { stop_reason: stopReason, stop_sequence: null },
      usage: { output_tokens: 0 },
    });
    this.emitStream({ type: 'message_stop' });
    turn.messageId = null;
  }

  private messageUsage(): Record<string, number> {
    return { input_tokens: this.usage.used ?? 0, output_tokens: 0, cache_read_input_tokens: 0, cache_creation_input_tokens: 0 };
  }

  private emitAssistant(block: Record<string, unknown>, extra: Record<string, unknown> = {}): void {
    const turn = this.turn!;
    const message = {
      id: turn.messageId, type: 'message', role: 'assistant', model: this.currentModel,
      content: [block], stop_reason: null, stop_sequence: null, usage: this.messageUsage(),
    };
    const entry = this.transcript.record({ type: 'assistant', message, ...extra });
    this.emit({ ...liveFields(entry), type: 'assistant', message, parent_tool_use_id: null, session_id: this.sessionId, ...extra });
  }

  private appendText(kind: 'text' | 'thinking', text: string): void {
    const turn = this.turn;
    if (!turn || !text) return;
    if (turn.openBlock && turn.openBlock.kind !== kind) this.closeOpenBlock();
    if (!turn.openBlock) {
      // Text after a tool call belongs to the model's next message, as in Claude.
      if (turn.messageHasToolUse) this.finishMessage('tool_use');
      this.ensureMessage();
      const index = turn.blockIndex++;
      turn.openBlock = { kind, index, text: '' };
      this.emitStream({
        type: 'content_block_start', index,
        content_block: kind === 'text' ? { type: 'text', text: '' } : { type: 'thinking', thinking: '', signature: '' },
      });
    }
    turn.openBlock.text += text;
    this.emitStream({
      type: 'content_block_delta', index: turn.openBlock.index,
      delta: kind === 'text' ? { type: 'text_delta', text } : { type: 'thinking_delta', thinking: text },
    });
  }

  private closeOpenBlock(): void {
    const turn = this.turn;
    const block = turn?.openBlock;
    if (!turn || !block) return;
    turn.openBlock = null;
    if (block.kind === 'text') {
      turn.lastText = block.text;
      this.emitAssistant({ type: 'text', text: block.text });
    } else {
      this.emitAssistant({ type: 'thinking', thinking: block.text, signature: '' });
    }
    this.emitStream({ type: 'content_block_stop', index: block.index });
  }

  // ─── Tool calls ──────────────────────────────────────────────────────────

  private toolState(update: AcpToolCall): ToolState {
    const turn = this.turn!;
    let state = turn.tools.get(update.toolCallId);
    if (!state) {
      state = { call: { toolCallId: update.toolCallId }, emitted: false, resulted: false, name: '', input: {} };
      turn.tools.set(update.toolCallId, state);
    }
    state.call = mergeToolCall(state.call, update);
    return state;
  }

  private onToolCall(update: AcpToolCall): void {
    if (!this.turn || !update.toolCallId) return;
    const state = this.toolState(update);
    if (!state.emitted && toolCallReady(state.call)) this.emitToolUse(state);
    if (state.emitted && !state.resulted && (state.call.status === 'completed' || state.call.status === 'failed')) {
      this.emitToolResult(state, state.call.status === 'failed');
      this.deliverSteeringAtBoundary();
    }
  }

  /**
   * The CLI hands a steering message (Send now) to the model at the next step,
   * as a tool returns. A harness takes input only between prompts, so once the
   * turn's last running tool returns while one waits, the prompt is cancelled
   * and the message goes next instead of after the whole answer. While no tool
   * runs, the backend interrupts before writing the message.
   */
  private deliverSteeringAtBoundary(): void {
    const turn = this.turn;
    if (!turn || turn.cancelled || this.queue.length === 0 || !this.agentSessionId) return;
    for (const state of turn.tools.values()) {
      if (!state.resulted && state.call.status !== 'completed' && state.call.status !== 'failed') return;
    }
    turn.cancelled = true;
    this.peer?.notify('session/cancel', { sessionId: this.agentSessionId });
  }

  private emitToolUse(state: ToolState): void {
    const turn = this.turn!;
    this.closeOpenBlock();
    this.ensureMessage();
    const { name, input } = toClaudeTool(state.call, this.options.cwd);
    state.name = name;
    state.input = input;
    state.emitted = true;
    turn.messageHasToolUse = true;
    const index = turn.blockIndex++;
    const id = state.call.toolCallId;
    this.emitStream({ type: 'content_block_start', index, content_block: { type: 'tool_use', id, name, input: {} } });
    this.emitStream({ type: 'content_block_delta', index, delta: { type: 'input_json_delta', partial_json: JSON.stringify(input) } });
    // The harness's own description of the call travels with it, unedited.
    this.emitAssistant({ type: 'tool_use', id, name, input }, { acp_tool_call: state.call });
    this.emitStream({ type: 'content_block_stop', index });
  }

  private emitToolResult(state: ToolState, isError: boolean, overrideText?: string): void {
    const turn = this.turn!;
    if (turn.messageHasToolUse && turn.messageId) this.finishMessage('tool_use');
    state.resulted = true;
    const text = overrideText ?? state.declineNote ?? toolResultText(state.call);
    const content = [{ tool_use_id: state.call.toolCallId, type: 'tool_result', content: text, is_error: isError || !!state.declineNote }];
    const extra = { toolUseResult: state.call.rawOutput ?? text, acp_tool_call: state.call };
    const entry = this.transcript.record({ type: 'user', message: { role: 'user', content }, ...extra });
    this.emit({
      ...liveFields(entry), type: 'user', message: { role: 'user', content },
      parent_tool_use_id: null, session_id: this.sessionId,
      tool_use_result: extra.toolUseResult, acp_tool_call: state.call,
    });
  }

  /** At turn end no tool card may stay spinning. */
  private settleOpenTools(cancelled: boolean): void {
    const turn = this.turn;
    if (!turn) return;
    for (const state of turn.tools.values()) {
      if (state.emitted && !state.resulted) {
        this.emitToolResult(state, true, cancelled ? 'Interrupted.' : `${this.label} did not report a result for this tool.`);
      }
    }
  }

  private onPlan(entries: unknown): void {
    const turn = this.turn;
    if (!turn) return;
    const todos = planToTodos(entries);
    const id = `plan_${randomUUID().replace(/-/g, '').slice(0, 16)}`;
    const state: ToolState = {
      call: { toolCallId: id, title: 'TodoWrite', kind: 'think', status: 'completed', rawInput: { entries } as Record<string, unknown> },
      emitted: false, resulted: false, name: 'TodoWrite', input: { todos },
    };
    turn.tools.set(id, state);
    this.closeOpenBlock();
    this.ensureMessage();
    state.emitted = true;
    turn.messageHasToolUse = true;
    const index = turn.blockIndex++;
    this.emitStream({ type: 'content_block_start', index, content_block: { type: 'tool_use', id, name: 'TodoWrite', input: {} } });
    this.emitStream({ type: 'content_block_delta', index, delta: { type: 'input_json_delta', partial_json: JSON.stringify({ todos }) } });
    this.emitAssistant({ type: 'tool_use', id, name: 'TodoWrite', input: { todos } }, { acp_plan: entries });
    this.emitStream({ type: 'content_block_stop', index });
    this.emitToolResult(state, false, 'Todos have been modified successfully.');
  }

  // ─── Agent → client ──────────────────────────────────────────────────────

  private onAgentNotification(method: string, params: unknown): void {
    if (method !== 'session/update') return;
    const p = params as { sessionId?: string; update?: Record<string, unknown> } | undefined;
    const update = p?.update;
    if (!update || (this.agentSessionId && p?.sessionId !== this.agentSessionId)) return;
    switch (update.sessionUpdate) {
      case 'available_commands_update':
        this.commands = Array.isArray(update.availableCommands) ? update.availableCommands as typeof this.commands : [];
        return;
      case 'config_option_update':
        if (Array.isArray(update.configOptions)) this.configOptions = update.configOptions as ConfigOption[];
        return;
      case 'current_mode_update': {
        const option = findOption(this.configOptions, 'mode');
        if (option && typeof update.currentModeId === 'string') option.currentValue = update.currentModeId;
        return;
      }
      case 'usage_update':
        this.usage = {
          used: typeof update.used === 'number' ? update.used : this.usage.used,
          size: typeof update.size === 'number' ? update.size : this.usage.size,
          cost: typeof (update.cost as Record<string, unknown> | undefined)?.amount === 'number'
            ? (update.cost as Record<string, number>).amount : this.usage.cost,
        };
        return;
      default:
        break;
    }
    if (this.suppressUpdates || !this.turn) return;
    switch (update.sessionUpdate) {
      case 'agent_message_chunk':
        this.appendText('text', chunkText(update.content));
        return;
      case 'agent_thought_chunk':
        this.appendText('thinking', chunkText(update.content));
        return;
      case 'tool_call':
      case 'tool_call_update':
        this.onToolCall(update as unknown as AcpToolCall);
        return;
      case 'plan':
        this.onPlan(update.entries);
        return;
      default:
        return;
    }
  }

  private async onAgentRequest(method: string, params: unknown): Promise<unknown> {
    if (method === 'session/request_permission') return this.requestPermission(params as Record<string, unknown>);
    // The bridge declares no fs or terminal capability, so a conforming agent never asks.
    throw new RpcRequestError({ code: METHOD_NOT_FOUND, message: `${method} is not supported by this client` });
  }

  /**
   * A harness asking to run a tool becomes the CLI's `can_use_tool` request, so
   * the chat's own permission prompt answers it.
   */
  private async requestPermission(params: Record<string, unknown>): Promise<unknown> {
    const options = (params.options as PermissionOption[] | undefined) ?? [];
    const toolCall = params.toolCall as AcpToolCall | undefined;
    if (!this.turn || !toolCall?.toolCallId) return choose(options, 'reject_once');
    const state = this.toolState(toolCall);
    if (!state.emitted) this.emitToolUse(state);

    const kind = state.call.kind;
    if (this.mode === 'bypassPermissions' || (this.mode === 'acceptEdits' && kind === 'edit')) {
      return choose(options, 'allow_once');
    }

    const requestId = `acp_${randomUUID()}`;
    const answer = new Promise<Record<string, unknown> | null>((resolve) => {
      this.pendingPermissions.set(requestId, { resolve });
    });
    this.emit({
      type: 'control_request',
      request_id: requestId,
      request: {
        subtype: 'can_use_tool',
        tool_name: state.name,
        input: state.input,
        tool_use_id: state.call.toolCallId,
        ...(state.call.title ? { title: state.call.title } : {}),
      },
    });
    const response = await answer;
    if (!response) return { outcome: { outcome: 'cancelled' } };
    if (response.behavior === 'allow') {
      const updated = response.updatedInput as Record<string, unknown> | undefined;
      if (updated && Object.keys(updated).length > 0 && !sameJson(updated, state.input)) {
        // ACP has no way to hand back an amended call. Writing the whole proposal
        // after the user kept only part of it would write what they refused.
        state.declineNote = buildUserDeclinedContent(
          `${this.label} can only apply a change exactly as proposed, so the partly accepted change was not applied. Ask for the narrower change instead.`,
        );
        return choose(options, 'reject_once');
      }
      const always = Array.isArray(response.updatedPermissions) && response.updatedPermissions.length > 0;
      return choose(options, always ? 'allow_always' : 'allow_once');
    }
    if (typeof response.message === 'string' && response.message) state.declineNote = response.message;
    return choose(options, 'reject_once');
  }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

function choose(options: PermissionOption[], kind: string): unknown {
  const family = kind.split('_')[0];
  const option = options.find(o => o.kind === kind)
    ?? options.find(o => o.kind?.startsWith(family) && (family !== 'allow' || kind !== 'allow_once' || o.kind === 'allow_once'))
    ?? options.find(o => o.kind?.startsWith(family));
  return option ? { outcome: { outcome: 'selected', optionId: option.optionId } } : { outcome: { outcome: 'cancelled' } };
}

function chunkText(content: unknown): string {
  const c = content as Record<string, unknown> | undefined;
  return c?.type === 'text' && typeof c.text === 'string' ? c.text : '';
}

function liveFields(entry: Record<string, unknown>): Record<string, unknown> {
  return { uuid: entry.uuid, timestamp: entry.timestamp };
}

/**
 * cmd.exe exits 9009 for an unknown command and a POSIX shell 127; the text
 * check covers shells that say so in English.
 */
export function isCommandNotFound(code: number | null, stderr: string): boolean {
  return code === 9009 || code === 127 ||
    /is not recognized as an internal or external command|command not found|ENOENT/i.test(stderr);
}

/**
 * The part of a stopped agent's stderr that says why. Node prints the error,
 * then its stack frames, any error properties and `Node.js vX`, so the end of
 * stderr is mostly frames; keep the last error line and what follows it,
 * without the frames.
 */
export function stderrSummary(stderr: string, max = 6): string {
  const lines = stderr.split(/\r?\n/)
    .map(line => line.trimEnd())
    .filter(line => line.trim() && !/^\s*at\s/.test(line) && !/^Node\.js v\d/.test(line.trim()));
  let start = -1;
  for (let i = lines.length - 1; i >= 0 && start < 0; i--) {
    if (/\b\w*(Error|Exception)\b/.test(lines[i])) start = i;
  }
  return (start >= 0 ? lines.slice(start, start + max) : lines.slice(-max)).join('\n');
}

function describe(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}

function delay(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/** Quote a token for cmd.exe when it holds spaces (an install path, typically). */
function winQuote(token: string): string {
  return /\s/.test(token) && !/^".*"$/.test(token) ? `"${token}"` : token;
}

function defaultSpawn(command: string, args: string[], cwd: string): ChildProcess {
  const options: SpawnOptions = { cwd, stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true, env: process.env };
  if (process.platform !== 'win32') return cpSpawn(command, args, options);
  // npm installs harness launchers as .cmd shims on Windows, which only a shell
  // can start. The line is joined here: Node 24 deprecates shell + an args array.
  return cpSpawn([command, ...args].map(winQuote).join(' '), { ...options, shell: true });
}
