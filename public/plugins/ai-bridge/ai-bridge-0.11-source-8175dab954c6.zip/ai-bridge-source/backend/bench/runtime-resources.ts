/** Real Windows parent/child workload. Run only through build.sh be-bench-runtime. */
import {execFile, spawn, type ChildProcess} from 'node:child_process';
import {promisify} from 'node:util';
import {existsSync, mkdirSync, writeFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import {join} from 'node:path';
import {RuntimeResourceSampler} from '../src/core/features/runtime-resources';
import type {ConnectionManager} from '../src/ws/connection-manager';

const after = process.argv.includes('--native');
const inspectOnly = process.argv.includes('--inspect-only');
const cleanupSmoke = process.argv.includes('--cleanup-smoke');
const forceParentExit = process.argv.includes('--force-parent-exit');
if ((inspectOnly || cleanupSmoke) && !after) throw new Error('Inspection and cleanup smoke require --native');
if (forceParentExit && !cleanupSmoke) throw new Error('--force-parent-exit requires --cleanup-smoke');
const label = after ? 'native' : 'baseline';
const sampleCount = 8;
const sleep = (ms: number) => new Promise<void>(resolve => setTimeout(resolve, ms));
const busyChild = `
const memory = Buffer.alloc(32 * 1024 * 1024, 1);
setInterval(() => { const until = performance.now() + 20; while(performance.now() < until) {} }, 100);
process.on('message', id => process.send({id, pid:process.pid, rssBytes:process.memoryUsage().rss, cpu:process.cpuUsage(), retained:memory.length}));
process.on('disconnect', () => process.exit(0));
process.send({ready:true,pid:process.pid});
`;
const parentCode = `
const {spawn} = require('node:child_process');
const memory = Buffer.alloc(24 * 1024 * 1024, 1);
const child = spawn(process.execPath, ['-e', ${JSON.stringify(busyChild)}], {stdio:['ignore','ignore','ignore','ipc'], windowsHide:true});
let stopping = false;
function stop() {
 if(stopping) return;
 stopping = true;
 if(child.exitCode !== null || child.signalCode !== null) process.exit(0);
 child.once('exit', () => process.exit(0));
 child.kill();
}
child.on('message', data => {
 if(data.ready) process.send({ready:true,pid:process.pid,childPid:data.pid});
 else process.send({id:data.id, processes:[{pid:process.pid,rssBytes:process.memoryUsage().rss,cpu:process.cpuUsage(),retained:memory.length},data]});
});
process.on('message', id => {
 if(id === 'stop') stop();
 else child.send(id);
});
process.on('disconnect', stop);
`;

function waitMessage(child: ChildProcess, matches: (value: any) => boolean): Promise<any> {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { child.off('message', receive); reject(new Error('Workload did not reply')); }, 5000);
    function receive(value: any) {
      if (!matches(value)) return;
      clearTimeout(timer);
      child.off('message', receive);
      resolve(value);
    }
    child.on('message', receive);
  });
}

if (process.platform !== 'win32') throw new Error('Run this benchmark with Windows Node via the Git Bash build runner.');
const target = spawn(process.execPath, ['-e', parentCode], {stdio: ['ignore', 'ignore', 'pipe', 'ipc'], windowsHide: true});
const targetExited = new Promise<void>(resolve => { target.once('exit', () => resolve()); target.once('error', () => resolve()); });
let childPid: number | undefined;
let cleanupIdentity: string | undefined;
let readNative: ((roots: number[]) => Promise<import('../src/core/features/runtime-resources').ProcessSample[]>) | undefined;
try {
  const ready = await waitMessage(target, value => value.ready);
  childPid = ready.childPid;
  const connections = {
    getRuntimeSessions: () => [{pid: target.pid!, sessionId: 'benchmark-owned-workload', workingDir: process.cwd()}],
    getConnectionStats: () => ({total: 1}),
    broadcastToAll: () => {},
  } as unknown as ConnectionManager;
  let sampler: RuntimeResourceSampler;
  let measuredPids: number[] = [];
  if (after) {
    const helper = fileURLToPath(new URL('../native/win-job/target/release/ai-bridge-job.exe', import.meta.url));
    if (!existsSync(helper)) throw new Error('Build the native helper before the --native benchmark.');
    // The source run has no helper beside win-job.ts; production resolves the
    // same built helper beside its bundle. Inject only the helper's location.
    const {readWindowsResourceSamples} = await import('../src/core/windows-resource-samples');
    readNative = roots => readWindowsResourceSamples(roots, helper);
    sampler = new RuntimeResourceSampler(async roots => {
      const samples = await readWindowsResourceSamples(roots, helper);
      measuredPids = samples.map(sample => sample.pid);
      return samples;
    });
  } else {
    sampler = new RuntimeResourceSampler();
  }
  if (cleanupSmoke) {
    cleanupIdentity = (await readNative!([childPid!])).find(sample => sample.pid === childPid)?.identity;
    if (!cleanupIdentity) throw new Error('Cleanup smoke could not establish fixture child identity.');
    if (forceParentExit) target.kill();
  } else if (inspectOnly) {
    const sample = await sampler.sample(connections);
    const {stdout} = await promisify(execFile)('powershell.exe', ['-NoProfile', '-NonInteractive', '-Command',
      `Get-Process -Id ${measuredPids.join(',')} | Select-Object Id,ProcessName | ConvertTo-Json -Compress`],
    {windowsHide: true, timeout: 5000});
    // Only fixture-owned process names, never command lines or a machine-wide list.
    console.log(JSON.stringify({fixtureParentPid: target.pid, fixtureChildPid: childPid, cli: sample.cli,
      measuredProcesses: JSON.parse(stdout), note: 'Inspection only; no timing measurements.'}, null, 2));
  } else {
  const observations: unknown[] = [];
  const durations: number[] = [];
  let driverCpuMicros = 0;
  await sleep(500);
  for (let index = 0; index < sampleCount; index++) {
    const reply = waitMessage(target, value => value.id === index);
    target.send(index);
    const reference = await reply;
    const cpuBefore = process.cpuUsage();
    const start = performance.now();
    const [sample, coalesced] = await Promise.all([sampler.sample(connections), sampler.sample(connections)]);
    const elapsedMs = performance.now() - start;
    const cpu = process.cpuUsage(cpuBefore);
    driverCpuMicros += cpu.user + cpu.system;
    durations.push(elapsedMs);
    observations.push({
      index, elapsedMs, coalescedSameObject: sample === coalesced,
      cli: sample.cli[0], measurementError: sample.measurementError ?? null,
      reference: reference.processes,
      referenceRssBytes: reference.processes.reduce((total: number, item: {rssBytes: number}) => total + item.rssBytes, 0),
    });
    if (index < sampleCount - 1) await sleep(1100);
  }
  const sorted = [...durations].sort((a, b) => a - b);
  const output = {
    label, node: process.version, platform: process.platform, architecture: process.arch,
    sampleCount, requestedCalls: sampleCount * 2, workload: '24 MiB parent + 32 MiB child, child busy 20ms each 100ms',
    p50Ms: sorted[Math.floor(sorted.length * .5)], p95Ms: sorted[Math.ceil(sorted.length * .95) - 1],
    driverCpuMicros, driverCpuScope: 'Node sampling caller only; excludes helper and workload CPU',
    observations,
  };
  const directory = fileURLToPath(new URL('../../ignore/benchmarks/', import.meta.url));
  mkdirSync(directory, {recursive: true});
  const path = join(directory, `runtime-resources-${label}.json`);
  writeFileSync(path, JSON.stringify(output, null, 2));
  console.log(JSON.stringify({...output, observations: undefined, resultPath: path}, null, 2));
  }
} finally {
  if (target.connected && !target.killed) target.send('stop', () => {});
  await Promise.race([targetExited, sleep(2000)]);
  if (target.exitCode === null && target.signalCode === null) {
    // This handle belongs to the fixture we spawned. The child's IPC disconnect
    // handler also closes it when its parent must be terminated on timeout.
    target.kill();
    await targetExited;
  }
  if (cleanupSmoke && cleanupIdentity && readNative) {
    const deadline = performance.now() + 2000;
    let childAlive = true;
    while (childAlive && performance.now() < deadline) {
      childAlive = (await readNative([childPid!])).some(sample => sample.pid === childPid && sample.identity === cleanupIdentity);
      if (childAlive) await sleep(25);
    }
    if (childAlive) throw new Error('Fixture child did not exit after parent cleanup.');
    console.log(JSON.stringify({cleanup: 'passed', mode: forceParentExit ? 'forced-parent-exit' : 'graceful', childExited: true}));
  }
}
