# Windows başlangıç incelemesi — 0.1

9 Eylül 2026. İnceleme ve otomatik testler macOS üzerinde yapıldı. Windows komut yolları kontrollü süreç yanıtlarıyla test edildi; gerçek Windows IDE açılış süresi veya yüzde hızlanma ölçülmedi.

## Bulunan gecikme kaynakları ve düzeltmeler

- Her yeni WebView, `GET_CLI_CONFIG` için `refresh:true` göndererek backend önbelleğini atlıyordu. Normal açılış artık önbelleği kullanır. Aynı proje, CLI yolu, config dizini ve PATH için tamamlanan sonuç 30 saniye saklanır. Açık yenileme güncel CLI verisini alır; hesap/sağlayıcı ayarları değişince katalog yenilenir.
- Birden fazla sekmenin eşzamanlı zorunlu yenilemesi bekleyen isteği silip ayrı CLI süreçleri başlatabiliyordu. Artık bekleyen initialize ve sürüm sorguları paylaşılır. Kontrollü testte 8 eşzamanlı initialize isteği 1 CLI başlatır.
- Initialize çıktısı her parçada baştan JSON olarak ayrıştırılıyordu. Artık JSONL satırı tamamlandığında yalnızca bir kez ayrıştırılır; bölünmüş UTF-8 karakterler korunur ve çıktı belleği sınırlandırılır. Testte 100 hook satırı ve 1 initialize satırı, küçük parçalar halinde gelse de toplam 101 kez ayrıştırılır.
- Windows initialize süreci bittiğinde eşzamanlı `taskkill` backend olay döngüsünü bekletiyordu. Yalnızca metadata sorgusu temizliği asenkron çalışır. IDE/backend kapanışında gereken eşzamanlı süreç ağacı temizliği korunur. Kapanış olayı gelmeyen kabukta 15 saniyelik süre sınırı isteği de sonlandırır.
- Açılıştaki eski süreç kayıtları için tekrarlanan PowerShell sorguları vardı. Windows taraması tek asenkron CIM görüntüsüyle canlı kayıtları sınıflandırır. Testte başka bir canlı backend'e ait 100 kayıt için yalnızca 1 PowerShell sorgusu çalışır; boş kayıt listesinde hiç çalışmaz. Yetim süreç öldürülmeden önce kimlik tekrar kontrol edilir; erişim hatası başarı sayılmaz.
- Windows Node araması gereksiz `cmd /c where node` kabuğu açıyordu. Artık `where.exe node` doğrudan çağrılır; cmd AutoRun çalışmaz.

Odak/ağ dönüşünde katalog yenilemesini engelleyen seçenekler açıkça sabitlendi. Önceki global React Query ayarları da bunları zaten kapatıyordu; bu nedenle önceki sürümde odak kaynaklı bir sorgu fırtınası tespit edildiği iddia edilmez.

## Süre günlükleri

IDE günlüğünde `Backend startup: phase=... elapsedMs=...` satırları dispatch, node-discovery, resource-readiness, process-launch, backend-readiness ve port-ready-total aşamalarını gösterir. `Chat startup` satırları browser-acquire (o an indeksleme sürüyor muydu: `indexing=`), page-load ve first-paint sürelerini gösterir; son ikisi sayfa yüklemesinin başından ölçülür. Kullanıcı dizinindeki `.ai-bridge/logs/server.log` backend günlüğü `phase=orphan-sweep` ve `[loadCliConfig] probe finished` ile tarama ve CLI initialize süresini ayırır. Eklenen süre günlükleri kimlik bilgisi veya süreç komut satırı içermez.

Panel artık IDE indekslemesinin bitmesini beklemez: sohbet IDE indekslerini okumaz, tarayıcının soğuk açılışı (Chromium, ardından sayfa) ise sohbeti açmanın en uzun kısmıdır; bu yüzden indekslemeyle aynı anda başlar. Tarayıcı bu kadar erken kurulduğunda IDE'nin proxy ayarlarını ilk okuyan JCEF olabiliyor; 2024.2 ve sonrasında bu okuma JCEF'in sınıf başlatıcısında bir servis istediği için platform AI Bridge'i suçlayan bir SEVERE hata yazıyordu. Bu yüzden ilk tarayıcıdan önce proxy ayarları bir kez okunur. İlk yüklemede "Loading chat..." yazısı, sayfa ilk karesini çizdiğini bildirene kadar (ya da yükleme bittikten 3 saniye sonra) tarayıcının üstünde kalır; bu yalnızca ekran dışı (OSR) tarayıcıda mümkündür, pencereli tarayıcının üstüne Swing çizemez. Pencereli tarayıcıda ve düz tarayıcı sekmesinde aynı yazıyı, sayfa geldiği andan React ilk kez çizene kadar sayfanın kendisi (`webview/index.html`) gösterir. JetBrains modunda backend açılır açılmaz projenin CLI kataloğunu (`initialize`) ısıtır; sayfanın ilk isteği bu denemeye katılır ya da sonucunu önbellekte bulur. WSL backend'inde ısıtma yapılmaz, çünkü kökü sayfanın sorduğu Windows yolu değildir. WSL içindeki Linux backend POSIX sürecini kullanır; Windows'a özgü taskkill/CIM değişiklikleri native Windows backend içindir.

## Doğrulama

| Kontrol | Sonuç |
| --- | --- |
| Backend tam test paketi | 172 dosya, 1.989 başarılı, mevcut 8 atlanan test |
| WebView tam test paketi | 337 dosya, 3.345 başarılı |
| Kotlin başlangıç testleri | 34 başarılı |
| Backend/WebView TypeScript | Başarılı |
| `git diff --check` | Başarılı |

Üretim ZIP'i başarıyla derlendi. Plugin Verifier, IC 242.26775.15 ve IU 262.8117.19 üzerinde **Compatible** sonucu verdi. Önceden mevcut iki `FileEditorManager.requestOpenFile` experimental API uyarısı devam eder; IC kontrolünde bulunmayan optional JCEF modülü kapsam dışıdır. Statik IDE uyumluluk kontrolü gerçek Windows açılış testi değildir.

ZIP CRC, plugin ID/ad/yayıncı/sürüm, gömülü lisanslar, eski servis adreslerinin bulunmaması ve backend dosyasının derlenen çıktıyla birebir eşleşmesi doğrulandı. Paket kimliği `com.birkankader.ai-bridge`, yayıncı Birkan Kader ve sürüm 0.1'dir. Yeni bundleRevision: `8e2a3d2b04b1ecdfa8e573541a756257876776faa1da05fe219a8ba118eff4a6`.

Kurulum dosyası: `output/AI-Bridge-0.1.zip`. Eşleşen kaynak: `output/AI-Bridge-0.1-Source.zip`. SHA-256 değerleri `output/AI_BRIDGE_0.1_SHA256SUMS.txt` içindedir.

Test günlükleri çalışma klasörünün yanındaki `validation/windows-startup-verification` dizinindedir. Windows CIM/taskkill/where komutları birim testlerinde simüle edilir. Kotlin için resolver, sınırlandırılmış süreç çalıştırma ve lifecycle testleri çalıştırıldı. Gerçek Windows gerektiren mevcut testler macOS üzerinde atlandı.

## Kapsam ve kalan sınırlar

Gerçek Windows makinesinde antivirüs taraması, Git Bash/WSL kurulumu, Claude hook/MCP yükleme süresi ve IDE indekslemesi ölçülmedi. Bu koşulların etkisi ancak Windows süre günlükleriyle ayrılabilir. CLI initialize zaman aşımı yeniden denenebilir bir başarısızlıkla sonuçlanır; başarılı veri uydurulmaz.

Farklı projelerin aynı anda farklı CLI/config dizinlerini kullanmasında mevcut backend genel ayar projeksiyonu atomik değildir. Bu çalışma önbellek anahtarlarını ayırır; tüm çağrıların proje bağlamını ayrı bir süreç başlatma nesnesine taşıyan daha geniş refaktör kapsamına girmez.

Sürüm 0.1 olarak korunur; paket içeriğinden türetilen bundleRevision yeni backend/arayüzün açılmasını sağlar. IDE'ye kurulum veya Marketplace yayını yapılmadı.
