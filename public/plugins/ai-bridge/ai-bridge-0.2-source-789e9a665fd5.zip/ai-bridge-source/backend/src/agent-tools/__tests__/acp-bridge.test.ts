import { EventEmitter } from 'events';
import { mkdtempSync, readFileSync, rmSync, mkdirSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { PassThrough } from 'stream';
import type { ChildProcess } from 'child_process';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { AcpBridge } from '../acp/bridge';
import { parseBridgeArgs } from '../acp/translate';
import { getHarnessSessionsPath } from '../../core/features/harness-sessions';
import { USER_DECLINED_PREFIX } from '../../shared';

type Handler = (params: Record<string, unknown>, agent: FakeAgent) => unknown | Promise<unknown>;

/** An in-process ACP agent: answers requests with the given handlers and records every call. */
class FakeAgent {
  readonly toAgent = new PassThrough();
  readonly fromAgent = new PassThrough();
  readonly stderr = new PassThrough();
  readonly calls: Array<{ method: string; params: Record<string, unknown> }> = [];
  readonly process: ChildProcess;
  private nextId = 1000;
  private readonly waiting = new Map<number, (result: unknown) => void>();
  private buffer = '';

  constructor(private readonly handlers: Record<string, Handler>) {
    const proc = new EventEmitter() as unknown as ChildProcess & EventEmitter;
    Object.assign(proc, { stdin: this.toAgent, stdout: this.fromAgent, stderr: this.stderr, kill: () => true, pid: 4242 });
    this.process = proc;
    this.toAgent.on('data', (chunk: Buffer) => {
      this.buffer += chunk.toString('utf8');
      let i: number;
      while ((i = this.buffer.indexOf('\n')) >= 0) {
        const line = this.buffer.slice(0, i);
        this.buffer = this.buffer.slice(i + 1);
        if (line.trim()) void this.onMessage(JSON.parse(line));
      }
    });
  }

  private async onMessage(message: Record<string, unknown>): Promise<void> {
    if (message.method === undefined) {
      this.waiting.get(message.id as number)?.(message.result ?? message.error);
      return;
    }
    const method = message.method as string;
    const params = (message.params as Record<string, unknown>) ?? {};
    this.calls.push({ method, params });
    const handler = this.handlers[method];
    if (message.id === undefined) {
      if (handler) await handler(params, this);
      return;
    }
    const result = handler ? await handler(params, this) : {};
    this.send({ jsonrpc: '2.0', id: message.id, result });
  }

  send(message: Record<string, unknown>): void {
    this.fromAgent.write(JSON.stringify(message) + '\n');
  }

  update(sessionId: string, update: Record<string, unknown>): void {
    this.send({ jsonrpc: '2.0', method: 'session/update', params: { sessionId, update } });
  }

  request(method: string, params: Record<string, unknown>): Promise<unknown> {
    const id = this.nextId++;
    return new Promise((resolve) => {
      this.waiting.set(id, resolve);
      this.send({ jsonrpc: '2.0', id, method, params });
    });
  }
}

const OPENCODE_CONFIG = [
  {
    id: 'model', category: 'model', type: 'select', currentValue: 'opencode/free-a',
    options: [{ value: 'opencode/free-a', name: 'Free A' }, { value: 'opencode/free-b', name: 'Free B' }],
  },
  {
    id: 'effort', category: 'thought_level', type: 'select', currentValue: 'default',
    options: ['none', 'minimal', 'low', 'medium', 'high', 'xhigh', 'default'].map(value => ({ value, name: value })),
  },
  {
    id: 'mode', category: 'mode', type: 'select', currentValue: 'build',
    options: [{ value: 'build', name: 'Build' }, { value: 'plan', name: 'Plan' }],
  },
];

const BASE_HANDLERS: Record<string, Handler> = {
  initialize: () => ({
    protocolVersion: 1,
    agentInfo: { name: 'Fake', version: '0.0.1' },
    agentCapabilities: {
      loadSession: true,
      promptCapabilities: { image: true },
      sessionCapabilities: { resume: {}, delete: {}, close: {} },
    },
  }),
  'session/new': () => ({ sessionId: 'ses_1', configOptions: structuredClone(OPENCODE_CONFIG) }),
  'session/resume': () => ({ configOptions: structuredClone(OPENCODE_CONFIG) }),
  'session/set_config_option': (params) => {
    const options = structuredClone(OPENCODE_CONFIG);
    const option = options.find(o => o.id === params.configId);
    if (option) option.currentValue = params.value as string;
    return { configOptions: options };
  },
  'session/delete': () => ({}),
};

let home: string;
const savedEnv = { HOME: process.env.HOME, USERPROFILE: process.env.USERPROFILE };

beforeEach(() => {
  home = mkdtempSync(join(tmpdir(), 'acp-bridge-'));
  process.env.HOME = home;
  process.env.USERPROFILE = home;
});

afterEach(() => {
  process.env.HOME = savedEnv.HOME;
  process.env.USERPROFILE = savedEnv.USERPROFILE;
  rmSync(home, { recursive: true, force: true });
});

function startBridge(handlers: Record<string, Handler>, argv: string[], cwd = join(home, 'project')) {
  const agent = new FakeAgent({ ...BASE_HANDLERS, ...handlers });
  const input = new PassThrough();
  const output = new PassThrough();
  const events: Array<Record<string, unknown>> = [];
  let buffer = '';
  output.on('data', (chunk: Buffer) => {
    buffer += chunk.toString('utf8');
    let i: number;
    while ((i = buffer.indexOf('\n')) >= 0) {
      const line = buffer.slice(0, i);
      buffer = buffer.slice(i + 1);
      if (line.trim()) events.push(JSON.parse(line));
    }
  });
  const exits: number[] = [];
  new AcpBridge({
    harness: 'opencode',
    agentCommand: ['fake-agent', 'acp'],
    cwd,
    args: parseBridgeArgs(argv),
    input,
    output,
    spawnAgent: () => agent.process,
    exit: (code) => exits.push(code),
  });
  const send = (message: Record<string, unknown>) => input.write(JSON.stringify(message) + '\n');
  const waitFor = async (predicate: (e: Record<string, unknown>) => boolean, timeout = 3000) => {
    const start = Date.now();
    while (Date.now() - start < timeout) {
      const found = events.find(predicate);
      if (found) return found;
      await new Promise(r => setTimeout(r, 5));
    }
    throw new Error(`timed out; events: ${events.map(e => `${e.type}/${(e.event as Record<string, unknown>)?.type ?? e.subtype ?? ''}`).join(', ')}`);
  };
  return { agent, events, send, waitFor, exits, cwd };
}

const userMessage = (text: string, uuid?: string) => ({
  type: 'user', ...(uuid ? { uuid } : {}), message: { role: 'user', content: text },
});

describe('AcpBridge', () => {
  it('turns a streamed answer into Claude stream-json and records it', async () => {
    const { send, waitFor, events, cwd } = startBridge({
      'session/prompt': async (params, agent) => {
        agent.update('ses_1', { sessionUpdate: 'agent_thought_chunk', content: { type: 'text', text: 'Thinking ' } });
        agent.update('ses_1', { sessionUpdate: 'agent_thought_chunk', content: { type: 'text', text: 'hard.' } });
        agent.update('ses_1', { sessionUpdate: 'agent_message_chunk', content: { type: 'text', text: 'Hello ' } });
        agent.update('ses_1', { sessionUpdate: 'agent_message_chunk', content: { type: 'text', text: 'world' } });
        agent.update('ses_1', { sessionUpdate: 'usage_update', used: 1200, size: 200000, cost: { amount: 0, currency: 'USD' } });
        expect(params.prompt).toEqual([{ type: 'text', text: 'hi' }]);
        return { stopReason: 'end_turn', usage: { inputTokens: 10, outputTokens: 5 } };
      },
    }, ['--session-id', 'sess-a']);

    send(userMessage('hi'));
    const result = await waitFor(e => e.type === 'result');
    expect(result).toMatchObject({ subtype: 'success', is_error: false, result: 'Hello world', session_id: 'sess-a' });
    expect((result.modelUsage as Record<string, { contextWindow: number }>)['opencode/free-a'].contextWindow).toBe(200000);

    const init = events.find(e => e.type === 'system' && e.subtype === 'init');
    expect(init).toMatchObject({ model: 'opencode/free-a', permissionMode: 'default', harness: 'opencode' });

    const assistants = events.filter(e => e.type === 'assistant');
    expect(assistants.map(a => (a.message as { content: Array<{ type: string }> }).content[0].type)).toEqual(['thinking', 'text']);
    // Both blocks belong to one message, as in Claude.
    const ids = new Set(assistants.map(a => (a.message as { id: string }).id));
    expect(ids.size).toBe(1);
    const streamTypes = events.filter(e => e.type === 'stream_event').map(e => (e.event as { type: string }).type);
    expect(streamTypes[0]).toBe('message_start');
    expect(streamTypes).toContain('content_block_delta');
    expect(streamTypes.at(-1)).toBe('message_stop');

    const lines = readFileSync(join(getHarnessSessionsPath(cwd), 'sess-a.jsonl'), 'utf8').trim().split('\n').map(l => JSON.parse(l));
    expect(lines[0]).toMatchObject({ type: 'harness-session', harness: 'opencode', agentSessionId: 'ses_1', sessionId: 'sess-a' });
    expect(lines.slice(1).map(l => l.type)).toEqual(['user', 'assistant', 'assistant']);
    // Entries chain like Claude's transcript, and the live events carry the same uuids.
    expect(lines[2].parentUuid).toBe(lines[1].uuid);
    expect(lines[3].uuid).toBe(assistants[1].uuid);
  });

  it('asks permission through can_use_tool and answers the agent with the chosen option', async () => {
    let permission: unknown;
    const { send, waitFor, events, cwd } = startBridge({
      'session/prompt': async (_params, agent) => {
        agent.update('ses_1', { sessionUpdate: 'tool_call', toolCallId: 'call-1', title: 'write', kind: 'edit', status: 'pending', rawInput: {} });
        agent.update('ses_1', {
          sessionUpdate: 'tool_call_update', toolCallId: 'call-1', status: 'pending',
          rawInput: { path: 'out.txt', content: 'HELLO' },
        });
        permission = await agent.request('session/request_permission', {
          sessionId: 'ses_1',
          toolCall: { toolCallId: 'call-1', kind: 'edit', title: 'write' },
          options: [
            { optionId: 'once', name: 'Allow', kind: 'allow_once' },
            { optionId: 'always', name: 'Always', kind: 'allow_always' },
            { optionId: 'no', name: 'Reject', kind: 'reject_once' },
          ],
        });
        agent.update('ses_1', {
          sessionUpdate: 'tool_call_update', toolCallId: 'call-1', status: 'completed',
          content: [{ type: 'content', content: { type: 'text', text: 'Created file successfully: out.txt' } }],
        });
        agent.update('ses_1', { sessionUpdate: 'agent_message_chunk', content: { type: 'text', text: 'done' } });
        return { stopReason: 'end_turn' };
      },
    }, ['--session-id', 'sess-b']);

    send(userMessage('write it'));
    const request = await waitFor(e => e.type === 'control_request');
    const inner = request.request as Record<string, unknown>;
    expect(inner).toMatchObject({
      subtype: 'can_use_tool', tool_name: 'Write', tool_use_id: 'call-1',
      input: { file_path: join(cwd, 'out.txt'), content: 'HELLO' },
    });
    send({
      type: 'control_response',
      response: { subtype: 'success', request_id: request.request_id, response: { behavior: 'allow', updatedInput: inner.input } },
    });
    await waitFor(e => e.type === 'result');
    expect(permission).toEqual({ outcome: { outcome: 'selected', optionId: 'once' } });

    const toolResult = events.find(e => e.type === 'user' && Array.isArray((e.message as { content: unknown }).content));
    expect((toolResult!.message as { content: Array<Record<string, unknown>> }).content[0]).toMatchObject({
      type: 'tool_result', tool_use_id: 'call-1', content: 'Created file successfully: out.txt', is_error: false,
    });
    // The text after the tool runs is the model's next message.
    const ids = events.filter(e => e.type === 'assistant').map(a => (a.message as { id: string }).id);
    expect(new Set(ids).size).toBe(2);
  });

  it('declines a partly accepted change instead of writing the whole proposal', async () => {
    let permission: unknown;
    const { send, waitFor, events } = startBridge({
      'session/prompt': async (_params, agent) => {
        agent.update('ses_1', {
          sessionUpdate: 'tool_call', toolCallId: 'call-2', title: 'edit', kind: 'edit', status: 'pending',
          rawInput: { filePath: 'a.ts', oldString: 'a\nb', newString: 'A\nB' },
        });
        permission = await agent.request('session/request_permission', {
          sessionId: 'ses_1', toolCall: { toolCallId: 'call-2' },
          options: [{ optionId: 'once', kind: 'allow_once' }, { optionId: 'no', kind: 'reject_once' }],
        });
        agent.update('ses_1', { sessionUpdate: 'tool_call_update', toolCallId: 'call-2', status: 'failed' });
        return { stopReason: 'end_turn' };
      },
    }, ['--session-id', 'sess-c']);

    send(userMessage('edit'));
    const request = await waitFor(e => e.type === 'control_request');
    expect((request.request as Record<string, unknown>).tool_name).toBe('Edit');
    send({
      type: 'control_response',
      response: {
        subtype: 'success', request_id: request.request_id,
        response: { behavior: 'allow', updatedInput: { file_path: 'x', old_string: 'a', new_string: 'A' } },
      },
    });
    await waitFor(e => e.type === 'result');
    expect(permission).toEqual({ outcome: { outcome: 'selected', optionId: 'no' } });
    const toolResult = events.find(e => e.type === 'user' && !e.isReplay);
    const block = (toolResult!.message as { content: Array<Record<string, unknown>> }).content[0];
    expect(block.is_error).toBe(true);
    expect(String(block.content).startsWith(USER_DECLINED_PREFIX)).toBe(true);
  });

  it('cancels the turn on interrupt and settles a pending permission', async () => {
    const { send, waitFor, agent, events } = startBridge({
      'session/prompt': async (_params, a) => {
        a.update('ses_1', { sessionUpdate: 'tool_call', toolCallId: 'call-3', kind: 'execute', title: 'bash', status: 'pending', rawInput: { command: 'ls' } });
        const answer = await a.request('session/request_permission', {
          sessionId: 'ses_1', toolCall: { toolCallId: 'call-3' }, options: [{ optionId: 'once', kind: 'allow_once' }],
        });
        expect(answer).toEqual({ outcome: { outcome: 'cancelled' } });
        return { stopReason: 'cancelled' };
      },
    }, ['--session-id', 'sess-d']);

    send(userMessage('run'));
    const request = await waitFor(e => e.type === 'control_request');
    expect((request.request as Record<string, unknown>)).toMatchObject({ tool_name: 'Bash', input: { command: 'ls' } });
    send({ type: 'control_request', request_id: 'int-1', request: { subtype: 'interrupt' } });
    await waitFor(e => e.type === 'result');
    expect(events.some(e => e.type === 'control_cancel_request' && e.request_id === request.request_id)).toBe(true);
    expect(agent.calls.some(c => c.method === 'session/cancel')).toBe(true);
    const interrupted = events.find(e => e.type === 'user' && JSON.stringify(e.message).includes('[Request interrupted by user]'));
    expect(interrupted).toBeTruthy();
  });

  it('folds a steering message into the running turn with one result', async () => {
    let prompts = 0;
    let release: () => void = () => {};
    const { send, waitFor, events, agent } = startBridge({
      'session/prompt': async (_params, a) => {
        prompts++;
        if (prompts === 1) {
          a.update('ses_1', { sessionUpdate: 'agent_message_chunk', content: { type: 'text', text: 'first' } });
          await new Promise<void>(r => { release = r; });
        } else {
          a.update('ses_1', { sessionUpdate: 'agent_message_chunk', content: { type: 'text', text: 'second' } });
        }
        return { stopReason: 'end_turn' };
      },
    }, ['--session-id', 'sess-e']);

    send(userMessage('one'));
    await waitFor(e => e.type === 'assistant' || (e.type === 'stream_event' && (e.event as { type: string }).type === 'content_block_delta'));
    send(userMessage('two', 'steer-uuid'));
    await new Promise(r => setTimeout(r, 30));
    release();
    await waitFor(e => e.type === 'result');
    expect(events.filter(e => e.type === 'result')).toHaveLength(1);
    expect(events.find(e => e.type === 'user' && e.isReplay === true)).toMatchObject({ uuid: 'steer-uuid' });
    expect(agent.calls.filter(c => c.method === 'session/prompt')).toHaveLength(2);
    expect(events.find(e => e.type === 'result')!.result).toBe('second');
  });

  it('answers initialize with the model catalogue and drops the probe session', async () => {
    const { send, waitFor, agent } = startBridge({}, ['--no-session-persistence']);
    send({ type: 'control_request', request_id: 'config_init', request: { subtype: 'initialize' } });
    const response = await waitFor(e => e.type === 'control_response');
    const catalog = (response.response as { response: Record<string, unknown> }).response;
    const models = catalog.models as Array<Record<string, unknown>>;
    expect(models.map(m => m.value)).toEqual(['default', 'opencode/free-a', 'opencode/free-b']);
    expect(models[0].displayName).toBe('Default (Free A)');
    expect(models[1]).toMatchObject({ supportsEffort: true, supportedEffortLevels: ['low', 'medium', 'high', 'xhigh'] });
    expect(agent.calls.some(c => c.method === 'session/delete')).toBe(true);
  });

  it('maps effort to the nearest level the harness offers and applies plan mode', async () => {
    const dshConfig = [
      { id: 'model', category: 'model', currentValue: 'm1', options: [{ group: 'g', name: 'G', options: [{ value: 'm1', name: 'M1' }] }] },
      {
        id: 'reasoning_effort', category: 'thought_level', currentValue: 'high',
        options: ['off', 'low', 'high', 'max'].map(value => ({ value, name: value })),
      },
    ];
    const { send, waitFor, agent } = startBridge({
      'session/new': () => ({ sessionId: 'ses_1', configOptions: structuredClone(dshConfig) }),
      'session/set_config_option': () => ({}),
      'session/prompt': () => ({ stopReason: 'end_turn' }),
    }, ['--session-id', 'sess-f', '--effort', 'medium', '--permission-mode', 'plan']);
    send(userMessage('go'));
    const init = await waitFor(e => e.type === 'system' && e.subtype === 'init');
    // This harness has no plan mode, so the bridge reports what is really in effect.
    expect(init.permissionMode).toBe('default');
    await waitFor(e => e.type === 'result');
    const sets = agent.calls.filter(c => c.method === 'session/set_config_option').map(c => c.params);
    // Already "high": nearest to "medium" with a tie broken upward, so nothing to change.
    expect(sets).toEqual([]);
  });

  it('resumes the harness session recorded in the transcript', async () => {
    const cwd = join(home, 'project');
    const dir = getHarnessSessionsPath(cwd);
    mkdirSync(dir, { recursive: true });
    writeFileSync(join(dir, 'sess-g.jsonl'), JSON.stringify({
      type: 'harness-session', harness: 'opencode', agentSessionId: 'ses_old', sessionId: 'sess-g', cwd, timestamp: 't',
    }) + '\n' + JSON.stringify({ type: 'user', uuid: 'u-1', message: { role: 'user', content: 'before' } }) + '\n');
    const { send, waitFor, agent } = startBridge({
      'session/prompt': (params) => {
        expect(params.sessionId).toBe('ses_old');
        return { stopReason: 'end_turn' };
      },
    }, ['--resume', 'sess-g', '--model', 'opencode/free-b'], cwd);
    send(userMessage('again'));
    await waitFor(e => e.type === 'result');
    expect(agent.calls.find(c => c.method === 'session/resume')!.params.sessionId).toBe('ses_old');
    expect(agent.calls.some(c => c.method === 'session/new')).toBe(false);
    expect(agent.calls.find(c => c.method === 'session/set_config_option')!.params).toMatchObject({ configId: 'model', value: 'opencode/free-b' });
    const lines = readFileSync(join(dir, 'sess-g.jsonl'), 'utf8').trim().split('\n').map(l => JSON.parse(l));
    expect(lines.at(-1)).toMatchObject({ type: 'user', parentUuid: 'u-1' });
  });

  /** An agent that writes [stderr], closes its output and exits with [code] instead of answering initialize. */
  const dyingAgent = (code: number, stderr = ''): Record<string, Handler> => ({
    initialize: (_params, agent) => {
      if (stderr) agent.stderr.write(stderr);
      agent.fromAgent.end();
      setTimeout(() => (agent.process as unknown as EventEmitter).emit('exit', code, null), 20);
      return new Promise(() => {});
    },
  });
  const assistantText = (events: Array<Record<string, unknown>>) => events
    .filter(e => e.type === 'assistant')
    .map(e => (e.message as { content: Array<{ text?: string }> }).content.map(c => c.text ?? '').join(''))
    .join('\n');

  it('reports the exit code and stderr of an agent that dies while starting', async () => {
    const { send, waitFor, events } = startBridge(dyingAgent(1, 'Error: Cannot find module tsx/esm\n'), ['--session-id', 'sess-d']);
    send(userMessage('selam'));
    await waitFor(e => e.type === 'result');
    const text = assistantText(events);
    expect(text).toContain('could not open a session');
    expect(text).toContain('stopped with exit code 1');
    expect(text).toContain('Cannot find module tsx/esm');
    expect(text).not.toContain('closed its output');
  });

  it('points to installing the harness when the shell cannot find it', async () => {
    // cmd.exe's own "is not recognized" text is localized; the exit code is what counts.
    const { send, waitFor, events } = startBridge(dyingAgent(9009, "'fake-agent' iç ya da dış komut olarak tanınmıyor.\n"), ['--session-id', 'sess-n']);
    send(userMessage('selam'));
    await waitFor(e => e.type === 'result');
    const text = assistantText(events);
    expect(text).toContain('could not be started (`fake-agent acp`): command not found');
    expect(text).toContain('Settings → Connection');
  });
});
