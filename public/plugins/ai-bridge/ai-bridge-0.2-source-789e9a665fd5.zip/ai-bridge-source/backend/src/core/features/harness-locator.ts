import { closeSync, existsSync, openSync, readFileSync, readSync, realpathSync, statSync } from 'fs';
import { mkdir, writeFile } from 'fs/promises';
import { execFile } from 'child_process';
import { homedir } from 'os';
import { dirname, extname, join, resolve } from 'path';
import { pathToFileURL } from 'url';
import { Command } from '../command';
import { readMergedSettings } from './settings';
import {
  HARNESS_ACP_COMMANDS,
  HARNESS_LABELS,
  HARNESS_NPM_PACKAGES,
  isAcpHarness,
  type AcpHarnessId,
  type HarnessSource,
} from '../../shared';

/**
 * Finding — and when asked, installing — the program behind an ACP harness.
 *
 * A harness is not always a command on PATH. The IDE may hand the backend a
 * PATH without the npm global directory, and a user who works on the harness
 * itself runs it from a source checkout (`pnpm dsh`) with nothing installed at
 * all. So the backend looks in the places a user can have it, in this order:
 *
 *   1. the location entered in Settings (`harnessPaths`): an executable, an npm
 *      install folder, or a deepseek-harness source checkout
 *   2. `AI_BRIDGE_HARNESS_COMMAND`, the environment override
 *   3. the copy AI Bridge installed under `~/.ai-bridge/harnesses/<id>`
 *   4. the command on PATH, as a terminal would run it
 *
 * and hands the bridge the command it found (AI_BRIDGE_HARNESS_COMMAND), so the
 * bridge never depends on PATH lookup itself. Nothing here edits the user's
 * PATH or shell profile; the "alias" lives in AI Bridge's own settings.
 */

export interface LocatedHarness {
  /** argv that serves the harness over ACP stdio. */
  command: string[];
  source: HarnessSource;
  /** The executable, script or source folder behind the command. */
  location: string;
}

export interface HarnessLookup {
  located: LocatedHarness | null;
  /** Why the location entered in Settings could not be used (the others were tried). */
  settingError?: string;
}

/**
 * dsh needs Node `^22.19.0 || >=24`. Node scripts run on the node that runs
 * this backend when it is that new — an absolute path, so it does not depend on
 * the PATH the IDE was started with — and otherwise on `node` from PATH.
 */
const MIN_SCRIPT_NODE: readonly [number, number] = [22, 19];

export function harnessNode(version: string = process.versions.node, execPath: string = process.execPath): string {
  const [major, minor] = version.split('.').map(Number);
  const [needMajor, needMinor] = MIN_SCRIPT_NODE;
  return major > needMajor || (major === needMajor && minor >= needMinor) ? execPath : 'node';
}

export function managedHarnessDir(harness: AcpHarnessId, home: string = homedir()): string {
  return join(home, '.ai-bridge', 'harnesses', harness);
}

function executableName(harness: AcpHarnessId): string {
  return HARNESS_ACP_COMMANDS[harness][0];
}

function acpArgs(harness: AcpHarnessId): string[] {
  return HARNESS_ACP_COMMANDS[harness].slice(1);
}

/** A JavaScript file, or an extension-less npm bin that starts with a node shebang. */
function isNodeScript(file: string): boolean {
  const ext = extname(file).toLowerCase();
  if (ext === '.js' || ext === '.mjs' || ext === '.cjs') return true;
  if (ext !== '') return false;
  try {
    const fd = openSync(file, 'r');
    try {
      const head = Buffer.alloc(128);
      const read = readSync(fd, head, 0, head.length, 0);
      const firstLine = head.subarray(0, read).toString('utf8').split('\n')[0];
      return firstLine.startsWith('#!') && /\bnode\b/.test(firstLine);
    } finally {
      closeSync(fd);
    }
  } catch {
    return false;
  }
}

function runFile(file: string, args: readonly string[]): string[] {
  return isNodeScript(file) ? [harnessNode(), file, ...args] : [file, ...args];
}

/** The `bin` entry an installed package declares for [executable], when it exists on disk. */
function packageEntry(packageDir: string, executable: string): string | null {
  try {
    const pkg = JSON.parse(readFileSync(join(packageDir, 'package.json'), 'utf8')) as { bin?: unknown };
    const bin = typeof pkg.bin === 'string' ? pkg.bin : (pkg.bin as Record<string, unknown> | undefined)?.[executable];
    if (typeof bin !== 'string') return null;
    const entry = join(packageDir, bin);
    return existsSync(entry) ? entry : null;
  } catch {
    return null;
  }
}

/** The harness package installed under an npm prefix (`<prefix>/node_modules/<package>`). */
function packageUnder(prefix: string, harness: AcpHarnessId): string | null {
  const dir = join(prefix, 'node_modules', ...HARNESS_NPM_PACKAGES[harness].split('/'));
  return packageEntry(dir, executableName(harness));
}

/** The file a `pkg.exports` condition points at (`"./esm": "./dist/esm/index.mjs"` or nested conditions). */
function exportTarget(value: unknown): string | null {
  if (typeof value === 'string') return value;
  if (value && typeof value === 'object') {
    const conditions = value as Record<string, unknown>;
    for (const key of ['import', 'node', 'default']) {
      const target = exportTarget(conditions[key]);
      if (target) return target;
    }
  }
  return null;
}

function tsxLoader(root: string): string | null {
  const dir = join(root, 'node_modules', 'tsx');
  try {
    const pkg = JSON.parse(readFileSync(join(dir, 'package.json'), 'utf8')) as { exports?: Record<string, unknown> };
    const file = join(dir, exportTarget(pkg.exports?.['./esm']) ?? 'dist/esm/index.mjs');
    return existsSync(file) ? file : null;
  } catch {
    return null;
  }
}

/**
 * A deepseek-harness checkout, run the way its root `pnpm dsh` script does
 * (`node --import tsx/esm apps/cli/src/bin.ts`). The loader is passed as a file
 * URL so it resolves from the project directory the harness runs in, and the
 * project stays the invoking directory, as with an installed `dsh`.
 */
function sourceCheckoutCommand(root: string, harness: AcpHarnessId): string[] | null {
  if (harness !== 'deepseek') return null;
  const entry = join(root, 'apps', 'cli', 'src', 'bin.ts');
  const loader = tsxLoader(root);
  if (!existsSync(entry) || !loader) return null;
  return [harnessNode(), '--import', pathToFileURL(loader).href, entry, ...acpArgs(harness)];
}

/** The executable itself inside a folder (`<dir>/dsh`, `dsh.cmd`, `dsh.exe`). */
function executableIn(dir: string, harness: AcpHarnessId): string | null {
  const name = executableName(harness);
  const suffixes = process.platform === 'win32' ? ['.exe', '.cmd', ''] : [''];
  for (const suffix of suffixes) {
    const file = join(dir, name + suffix);
    if (existsSync(file) && statSync(file).isFile()) return file;
  }
  return null;
}

function expandHome(path: string): string {
  return path === '~' || path.startsWith('~/') || path.startsWith('~\\') ? join(homedir(), path.slice(1)) : path;
}

function fromSetting(harness: AcpHarnessId, configured: string): LocatedHarness | { error: string } {
  const path = resolve(expandHome(configured.trim()));
  if (!existsSync(path)) return { error: `${path} does not exist.` };
  if (!statSync(path).isDirectory()) return { command: runFile(path, acpArgs(harness)), source: 'setting', location: path };

  const source = sourceCheckoutCommand(path, harness);
  if (source) return { command: source, source: 'setting', location: path };
  const entry = packageEntry(path, executableName(harness)) ?? packageUnder(path, harness);
  if (entry) return { command: runFile(entry, acpArgs(harness)), source: 'setting', location: entry };
  const executable = executableIn(path, harness);
  if (executable) return { command: runFile(executable, acpArgs(harness)), source: 'setting', location: executable };
  return { error: `No ${HARNESS_LABELS[harness]} found in ${path}.` };
}

function fromEnv(env: NodeJS.ProcessEnv): LocatedHarness | null {
  const raw = env.AI_BRIDGE_HARNESS_COMMAND;
  if (!raw) return null;
  try {
    const parsed = JSON.parse(raw) as unknown;
    if (Array.isArray(parsed) && parsed.length > 0 && parsed.every(p => typeof p === 'string')) {
      return { command: parsed as string[], source: 'env', location: (parsed as string[]).join(' ') };
    }
  } catch {
    // The bridge reports a malformed override itself.
  }
  return null;
}

async function fromPath(harness: AcpHarnessId): Promise<LocatedHarness | null> {
  const found = await new Command(executableName(harness)).which();
  if (!found) return null;
  // On Windows npm puts a `.cmd` shim beside the package it launches; on POSIX
  // the bin is a symlink to it. Either way run the package's own entry, so a
  // node script does not depend on `node` being on the IDE's PATH.
  const beside = process.platform === 'win32' ? packageUnder(dirname(found), harness) : null;
  let entry = beside ?? found;
  if (!beside) {
    try { entry = realpathSync(found); } catch { /* run what `which` found */ }
  }
  return { command: runFile(entry, acpArgs(harness)), source: 'path', location: found };
}

export async function locateHarness(
  harness: AcpHarnessId,
  configured: string | null | undefined,
  options: { home?: string; env?: NodeJS.ProcessEnv } = {},
): Promise<HarnessLookup> {
  let settingError: string | undefined;
  if (typeof configured === 'string' && configured.trim()) {
    const fromSettings = fromSetting(harness, configured);
    if ('command' in fromSettings) return { located: fromSettings };
    settingError = fromSettings.error;
  }
  const managedEntry = packageUnder(managedHarnessDir(harness, options.home), harness);
  const located =
    fromEnv(options.env ?? process.env) ??
    (managedEntry ? { command: runFile(managedEntry, acpArgs(harness)), source: 'managed' as const, location: managedEntry } : null) ??
    await fromPath(harness);
  return { located, ...(settingError ? { settingError } : {}) };
}

/** The `harnessPaths` entry for [harness] in the settings that apply to [workingDir]. */
export async function configuredHarnessPath(harness: AcpHarnessId, workingDir: string): Promise<string | null> {
  try {
    const { settings } = await readMergedSettings(workingDir);
    const paths = settings.harnessPaths;
    const value = paths && typeof paths === 'object' ? (paths as Record<string, unknown>)[harness] : null;
    return typeof value === 'string' ? value : null;
  } catch {
    return null;
  }
}

/**
 * The env that points the ACP bridge at the harness found for [workingDir].
 * Empty when it was not found (the bridge then reports it missing with the
 * install hint) or when the user's own AI_BRIDGE_HARNESS_COMMAND already does.
 */
export async function harnessCommandEnv(harness: string, workingDir: string): Promise<Record<string, string>> {
  if (!isAcpHarness(harness)) return {};
  const { located } = await locateHarness(harness, await configuredHarnessPath(harness, workingDir));
  if (!located || located.source === 'env') return {};
  return { AI_BRIDGE_HARNESS_COMMAND: JSON.stringify(located.command) };
}

function execFileText(file: string, args: string[], options: { cwd?: string; timeout: number; maxBuffer?: number }): Promise<{ stdout: string; stderr: string }> {
  return new Promise((resolvePromise, reject) => {
    execFile(file, args, { ...options, windowsHide: true, encoding: 'utf8' }, (error, stdout, stderr) => {
      if (error) reject(Object.assign(error, { stdout, stderr }));
      else resolvePromise({ stdout, stderr });
    });
  });
}

/** Runs argv: executables directly, `.cmd` shims and bare names through the shared Command (cmd.exe on Windows). */
function runArgv(argv: string[], options: { cwd?: string; timeout: number; maxBuffer?: number }): Promise<{ stdout: string; stderr: string }> {
  const [file, ...args] = argv;
  const viaShell = process.platform === 'win32' && !/\.exe$/i.test(file);
  if (viaShell) return new Command(file, args, options).exec();
  return execFileText(file, args, options);
}

/** First line of `<harness> --version`, run with the command the chat would use. */
export async function harnessVersion(located: LocatedHarness, harness: AcpHarnessId): Promise<{ version?: string; error?: string }> {
  const tail = acpArgs(harness);
  const command = located.command;
  const endsWithAcp = tail.every((arg, i) => command[command.length - tail.length + i] === arg);
  if (!endsWithAcp) return {};
  try {
    const { stdout, stderr } = await runArgv([...command.slice(0, command.length - tail.length), '--version'], { timeout: 30_000 });
    const line = (stdout.trim() || stderr.trim()).split(/\r?\n/)[0]?.trim();
    return line ? { version: line } : {};
  } catch (error) {
    return { error: lastLines(error) || 'Could not read its version.' };
  }
}

function lastLines(error: unknown, count = 4): string {
  const e = error as { stderr?: unknown; stdout?: unknown; message?: unknown };
  const text = [e.stderr, e.stdout].map(v => (typeof v === 'string' ? v : Buffer.isBuffer(v) ? v.toString('utf8') : '')).join('\n').trim();
  const lines = text.split(/\r?\n/).map(l => l.trim()).filter(Boolean);
  if (lines.length > 0) return lines.slice(-count).join('\n');
  return typeof e.message === 'string' ? e.message : String(error);
}

/**
 * npm, preferring the copy that ships with the node running this backend (its
 * `npm-cli.js`, run directly) over whatever `npm` the IDE's PATH resolves.
 */
function npmArgv(args: string[]): string[] {
  const nodeDir = dirname(process.execPath);
  const candidates = [
    join(nodeDir, 'node_modules', 'npm', 'bin', 'npm-cli.js'),
    join(nodeDir, '..', 'lib', 'node_modules', 'npm', 'bin', 'npm-cli.js'),
  ];
  const cli = candidates.find(file => existsSync(file));
  return cli ? [process.execPath, cli, ...args] : ['npm', ...args];
}

const INSTALL_TIMEOUT_MS = 15 * 60_000;
const installs = new Map<AcpHarnessId, Promise<void>>();

/**
 * `npm install <package>@latest` into AI Bridge's own folder for the harness.
 * The same package `npm install -g` would put on PATH, without touching the
 * user's global installs. A second click while one runs waits for the same run.
 */
export function installHarness(harness: AcpHarnessId, home: string = homedir()): Promise<void> {
  const running = installs.get(harness);
  if (running) return running;
  const run = (async () => {
    const dir = managedHarnessDir(harness, home);
    await mkdir(dir, { recursive: true });
    const manifest = join(dir, 'package.json');
    if (!existsSync(manifest)) {
      await writeFile(manifest, `${JSON.stringify({ name: `ai-bridge-harness-${harness}`, private: true }, null, 2)}\n`, 'utf8');
    }
    const spec = `${HARNESS_NPM_PACKAGES[harness]}@latest`;
    try {
      await runArgv(npmArgv(['install', spec, '--prefix', dir, '--no-fund', '--no-audit', '--loglevel=error']), {
        cwd: dir,
        timeout: INSTALL_TIMEOUT_MS,
        maxBuffer: 16 * 1024 * 1024,
      });
    } catch (error) {
      throw new Error(`npm install ${spec} failed: ${lastLines(error)}`);
    }
    if (!packageUnder(dir, harness)) throw new Error(`npm finished, but ${spec} is not in ${dir}.`);
  })();
  installs.set(harness, run);
  run.then(() => installs.delete(harness), () => installs.delete(harness));
  return run;
}

export function isInstallingHarness(harness: AcpHarnessId): boolean {
  return installs.has(harness);
}
