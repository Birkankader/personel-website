import { isAbsolute, resolve } from 'path';
import { classifyApiFailure, type ApiFailureKind } from '../../shared';
import type { RpcError } from './json-rpc';

/**
 * Pure translation between the Agent Client Protocol and the Claude CLI's
 * stream-json vocabulary that the rest of the plugin speaks. No I/O here, so
 * every rule is unit-testable on its own.
 */

// ─── Command line ────────────────────────────────────────────────────────────

/** The Claude CLI flags the backend passes that matter to a harness. */
export interface BridgeArgs {
  sessionId?: string;
  resume: boolean;
  noPersistence: boolean;
  permissionMode?: string;
  model?: string;
  effort?: string;
}

/**
 * Read the same flags the backend hands `claude`, so the bridge can stand in
 * for the CLI without the spawn path learning a second vocabulary. Flags with
 * no meaning for a harness (`--settings`, `--verbose`, formats) are skipped.
 */
export function parseBridgeArgs(argv: readonly string[], env: NodeJS.ProcessEnv = {}): BridgeArgs {
  const args: BridgeArgs = { resume: false, noPersistence: false };
  for (let i = 0; i < argv.length; i++) {
    const flag = argv[i];
    const value = argv[i + 1];
    switch (flag) {
      case '--session-id': args.sessionId = value; i++; break;
      case '--resume': args.sessionId = value; args.resume = true; i++; break;
      case '--permission-mode': args.permissionMode = value; i++; break;
      case '--model': args.model = value; i++; break;
      case '--effort': args.effort = value; i++; break;
      case '--no-session-persistence': args.noPersistence = true; break;
      default: break;
    }
  }
  // Model ids such as DeepSeek Harness's `["provider","model"]` cannot survive a
  // Windows command line, so the backend hands them over in the environment.
  if (env.AI_BRIDGE_HARNESS_MODEL) args.model = env.AI_BRIDGE_HARNESS_MODEL;
  return args;
}

// ─── Harness environment ─────────────────────────────────────────────────────

/** OpenCode tools that only look, matching what Claude Code runs without asking. */
const OPENCODE_READ_ONLY = ['read', 'glob', 'grep', 'list', 'todoread', 'todowrite'];

/**
 * Env that makes a harness ask the client before it acts, so the GUI's
 * permission mode decides (the bridge auto-allows whatever that mode allows).
 *
 * OpenCode runs every tool without asking by default. Its documented inline
 * config (`OPENCODE_CONFIG_CONTENT`) turns that into "ask" for everything but
 * read-only tools — MCP tools such as computer use included. Rules the user
 * already put in that variable are kept; a blanket rule there is left alone.
 */
export function harnessAgentEnv(harness: string, env: NodeJS.ProcessEnv): Record<string, string> {
  if (harness !== 'opencode') return {};
  let config: Record<string, unknown> = {};
  if (env.OPENCODE_CONFIG_CONTENT) {
    try {
      const parsed = JSON.parse(env.OPENCODE_CONFIG_CONTENT) as unknown;
      if (!isPlainObject(parsed)) return {};
      config = parsed;
    } catch {
      return {};
    }
  }
  if (config.permission !== undefined && !isPlainObject(config.permission)) return {};
  const own = isPlainObject(config.permission) ? config.permission : {};
  const permission: Record<string, unknown> = { '*': 'ask' };
  for (const tool of OPENCODE_READ_ONLY) permission[tool] = 'allow';
  return { OPENCODE_CONFIG_CONTENT: JSON.stringify({ ...config, permission: { ...permission, ...own } }) };
}

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

// ─── Session config options (ACP `configOptions`) ────────────────────────────

export interface ConfigOptionValue {
  value: string;
  name?: string;
  description?: string;
}

export interface ConfigOption {
  id: string;
  name?: string;
  description?: string;
  category?: string;
  type?: string;
  currentValue?: string;
  options?: Array<ConfigOptionValue | { group?: string; name?: string; options: ConfigOptionValue[] }>;
}

/** Options, with groups flattened. */
export function optionValues(option: ConfigOption | undefined): ConfigOptionValue[] {
  const out: ConfigOptionValue[] = [];
  for (const entry of option?.options ?? []) {
    if ('options' in entry && Array.isArray(entry.options)) out.push(...entry.options);
    else if ('value' in entry) out.push(entry as ConfigOptionValue);
  }
  return out;
}

export function findOption(options: readonly ConfigOption[], category: string): ConfigOption | undefined {
  return options.find(o => o.category === category) ?? options.find(o => o.id === category);
}

/** Our effort vocabulary, weakest to strongest. `auto` means "the harness's own default". */
const EFFORT_SCALE = ['off', 'none', 'minimal', 'low', 'medium', 'high', 'xhigh', 'max'] as const;
const EFFORT_RANK: Record<string, number> = {
  off: 0, none: 0, minimal: 1, low: 2, medium: 3, high: 4, xhigh: 5, max: 6,
};
/** The levels our effort picker offers. */
export const PICKER_EFFORTS = ['low', 'medium', 'high', 'xhigh', 'max'] as const;

/**
 * The harness value to select for our effort level, or undefined to leave the
 * harness's default alone. An exact match wins; otherwise the nearest level the
 * harness offers, preferring the stronger one on a tie, so "medium" on a harness
 * with only low/high gets high rather than silently less reasoning.
 */
export function pickEffortValue(effort: string | undefined, option: ConfigOption | undefined): string | undefined {
  if (!effort || effort === 'auto' || !option) return undefined;
  const values = optionValues(option).map(v => v.value);
  if (values.includes(effort)) return effort;
  const wanted = EFFORT_RANK[effort];
  if (wanted === undefined) return undefined;
  let best: string | undefined;
  let bestDistance = Infinity;
  for (const value of values) {
    const rank = EFFORT_RANK[value];
    if (rank === undefined || rank === 0) continue; // never switch reasoning off by approximation
    const distance = Math.abs(rank - wanted);
    if (distance < bestDistance || (distance === bestDistance && rank > (EFFORT_RANK[best ?? ''] ?? -1))) {
      best = value;
      bestDistance = distance;
    }
  }
  return best;
}

/** The picker levels this harness can honour exactly. */
export function supportedPickerEfforts(option: ConfigOption | undefined): string[] {
  const values = new Set(optionValues(option).map(v => v.value));
  return PICKER_EFFORTS.filter(level => values.has(level));
}

export interface PickerModel {
  value: string;
  displayName: string;
  description: string;
  supportsEffort?: boolean;
  supportedEffortLevels?: string[];
}

/**
 * The model picker's catalogue, in the shape the Claude CLI's `initialize`
 * answer uses. `default` leads, as in Claude's own list, and means "whatever the
 * harness picks" — so a user who never chooses keeps following the harness.
 */
export function pickerModels(options: readonly ConfigOption[], harnessLabel: string): PickerModel[] {
  const model = findOption(options, 'model');
  const effort = findOption(options, 'thought_level');
  const efforts = supportedPickerEfforts(effort);
  const effortFields = efforts.length > 0 ? { supportsEffort: true, supportedEffortLevels: efforts } : {};
  const values = optionValues(model);
  const current = values.find(v => v.value === model?.currentValue);
  const list: PickerModel[] = [{
    value: 'default',
    displayName: current?.name ? `Default (${current.name})` : 'Default',
    description: `${harnessLabel} default model`,
    ...effortFields,
  }];
  for (const v of values) {
    list.push({ value: v.value, displayName: v.name ?? v.value, description: v.description ?? '', ...effortFields });
  }
  return list;
}

// ─── Permission modes ────────────────────────────────────────────────────────

/** Claude permission-mode flags (the vocabulary `--permission-mode` and `system/init` use). */
export type ClaudeMode = 'default' | 'acceptEdits' | 'plan' | 'bypassPermissions' | 'auto';

export function normalizeMode(mode: string | undefined): ClaudeMode {
  return mode === 'acceptEdits' || mode === 'plan' || mode === 'bypassPermissions' || mode === 'auto'
    ? mode : 'default';
}

/** The harness session mode for a Claude mode: only plan has a counterpart. */
export function pickModeValue(mode: ClaudeMode, option: ConfigOption | undefined, baseValue: string | undefined): string | undefined {
  if (!option) return undefined;
  const values = optionValues(option).map(v => v.value);
  if (mode === 'plan') return values.includes('plan') ? 'plan' : undefined;
  if (option.currentValue === 'plan') return baseValue && baseValue !== 'plan' ? baseValue : values.find(v => v !== 'plan');
  return undefined;
}

// ─── Tool calls ──────────────────────────────────────────────────────────────

export interface AcpToolCall {
  toolCallId: string;
  title?: string;
  kind?: string;
  status?: string;
  name?: string;
  rawInput?: Record<string, unknown>;
  rawOutput?: unknown;
  locations?: Array<{ path: string; line?: number }>;
  content?: Array<Record<string, unknown>>;
}

/** Merge a `tool_call_update` into what is known about the call; absent fields keep their value. */
export function mergeToolCall(previous: AcpToolCall | undefined, update: AcpToolCall): AcpToolCall {
  const merged: AcpToolCall = { ...(previous ?? { toolCallId: update.toolCallId }) };
  for (const [key, value] of Object.entries(update)) {
    if (value === undefined || value === null) continue;
    if (key === 'rawInput' && typeof value === 'object' && Object.keys(value as object).length === 0 && previous?.rawInput) continue;
    if (key === 'locations' && Array.isArray(value) && value.length === 0 && previous?.locations?.length) continue;
    (merged as unknown as Record<string, unknown>)[key] = value;
  }
  return merged;
}

/** Whether the call is described well enough to show (its arguments are known). */
export function toolCallReady(call: AcpToolCall): boolean {
  if (call.rawInput && Object.keys(call.rawInput).length > 0) return true;
  if (call.content?.length) return true;
  return call.status === 'in_progress' || call.status === 'completed' || call.status === 'failed';
}

function str(value: unknown): string | undefined {
  return typeof value === 'string' && value.length > 0 ? value : undefined;
}

function absolutePath(path: string | undefined, cwd: string): string | undefined {
  if (!path) return undefined;
  return isAbsolute(path) ? path : resolve(cwd, path);
}

function callPath(call: AcpToolCall, cwd: string): string | undefined {
  const raw = call.rawInput ?? {};
  const located = call.locations?.find(l => isAbsolute(l.path))?.path;
  return located ?? absolutePath(str(raw.filePath) ?? str(raw.file_path) ?? str(raw.path), cwd);
}

/**
 * The ACP kind each harness tool name stands for. DeepSeek Harness reports
 * every call as `other`, titled with its own tool name, so the name is all
 * there is to go on. Exact names only: a descriptive title such as OpenCode's
 * "Read a.txt" never matches.
 */
const KIND_BY_TOOL_NAME: Record<string, string> = {
  read: 'read',
  write: 'edit', edit: 'edit',
  grep: 'search', glob: 'search',
  bash: 'execute', pwsh: 'execute',
  web_fetch: 'fetch',
};

function toolName(call: AcpToolCall): string {
  return (call.name || call.title || '').trim().toLowerCase();
}

/** The call's kind, or the one its tool name stands for when the harness says only `other`. */
function callKind(call: AcpToolCall): string | undefined {
  if (call.kind && call.kind !== 'other') return call.kind;
  return KIND_BY_TOOL_NAME[toolName(call)] ?? call.kind;
}

/**
 * Present an ACP tool call as the Claude tool it corresponds to, when the
 * correspondence is exact, so the chat draws its usual card (a Read, a Bash
 * command, an edit with its diff). Anything else keeps the harness's own tool
 * name and arguments untouched and renders as a generic tool.
 */
export function toClaudeTool(call: AcpToolCall, cwd: string): { name: string; input: Record<string, unknown> } {
  const raw = call.rawInput ?? {};
  const path = callPath(call, cwd);
  const own = { name: call.name || call.title || call.kind || 'tool', input: raw };
  switch (callKind(call)) {
    case 'read':
      if (!path) return own;
      return {
        name: 'Read',
        input: {
          file_path: path,
          ...(typeof raw.offset === 'number' ? { offset: raw.offset } : {}),
          ...(typeof raw.limit === 'number' ? { limit: raw.limit } : {}),
        },
      };
    case 'edit': {
      if (!path) return own;
      const oldString = str(raw.oldString) ?? str(raw.old_string);
      const newString = typeof raw.newString === 'string' ? raw.newString : typeof raw.new_string === 'string' ? raw.new_string : undefined;
      if (oldString !== undefined && newString !== undefined) {
        return { name: 'Edit', input: { file_path: path, old_string: oldString, new_string: newString } };
      }
      if (typeof raw.content === 'string') return { name: 'Write', input: { file_path: path, content: raw.content } };
      const diffs = (call.content ?? []).filter(c => c.type === 'diff');
      if (diffs.length === 1) {
        const diff = diffs[0];
        const newText = typeof diff.newText === 'string' ? diff.newText : '';
        const oldText = typeof diff.oldText === 'string' ? diff.oldText : undefined;
        return oldText === undefined || oldText === ''
          ? { name: 'Write', input: { file_path: path, content: newText } }
          : { name: 'Edit', input: { file_path: path, old_string: oldText, new_string: newText } };
      }
      return own;
    }
    case 'execute': {
      const command = str(raw.command) ?? str(raw.cmd);
      if (!command) return own;
      const shell = toolName(call) === 'pwsh' ? 'PowerShell' : 'Bash';
      return { name: shell, input: { command, ...(str(raw.description) ? { description: raw.description } : {}) } };
    }
    case 'search': {
      const pattern = str(raw.pattern) ?? str(raw.query);
      if (!pattern) return own;
      const where = absolutePath(str(raw.path), cwd);
      const label = `${call.name ?? ''} ${call.title ?? ''}`.toLowerCase();
      if (label.includes('glob')) return { name: 'Glob', input: { pattern, ...(where ? { path: where } : {}) } };
      return {
        name: 'Grep',
        input: { pattern, ...(where ? { path: where } : {}), ...(str(raw.include) ? { glob: raw.include } : {}) },
      };
    }
    case 'fetch': {
      const url = str(raw.url);
      if (!url) return own;
      return { name: 'WebFetch', input: { url, prompt: str(raw.prompt) ?? '' } };
    }
    default:
      return own;
  }
}

/** The text a tool result shows, from the call's ACP content (or its raw output). */
export function toolResultText(call: AcpToolCall): string {
  const parts: string[] = [];
  for (const item of call.content ?? []) {
    if (item.type === 'content') {
      const inner = item.content as Record<string, unknown> | undefined;
      if (inner?.type === 'text' && typeof inner.text === 'string') parts.push(inner.text);
      else if (inner?.type === 'resource_link' && typeof inner.uri === 'string') parts.push(inner.uri);
    } else if (item.type === 'diff' && typeof item.path === 'string') {
      parts.push(`Updated ${item.path}`);
    } else if (item.type === 'terminal') {
      parts.push('(terminal output)');
    }
  }
  if (parts.length > 0) return parts.join('\n');
  const out = call.rawOutput;
  if (typeof out === 'string') return out;
  if (out && typeof out === 'object') {
    const o = out as Record<string, unknown>;
    for (const key of ['output', 'stdout', 'result', 'error', 'message']) {
      if (typeof o[key] === 'string' && o[key]) return o[key] as string;
    }
  }
  return call.status === 'failed' ? 'The tool failed.' : 'Done.';
}

/** An ACP plan, as the TodoWrite input the chat renders as a task list. */
export function planToTodos(entries: unknown): Array<{ content: string; status: string; activeForm: string }> {
  if (!Array.isArray(entries)) return [];
  return entries
    .filter((e): e is Record<string, unknown> => !!e && typeof e === 'object' && typeof (e as Record<string, unknown>).content === 'string')
    .map(e => {
      const status = e.status === 'in_progress' || e.status === 'completed' ? e.status : 'pending';
      return { content: e.content as string, status, activeForm: e.content as string };
    });
}

// ─── Prompts ─────────────────────────────────────────────────────────────────

export type AcpContentBlock =
  | { type: 'text'; text: string }
  | { type: 'image'; mimeType: string; data: string };

/** A Claude user message's content as ACP prompt blocks. */
export function toAcpPrompt(content: unknown, acceptsImages: boolean): AcpContentBlock[] {
  if (typeof content === 'string') return [{ type: 'text', text: content }];
  if (!Array.isArray(content)) return [];
  const blocks: AcpContentBlock[] = [];
  let droppedImages = 0;
  for (const block of content as Array<Record<string, unknown>>) {
    if (block.type === 'text' && typeof block.text === 'string') {
      blocks.push({ type: 'text', text: block.text });
    } else if (block.type === 'image') {
      const source = block.source as Record<string, unknown> | undefined;
      if (acceptsImages && source?.type === 'base64' && typeof source.data === 'string') {
        blocks.push({ type: 'image', mimeType: String(source.media_type ?? 'image/png'), data: source.data });
      } else {
        droppedImages++;
      }
    }
  }
  if (droppedImages > 0) {
    blocks.push({ type: 'text', text: `[${droppedImages} attached image(s) omitted: this agent does not accept images]` });
  }
  return blocks;
}

/** Several queued messages folded into one prompt, in the order they were sent. */
export function joinPrompts(prompts: AcpContentBlock[][]): AcpContentBlock[] {
  const out: AcpContentBlock[] = [];
  prompts.forEach((prompt, i) => {
    if (i > 0) out.push({ type: 'text', text: '\n\n' });
    out.push(...prompt);
  });
  return out;
}

/** True when [content] is the bare slash command [name] and nothing else. */
export function isCommandPrompt(content: unknown, name: string): boolean {
  const blocks = Array.isArray(content) ? content as Array<Record<string, unknown>> : null;
  const text = typeof content === 'string' ? content
    : blocks?.length === 1 && blocks[0]?.type === 'text' && typeof blocks[0].text === 'string' ? blocks[0].text : null;
  return text?.trim() === `/${name}`;
}

// ─── Failed turns ────────────────────────────────────────────────────────────

/** A failed turn, told the way the Claude CLI tells its own API errors. */
export interface HarnessApiError {
  kind: ApiFailureKind;
  /** The error code of the CLI's synthetic API-error entry. */
  error: string;
  /** The HTTP status, when the harness named one that fits the failure. */
  status?: number;
  /** `API Error: …`, followed by the harness's own words. */
  text: string;
}

/** OpenCode names the provider failure in its JSON-RPC error's `data.errorName`. */
const ERROR_NAME_KINDS: Record<string, ApiFailureKind> = {
  'provider.rate-limit': 'rate',
  'provider.transport': 'network',
  'provider.timeout': 'network',
  'provider.internal': 'server',
};
const LASTING_ERROR_NAMES = new Set([
  'provider.auth', 'provider.quota', 'provider.content-filter', 'provider.no-route', 'provider.unsupported-operation',
]);
/** Failures that waiting does not heal: an empty balance, a used-up quota, a refused key. */
const LASTING_FAILURE = new RegExp([
  String.raw`insufficient[\s_-]+(?:quota|balance|credits?)`,
  String.raw`(?:quota|usage[\s_-]+limit)[\s_-]+(?:exceeded|exhausted|reached)`,
  String.raw`exceed(?:ed|s)?[\s_-]+(?:(?:your|the)[\s_-]+)?(?:current[\s_-]+)?quota`,
  String.raw`out[\s_-]+of[\s_-]+(?:credits?|budget)`,
  String.raw`\b40[123]\b`, 'unauthori[sz]ed', String.raw`invalid[\s_-]+api[\s_-]+key`,
].join('|'), 'i');
const RATE_LIMIT = /\b429\b|rate[\s_-]?limit|too many requests/i;
/** Statuses that mean the same whatever words surround them. */
const STATUS = /\b(408|413|429|5\d\d)\b/;
/**
 * A rate limit carries the provider's own error type, not the CLI's
 * `rate_limit` or a 429 status: those two mark a Claude usage-limit notice,
 * which the chat offers to resume at its reset or by switching Claude accounts.
 */
const CODES: Record<ApiFailureKind, string> = {
  rate: 'rate_limit_error', server: 'server_error', network: 'unknown', context: 'invalid_request',
};
const FITTING_STATUS: Record<ApiFailureKind, (status: number) => boolean> = {
  rate: () => false,
  server: status => status >= 500,
  network: status => status === 408,
  context: status => status === 413,
};

function failureKind(errorName: string | undefined, detail: string): ApiFailureKind | null {
  if (errorName && ERROR_NAME_KINDS[errorName]) return ERROR_NAME_KINDS[errorName];
  if (errorName && LASTING_ERROR_NAMES.has(errorName)) return null;
  if (LASTING_FAILURE.test(detail)) return null;
  if (RATE_LIMIT.test(detail)) return 'rate';
  const status = Number(STATUS.exec(detail)?.[1]);
  return classifyApiFailure(detail, undefined, Number.isFinite(status) ? status : undefined);
}

/**
 * Read a harness's failed `session/prompt` as the API error the Claude CLI
 * would have reported, so automatic recovery retries it and the chat shows it
 * as a temporary failure. Null for every other failure — a refused key, an
 * empty balance, an internal fault — which keeps its plain wording.
 *
 * Harnesses retry rate limits and dropped connections themselves first; this
 * is what is left once they give up. OpenCode names the provider failure in
 * `data.errorName`; DeepSeek Harness only in the message ("Internal error:
 * turn failed: <the provider's text>").
 */
export function harnessApiError(rpc: RpcError, label: string): HarnessApiError | null {
  const data = rpc.data && typeof rpc.data === 'object' ? rpc.data as Record<string, unknown> : {};
  const errorName = typeof data.errorName === 'string' ? data.errorName : undefined;
  const detail = [rpc.message, data.details, data.message].filter((v): v is string => typeof v === 'string' && v.length > 0).join('\n');
  const kind = failureKind(errorName, detail);
  if (!kind) return null;
  const parsed = Number(STATUS.exec(detail)?.[1]);
  const status = Number.isFinite(parsed) && FITTING_STATUS[kind](parsed) ? parsed : undefined;
  // The chat reads the failure from the text as well; say what the code means
  // when the harness's own words do not.
  const lead = kind === 'network' && classifyApiFailure(detail) !== 'network' ? 'Connection error. ' : '';
  return { kind, error: CODES[kind], ...(status ? { status } : {}), text: `API Error: ${lead}${label}: ${detail}` };
}

/** Deep equality for plain JSON values (key order insensitive). */
export function sameJson(a: unknown, b: unknown): boolean {
  if (a === b) return true;
  if (typeof a !== typeof b || a === null || b === null || typeof a !== 'object') return false;
  if (Array.isArray(a) !== Array.isArray(b)) return false;
  if (Array.isArray(a)) {
    const bb = b as unknown[];
    return a.length === bb.length && a.every((v, i) => sameJson(v, bb[i]));
  }
  const ao = a as Record<string, unknown>;
  const bo = b as Record<string, unknown>;
  const keys = Object.keys(ao).filter(k => ao[k] !== undefined);
  const bkeys = Object.keys(bo).filter(k => bo[k] !== undefined);
  return keys.length === bkeys.length && keys.every(k => sameJson(ao[k], bo[k]));
}

export { EFFORT_SCALE };
