---
name: cc-gui-reporter
description: Status and triage report for AI Bridge: runs the read-only ignore/cc-gui-report.sh (local versions and git state, the published update repository, GitHub issues and PRs when gh is available) and turns it into a short prioritised report with suggested next actions; drafts replies but never posts them. Trigger on: check marketplace, check reviews/comments/replies, unanswered, unresolved bugs, status, report, triage, rapor, durum.
---

> This document is written in English; if the user communicates in another language, read it and relay it translated into the user's language.

# cc-gui-reporter — Status and Triage Report

Collects the state of AI Bridge from one read-only script and turns it into a short report the user can act on. The script
only reads: it writes no files, fetches nothing, and posts, comments, labels or closes nothing. (The skill name is historical;
it reports on AI Bridge.)

## Run the script

```bash
bash ./ignore/cc-gui-report.sh            # local, update repository and GitHub (when gh is installed and logged in)
bash ./ignore/cc-gui-report.sh --offline  # skip every network call
```

`ignore/` is not tracked by git, so the script exists only on the owner's machine. If `ignore/cc-gui-report.sh` is missing,
say that it is local-only and not part of the repository, and stop. Do not recreate it from memory.

The script ends with exit code 0 even when a section is skipped. A `SKIPPED: …` line says why (offline, no `curl`, no `gh`,
`gh` not logged in); pass the reason on instead of treating it as an error. The GitHub repository defaults to
`Birkankader/ai-bridge`; `AI_BRIDGE_REPORT_REPO=<owner>/<name>` overrides it.

## Read the output

Summarise each section in a few lines, then call out what needs attention:

- **Local versions** — `MISMATCH` between `gradle.properties`, `backend/package.json` and `webview/package.json`; a missing
  `<h3><ver> (` change-notes entry.
- **Git** — uncommitted changes, the branch, commits ahead of / behind `origin/main` (local refs only: say that numbers may
  be stale until the user runs `git fetch`), unreleased commits.
- **Update repository** — published version vs local: equal, local newer (unreleased work), or published newer (the local
  tree is behind). A plugin ZIP that does not answer 200.
- **GitHub** — unanswered issues (no comments, or the last comment is not the owner's), open `bug`-labelled issues, open PRs
  and drafts, the latest releases.

## Triage

End with three buckets, each item with its number or section and one line on why:

- **Now** — breaks users or a release: a published ZIP that is not served, a version mismatch, an open bug with a clear fix,
  an unanswered issue with a concrete question.
- **Next** — worth doing soon: open PRs waiting for review, unreleased commits to ship, stale branches.
- **Later** — everything else.

For unanswered issues you may **draft** a reply and show it to the user. Answer in the user's language.

## Boundaries

- AI Bridge is not on the JetBrains Marketplace; it ships through its own update repository. A request about "marketplace",
  "reviews" or "approval" gets the update-repository and GitHub view, and a short note saying so.
- Posting a comment, closing, labelling, assigning or merging anything needs the user's explicit approval **per item**. A
  general "go ahead" or "handle it" is not approval to post. Do not call `gh issue comment`, `gh pr review` or similar on your own.
- Do not push, tag or release from here; that is [/deploy](../deploy/SKILL.md) after [/precheck](../precheck/SKILL.md).
- Never print tokens or credentials, even if the environment has them.
