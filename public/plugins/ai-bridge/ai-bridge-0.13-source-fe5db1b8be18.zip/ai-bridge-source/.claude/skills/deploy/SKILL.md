---
name: deploy
description: Release AI Bridge through its own plugin update repository (birkankader.com/plugins/ai-bridge) with bash ./scripts/build.sh release-site: prepare the release files in the personel-website checkout, show them, and only on an explicit go-ahead publish them (commit and push of the website's main branch, which triggers Netlify). Never publishes to the JetBrains Marketplace unless told to. Trigger on: deploy, release, publish, publish to marketplace, ship a version, yayınla, sürüm çıkar.
---

> This document is written in English; if the user communicates in another language, read it and relay it translated into the user's language.

# deploy — Release Through the AI Bridge Update Repository

AI Bridge is not distributed through the JetBrains Marketplace. It ships from its own plugin repository:
`release-site` builds and verifies the plugin, then writes the release files into the `personel-website` checkout, and the
website's Netlify build serves them at `https://birkankader.com/plugins/ai-bridge/`. IDEs read
`https://birkankader.com/plugins/ai-bridge/updatePlugins.xml` (Settings → Plugins → ⚙ → Manage Plugin Repositories).

**If the user says "marketplace" or "publish to the Marketplace"**, explain this and ask whether they mean the update
repository. Do not run `publishPlugin` or use `PUBLISH_TOKEN` unless they explicitly ask for exactly that.

## Preconditions

1. [/precheck](../precheck/SKILL.md) was run on this tree and every check is PASS. If it was not, run it first. Any FAIL
   blocks the release.
2. The user gave the path of the website checkout (called `<website-checkout>` below). Ask for it if you do not have it;
   never guess a path or search the disk for one. It must be the complete `Birkankader/personel-website` checkout
   (`netlify.toml` and `package.json` present, `origin` pointing at that repository); the script refuses anything else.
3. The version is bumped consistently: `pluginVersion` in `gradle.properties`, `version` in `backend/package.json` and
   `webview/package.json`, and a `changeNotes` entry for it in `build.gradle.kts`. The new version must be greater than the
   published one.

## Step 1 — Prepare (changes nothing in production)

```bash
bash ./scripts/build.sh release-site <website-checkout>
```

This is `--prepare`. It runs `dist`, `verify-plugin` and `source-zip` (Gradle needs JDK 17, see
[build](../build/SKILL.md); Python 3.11+ is needed for the repository script), then writes into
`<website-checkout>/public/plugins/ai-bridge/`: `updatePlugins.xml`, `release.json`, `SHA256SUMS.txt`, the plugin ZIP
(`ai-bridge-<ver>-<sha12>.zip`) and the source ZIP (`ai-bridge-<ver>-source-<sha12>.zip`).

Then show the result and stop:

```bash
git -C <website-checkout> status -- public/plugins/ai-bridge
git -C <website-checkout> diff --stat -- public/plugins/ai-bridge
```

Report the version, the two file names with their SHA-256, and the change notes that will be shown. Ask: "Publish?"

## Step 2 — Publish (only after an explicit "publish" in chat)

Only when the user has said, in this conversation, to publish this version:

```bash
bash ./scripts/build.sh release-site <website-checkout> --publish
```

The script requires the website checkout to be on `main`, equal to `origin/main`, and to have no changes outside
`public/plugins/ai-bridge`. It rebuilds, commits only the release directory and pushes `main`, which triggers Netlify.
If it refuses, report the reason and let the user fix the website checkout; do not work around the checks (no force, no
resetting or cleaning the website repository).

## Step 3 — Hand over

Tell the user the push happened and that nothing is live until Netlify finishes. Continue with
[/release-monitor](../release-monitor/SKILL.md) to watch for it.

## Never

- Push or tag **this** repository. Pushing and tagging stay with the user.
- Reuse a version number with different files. `plugin_repository.py` refuses, and a different ZIP under a known version
  would break the checksums IDEs have cached.
- Publish without the preceding explicit go-ahead, or on an earlier "yes" for another version.
- Edit the website's other files, or commit anything there outside `public/plugins/ai-bridge`.
- Run `publishPlugin` or read or print `PUBLISH_TOKEN`, unless the user explicitly asked for a Marketplace upload.
- Put credentials, tokens or personal paths in any file.
