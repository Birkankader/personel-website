---
name: precheck
description: Pre-release review for AI Bridge before a release is prepared or published: version consistency against the live update repository, change notes, all test layers, distribution build, Plugin Verifier, descriptor/vendor/logo rules, licence and source archive, and secrets. Reports a PASS/FAIL table and blocks /deploy on any FAIL. Trigger on: precheck, pre-deploy check, pre-release review, release readiness, is it ready to release, ön kontrol, yayın öncesi kontrol.
---

> This document is written in English; if the user communicates in another language, read it and relay it translated into the user's language.

# precheck — Review Before a Release

Runs the checks a release must pass, in order, and ends with a PASS/FAIL table. **Any FAIL means: do not run `/deploy`.**
It mirrors the "Agent Checklist" in [CLAUDE.md](../../../CLAUDE.md) and the Marketplace guidelines kept there, applied to
AI Bridge's own update repository (`https://birkankader.com/plugins/ai-bridge`). [pr-checklist](../pr-checklist/SKILL.md)
covers the PR-level checks (rebase, feature docs, principles); this skill covers release-level checks.

Run every build command through `bash ./scripts/build.sh` (see [build](../build/SKILL.md): JDK 17, one Gradle run at a
time, Git Bash on Windows). Do not change anything while checking; report, and let the user decide.

## Checks

### 1. Versions

```bash
grep '^pluginVersion=' gradle.properties
grep -m1 '"version"' backend/package.json webview/package.json
curl -fsS --max-time 10 https://birkankader.com/plugins/ai-bridge/release.json
```

- The three local versions are equal.
- The local version is **greater** than `version` in the published `release.json`. Versions are numeric (`0.11`, `0.12`,
  `0.11.1`); `plugin_repository.py` refuses an older version and refuses to reuse a version with different files; this check additionally requires a greater one.
- If `curl` fails (offline), mark the comparison `SKIPPED`, not PASS, and say what is unverified.

### 2. Change notes

`build.gradle.kts` → `changeNotes` must contain `<h3><ver> (` for the current version, with a date and real entries, and no
placeholder text ("Add change notes here", "TODO"). Notes describe what a user sees, not the implementation.

### 3. Tree

```bash
git status --porcelain
git branch --show-current
git log --oneline origin/main..HEAD
```

The tree is clean (untracked files under `docs/performance/` belong to the user and are reported, not counted as a failure
unless they would be packed), and the branch is the one the user means to release from.

### 4. Gates

```bash
bash ./scripts/build.sh be-lint
bash ./scripts/build.sh wv-lint
bash ./scripts/build.sh be-test
bash ./scripts/build.sh wv-test
bash ./scripts/build.sh test --rerun
bash ./scripts/build.sh cli-test
```

All pass. Report counts per command. A test that fails only on this machine still counts as FAIL until the user decides.

### 5. Distribution build and Plugin Verifier

```bash
bash ./scripts/build.sh dist
bash ./scripts/build.sh verify-plugin
grep -rn "@ApiStatus.Internal\|StartupManager\|PluginManagerConfigurable" src/main/kotlin --include="*.kt"
```

- `dist` produces `build/distributions/ai-bridge-<ver>.zip`.
- `verify-plugin` reports **zero** "Internal API usages" and no incompatible/missing-class problems in any IDE of the
  `pluginVerification.ides` matrix. Review the deprecated-API warnings and list them; they do not fail the check but must be
  mentioned.
- The `grep` returns nothing (or only comments the reviewer explains).

### 6. Descriptor, vendor and logo

- `src/main/resources/META-INF/plugin.xml`: `<id>com.birkankader.ai-bridge</id>`, `<name>` is at most 30 characters and
  has no JetBrains product name ("IntelliJ", "JetBrains", "Plugin"), `<vendor url="https://birkankader.com">` is set.
- `src/main/resources/META-INF/pluginIcon.svg` (and `pluginIcon_dark.svg`) is 40×40 and is not the IntelliJ template logo
  or anything resembling a JetBrains logo.
- `docs/marketplaces/jetbrains/en.md` (the description) renders, is English, and every link in it is valid and relates to
  the plugin or its author. No broken images.
- The built ZIP's descriptor has `since-build` (the repository script rejects one without).

### 7. Legal

- `LICENSE` and `COMMUNITY_NOTICE.md` are packed into the plugin JAR under `META-INF` (the `processResources` task copies
  them). List the plugin JAR to confirm, for example with `unzip -l` on the jar inside the ZIP.
- `bash ./scripts/build.sh source-zip` builds `dist/ai-bridge-<ver>-source.zip` (needs Python 3). The source archive is
  what the AGPL "corresponding source" link points to.
- A privacy policy link is present if personal data is collected; telemetry needs explicit consent and nothing is sent
  while the plugin is disabled (CLAUDE.md "Data collection").

### 8. Secrets

```bash
git ls-files | grep -E '(^|/)\.env'
```

- Only `.env.example` is tracked.
- Keys beginning with `_` in `.env.production` (and `.env`) are **embedded in the distributable backend bundle** and can be
  read by anyone who gets the plugin. Review each `_`-prefixed key: no private credential may be among them. Do not print
  secret values in the report; name the keys only.
- `AI_BRIDGE_PUBLIC_*` and `VITE_*` values are exposed to the WebView: no secrets either.
- No tokens in `build.gradle.kts` (`PUBLISH_TOKEN` is read from the environment only).

## Output

```
| # | Check                          | Result | Evidence |
|---|--------------------------------|--------|----------|
| 1 | Versions (local 0.12 > 0.11)   | PASS   | gradle.properties, both package.json, release.json |
| 2 | Change notes                   | PASS   | <h3>0.12 (…) present |
| … | …                              | …      | … |
```

Results are `PASS`, `FAIL` or `SKIPPED` (with the reason). End with one line: **READY** (all PASS, no unexplained SKIPPED)
or **NOT READY: do not deploy** with the list of FAILs. Offer `/deploy` only on READY.
