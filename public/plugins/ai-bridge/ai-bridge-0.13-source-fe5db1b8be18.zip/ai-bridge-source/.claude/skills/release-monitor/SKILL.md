---
name: release-monitor
description: Watch a published AI Bridge release go live: poll the update repository's updatePlugins.xml and release.json until they show the new version, check that the plugin and source ZIPs download and match their SHA-256, and tell the user what to check in Netlify or the IDE when they do not. Read-only. Trigger on: release monitoring, release-monitor, marketplace monitoring, check approval, is the release live, sürüm takibi, yayın kontrolü.
---

> This document is written in English; if the user communicates in another language, read it and relay it translated into the user's language.

# release-monitor — Is the Release Live?

AI Bridge has no Marketplace review queue to wait for: a release is live when the website build that
[/deploy](../deploy/SKILL.md) triggered has finished and serves the new files. This skill checks exactly that and changes
nothing. If the user asks about "approval" or the "marketplace", say so and monitor the update repository instead.

Base URL: `https://birkankader.com/plugins/ai-bridge`

## What to check

Read the local version once: `grep '^pluginVersion=' gradle.properties` (call it `<ver>`).

1. **`release.json`** — `curl -fsS --max-time 10 <base>/release.json`: `version` equals `<ver>`; note `pluginFile`,
   `pluginSha256`, `sourceFile`, `sourceSha256`.
2. **`updatePlugins.xml`** — `curl -fsS --max-time 10 <base>/updatePlugins.xml`: contains
   `<plugin id="com.birkankader.ai-bridge" version="<ver>" url="<base>/<pluginFile>">` and a `since-build`.
3. **Downloads exist** — `curl -fsSI --max-time 10 <base>/<pluginFile>` and `<base>/<sourceFile>` both answer `200`.
4. **Checksums (optional but preferred)** — download each ZIP into a temporary directory (the scratchpad or `mktemp -d`,
   never into the repository), run `sha256sum`, compare with `pluginSha256` / `sourceSha256`, then delete the files.
   `<base>/SHA256SUMS.txt` carries the same values.

## Polling

Poll about every 60 seconds, for up to about 15 minutes, until checks 1 and 2 show `<ver>`. Keep each poll short and print
one line per attempt (`attempt 4: release.json 0.11, waiting for 0.12`). Stop early as soon as everything passes.

If it times out:

- Say that the version is not live yet and which check failed (old `release.json`, old XML, 404 on a ZIP, checksum
  mismatch).
- Ask the user to check the **Netlify deploy log** for the website (this session has no access to it) and the latest commit
  of the website's `main` branch, which should be "Publish AI Bridge plugin `<ver>`".
- A checksum mismatch is serious: do not call the release good; tell the user not to announce it.

## When it is live

Report a table:

```
| Check                         | Result |
|-------------------------------|--------|
| release.json version = 0.12   | PASS   |
| updatePlugins.xml entry       | PASS   |
| plugin ZIP (200, SHA-256)     | PASS   |
| source ZIP (200, SHA-256)     | PASS   |
```

The last step is the user's: in an IDE with the repository added, **Settings → Plugins → Updates** should offer
`<ver>`. Remind them of that; this skill cannot see the IDE.

## Never

Modify, push, delete or re-upload anything, and never write into the repository or the website checkout. This skill only
reads.
