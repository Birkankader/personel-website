# AI Bridge

Developer and publisher of this independent distribution: **Birkan Kader**.
Copyright (c) 2026 Birkan Kader for the AI Bridge modifications.
Pre-existing source authors retain their original copyrights.

This is a modified local distribution, prepared on 2026-09-08 from
[Swttch v0.30.1](https://github.com/Swttch/swttch/tree/v0.30.1), commit
`8c4264187610b6a1aace281d88e34d09ac28c4d7`. It is not an official Swttch release.
Original authorship, copyright notices and the GNU Affero General Public License
version 3 are retained; see `LICENSE` and the upstream source headers.

The UI and JetBrains descriptor display name is AI Bridge.

AI Bridge modifications and release preparation: 2026-09-08, Birkan Kader.
This software is distributed under GNU AGPL v3 without warranty.

The corresponding modified source is supplied alongside the plugin. Keep this
notice, LICENSE, and the matching source available when sharing the distribution.
This release uses its own plugin ID, `com.birkankader.ai-bridge`,
namespace and settings directory (`~/.ai-bridge`). It installs independently of upstream versions
and does not automatically migrate or remove their data. No upstream sponsor,
telemetry, announcement or plugin-update service is used.

Build from this directory with JDK 17, Node.js and the pinned pnpm version:

```sh
bash ./scripts/build.sh be-install
bash ./scripts/build.sh wv-install
bash ./scripts/build.sh be-lint
bash ./scripts/build.sh wv-lint
bash ./scripts/build.sh be-test --maxWorkers=2
bash ./scripts/build.sh wv-test --maxWorkers=2
bash ./scripts/build.sh test --max-workers=2
bash ./scripts/build.sh dist
```

The build requires no private upstream build keys. A fresh build fetches the
declared IntelliJ SDK and JetBrains Runtime. Current release validation is recorded in `docs/reports/AI_BRIDGE_0.1_TR.md`.
