//! Drives the built helper the way win-job.ts does: the CLI command line in
//! AI_BRIDGE_JOB_CMDLINE, the sessionId as the only argument, stdio as pipes.
#![cfg(windows)]

use std::io::{BufRead, BufReader, Read, Write};
use std::process::{Child, ChildStdout, Command, Output, Stdio};
use std::time::{Duration, Instant};

const HELPER: &str = env!("CARGO_BIN_EXE_ai-bridge-job");

/// A CLI stand-in that prints its PID, then sleeps for two minutes.
const STAND_IN: &str =
    r#"powershell -NoProfile -NonInteractive -Command "[Console]::Out.WriteLine($PID); Start-Sleep 120""#;

fn helper(cmdline: Option<&str>) -> Command {
    let mut command = Command::new(HELPER);
    command.arg("ccg-test-session").env_remove("AI_BRIDGE_JOB_CMDLINE");
    if let Some(cmdline) = cmdline {
        command.env("AI_BRIDGE_JOB_CMDLINE", cmdline);
    }
    command.stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::piped());
    command
}

fn run(cmdline: Option<&str>) -> Output {
    helper(cmdline).output().expect("helper starts")
}

fn first_line(stdout: &mut BufReader<ChildStdout>) -> String {
    let mut line = String::new();
    stdout.read_line(&mut line).expect("stand-in prints its PID");
    line.trim().to_owned()
}

fn alive(pid: u32) -> bool {
    let out = Command::new("tasklist")
        .args(["/FI", &format!("PID eq {pid}"), "/NH", "/FO", "CSV"])
        .output()
        .expect("tasklist runs");
    String::from_utf8_lossy(&out.stdout).contains(&format!("\"{pid}\""))
}

fn dies_within(pid: u32, limit: Duration) -> bool {
    let deadline = Instant::now() + limit;
    while Instant::now() < deadline {
        if !alive(pid) {
            return true;
        }
        std::thread::sleep(Duration::from_millis(100));
    }
    false
}

/// Ends a stand-in a failed assertion left sleeping.
struct Reap(u32);

impl Drop for Reap {
    fn drop(&mut self) {
        if alive(self.0) {
            let _ = Command::new("taskkill").args(["/F", "/PID", &self.0.to_string()]).output();
        }
    }
}

fn spawn_stand_in(cmdline: &str) -> (Child, BufReader<ChildStdout>, Reap) {
    let mut child = helper(Some(cmdline)).spawn().expect("helper starts");
    let mut stdout = BufReader::new(child.stdout.take().unwrap());
    let pid: u32 = first_line(&mut stdout).parse().expect("a PID");
    assert!(alive(pid));
    (child, stdout, Reap(pid))
}

#[test]
fn passes_the_exit_code_through_and_adds_nothing_to_stdout() {
    let out = run(Some("echo ccg-job-ok& exit 7"));
    assert_eq!(out.status.code(), Some(7));
    assert_eq!(String::from_utf8_lossy(&out.stdout), "ccg-job-ok\r\n");
    assert_eq!(String::from_utf8_lossy(&out.stderr), "");
}

#[test]
fn refuses_to_start_without_the_command_line() {
    let out = run(None);
    assert_eq!(out.status.code(), Some(210));
    assert!(out.stdout.is_empty());
    assert!(String::from_utf8_lossy(&out.stderr).contains("AI_BRIDGE_JOB_CMDLINE not set"));
}

#[test]
fn probe_succeeds_silently() {
    let out = Command::new(HELPER).arg("--probe").output().expect("helper starts");
    assert_eq!(out.status.code(), Some(0));
    assert!(out.stdout.is_empty());
    assert!(out.stderr.is_empty());
}

#[test]
fn hands_the_cli_its_stdin() {
    let mut child = helper(Some("findstr ccg")).spawn().expect("helper starts");
    child.stdin.take().unwrap().write_all(b"ccg-in\r\nother\r\n").unwrap();
    let mut stdout = String::new();
    child.stdout.take().unwrap().read_to_string(&mut stdout).unwrap();
    assert_eq!(child.wait().unwrap().code(), Some(0));
    assert_eq!(stdout, "ccg-in\r\n");
}

#[test]
fn kills_the_cli_tree_with_the_helper() {
    // No delay before the stand-in starts: the CLI is in the job before it runs, so
    // even a grandchild started at once cannot slip out.
    let (mut child, _stdout, reap) = spawn_stand_in(STAND_IN);
    child.kill().unwrap();
    assert!(dies_within(reap.0, Duration::from_secs(10)));
}

#[test]
fn kills_what_the_cli_leaves_behind_when_it_exits() {
    // The MSYS case: a background worker that outlives the CLI's own exit.
    let (mut child, _stdout, reap) = spawn_stand_in(&format!("start /b {STAND_IN} & set /p ready= & exit 4"));
    child.stdin.take().unwrap().write_all(b"go\r\n").unwrap();
    assert_eq!(child.wait().unwrap().code(), Some(4));
    assert!(dies_within(reap.0, Duration::from_secs(10)));
}
