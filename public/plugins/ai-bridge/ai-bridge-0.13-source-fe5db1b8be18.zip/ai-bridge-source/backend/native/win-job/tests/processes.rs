//! Drives `--processes` the way windows-processes.ts does, and checks it finds a
//! process by what its command line carries, as the orphan sweep looks for a
//! sessionId. Only the marked process's row is inspected: other processes' command
//! lines are never printed.
#![cfg(windows)]

use std::process::{Command, Stdio};

const HELPER: &str = env!("CARGO_BIN_EXE_ai-bridge-job");

#[test]
fn lists_a_running_process_with_its_command_line() {
    // A distinct echo size marks the stand-in's command line.
    let marker = format!("-l {}", 1000 + std::process::id() % 50000);
    let mut marked = Command::new("ping")
        .args(["-n", "30", &marker[..2], &marker[3..], "127.0.0.1"])
        .stdout(Stdio::null())
        .spawn()
        .unwrap();
    let out = Command::new(HELPER).arg("--processes").output().expect("helper starts");
    let _ = marked.kill();
    let _ = marked.wait();

    assert_eq!(out.status.code(), Some(0));
    assert!(out.stderr.is_empty());
    let stdout = String::from_utf8(out.stdout).expect("UTF-8 output");
    assert!(stdout.starts_with("[{\"ProcessId\":") && stdout.ends_with("}]"), "one JSON array");
    let row = format!("{{\"ProcessId\":{},\"CommandLine\":\"", marked.id());
    let at = stdout.find(&row).expect("the marked process is listed with a command line");
    let line = &stdout[at..stdout[at..].find('}').map_or(stdout.len(), |end| at + end)];
    assert!(line.contains(&marker), "{line}");
}
