//! `ai-bridge-job --processes`: every running process and its command line, for
//! the CLI registry's identity checks through backend/src/core/windows-processes.ts.
//! It is the native twin of the `Get-CimInstance Win32_Process` PowerShell scan
//! there, which stays as the fallback. The registry scans at backend start whenever
//! an unclean exit left CLI records behind, before a chat starts on a session that
//! still has a record, and again before each process it kills.
//!
//! Contract, the scan's:
//!   - stdout: `[{"ProcessId":N,"CommandLine":string|null}, …]`, one row per
//!     process. The command line is null where Windows does not give it to this
//!     user (System, protected processes, other users' processes), as WMI leaves it
//!     empty. A process that exits during the scan is left out or listed without one.
//!   - Command lines go to stdout only: they can hold secrets.
//!   - Exit 1 when the process list cannot be read, or this Windows cannot give
//!     command lines at all. The backend then scans with PowerShell.
//!
//! The command line comes from NtQueryInformationProcess(ProcessCommandLineInformation),
//! Windows 8.1 and later. It needs only PROCESS_QUERY_LIMITED_INFORMATION, not the
//! memory read that walking the target's PEB would.

use std::ffi::c_void;
use std::io::{self, Write};
use std::mem::{size_of, zeroed};
use std::process;

use crate::json;

type Handle = *mut c_void;
type Bool = i32;

const INVALID_HANDLE_VALUE: Handle = -1isize as Handle;
const TH32CS_SNAPPROCESS: u32 = 0x2;
const PROCESS_QUERY_LIMITED_INFORMATION: u32 = 0x1000;
const PROCESS_COMMAND_LINE_INFORMATION: u32 = 60;
const STATUS_SUCCESS: i32 = 0;
const STATUS_INVALID_INFO_CLASS: i32 = 0xC000_0003u32 as i32;
const STATUS_INFO_LENGTH_MISMATCH: i32 = 0xC000_0004u32 as i32;
const STATUS_BUFFER_TOO_SMALL: i32 = 0xC000_0023u32 as i32;
const STATUS_NOT_IMPLEMENTED: i32 = 0xC000_0002u32 as i32;
/// A command line is at most 32767 UTF-16 units; anything claiming more is not one.
const MAX_INFO_BYTES: usize = 1 << 20;

// Win32 layouts, named as in the SDK headers so they can be checked against them.
#[repr(C)]
#[allow(non_camel_case_types, non_snake_case, clippy::upper_case_acronyms)]
struct PROCESSENTRY32W {
    dwSize: u32,
    cntUsage: u32,
    th32ProcessID: u32,
    th32DefaultHeapID: usize,
    th32ModuleID: u32,
    cntThreads: u32,
    th32ParentProcessID: u32,
    pcPriClassBase: i32,
    dwFlags: u32,
    szExeFile: [u16; 260],
}

#[repr(C)]
#[allow(non_camel_case_types, non_snake_case)]
struct UNICODE_STRING {
    Length: u16,
    MaximumLength: u16,
    Buffer: *const u16,
}

#[cfg(target_pointer_width = "64")]
const _: () = {
    assert!(size_of::<PROCESSENTRY32W>() == 568);
    assert!(size_of::<UNICODE_STRING>() == 16);
};

#[link(name = "kernel32")]
extern "system" {
    fn CreateToolhelp32Snapshot(flags: u32, process_id: u32) -> Handle;
    fn Process32FirstW(snapshot: Handle, entry: *mut PROCESSENTRY32W) -> Bool;
    fn Process32NextW(snapshot: Handle, entry: *mut PROCESSENTRY32W) -> Bool;
    fn OpenProcess(access: u32, inherit: Bool, process_id: u32) -> Handle;
    fn CloseHandle(handle: Handle) -> Bool;
}

#[link(name = "ntdll")]
extern "system" {
    fn NtQueryInformationProcess(
        process: Handle,
        class: u32,
        info: *mut c_void,
        length: u32,
        returned: *mut u32,
    ) -> i32;
}

/// This Windows has no ProcessCommandLineInformation (before 8.1).
struct Unsupported;

/// Every process id and its snapshot parent, or None when the list cannot be read.
pub(crate) fn process_entries() -> Option<Vec<(u32, u32)>> {
    // SAFETY: a toolhelp snapshot walked with a correctly sized entry, then closed.
    unsafe {
        let snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        if snapshot == INVALID_HANDLE_VALUE {
            return None;
        }
        let mut entry: PROCESSENTRY32W = zeroed();
        entry.dwSize = size_of::<PROCESSENTRY32W>() as u32;
        let mut ids = Vec::new();
        let mut more = Process32FirstW(snapshot, &mut entry) != 0;
        while more {
            ids.push((entry.th32ProcessID, entry.th32ParentProcessID));
            more = Process32NextW(snapshot, &mut entry) != 0;
        }
        CloseHandle(snapshot);
        // A machine always runs something: an empty list is a failed read.
        (!ids.is_empty()).then_some(ids)
    }
}

fn process_ids() -> Option<Vec<u32>> {
    process_entries().map(|entries| entries.into_iter().map(|(pid, _)| pid).collect())
}

/// The command line `process_id` was started with, None when Windows does not give
/// it to us (or the process has exited).
fn command_line(process_id: u32) -> Result<Option<String>, Unsupported> {
    // SAFETY: OpenProcess either fails or returns a handle closed below.
    let process = unsafe { OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, process_id) };
    if process.is_null() {
        return Ok(None);
    }
    // u64 elements keep the UNICODE_STRING at the start of the buffer aligned.
    let mut buffer = vec![0u64; 512];
    let result = loop {
        let size = buffer.len() * size_of::<u64>();
        let mut needed = 0u32;
        // SAFETY: `buffer` holds `size` writable bytes for the call to fill.
        let status = unsafe {
            NtQueryInformationProcess(process, PROCESS_COMMAND_LINE_INFORMATION, buffer.as_mut_ptr().cast(), size as u32, &mut needed)
        };
        match status {
            STATUS_SUCCESS => break Ok(Some(())),
            STATUS_INFO_LENGTH_MISMATCH | STATUS_BUFFER_TOO_SMALL
                if (needed as usize) > size && (needed as usize) <= MAX_INFO_BYTES =>
            {
                buffer.resize((needed as usize).div_ceil(size_of::<u64>()), 0);
            }
            STATUS_INVALID_INFO_CLASS | STATUS_NOT_IMPLEMENTED => break Err(Unsupported),
            // Access denied, exited, or a size that makes no sense.
            _ => break Ok(None),
        }
    };
    // SAFETY: the handle OpenProcess returned, closed once.
    unsafe { CloseHandle(process) };
    if result?.is_none() {
        return Ok(None);
    }
    // SAFETY: on success the buffer starts with a UNICODE_STRING whose text the
    // call copied into the same buffer; it is only read inside the buffer's bounds.
    let text = unsafe {
        let header = &*(buffer.as_ptr() as *const UNICODE_STRING);
        let units = usize::from(header.Length) / 2;
        let start = buffer.as_ptr() as usize;
        let end = start + buffer.len() * size_of::<u64>();
        let text = header.Buffer as usize;
        if units == 0 {
            return Ok(Some(String::new()));
        }
        if text < start || text + units * 2 > end {
            return Ok(None);
        }
        std::slice::from_raw_parts(header.Buffer, units)
    };
    Ok(Some(String::from_utf16_lossy(text)))
}

fn scan() -> Option<String> {
    let mut out = String::from("[");
    for (index, id) in process_ids()?.into_iter().enumerate() {
        if index > 0 {
            out.push(',');
        }
        out.push_str(&format!("{{\"ProcessId\":{id},\"CommandLine\":"));
        match command_line(id).ok()? {
            Some(line) => json::push_string(&mut out, &line),
            None => out.push_str("null"),
        }
        out.push('}');
    }
    out.push(']');
    Some(out)
}

pub fn main() -> ! {
    if let Some(output) = scan() {
        let mut stdout = io::stdout().lock();
        if stdout.write_all(output.as_bytes()).and_then(|()| stdout.flush()).is_ok() {
            process::exit(0);
        }
    }
    let _ = io::stderr().write_all(b"[ccg-job] could not list processes");
    process::exit(1)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::process::{Command, Stdio};

    #[test]
    fn lists_this_process() {
        let ids = process_ids().unwrap();
        assert!(ids.contains(&process::id()));
        assert!(ids.len() > 10, "a running Windows has more than a handful of processes");
    }

    #[test]
    fn reads_another_process_command_line_as_started() {
        let size = (1000 + process::id() % 50000).to_string();
        let mut child = Command::new("ping")
            .args(["-n", "30", "-l", &size, "127.0.0.1"])
            .stdout(Stdio::null())
            .spawn()
            .unwrap();
        // Give it time to fail if its arguments were wrong: a quick exit would make
        // the read below pass or fail on timing alone.
        std::thread::sleep(std::time::Duration::from_millis(300));
        assert!(child.try_wait().unwrap().is_none(), "the stand-in is still running");
        let line = command_line(child.id()).ok().flatten();
        let _ = child.kill();
        let _ = child.wait();
        let line = line.expect("our own child's command line is readable");
        assert!(line.contains(&format!("-n 30 -l {size} 127.0.0.1")), "{line}");
        assert_eq!(command_line(child.id()).ok().flatten(), None, "an exited process has none");
    }

    #[test]
    fn reads_this_process_like_get_command_line() {
        let own = command_line(process::id()).ok().flatten().unwrap();
        let exe = std::env::current_exe().unwrap();
        let name = exe.file_name().unwrap().to_string_lossy().into_owned();
        assert!(own.contains(&name), "{own}");
    }

    #[test]
    fn scans_into_one_json_array() {
        let out = scan().unwrap();
        assert!(out.starts_with("[{\"ProcessId\":") && out.ends_with("}]"));
        assert!(out.contains(&format!("{{\"ProcessId\":{},\"CommandLine\":\"", process::id())));
    }
}
