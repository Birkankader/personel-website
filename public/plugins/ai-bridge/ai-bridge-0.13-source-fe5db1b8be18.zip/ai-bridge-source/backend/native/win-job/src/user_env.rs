//! `ai-bridge-job --user-env`: reads and writes the connection variables in the
//! Windows user environment for backend/src/core/features/windows-user-env.ts. It is
//! the native twin of the PowerShell script there, which stays as the fallback. The
//! backend runs it at every start and on every save, before chats may launch, so it
//! must not cost a PowerShell start.
//!
//! Contract, the script's:
//!   - stdin: base64 of UTF-8 JSON `{"key"?: string, "value"?: string}`. Values never
//!     travel in argv, where any process listing shows them.
//!   - With `key` (one of KEYS, exact case), `value` goes to HKCU\Environment as
//!     REG_SZ, or the variable is deleted when it is empty, as
//!     [Environment]::SetEnvironmentVariable(key, value, 'User') does. Then running
//!     programs are told with WM_SETTINGCHANGE "Environment", as .NET does.
//!   - stdout: `{"values":{KEY: string|null, …},"machine":{…}}`, every key read back
//!     from the user and the machine environment, as GetEnvironmentVariable gives
//!     them: REG_EXPAND_SZ expanded, a value of a non-string type as null.
//!   - Any failure: exit 1 with a fixed message on stderr. Nothing that could hold a
//!     value is ever written there.
//!
//! One deliberate difference: the broadcast skips hung windows (SMTO_ABORTIFHUNG)
//! where .NET waits a second on each.

use std::ffi::c_void;
use std::fmt::Write as _;
use std::io::{self, Read, Write};
use std::iter::Peekable;
use std::process;
use std::ptr::null_mut;
use std::str::Chars;

use crate::json;

const KEYS: [&str; 3] = ["ANTHROPIC_AUTH_TOKEN", "ANTHROPIC_BASE_URL", "ANTHROPIC_MODEL"];

/// .NET refuses a value this long or longer.
const MAX_VALUE_UNITS: usize = 32767;
/// Far above the largest request the backend sends (one such value, base64'd).
const MAX_REQUEST_BYTES: u64 = 1 << 20;

type Hkey = *mut c_void;

// Predefined keys are sign-extended 32-bit values (winreg.h).
const HKEY_CURRENT_USER: Hkey = 0x8000_0001u32 as i32 as isize as Hkey;
const HKEY_LOCAL_MACHINE: Hkey = 0x8000_0002u32 as i32 as isize as Hkey;
const KEY_QUERY_VALUE: u32 = 0x0001;
const KEY_SET_VALUE: u32 = 0x0002;
const REG_SZ: u32 = 1;
const REG_EXPAND_SZ: u32 = 2;
const ERROR_SUCCESS: i32 = 0;
const ERROR_FILE_NOT_FOUND: i32 = 2;
const ERROR_MORE_DATA: i32 = 234;
const HWND_BROADCAST: isize = 0xFFFF;
const WM_SETTINGCHANGE: u32 = 0x001A;
const SMTO_ABORTIFHUNG: u32 = 0x0002;
const LOAD_LIBRARY_SEARCH_SYSTEM32: u32 = 0x0800;

#[link(name = "advapi32")]
extern "system" {
    fn RegOpenKeyExW(key: Hkey, sub_key: *const u16, options: u32, desired: u32, result: *mut Hkey) -> i32;
    fn RegQueryValueExW(
        key: Hkey,
        name: *const u16,
        reserved: *mut u32,
        kind: *mut u32,
        data: *mut u8,
        size: *mut u32,
    ) -> i32;
    fn RegSetValueExW(key: Hkey, name: *const u16, reserved: u32, kind: u32, data: *const u8, size: u32) -> i32;
    fn RegDeleteValueW(key: Hkey, name: *const u16) -> i32;
    fn RegCloseKey(key: Hkey) -> i32;
}

#[link(name = "kernel32")]
extern "system" {
    fn ExpandEnvironmentStringsW(source: *const u16, destination: *mut u16, size: u32) -> u32;
    fn LoadLibraryExW(name: *const u16, file: *mut c_void, flags: u32) -> *mut c_void;
    fn GetProcAddress(module: *mut c_void, name: *const u8) -> *mut c_void;
}

fn wide(value: &str) -> Vec<u16> {
    value.encode_utf16().chain(Some(0)).collect()
}

/// A registry key that holds environment variables.
#[derive(Clone, Copy)]
struct Location<'a> {
    root: Hkey,
    path: &'a str,
}

const USER: Location<'static> = Location { root: HKEY_CURRENT_USER, path: "Environment" };
const MACHINE: Location<'static> =
    Location { root: HKEY_LOCAL_MACHINE, path: r"SYSTEM\CurrentControlSet\Control\Session Manager\Environment" };

struct Key(Hkey);

impl Key {
    /// None when the key does not exist: it then holds no variables.
    fn open(location: Location, access: u32) -> Result<Option<Key>, ()> {
        let path = wide(location.path);
        let mut key = null_mut();
        // SAFETY: `path` is NUL-terminated and outlives the call; `key` is written.
        match unsafe { RegOpenKeyExW(location.root, path.as_ptr(), 0, access, &mut key) } {
            ERROR_SUCCESS => Ok(Some(Key(key))),
            ERROR_FILE_NOT_FOUND => Ok(None),
            _ => Err(()),
        }
    }

    fn read(&self, name: &str) -> Result<Option<String>, ()> {
        let name = wide(name);
        let mut buffer = vec![0u16; 256];
        loop {
            let mut kind = 0;
            let mut size = (buffer.len() * 2) as u32;
            // SAFETY: `size` is the byte length of `buffer`, which the call fills.
            let status = unsafe {
                RegQueryValueExW(self.0, name.as_ptr(), null_mut(), &mut kind, buffer.as_mut_ptr().cast(), &mut size)
            };
            match status {
                ERROR_SUCCESS => {}
                ERROR_FILE_NOT_FOUND => return Ok(None),
                // Grown since the last try, or larger than the first guess.
                ERROR_MORE_DATA => {
                    buffer.resize(size as usize / 2 + 1, 0);
                    continue;
                }
                _ => return Err(()),
            }
            if kind != REG_SZ && kind != REG_EXPAND_SZ {
                return Ok(None);
            }
            // The stored terminator is optional, so the end is the first NUL or the size.
            let units = &buffer[..size as usize / 2];
            let units = &units[..units.iter().position(|&unit| unit == 0).unwrap_or(units.len())];
            return if kind == REG_EXPAND_SZ { expand(units).map(Some) } else { Ok(Some(String::from_utf16_lossy(units))) };
        }
    }
}

impl Drop for Key {
    fn drop(&mut self) {
        // SAFETY: a key RegOpenKeyExW opened, closed once.
        unsafe { RegCloseKey(self.0) };
    }
}

/// %VARIABLES% replaced from this process's environment, which is the backend's,
/// as .NET expands them in the PowerShell it starts.
fn expand(units: &[u16]) -> Result<String, ()> {
    let source: Vec<u16> = units.iter().copied().chain(Some(0)).collect();
    let mut size = source.len() as u32 + 256;
    loop {
        let mut out = vec![0u16; size as usize];
        // SAFETY: `source` is NUL-terminated; `out` holds `size` units.
        let needed = unsafe { ExpandEnvironmentStringsW(source.as_ptr(), out.as_mut_ptr(), size) };
        if needed == 0 {
            return Err(());
        }
        if needed <= size {
            out.truncate(needed as usize - 1);
            return Ok(String::from_utf16_lossy(&out));
        }
        size = needed;
    }
}

fn write(location: Location, name: &str, value: &str) -> Result<(), ()> {
    let key = Key::open(location, KEY_SET_VALUE)?.ok_or(())?;
    let name = wide(name);
    let status = if value.is_empty() {
        // SAFETY: `name` is NUL-terminated and outlives the call.
        match unsafe { RegDeleteValueW(key.0, name.as_ptr()) } {
            ERROR_FILE_NOT_FOUND => ERROR_SUCCESS,
            status => status,
        }
    } else {
        let data = wide(value);
        // SAFETY: `data` is the value with its terminator, `size` its byte length.
        unsafe { RegSetValueExW(key.0, name.as_ptr(), 0, REG_SZ, data.as_ptr().cast(), (data.len() * 2) as u32) }
    };
    if status == ERROR_SUCCESS { Ok(()) } else { Err(()) }
}

/// Tells Explorer and every other running program to reload the environment, so the
/// next terminal opened from them sees the change. Best effort, as in .NET. user32 is
/// loaded here, not linked: it would load into every chat's job helper otherwise and
/// connect it to the desktop. advapi32 is linked; it adds about 0.2 MB there.
fn broadcast_environment_change() {
    type SendMessageTimeoutW = unsafe extern "system" fn(isize, u32, usize, isize, u32, u32, *mut usize) -> isize;
    // SAFETY: user32 comes from System32 only, and the symbol has the signature above.
    unsafe {
        let user32 = LoadLibraryExW(wide("user32.dll").as_ptr(), null_mut(), LOAD_LIBRARY_SEARCH_SYSTEM32);
        if user32.is_null() {
            return;
        }
        let send = GetProcAddress(user32, c"SendMessageTimeoutW".as_ptr().cast());
        if send.is_null() {
            return;
        }
        let send: SendMessageTimeoutW = std::mem::transmute(send);
        let environment = wide("Environment");
        let mut result = 0;
        send(HWND_BROADCAST, WM_SETTINGCHANGE, 0, environment.as_ptr() as isize, SMTO_ABORTIFHUNG, 1000, &mut result);
    }
}

fn snapshot(user: Location, machine: Location) -> Result<String, ()> {
    let mut out = String::from("{");
    for (group, location) in [("values", user), ("machine", machine)] {
        if group != "values" {
            out.push(',');
        }
        let key = Key::open(location, KEY_QUERY_VALUE)?;
        let _ = write!(out, "\"{group}\":{{");
        for (index, name) in KEYS.iter().enumerate() {
            if index > 0 {
                out.push(',');
            }
            json::push_string(&mut out, name);
            out.push(':');
            match key.as_ref().map(|key| key.read(name)).transpose()?.flatten() {
                Some(value) => json::push_string(&mut out, &value),
                None => out.push_str("null"),
            }
        }
        out.push('}');
    }
    out.push('}');
    Ok(out)
}

fn base64_decode(text: &[u8]) -> Option<Vec<u8>> {
    let mut out = Vec::with_capacity(text.len() / 4 * 3);
    let (mut bits, mut count, mut padded) = (0u32, 0, false);
    for &byte in text {
        let digit = match byte {
            b'A'..=b'Z' => byte - b'A',
            b'a'..=b'z' => byte - b'a' + 26,
            b'0'..=b'9' => byte - b'0' + 52,
            b'+' => 62,
            b'/' => 63,
            b'=' => {
                padded = true;
                continue;
            }
            b' ' | b'\t' | b'\r' | b'\n' => continue,
            _ => return None,
        };
        if padded {
            return None;
        }
        bits = (bits << 6 | u32::from(digit)) & 0xFFFF;
        count += 6;
        if count >= 8 {
            count -= 8;
            out.push((bits >> count) as u8);
        }
    }
    Some(out)
}

#[derive(Debug, PartialEq)]
struct Request {
    key: Option<String>,
    value: Option<String>,
}

/// The request is JSON.stringify of a flat object, so this reads exactly that: an
/// object whose members are strings or null. Anything else is refused.
fn parse_request(text: &str) -> Option<Request> {
    let mut json = Json(text.chars().peekable());
    let mut request = Request { key: None, value: None };
    json.eat('{')?;
    json.skip_space();
    if json.0.peek() == Some(&'}') {
        json.0.next();
    } else {
        loop {
            json.eat('"')?;
            let name = json.string()?;
            json.eat(':')?;
            json.skip_space();
            let value = if json.0.peek() == Some(&'n') {
                "null".chars().try_for_each(|c| (json.0.next()? == c).then_some(()))?;
                None
            } else {
                json.eat('"')?;
                Some(json.string()?)
            };
            match name.as_str() {
                "key" => request.key = value,
                "value" => request.value = value,
                _ => {}
            }
            json.skip_space();
            match json.0.next()? {
                ',' => continue,
                '}' => break,
                _ => return None,
            }
        }
    }
    json.skip_space();
    json.0.next().is_none().then_some(request)
}

struct Json<'a>(Peekable<Chars<'a>>);

impl Json<'_> {
    fn skip_space(&mut self) {
        while matches!(self.0.peek(), Some(' ' | '\t' | '\n' | '\r')) {
            self.0.next();
        }
    }

    fn eat(&mut self, expected: char) -> Option<()> {
        self.skip_space();
        (self.0.next()? == expected).then_some(())
    }

    /// The rest of a string whose opening quote is read.
    fn string(&mut self) -> Option<String> {
        let mut out = String::new();
        loop {
            match self.0.next()? {
                '"' => return Some(out),
                '\\' => out.push(match self.0.next()? {
                    '"' => '"',
                    '\\' => '\\',
                    '/' => '/',
                    'b' => '\u{8}',
                    'f' => '\u{c}',
                    'n' => '\n',
                    'r' => '\r',
                    't' => '\t',
                    'u' => self.escaped_char()?,
                    _ => return None,
                }),
                c if (c as u32) < 0x20 => return None,
                c => out.push(c),
            }
        }
    }

    /// `\uXXXX`, or two of them for a character outside the BMP. A lone surrogate
    /// is no character and is refused.
    fn escaped_char(&mut self) -> Option<char> {
        let high = self.hex4()?;
        if !(0xD800..0xDC00).contains(&high) {
            return char::from_u32(high);
        }
        if self.0.next()? != '\\' || self.0.next()? != 'u' {
            return None;
        }
        let low = self.hex4()?;
        if !(0xDC00..0xE000).contains(&low) {
            return None;
        }
        char::from_u32(0x10000 + ((high - 0xD800) << 10) + (low - 0xDC00))
    }

    fn hex4(&mut self) -> Option<u32> {
        (0..4).try_fold(0, |n, _| Some(n * 16 + self.0.next()?.to_digit(16)?))
    }
}

fn run() -> Result<String, ()> {
    let mut input = Vec::new();
    io::stdin().take(MAX_REQUEST_BYTES + 1).read_to_end(&mut input).map_err(drop)?;
    if input.len() as u64 > MAX_REQUEST_BYTES {
        return Err(());
    }
    // A PowerShell pipe set to UTF-8 starts with a BOM. The backend sends none.
    let input = input.strip_prefix(b"\xEF\xBB\xBF").unwrap_or(&input);
    let request = base64_decode(input)
        .and_then(|bytes| String::from_utf8(bytes).ok())
        .and_then(|text| parse_request(&text))
        .ok_or(())?;
    if let Some(key) = request.key {
        let value = request.value.unwrap_or_default();
        if !KEYS.contains(&key.as_str()) || value.contains('\0') || value.encode_utf16().count() >= MAX_VALUE_UNITS {
            return Err(());
        }
        write(USER, &key, &value)?;
        broadcast_environment_change();
    }
    snapshot(USER, MACHINE)
}

pub fn main() -> ! {
    if let Ok(output) = run() {
        let mut stdout = io::stdout().lock();
        if stdout.write_all(output.as_bytes()).and_then(|()| stdout.flush()).is_ok() {
            process::exit(0);
        }
    }
    let _ = io::stderr().write_all(b"Windows user environment operation failed.");
    process::exit(1)
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::env;

    #[link(name = "advapi32")]
    extern "system" {
        fn RegCreateKeyExW(
            key: Hkey,
            sub_key: *const u16,
            reserved: u32,
            class: *const u16,
            options: u32,
            desired: u32,
            attributes: *const c_void,
            result: *mut Hkey,
            disposition: *mut u32,
        ) -> i32;
        fn RegDeleteTreeW(key: Hkey, sub_key: *const u16) -> i32;
    }

    const KEY_ALL_ACCESS: u32 = 0xF003F;
    const REG_DWORD: u32 = 4;

    /// A throwaway HKCU key standing in for HKCU\Environment, so the tests never
    /// touch the variables of the user running them. Deleted with everything in it.
    struct Scratch(String);

    impl Scratch {
        fn new(name: &str) -> Scratch {
            let path = format!(r"Software\ai-bridge-job-test-{}-{name}", process::id());
            let mut key = null_mut();
            // SAFETY: plain registry calls on NUL-terminated buffers.
            unsafe {
                let status = RegCreateKeyExW(
                    HKEY_CURRENT_USER,
                    wide(&path).as_ptr(),
                    0,
                    std::ptr::null(),
                    0,
                    KEY_ALL_ACCESS,
                    std::ptr::null(),
                    &mut key,
                    null_mut(),
                );
                assert_eq!(status, ERROR_SUCCESS, "scratch key created");
                RegCloseKey(key);
            }
            Scratch(path)
        }

        fn location(&self) -> Location<'_> {
            Location { root: HKEY_CURRENT_USER, path: &self.0 }
        }

        fn set_raw(&self, name: &str, kind: u32, data: &[u8]) {
            let key = Key::open(self.location(), KEY_SET_VALUE).unwrap().unwrap();
            // SAFETY: `data` outlives the call and `size` is its length.
            let status =
                unsafe { RegSetValueExW(key.0, wide(name).as_ptr(), 0, kind, data.as_ptr(), data.len() as u32) };
            assert_eq!(status, ERROR_SUCCESS);
        }

        fn read(&self, name: &str) -> Option<String> {
            Key::open(self.location(), KEY_QUERY_VALUE).unwrap().unwrap().read(name).unwrap()
        }
    }

    impl Drop for Scratch {
        fn drop(&mut self) {
            // SAFETY: deletes the key this test created, and nothing else.
            unsafe { RegDeleteTreeW(HKEY_CURRENT_USER, wide(&self.0).as_ptr()) };
        }
    }

    fn utf16_bytes(value: &str) -> Vec<u8> {
        wide(value).iter().flat_map(|unit| unit.to_le_bytes()).collect()
    }

    #[test]
    fn writes_reads_and_deletes_like_set_environment_variable() {
        let scratch = Scratch::new("write");
        let value = "fixture ç 😀 %PATH% \"quoted\" $() ` & |";
        write(scratch.location(), "ANTHROPIC_MODEL", value).unwrap();
        assert_eq!(scratch.read("ANTHROPIC_MODEL").as_deref(), Some(value));
        write(scratch.location(), "ANTHROPIC_MODEL", "").unwrap();
        assert_eq!(scratch.read("ANTHROPIC_MODEL"), None);
        // Clearing what is not there is no error, as in .NET.
        write(scratch.location(), "ANTHROPIC_MODEL", "").unwrap();
    }

    #[test]
    fn expands_reg_expand_sz_and_reads_other_types_as_null() {
        let scratch = Scratch::new("kinds");
        scratch.set_raw("EXPANDED", REG_EXPAND_SZ, &utf16_bytes(r"%SystemRoot%\x"));
        scratch.set_raw("NUMBER", REG_DWORD, &7u32.to_le_bytes());
        // Stored without its terminator, which the registry allows.
        scratch.set_raw("BARE", REG_SZ, &utf16_bytes("bare")[..8]);
        let root = env::var("SystemRoot").unwrap();
        assert_eq!(scratch.read("EXPANDED"), Some(format!(r"{root}\x")));
        assert_eq!(scratch.read("NUMBER"), None);
        assert_eq!(scratch.read("BARE").as_deref(), Some("bare"));
        assert_eq!(scratch.read("MISSING"), None);
    }

    #[test]
    fn reads_values_longer_than_the_first_buffer() {
        let scratch = Scratch::new("long");
        let value = "x".repeat(MAX_VALUE_UNITS - 1);
        write(scratch.location(), "ANTHROPIC_AUTH_TOKEN", &value).unwrap();
        assert_eq!(scratch.read("ANTHROPIC_AUTH_TOKEN"), Some(value));
    }

    #[test]
    fn snapshots_both_locations_as_json() {
        let user = Scratch::new("user");
        let machine = Scratch::new("machine");
        write(user.location(), "ANTHROPIC_BASE_URL", "https://office.example/\"q\"").unwrap();
        write(machine.location(), "ANTHROPIC_MODEL", "line\nbreak").unwrap();
        assert_eq!(
            snapshot(user.location(), machine.location()).unwrap(),
            concat!(
                r#"{"values":{"ANTHROPIC_AUTH_TOKEN":null,"ANTHROPIC_BASE_URL":"https://office.example/\"q\"","ANTHROPIC_MODEL":null},"#,
                r#""machine":{"ANTHROPIC_AUTH_TOKEN":null,"ANTHROPIC_BASE_URL":null,"ANTHROPIC_MODEL":"line\u000abreak"}}"#,
            )
        );
        let missing = Location { root: HKEY_CURRENT_USER, path: r"Software\ai-bridge-job-test-missing-key" };
        assert!(snapshot(missing, missing).unwrap().matches("null").count() == 6);
    }

    /// The real locations, through variables Windows always sets.
    #[test]
    fn reads_the_real_user_and_machine_environment() {
        let machine = Key::open(MACHINE, KEY_QUERY_VALUE).unwrap().unwrap();
        assert_eq!(machine.read("OS").unwrap().as_deref(), Some("Windows_NT"));
        let comspec = machine.read("ComSpec").unwrap().unwrap();
        assert!(comspec.to_lowercase().ends_with(r"\system32\cmd.exe") && !comspec.contains('%'));
        let user = Key::open(USER, KEY_QUERY_VALUE).unwrap().unwrap();
        assert!(user.read("TEMP").unwrap().is_some_and(|temp| !temp.contains('%')));
    }

    #[test]
    fn decodes_base64() {
        assert_eq!(base64_decode(b"").unwrap(), b"");
        assert_eq!(base64_decode(b"Zg==").unwrap(), b"f");
        assert_eq!(base64_decode(b"Zm8=").unwrap(), b"fo");
        assert_eq!(base64_decode(b"Zm9vYmFy\r\n").unwrap(), b"foobar");
        assert_eq!(base64_decode(b"w6f/+A==").unwrap(), [0xC3, 0xA7, 0xFF, 0xF8]);
        assert_eq!(base64_decode(b"Zg==Zg"), None);
        assert_eq!(base64_decode(b"Zm9v!"), None);
    }

    #[test]
    fn parses_what_json_stringify_writes() {
        let request = |key: Option<&str>, value: Option<&str>| Request { key: key.map(Into::into), value: value.map(Into::into) };
        assert_eq!(parse_request("{}"), Some(request(None, None)));
        assert_eq!(parse_request(" { } "), Some(request(None, None)));
        assert_eq!(
            parse_request(r#"{"key":"ANTHROPIC_MODEL","value":"m"}"#),
            Some(request(Some("ANTHROPIC_MODEL"), Some("m")))
        );
        assert_eq!(
            parse_request(r#"{"value":"\"\\\/\b\f\n\r\tç😀 ç😀","key":null,"other":"x"}"#),
            Some(request(None, Some("\"\\/\u{8}\u{c}\n\r\tç😀 ç😀")))
        );
        for refused in [
            "",
            "[]",
            r#"{"key":1}"#,
            r#"{"key":"a""#,
            r#"{"key":"a",}"#,
            r#"{"key":"a"} x"#,
            r#"{"key":"\ud83d"}"#,
            r#"{"key":"\x"}"#,
            "{\"key\":\"a\nb\"}",
            r#"{"key":nul}"#,
        ] {
            assert_eq!(parse_request(refused), None, "{refused:?}");
        }
    }
}
