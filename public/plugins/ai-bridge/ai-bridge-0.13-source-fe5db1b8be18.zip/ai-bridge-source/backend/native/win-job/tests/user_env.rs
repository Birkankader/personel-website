//! Drives `--user-env` the way windows-user-env.ts does: the request as base64 JSON
//! on stdin. Only requests that cannot write are sent here; the write path runs
//! against a scratch key in the unit tests, so the variables of whoever runs the
//! tests are never touched. Outputs are checked, never printed: a real snapshot can
//! hold the user's token.
#![cfg(windows)]

use std::io::Write;
use std::process::{Command, Output, Stdio};

const HELPER: &str = env!("CARGO_BIN_EXE_ai-bridge-job");
const FAILED: &str = "Windows user environment operation failed.";

fn base64(bytes: &[u8]) -> String {
    const DIGITS: &[u8; 64] = b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let mut out = String::new();
    for chunk in bytes.chunks(3) {
        let n = chunk.iter().enumerate().fold(0u32, |n, (i, &b)| n | u32::from(b) << (16 - 8 * i));
        for i in 0..4 {
            out.push(if i <= chunk.len() { DIGITS[(n >> (18 - 6 * i) & 63) as usize] as char } else { '=' });
        }
    }
    out
}

fn user_env(stdin: &str) -> Output {
    let mut child = Command::new(HELPER)
        .arg("--user-env")
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("helper starts");
    child.stdin.take().unwrap().write_all(stdin.as_bytes()).unwrap();
    child.wait_with_output().unwrap()
}

#[test]
fn reads_both_environments_as_json() {
    let out = user_env(&base64(b"{}"));
    let stdout = String::from_utf8(out.stdout).expect("UTF-8 output");
    assert_eq!(out.status.code(), Some(0));
    assert!(out.stderr.is_empty());
    assert!(stdout.starts_with(r#"{"values":{"ANTHROPIC_AUTH_TOKEN":"#), "output starts with the user values");
    assert!(stdout.contains(r#"},"machine":{"ANTHROPIC_AUTH_TOKEN":"#), "output carries the machine values");
    assert!(stdout.ends_with("}}"), "output is one object");
}

#[test]
fn refuses_other_variables_without_echoing_the_value() {
    for key in ["PATH", "anthropic_model", "ANTHROPIC_MODEL "] {
        let request = format!(r#"{{"key":"{key}","value":"ccg-secret-fixture"}}"#);
        let out = user_env(&base64(request.as_bytes()));
        assert_eq!(out.status.code(), Some(1), "{key:?} refused");
        assert!(out.stdout.is_empty());
        assert_eq!(String::from_utf8_lossy(&out.stderr), FAILED);
    }
}

#[test]
fn refuses_requests_it_cannot_read() {
    let too_long = format!(r#"{{"key":"ANTHROPIC_MODEL","value":"{}"}}"#, "x".repeat(32767));
    let with_nul = r#"{"key":"ANTHROPIC_MODEL","value":"a\u0000b"}"#;
    for stdin in ["", "not base64!", &base64(b"not json"), &base64(too_long.as_bytes()), &base64(with_nul.as_bytes())] {
        let out = user_env(stdin);
        assert_eq!(out.status.code(), Some(1));
        assert!(out.stdout.is_empty());
        assert_eq!(String::from_utf8_lossy(&out.stderr), FAILED);
    }
}
