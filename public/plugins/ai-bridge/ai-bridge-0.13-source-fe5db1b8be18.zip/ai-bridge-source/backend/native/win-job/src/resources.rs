//! On-demand counters for selected CLI trees. No timer, command lines, process
//! mutation, or elevation. Unreadable counters stay null instead of becoming zero.
use std::collections::{HashMap, HashSet};
use std::ffi::c_void;
use std::io::{self, Write};
use std::mem::{size_of, zeroed};
use std::process;

type Handle = *mut c_void;
const PROCESS_QUERY_LIMITED_INFORMATION: u32 = 0x1000;

#[repr(C)]
#[derive(Default)]
struct FileTime { low: u32, high: u32 }
impl FileTime {
    fn ticks(&self) -> u64 { (u64::from(self.high) << 32) | u64::from(self.low) }
}

#[repr(C)]
#[allow(non_camel_case_types, non_snake_case)]
struct PROCESS_MEMORY_COUNTERS {
    cb: u32,
    PageFaultCount: u32,
    PeakWorkingSetSize: usize,
    WorkingSetSize: usize,
    QuotaPeakPagedPoolUsage: usize,
    QuotaPagedPoolUsage: usize,
    QuotaPeakNonPagedPoolUsage: usize,
    QuotaNonPagedPoolUsage: usize,
    PagefileUsage: usize,
    PeakPagefileUsage: usize,
}

#[cfg(target_pointer_width = "64")]
const _: () = {
    assert!(size_of::<PROCESS_MEMORY_COUNTERS>() == 72);
    assert!(size_of::<FileTime>() == 8);
};

#[link(name = "kernel32")]
extern "system" {
    fn OpenProcess(access: u32, inherit: i32, pid: u32) -> Handle;
    fn CloseHandle(handle: Handle) -> i32;
    fn GetProcessTimes(process: Handle, creation: *mut FileTime, exit: *mut FileTime,
        kernel: *mut FileTime, user: *mut FileTime) -> i32;
    fn K32GetProcessMemoryInfo(process: Handle, counters: *mut PROCESS_MEMORY_COUNTERS, size: u32) -> i32;
}

struct Counters { rss_bytes: Option<usize>, cpu_seconds: Option<f64>, identity: Option<u64> }

fn counters(pid: u32) -> Counters {
    let mut result = Counters { rss_bytes: None, cpu_seconds: None, identity: None };
    // SAFETY: read-only process handle, sized SDK counter layout and FILETIME
    // outputs. Every successful OpenProcess handle is closed before returning.
    unsafe {
        let handle = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, 0, pid);
        if handle.is_null() { return result; }
        let (mut creation, mut exit, mut kernel, mut user) =
            (FileTime::default(), FileTime::default(), FileTime::default(), FileTime::default());
        if GetProcessTimes(handle, &mut creation, &mut exit, &mut kernel, &mut user) != 0 {
            result.identity = Some(creation.ticks());
            result.cpu_seconds = Some(kernel.ticks() as f64 / 10_000_000.0 + user.ticks() as f64 / 10_000_000.0);
        }
        let mut memory: PROCESS_MEMORY_COUNTERS = zeroed();
        memory.cb = size_of::<PROCESS_MEMORY_COUNTERS>() as u32;
        if K32GetProcessMemoryInfo(handle, &mut memory, size_of::<PROCESS_MEMORY_COUNTERS>() as u32) != 0 {
            result.rss_bytes = Some(memory.WorkingSetSize);
        }
        CloseHandle(handle);
    }
    result
}

fn selected_tree(entries: &[(u32, u32)], roots: &[u32]) -> Vec<(u32, u32)> {
    let by_pid: HashMap<u32, u32> = entries.iter().copied().collect();
    let mut by_parent: HashMap<u32, Vec<u32>> = HashMap::new();
    for &(pid, ppid) in entries { by_parent.entry(ppid).or_default().push(pid); }
    let mut seen = HashSet::new();
    let mut pending = roots.to_vec();
    let mut result = Vec::new();
    while let Some(pid) = pending.pop() {
        if !seen.insert(pid) { continue; }
        if let Some(&ppid) = by_pid.get(&pid) { result.push((pid, ppid)); }
        if let Some(children) = by_parent.get(&pid) { pending.extend(children); }
    }
    result
}

fn scan(roots: &[u32]) -> Option<String> {
    let entries = crate::processes::process_entries()?;
    let mut output = String::from("[");
    for (index, (pid, ppid)) in selected_tree(&entries, roots).into_iter().enumerate() {
        if index > 0 { output.push(','); }
        let counter = counters(pid);
        let rss = counter.rss_bytes.map(|v| v.to_string()).unwrap_or_else(|| "null".into());
        let cpu = counter.cpu_seconds.map(|v| format!("{v:.7}")).unwrap_or_else(|| "null".into());
        // Creation FILETIME exceeds JavaScript's exact integer range: carry it as
        // an opaque string so reused PIDs never share a CPU-delta history.
        let identity = counter.identity.map(|v| format!("\"{v}\"")).unwrap_or_else(|| "null".into());
        output.push_str(&format!("{{\"pid\":{pid},\"ppid\":{ppid},\"rssBytes\":{rss},\"cpuSeconds\":{cpu},\"identity\":{identity}}}"));
    }
    output.push(']');
    Some(output)
}

pub fn main() -> ! {
    let parsed: Result<Vec<u32>, _> = std::env::args().skip(2).map(|arg| arg.parse()).collect();
    if let Ok(roots) = parsed {
        if !roots.is_empty() && roots.len() <= 128 && roots.iter().all(|pid| *pid > 0) {
            if let Some(output) = scan(&roots) {
                let mut stdout = io::stdout().lock();
                if stdout.write_all(output.as_bytes()).and_then(|()| stdout.flush()).is_ok() {
                    process::exit(0);
                }
            }
        }
    }
    let _ = writeln!(io::stderr(), "[ccg-job] could not read process resources");
    process::exit(1)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn reads_own_working_set_and_cpu_without_elevation() {
        let data = vec![1u8; 8 * 1024 * 1024];
        std::hint::black_box(&data);
        let sample = counters(process::id());
        assert!(sample.rss_bytes.unwrap() > data.len());
        assert!(sample.cpu_seconds.unwrap() >= 0.0);
        assert!(sample.identity.unwrap() > 0);
    }

    #[test]
    fn unavailable_process_has_no_invented_zero_counters() {
        let sample = counters(0);
        assert!(sample.rss_bytes.is_none());
        assert!(sample.cpu_seconds.is_none());
    }

    #[test]
    fn selected_trees_are_deduplicated_and_cycles_terminate() {
        let entries = [(10, 1), (11, 10), (12, 11), (20, 1), (30, 31), (31, 30)];
        let mut selected = selected_tree(&entries, &[10, 11, 30]);
        selected.sort();
        assert_eq!(selected, vec![(10, 1), (11, 10), (12, 11), (30, 31), (31, 30)]);
    }

    #[test]
    fn a_scan_only_reports_the_requested_tree() {
        let output = scan(&[process::id()]).unwrap();
        assert!(output.starts_with(&format!("[{{\"pid\":{},", process::id())));
        assert!(output.contains("\"rssBytes\":"));
        assert!(!output.contains("CommandLine"));
    }
}
