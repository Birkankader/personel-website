//! ai-bridge-job: the win32 Job Object wrapper the backend starts in front of every
//! chat CLI. It is the native twin of win-job-wrapper.ps1, which stays as the
//! fallback (backend/src/core/win-job.ts picks one): the same contract, without a
//! PowerShell process (~85 MB) held open for each chat.
//!
//! Why a job at all: win32 has no process groups. `taskkill /F /T` walks the LIVE
//! parent-child tree, but git-bash (MSYS) starts its workers under a fork helper that
//! exits at once, so they drop out of the cmd->claude->bash tree and survive every
//! tree kill as orphans that keep running (and billing). A Job Object with
//! KILL_ON_JOB_CLOSE keeps every descendant regardless of reparenting. When this
//! process dies (killed by the backend, or together with it), the last job handle
//! closes and the kernel tears the whole tree down.
//!
//! Contract with the backend (win-job.ts), identical to the PowerShell wrapper's:
//!   - AI_BRIDGE_JOB_CMDLINE holds the command line cmd.exe runs, as `/d /s /c "<it>"`.
//!   - argv[1] is the sessionId, carried ONLY so the registry's orphan sweep can find
//!     and kill this process. The helper ignores it.
//!   - Nothing on stdout: the backend reads the child's stdout as the stream-json
//!     protocol. Only genuine errors go to stderr.
//!   - The exit code is the CLI's. 210 = AI_BRIDGE_JOB_CMDLINE is missing, 211 = the
//!     CLI could not be started.
//!   - `--probe` in place of the sessionId: create a job and exit 0 (3 when the job
//!     API is unavailable). The backend runs it once to learn whether the helper can
//!     run on this machine at all before it trusts a chat to it.
//!
//! One deliberate difference from the PowerShell wrapper: the CLI is created
//! suspended and put in the job before it runs, so not even its first child can
//! escape. The wrapper assigns it after Process.Start. Everything else is the same
//! on purpose, down to the wording of the `[ccg-job]` lines on stderr: cmd.exe is
//! started by absolute path (%ComSpec% when absolute, else the System32 copy), and
//! a CLI that cannot be started is exit 211.
//!
//! Two other jobs take the sessionId's place, each the native twin of a PowerShell
//! script the backend keeps as its fallback:
//!   - `--user-env`: the Windows user environment read and write of
//!     windows-user-env.ts (user_env.rs).
//!   - `--processes`: the process list with command lines that the CLI registry's
//!     identity checks read through windows-processes.ts (processes.rs).
//!   - `--resources <pid>...`: working set and cumulative CPU for the requested
//!     process trees, without reading command lines (resources.rs).

#[cfg(windows)]
mod json;
#[cfg(windows)]
mod processes;
#[cfg(windows)]
mod resources;
#[cfg(windows)]
mod user_env;

#[cfg(windows)]
fn main() {
    match std::env::args_os().nth(1).as_deref().and_then(|arg| arg.to_str()) {
        Some("--user-env") => user_env::main(),
        Some("--processes") => processes::main(),
        Some("--resources") => resources::main(),
        _ => win::main(),
    }
}

#[cfg(not(windows))]
fn main() {
    eprintln!("[ccg-job] ai-bridge-job only runs on Windows");
    std::process::exit(1);
}

#[cfg(windows)]
mod win {
    use std::env;
    use std::ffi::{c_void, OsStr, OsString};
    use std::io::{self, Write};
    use std::mem::{size_of, zeroed};
    use std::os::windows::ffi::OsStrExt;
    use std::path::Path;
    use std::process;
    use std::ptr::{null, null_mut};

    const EXIT_NO_CMDLINE: i32 = 210;
    const EXIT_START_FAILED: i32 = 211;
    const EXIT_PROBE_NO_JOB: i32 = 3;

    type Handle = *mut c_void;
    type Bool = i32;

    const INVALID_HANDLE_VALUE: Handle = -1isize as Handle;
    const STD_INPUT_HANDLE: u32 = -10i32 as u32;
    const STD_OUTPUT_HANDLE: u32 = -11i32 as u32;
    const STD_ERROR_HANDLE: u32 = -12i32 as u32;
    const DUPLICATE_SAME_ACCESS: u32 = 0x2;
    const STARTF_USESTDHANDLES: u32 = 0x100;
    const CREATE_SUSPENDED: u32 = 0x4;
    const INFINITE: u32 = 0xFFFF_FFFF;
    const JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE: u32 = 0x2000;
    const JOB_OBJECT_EXTENDED_LIMIT_INFORMATION_CLASS: i32 = 9;

    // Win32 layouts, named as in the SDK headers so they can be checked against them.
    #[repr(C)]
    #[allow(non_camel_case_types, non_snake_case)]
    struct JOBOBJECT_BASIC_LIMIT_INFORMATION {
        PerProcessUserTimeLimit: i64,
        PerJobUserTimeLimit: i64,
        LimitFlags: u32,
        MinimumWorkingSetSize: usize,
        MaximumWorkingSetSize: usize,
        ActiveProcessLimit: u32,
        Affinity: usize,
        PriorityClass: u32,
        SchedulingClass: u32,
    }

    #[repr(C)]
    #[allow(non_camel_case_types, non_snake_case)]
    struct IO_COUNTERS {
        ReadOperationCount: u64,
        WriteOperationCount: u64,
        OtherOperationCount: u64,
        ReadTransferCount: u64,
        WriteTransferCount: u64,
        OtherTransferCount: u64,
    }

    #[repr(C)]
    #[allow(non_camel_case_types, non_snake_case)]
    struct JOBOBJECT_EXTENDED_LIMIT_INFORMATION {
        BasicLimitInformation: JOBOBJECT_BASIC_LIMIT_INFORMATION,
        IoInfo: IO_COUNTERS,
        ProcessMemoryLimit: usize,
        JobMemoryLimit: usize,
        PeakProcessMemoryUsed: usize,
        PeakJobMemoryUsed: usize,
    }

    #[repr(C)]
    #[allow(non_camel_case_types, non_snake_case, clippy::upper_case_acronyms)]
    struct STARTUPINFOW {
        cb: u32,
        lpReserved: *mut u16,
        lpDesktop: *mut u16,
        lpTitle: *mut u16,
        dwX: u32,
        dwY: u32,
        dwXSize: u32,
        dwYSize: u32,
        dwXCountChars: u32,
        dwYCountChars: u32,
        dwFillAttribute: u32,
        dwFlags: u32,
        wShowWindow: u16,
        cbReserved2: u16,
        lpReserved2: *mut u8,
        hStdInput: Handle,
        hStdOutput: Handle,
        hStdError: Handle,
    }

    #[repr(C)]
    #[allow(non_camel_case_types, non_snake_case)]
    struct PROCESS_INFORMATION {
        hProcess: Handle,
        hThread: Handle,
        dwProcessId: u32,
        dwThreadId: u32,
    }

    // The sizes the SDK gives on 64-bit Windows. A wrong field here would hand the
    // kernel a misread struct, so a mismatch fails the build instead.
    #[cfg(target_pointer_width = "64")]
    const _: () = {
        assert!(size_of::<JOBOBJECT_BASIC_LIMIT_INFORMATION>() == 64);
        assert!(size_of::<JOBOBJECT_EXTENDED_LIMIT_INFORMATION>() == 144);
        assert!(size_of::<STARTUPINFOW>() == 104);
        assert!(size_of::<PROCESS_INFORMATION>() == 24);
    };

    #[link(name = "kernel32")]
    extern "system" {
        fn CreateJobObjectW(attributes: *const c_void, name: *const u16) -> Handle;
        fn SetInformationJobObject(job: Handle, class: i32, info: *const c_void, length: u32) -> Bool;
        fn AssignProcessToJobObject(job: Handle, process: Handle) -> Bool;
        fn CreateProcessW(
            application: *const u16,
            command_line: *mut u16,
            process_attributes: *const c_void,
            thread_attributes: *const c_void,
            inherit_handles: Bool,
            creation_flags: u32,
            environment: *const c_void,
            current_directory: *const u16,
            startup_info: *const STARTUPINFOW,
            process_information: *mut PROCESS_INFORMATION,
        ) -> Bool;
        fn ResumeThread(thread: Handle) -> u32;
        fn TerminateProcess(process: Handle, exit_code: u32) -> Bool;
        fn WaitForSingleObject(handle: Handle, milliseconds: u32) -> u32;
        fn GetExitCodeProcess(process: Handle, exit_code: *mut u32) -> Bool;
        fn GetStdHandle(which: u32) -> Handle;
        fn GetCurrentProcess() -> Handle;
        fn DuplicateHandle(
            source_process: Handle,
            source: Handle,
            target_process: Handle,
            target: *mut Handle,
            desired_access: u32,
            inherit: Bool,
            options: u32,
        ) -> Bool;
        fn CloseHandle(handle: Handle) -> Bool;
    }

    /// stderr only, and never a panic: a broken stderr must not take the CLI down.
    fn log(message: &str) {
        let _ = writeln!(io::stderr(), "[ccg-job] {message}");
    }

    fn last_error() -> i32 {
        io::Error::last_os_error().raw_os_error().unwrap_or(0)
    }

    fn wide(value: &OsStr) -> Vec<u16> {
        value.encode_wide().chain(Some(0)).collect()
    }

    /// A job whose last closed handle kills every process in it, or None when the
    /// job API is unavailable. The handle is never closed by us: process exit closes
    /// it, and that is the moment the tree has to go.
    fn create_kill_on_close_job() -> Option<Handle> {
        // SAFETY: plain kernel32 calls. `info` is a zeroed, correctly sized struct
        // that outlives the call, and the handle is closed on the failure path only.
        unsafe {
            let job = CreateJobObjectW(null(), null());
            if job.is_null() {
                return None;
            }
            let mut info: JOBOBJECT_EXTENDED_LIMIT_INFORMATION = zeroed();
            info.BasicLimitInformation.LimitFlags = JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE;
            let set = SetInformationJobObject(
                job,
                JOB_OBJECT_EXTENDED_LIMIT_INFORMATION_CLASS,
                &info as *const _ as *const c_void,
                size_of::<JOBOBJECT_EXTENDED_LIMIT_INFORMATION>() as u32,
            );
            if set == 0 {
                CloseHandle(job);
                return None;
            }
            Some(job)
        }
    }

    /// One of our std handles as the CLI gets it. `owned` marks a copy we made and
    /// close once the CLI has inherited it.
    struct StdHandle {
        handle: Handle,
        owned: bool,
    }

    /// An inheritable copy of one of our std handles, so the CLI's stdio is the
    /// backend's pipes byte for byte. When the copy fails, the handle itself: one we
    /// inherited is inheritable already. Null when we have none to give.
    fn inheritable_std_handle(which: u32) -> StdHandle {
        // SAFETY: duplicating our own valid std handle into our own process.
        unsafe {
            let handle = GetStdHandle(which);
            if handle.is_null() || handle == INVALID_HANDLE_VALUE {
                return StdHandle { handle: null_mut(), owned: false };
            }
            let mut copy = null_mut();
            let process = GetCurrentProcess();
            if DuplicateHandle(process, handle, process, &mut copy, 0, 1, DUPLICATE_SAME_ACCESS) == 0 {
                return StdHandle { handle, owned: false };
            }
            StdHandle { handle: copy, owned: true }
        }
    }

    /// %ComSpec% when it is an absolute path (what Node's shell:true runs), else the
    /// System32 copy, else a plain `cmd.exe` for CreateProcess to search.
    fn cmd_exe() -> OsString {
        if let Some(spec) = env::var_os("ComSpec") {
            if Path::new(&spec).is_absolute() {
                return spec;
            }
        }
        if let Some(root) = env::var_os("SystemRoot") {
            let path = Path::new(&root).join("System32").join("cmd.exe");
            if path.is_absolute() {
                return path.into_os_string();
            }
        }
        OsString::from("cmd.exe")
    }

    pub fn main() {
        if env::args_os().nth(1).as_deref() == Some(OsStr::new("--probe")) {
            process::exit(if create_kill_on_close_job().is_some() { 0 } else { EXIT_PROBE_NO_JOB });
        }

        let cmdline = match env::var_os("AI_BRIDGE_JOB_CMDLINE") {
            Some(value) if !value.is_empty() => value,
            _ => {
                log("AI_BRIDGE_JOB_CMDLINE not set");
                process::exit(EXIT_NO_CMDLINE);
            }
        };

        // A missing job only reopens the orphan gap. It must never block the chat.
        let job = create_kill_on_close_job();
        if job.is_none() {
            log(&format!("Job Object unavailable (error {}); running without the orphan guard", last_error()));
        }

        // `"<cmd>" /d /s /c "<cmdline>"`, the line the PowerShell wrapper's
        // Process.Start built: cmd resolves the claude launcher via PATHEXT exactly
        // as the pre-job spawn did.
        let cmd = cmd_exe();
        let mut line = OsString::from("\"");
        line.push(&cmd);
        line.push("\" /d /s /c \"");
        line.push(&cmdline);
        line.push("\"");
        let mut line = wide(&line);
        let application = if Path::new(&cmd).is_absolute() { Some(wide(&cmd)) } else { None };

        let stdio = [
            inheritable_std_handle(STD_INPUT_HANDLE),
            inheritable_std_handle(STD_OUTPUT_HANDLE),
            inheritable_std_handle(STD_ERROR_HANDLE),
        ];
        // SAFETY: zeroed is the documented initial state of STARTUPINFOW.
        let mut startup: STARTUPINFOW = unsafe { zeroed() };
        startup.cb = size_of::<STARTUPINFOW>() as u32;
        startup.dwFlags = STARTF_USESTDHANDLES;
        startup.hStdInput = stdio[0].handle;
        startup.hStdOutput = stdio[1].handle;
        startup.hStdError = stdio[2].handle;
        // SAFETY: zeroed is a valid PROCESS_INFORMATION for CreateProcessW to fill.
        let mut child: PROCESS_INFORMATION = unsafe { zeroed() };

        // SAFETY: every pointer is either null or a NUL-terminated buffer / struct that
        // lives until the call returns; `line` is mutable, as CreateProcessW requires.
        // The environment and working directory are inherited from this process.
        let created = unsafe {
            CreateProcessW(
                application.as_ref().map_or(null(), |path| path.as_ptr()),
                line.as_mut_ptr(),
                null(),
                null(),
                1,
                CREATE_SUSPENDED,
                null(),
                null(),
                &startup,
                &mut child,
            )
        };
        let start_error = last_error();
        for std_handle in stdio {
            if std_handle.owned {
                // SAFETY: our own copy, which the child has inherited by now.
                unsafe { CloseHandle(std_handle.handle) };
            }
        }
        if created == 0 {
            log(&format!("could not start {} (error {start_error})", cmd.to_string_lossy()));
            process::exit(EXIT_START_FAILED);
        }

        // SAFETY: `child` holds the valid handles CreateProcessW just returned.
        unsafe {
            // Non-fatal on failure: the helper must still outlive the CLI, or the
            // backend loses track of a running tree.
            if let Some(job) = job {
                if AssignProcessToJobObject(job, child.hProcess) == 0 {
                    log(&format!("could not add the CLI to the job (error {}); running without the orphan guard", last_error()));
                }
            }
            if ResumeThread(child.hThread) == u32::MAX {
                let error = last_error();
                TerminateProcess(child.hProcess, EXIT_START_FAILED as u32);
                log(&format!("could not resume the CLI (error {error})"));
                process::exit(EXIT_START_FAILED);
            }
            CloseHandle(child.hThread);

            WaitForSingleObject(child.hProcess, INFINITE);
            let mut code: u32 = 1;
            if GetExitCodeProcess(child.hProcess, &mut code) == 0 {
                code = 1;
            }
            // Exiting closes the job handle: whatever the CLI left behind goes with it.
            process::exit(code as i32);
        }
    }
}
