#![cfg(windows)]
use std::process::{Command, Stdio};

const HELPER: &str = env!("CARGO_BIN_EXE_ai-bridge-job");

#[test]
fn reports_only_a_requested_process_with_real_counters() {
    let mut child = Command::new("ping").args(["-n", "30", "127.0.0.1"])
        .stdout(Stdio::null()).spawn().unwrap();
    let output = Command::new(HELPER).args(["--resources", &child.id().to_string()]).output().unwrap();
    let _ = child.kill();
    let _ = child.wait();
    assert_eq!(output.status.code(), Some(0));
    assert!(output.stderr.is_empty());
    let text = String::from_utf8(output.stdout).unwrap();
    assert!(text.starts_with(&format!("[{{\"pid\":{},\"ppid\":{},", child.id(), std::process::id())), "{text}");
    assert!(!text.contains("null"), "own child's counters must be readable: {text}");
    assert!(!text.contains("CommandLine"));
}

#[test]
fn refuses_missing_or_invalid_roots_without_launching_a_cli() {
    for args in [vec!["--resources"], vec!["--resources", "-1"], vec!["--resources", "0"], vec!["--resources", "not-a-pid"]] {
        let output = Command::new(HELPER).args(args).output().unwrap();
        assert_eq!(output.status.code(), Some(1));
        assert!(output.stdout.is_empty());
    }
}
