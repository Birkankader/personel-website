//! The one piece of JSON writing the helper's commands share.

use std::fmt::Write as _;

/// `value` as a JSON string literal, appended to `out`.
pub fn push_string(out: &mut String, value: &str) {
    out.push('"');
    for c in value.chars() {
        match c {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            c if (c as u32) < 0x20 => {
                let _ = write!(out, "\\u{:04x}", c as u32);
            }
            c => out.push(c),
        }
    }
    out.push('"');
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn writes_json_strings() {
        let mut out = String::new();
        push_string(&mut out, "a\"b\\c\n\u{1}ç😀");
        assert_eq!(out, r#""a\"b\\c\u000a\u0001ç😀""#);
    }
}
