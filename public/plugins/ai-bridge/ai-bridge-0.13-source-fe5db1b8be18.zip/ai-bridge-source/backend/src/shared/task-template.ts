export interface TaskTemplate {
  id: string;
  name: string;
  prompt: string;
  model: string;
  effort: string | null;
  includeEditorContext: boolean;
  attachments: { path: string; name: string; type: 'file' | 'folder' }[];
}

export function validTaskTemplates(value: unknown): value is TaskTemplate[] {
  if (!Array.isArray(value) || value.length > 50) return false;
  const ids = new Set<string>();
  return value.every((v) => {
    if (!v || typeof v !== 'object') return false;
    if (typeof v.id !== 'string' || !v.id || v.id.length > 100 || ids.has(v.id)) return false;
    ids.add(v.id);
    return typeof v.name === 'string' && v.name.trim().length > 0 && v.name.length <= 100
      && typeof v.prompt === 'string' && v.prompt.length <= 100_000
      && typeof v.model === 'string' && v.model.length <= 200
      && (v.effort === null || ['auto', 'low', 'medium', 'high', 'xhigh', 'max'].includes(v.effort))
      && typeof v.includeEditorContext === 'boolean'
      && Array.isArray(v.attachments) && v.attachments.length <= 50
      && v.attachments.every((a: Record<string, unknown>) => a && (a.type === 'file' || a.type === 'folder')
        && typeof a.path === 'string' && a.path.length > 0 && a.path.length <= 4096 && !a.path.includes('\0')
        && typeof a.name === 'string' && a.name.length <= 256);
  });
}
