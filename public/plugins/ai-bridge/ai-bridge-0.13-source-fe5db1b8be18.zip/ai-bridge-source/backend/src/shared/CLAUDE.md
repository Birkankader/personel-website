# shared Folder Sync Rules

`webview/src/shared/` and `backend/src/shared/` are mirrors: they must keep **exactly the same contents**, byte for byte — `__tests__/` and this file included.

## Rules

1. When you modify a file in either folder, apply the same modification to the other one.
2. The file list, contents, and structure must always match 1:1. `backend/src/__tests__/shared-mirror.test.ts` fails when they drift.
3. Tests for shared code live in `__tests__/` on both sides, so each workspace runs them.
4. `message-type.ts` is also mirrored by the Kotlin `MessageType` object (`src/main/kotlin/com/birkankader/aibridge/bridge/MessageType.kt`); `MessageTypeParityTest` checks it.

## Purpose

Because backend and webview are separate pnpm workspaces, this is the convention for keeping shared types/enums identical on both sides.
