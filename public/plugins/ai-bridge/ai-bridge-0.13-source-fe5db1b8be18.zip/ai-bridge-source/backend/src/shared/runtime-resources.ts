export type RuntimeTaskState = 'queued' | 'starting' | 'running' | 'stopping' | 'completed' | 'cancelled' | 'failed';

export type QueuedAttachment =
  | { type: 'image'; fileName: string; mimeType: string; base64: string }
  | { type: 'file'; fileName: string; absolutePath: string }
  | { type: 'folder'; folderName: string; absolutePath: string };

/** Kept by the backend until admission; shared only with this session's views. */
export interface QueuedPrompt {
  content: string;
  attachments?: QueuedAttachment[];
  inputMode?: string;
  model?: string;
}

export interface QueuedMessage extends QueuedPrompt {
  sessionId: string;
  userMessageId: string;
}

export interface RuntimeTask {
  id: string;
  sessionId: string;
  workingDir: string;
  state: RuntimeTaskState;
  createdAt: number;
  startedAt?: number;
  error?: string;
  userMessageId?: string;
  replacedBy?: string;
  /** Written to the CLI, awaiting its consumption acknowledgement. */
  steering?: boolean;
}

export interface RuntimeTaskSnapshot {
  limit: number;
  tasks: RuntimeTask[];
  changedTask?: RuntimeTask;
}

export interface RuntimeProcessUsage {
  pid: number;
  sessionId?: string;
  workingDir?: string;
  cpuPercent: number | null;
  rssBytes: number | null;
  processCount: number;
}

export interface RuntimeResources extends RuntimeTaskSnapshot {
  sampledAt: number;
  connectedViews: number;
  backend: RuntimeProcessUsage;
  cli: RuntimeProcessUsage[];
  measurementError?: string;
}
