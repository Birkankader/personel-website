/**
 * Structured codes carried in an ERROR message's `payload.errorCode`, so the
 * webview can react to a failure by kind instead of parsing the human-readable
 * `error` string. Payload sub-classification (not an IPC envelope `type`), kept
 * as an enum so the same token is shared verbatim across backend and webview.
 *
 * NOTE: This file is mirrored 1:1 in `webview/src/shared/error-code.ts`.
 * Any edit here MUST be copied there (see `shared/CLAUDE.md`).
 */
export enum ErrorCode {
  /**
   * Carried in a SERVICE_ERROR payload (with `kind`, an `ApiFailureKind`) when
   * automatic recovery retried a temporary API failure as often as its budget
   * allows and the failure persists. The conversation is intact; the webview
   * offers a manual retry instead of showing the raw backend text.
   */
  API_RECOVERY_STOPPED = 'API_RECOVERY_STOPPED',
}
