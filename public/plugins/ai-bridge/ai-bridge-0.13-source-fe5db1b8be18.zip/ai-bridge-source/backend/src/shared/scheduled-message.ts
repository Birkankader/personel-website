/**
 * ScheduledMessage — a "send later" reservation bound to ONE chat session.
 *
 * This is the data contract for the generic scheduled-message engine (the
 * Slack-style "schedule send"): at `sendAt` the backend delivers `message` to
 * the session's Claude CLI process. Reservations are bound to a SESSION (not an
 * account) — a session may hold several independent reservations.
 *
 * A higher-level feature (e.g. "auto-resume") creates a reservation and tags it
 * with `kind` so the engine can pick the right pre-send hook. The engine itself
 * knows nothing about the domain decision (quota reset, etc.); that lives in the
 * hook the higher layer registers.
 *
 * Field names are preserved verbatim end-to-end (data-preservation rule in
 * CLAUDE.md): no renaming or structural editing between backend and webview.
 *
 * NOTE: This file is mirrored 1:1 in `webview/src/shared/scheduled-message.ts`.
 * Any edit here MUST be copied there (see `shared/CLAUDE.md`).
 */

/**
 * Which higher-level feature created a reservation. Used to select the pre-send
 * hook from the engine's per-kind registry. `AUTO_RESUME` is the first member;
 * more are added as new features build on the engine.
 */
export enum ScheduledMessageKind {
  /** Reservation created by the "auto-resume on limit reset" feature (layer 2). */
  AUTO_RESUME = 'AUTO_RESUME',
  /**
   * A plain "schedule send" the user created directly (from the command palette):
   * an arbitrary message to deliver at an arbitrary time. No pre-send hook is
   * registered for this kind, so the engine falls back to always-proceed and just
   * delivers `message` at `sendAt` — the Slack-style scheduled send.
   */
  USER_SCHEDULED = 'USER_SCHEDULED',
}

/** Progress of the reported-reset timed retry; no phase guarantees quota availability. */
export enum AutoResumeStatusPhase {
  /** Legacy waiting phase retained for protocol compatibility. */
  RETRYING = 'RETRYING',
  /** The scheduled time arrived; a normal continue is being delivered. */
  PROCEEDING = 'PROCEEDING',
  /** The local hook or send admission failed; an admission failure retains the reservation. */
  FAILED = 'FAILED',
}

export interface ScheduledMessage {
  /** Reservation id (unique per reservation). */
  id: string;
  /** The session this reservation is bound to. */
  sessionId: string;
  /** ISO 8601 timestamp at which the message should be sent. */
  sendAt: string;
  /** The message to deliver at `sendAt` (e.g. "continue"). */
  message: string;
  /** Which higher-level feature created this reservation (selects the pre-send hook). */
  kind: ScheduledMessageKind;
  /** ISO 8601 timestamp at which the reservation was created. */
  createdAt: string;
  /**
   * The webview tab (panelId) that created this reservation, when known. At send
   * time the engine prefers delivering through this exact tab (it's the tab the
   * user set the reservation from, so it best matches "a person sending from that
   * window"); if that tab is gone, delivery falls back to another tab on the
   * session, then the most-recently-focused tab. Optional: standalone/browser
   * tabs may not carry a panelId, and older reservations predate this field.
   */
  panelId?: string;
}
