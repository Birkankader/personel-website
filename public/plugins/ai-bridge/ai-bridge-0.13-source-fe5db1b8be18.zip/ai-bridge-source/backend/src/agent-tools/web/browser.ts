import { spawn, type ChildProcess } from 'child_process';
import { existsSync } from 'fs';
import { mkdtemp, readdir, readFile, rm } from 'fs/promises';
import { tmpdir, userInfo } from 'os';
import { join, posix, win32 } from 'path';
import WebSocket from 'ws';

/**
 * A headless Chrome or Edge driven over the Chrome DevTools Protocol, for the
 * web tools (server.ts).
 *
 * The browser is the one already installed (every Windows has Edge), so nothing
 * is downloaded, and the protocol is its own documented one. It runs with a
 * throwaway profile and renders on the CPU (SwiftShader), so pages and shaders
 * draw the same on a PC without a GPU as on one with it.
 */

/** Where Chrome, Edge or Chromium may be installed, most likely first. AI_BRIDGE_BROWSER names one outright. */
export function browserCandidates(platform: NodeJS.Platform = process.platform, env: NodeJS.ProcessEnv = process.env): string[] {
  const override = env.AI_BRIDGE_BROWSER?.trim();
  if (override) return [override];
  if (platform === 'win32') {
    const roots = [env.ProgramFiles ?? env.PROGRAMFILES, env['ProgramFiles(x86)'] ?? env['PROGRAMFILES(X86)'], env.LOCALAPPDATA]
      .filter((root): root is string => !!root);
    const apps = [['Google', 'Chrome', 'Application', 'chrome.exe'], ['Microsoft', 'Edge', 'Application', 'msedge.exe'], ['Chromium', 'Application', 'chrome.exe']];
    return apps.flatMap(app => roots.map(root => win32.join(root, ...app)));
  }
  if (platform === 'darwin') {
    const apps = ['Google Chrome.app/Contents/MacOS/Google Chrome', 'Microsoft Edge.app/Contents/MacOS/Microsoft Edge', 'Chromium.app/Contents/MacOS/Chromium'];
    const dirs = ['/Applications', ...(env.HOME ? [posix.join(env.HOME, 'Applications')] : [])];
    return apps.flatMap(app => dirs.map(dir => posix.join(dir, app)));
  }
  const names = ['google-chrome', 'google-chrome-stable', 'chromium', 'chromium-browser', 'microsoft-edge', 'microsoft-edge-stable'];
  const dirs = (env.PATH ?? '').split(':').filter(Boolean);
  return names.flatMap(name => dirs.map(dir => posix.join(dir, name)));
}

export function findBrowser(): string | null {
  return browserCandidates().find(path => existsSync(path)) ?? null;
}

type Listener = (params: unknown, sessionId?: string) => void;

/** One DevTools WebSocket: numbered commands and their answers, and events. */
export class Cdp {
  private nextId = 0;
  private readonly waiting = new Map<number, { resolve: (value: unknown) => void; reject: (error: Error) => void }>();
  private readonly listeners = new Map<string, Set<Listener>>();
  private closed: Error | null = null;

  constructor(private readonly ws: WebSocket) {
    ws.on('message', data => this.receive(String(data)));
    ws.on('close', () => this.fail(new Error('The browser closed.')));
    ws.on('error', error => this.fail(error));
  }

  get isClosed(): boolean {
    return this.closed !== null;
  }

  private fail(error: Error): void {
    this.closed ??= error;
    for (const waiter of this.waiting.values()) waiter.reject(this.closed);
    this.waiting.clear();
  }

  private receive(raw: string): void {
    let message: { id?: number; method?: string; params?: unknown; sessionId?: string; result?: unknown; error?: { message: string } };
    try { message = JSON.parse(raw); } catch { return; }
    if (message.id !== undefined) {
      const waiter = this.waiting.get(message.id);
      if (!waiter) return;
      this.waiting.delete(message.id);
      if (message.error) waiter.reject(new Error(message.error.message));
      else waiter.resolve(message.result ?? {});
      return;
    }
    if (message.method) for (const listener of this.listeners.get(message.method) ?? []) listener(message.params, message.sessionId);
  }

  send<T = unknown>(method: string, params: object = {}, sessionId?: string, timeoutMs = 30_000): Promise<T> {
    if (this.closed) return Promise.reject(this.closed);
    const id = ++this.nextId;
    return new Promise<T>((resolve, reject) => {
      const timer = setTimeout(() => {
        this.waiting.delete(id);
        reject(new Error(`${method} got no answer in ${Math.round(timeoutMs / 1000)} s.`));
      }, timeoutMs);
      this.waiting.set(id, {
        resolve: value => { clearTimeout(timer); resolve(value as T); },
        reject: error => { clearTimeout(timer); reject(error); },
      });
      this.ws.send(JSON.stringify({ id, method, params, ...(sessionId ? { sessionId } : {}) }));
    });
  }

  on(method: string, listener: Listener): () => void {
    const set = this.listeners.get(method) ?? new Set<Listener>();
    set.add(listener);
    this.listeners.set(method, set);
    return () => set.delete(listener);
  }

  close(): void {
    this.ws.close();
  }
}

/** Waits for the DevToolsActivePort file a browser started with --remote-debugging-port=0 writes. */
async function readEndpoint(profile: string, timeoutMs: number): Promise<string> {
  const file = join(profile, 'DevToolsActivePort');
  const deadline = Date.now() + timeoutMs;
  while (Date.now() < deadline) {
    const lines = (await readFile(file, 'utf8').catch(() => '')).split('\n').map(line => line.trim());
    if (/^\d+$/.test(lines[0] ?? '') && lines[1]?.startsWith('/devtools/browser/')) return `ws://127.0.0.1:${lines[0]}${lines[1]}`;
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  throw new Error(`the browser did not open its DevTools port in ${Math.round(timeoutMs / 1000)} s`);
}

export interface ConsoleEntry {
  level: string;
  text: string;
  /** url:line:column, when the browser says where. */
  where?: string;
}

const MAX_LOG = 300;

/** One tab, attached with its own CDP session. */
export class Page {
  /** Console messages, uncaught errors and failed requests since the last navigation. */
  readonly log: ConsoleEntry[] = [];
  /** HTTP status of the main document of the last navigation. */
  documentStatus?: number;
  private readonly inflight = new Set<string>();
  private readonly requestUrls = new Map<string, string>();
  private lastNetwork = Date.now();
  private readonly stop: Array<() => void> = [];

  private constructor(private readonly cdp: Cdp, readonly targetId: string, readonly sessionId: string) {}

  static async create(cdp: Cdp, width: number, height: number): Promise<Page> {
    const { targetId } = await cdp.send<{ targetId: string }>('Target.createTarget', { url: 'about:blank' });
    const { sessionId } = await cdp.send<{ sessionId: string }>('Target.attachToTarget', { targetId, flatten: true });
    const page = new Page(cdp, targetId, sessionId);
    page.listen();
    await Promise.all([
      page.send('Page.enable'),
      page.send('Runtime.enable'),
      page.send('Network.enable'),
      page.send('Log.enable'),
      // A page reloaded after an edit must not come from the cache.
      page.send('Network.setCacheDisabled', { cacheDisabled: true }),
    ]);
    await page.setViewport(width, height);
    return page;
  }

  send<T = unknown>(method: string, params: object = {}, timeoutMs?: number): Promise<T> {
    return this.cdp.send<T>(method, params, this.sessionId, timeoutMs);
  }

  // CDP event parameters are JSON the browser sends; each listener names the shape it reads.
  private on<P>(method: string, listener: (params: P) => void): void {
    this.stop.push(this.cdp.on(method, (params, sessionId) => { if (sessionId === this.sessionId) listener(params as P); }));
  }

  private record(entry: ConsoleEntry): void {
    this.log.push({ ...entry, text: entry.text.slice(0, 2000) });
    if (this.log.length > MAX_LOG) this.log.shift();
  }

  private listen(): void {
    const where = (url?: string, line?: number, column?: number) =>
      url ? `${url}${line !== undefined ? `:${line + 1}` : ''}${column !== undefined ? `:${column + 1}` : ''}` : undefined;
    this.on('Runtime.consoleAPICalled', (p: { type: string; args: Array<{ value?: unknown; description?: string; unserializableValue?: string }>; stackTrace?: { callFrames: Array<{ url: string; lineNumber: number; columnNumber: number }> } }) => {
      const text = p.args.map(arg => arg.value !== undefined ? (typeof arg.value === 'string' ? arg.value : JSON.stringify(arg.value)) : arg.unserializableValue ?? arg.description ?? '').join(' ');
      const frame = p.stackTrace?.callFrames[0];
      this.record({ level: p.type === 'warning' ? 'warn' : p.type, text, where: where(frame?.url, frame?.lineNumber, frame?.columnNumber) });
    });
    this.on('Runtime.exceptionThrown', (p: { exceptionDetails: { text: string; exception?: { description?: string }; url?: string; lineNumber?: number; columnNumber?: number } }) => {
      const d = p.exceptionDetails;
      this.record({ level: 'error', text: d.exception?.description ?? d.text, where: where(d.url, d.lineNumber, d.columnNumber) });
    });
    this.on('Log.entryAdded', (p: { entry: { level: string; text: string; source: string; url?: string; lineNumber?: number } }) => {
      // Network failures come from the Network events below, with their URL.
      if (p.entry.source === 'network' || p.entry.source === 'violation' || p.entry.level === 'verbose') return;
      this.record({ level: p.entry.level === 'warning' ? 'warn' : p.entry.level, text: p.entry.text, where: where(p.entry.url, p.entry.lineNumber) });
    });
    this.on('Network.requestWillBeSent', (p: { requestId: string; request: { url: string } }) => {
      this.inflight.add(p.requestId);
      this.requestUrls.set(p.requestId, p.request.url);
      this.lastNetwork = Date.now();
    });
    this.on('Network.responseReceived', (p: { requestId: string; type: string; response: { url: string; status: number; statusText?: string } }) => {
      if (p.type === 'Document' && this.documentStatus === undefined) this.documentStatus = p.response.status;
      if (p.response.status >= 400) this.record({ level: 'error', text: `HTTP ${p.response.status}${p.response.statusText ? ` ${p.response.statusText}` : ''} for ${p.response.url}` });
    });
    const done = (p: { requestId: string }) => {
      this.inflight.delete(p.requestId);
      this.lastNetwork = Date.now();
    };
    this.on('Network.loadingFinished', done);
    this.on('Network.loadingFailed', (p: { requestId: string; errorText: string; canceled?: boolean }) => {
      done(p);
      if (!p.canceled) this.record({ level: 'error', text: `${p.errorText} for ${this.requestUrls.get(p.requestId) ?? 'a request'}` });
    });
  }

  async setViewport(width: number, height: number): Promise<void> {
    await this.send('Emulation.setDeviceMetricsOverride', { width, height, deviceScaleFactor: 1, mobile: false });
  }

  private waitFor(method: string, timeoutMs: number): Promise<boolean> {
    return new Promise((resolve) => {
      let off = () => {};
      const timer = setTimeout(() => { off(); resolve(false); }, timeoutMs);
      off = this.cdp.on(method, (_params, sessionId) => {
        if (sessionId !== this.sessionId) return;
        clearTimeout(timer);
        off();
        resolve(true);
      });
    });
  }

  /** Until no request has been in flight for `quietMs`, or `maxMs` passed. */
  async settle(quietMs = 500, maxMs = 5000): Promise<void> {
    const deadline = Date.now() + maxMs;
    while (Date.now() < deadline) {
      if (this.inflight.size === 0 && Date.now() - this.lastNetwork >= quietMs) break;
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    // Let a framework paint what the last response changed.
    await this.evaluate('new Promise(resolve => requestAnimationFrame(() => requestAnimationFrame(() => resolve(true))))', 5000).catch(() => {});
  }

  /**
   * Opens a URL and waits for it to load and go quiet. Returns whether the
   * load event came before the timeout (a page can be usable before it does).
   */
  async navigate(url: string, timeoutMs = 30_000): Promise<boolean> {
    this.log.length = 0;
    this.documentStatus = undefined;
    this.inflight.clear();
    const loaded = this.waitFor('Page.loadEventFired', timeoutMs);
    const result = await this.send<{ errorText?: string; loaderId?: string }>('Page.navigate', { url }, timeoutMs);
    if (result.errorText) throw new Error(navigationError(url, result.errorText));
    // A same-document navigation (a #hash) has no loader and no load event.
    const ok = result.loaderId ? await loaded : true;
    await this.settle();
    return ok;
  }

  /** Runs an expression in the page and gives back its JSON value. */
  async evaluate<T = unknown>(expression: string, timeoutMs = 30_000): Promise<T> {
    const result = await this.send<{ result: { value?: unknown; unserializableValue?: string; description?: string; type: string }; exceptionDetails?: { text: string; exception?: { description?: string } } }>(
      'Runtime.evaluate', { expression, returnByValue: true, awaitPromise: true, userGesture: true }, timeoutMs);
    if (result.exceptionDetails) {
      throw new Error(result.exceptionDetails.exception?.description ?? result.exceptionDetails.text);
    }
    const r = result.result;
    return (r.value !== undefined ? r.value : r.unserializableValue ?? (r.type === 'undefined' ? undefined : r.description)) as T;
  }

  /**
   * Runs one of page-scripts.ts's functions in the page with JSON arguments.
   * A compiler that keeps function names (tsx, esbuild keepNames) calls a
   * __name helper inside the source, so the page gets one.
   */
  call<T>(fn: (...args: never[]) => unknown, ...args: unknown[]): Promise<T> {
    return this.callWithin<T>(30_000, fn, ...args);
  }

  callWithin<T>(timeoutMs: number, fn: (...args: never[]) => unknown, ...args: unknown[]): Promise<T> {
    return this.evaluate<T>(`(() => { const __name = (target) => target; return (${fn.toString()})(...${JSON.stringify(args)}); })()`, timeoutMs);
  }

  async click(x: number, y: number): Promise<void> {
    await this.send('Input.dispatchMouseEvent', { type: 'mouseMoved', x, y });
    await this.send('Input.dispatchMouseEvent', { type: 'mousePressed', x, y, button: 'left', buttons: 1, clickCount: 1 });
    await this.send('Input.dispatchMouseEvent', { type: 'mouseReleased', x, y, button: 'left', buttons: 0, clickCount: 1 });
  }

  async insertText(text: string): Promise<void> {
    await this.send('Input.insertText', { text });
  }

  async pressEnter(): Promise<void> {
    const key = { key: 'Enter', code: 'Enter', windowsVirtualKeyCode: 13, nativeVirtualKeyCode: 13 };
    await this.send('Input.dispatchKeyEvent', { type: 'keyDown', ...key, text: '\r' });
    await this.send('Input.dispatchKeyEvent', { type: 'keyUp', ...key });
  }

  /** A PNG of the viewport, of a clip (CSS pixels from the page's top-left), or of the whole page. */
  async screenshot(options: { clip?: { x: number; y: number; width: number; height: number }; fullPage?: boolean } = {}): Promise<string> {
    const params: Record<string, unknown> = { format: 'png' };
    if (options.clip) params.clip = { ...options.clip, scale: 1 };
    if (options.fullPage || options.clip) params.captureBeyondViewport = true;
    if (options.fullPage && !options.clip) {
      const { cssContentSize } = await this.send<{ cssContentSize: { width: number; height: number } }>('Page.getLayoutMetrics');
      params.clip = { x: 0, y: 0, width: Math.ceil(cssContentSize.width), height: Math.min(Math.ceil(cssContentSize.height), 16_000), scale: 1 };
    }
    const { data } = await this.send<{ data: string }>('Page.captureScreenshot', params, 60_000);
    return data;
  }

  async close(): Promise<void> {
    for (const stop of this.stop) stop();
    await this.cdp.send('Target.closeTarget', { targetId: this.targetId }, undefined, 5000).catch(() => {});
  }
}

/** A Page.navigate error in words, with the likely cause for the common ones. */
export function navigationError(url: string, errorText: string): string {
  if (errorText.includes('ERR_CONNECTION_REFUSED')) return `Nothing answers at ${url} (${errorText}). Is the dev server running, and on this port?`;
  if (errorText.includes('ERR_NAME_NOT_RESOLVED')) return `The host of ${url} was not found (${errorText}).`;
  if (errorText.includes('ERR_FILE_NOT_FOUND')) return `There is no file at ${url} (${errorText}).`;
  return `Could not open ${url}: ${errorText}.`;
}

/** Throwaway profiles are named after the process that owns them: ai-bridge-browser-<pid>-<random>. */
const PROFILE_PREFIX = 'ai-bridge-browser-';

function isAlive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch (error) {
    return (error as NodeJS.ErrnoException).code === 'EPERM';
  }
}

/**
 * Removes the profiles of servers that are gone. A chat's process tree is
 * killed outright when the chat closes, so its server has no chance to remove
 * its own; one still in use is left alone (and on Windows, locked anyway).
 */
export async function removeOrphanProfiles(dir = tmpdir(), alive: (pid: number) => boolean = isAlive): Promise<string[]> {
  const names = await readdir(dir).catch(() => [] as string[]);
  const orphans = names.filter((name) => {
    const match = new RegExp(`^${PROFILE_PREFIX}(\\d+)-`).exec(name);
    return match !== null && Number(match[1]) !== process.pid && !alive(Number(match[1]));
  });
  await Promise.all(orphans.map(name => rm(join(dir, name), { recursive: true, force: true }).catch(() => {})));
  return orphans;
}

/**
 * The environment the browser starts in. On Windows, Chrome and Edge refuse
 * remote debugging ("requires a non-default data directory") when USERPROFILE
 * is not the account's own profile folder, as when a tool runs the agent with
 * a home of its own; the browser gets the account's folder back.
 */
export function browserEnv(env: NodeJS.ProcessEnv = process.env, platform: NodeJS.Platform = process.platform, accountHome: () => string = () => userInfo().homedir): NodeJS.ProcessEnv {
  if (platform !== 'win32') return env;
  let home = '';
  try { home = accountHome(); } catch { /* no account entry; keep what is set */ }
  return home && env.USERPROFILE !== home ? { ...env, USERPROFILE: home } : env;
}

/** The last lines the browser wrote, plain messages before its [pid:tid:...] log lines, for an error. */
export function browserSaid(stderr: string): string {
  const lines = stderr.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
  const plain = lines.filter(line => !line.startsWith('[') && !line.startsWith('DevTools listening'));
  const said = (plain.length ? plain : lines).slice(-3).join(' ');
  return said ? `; the browser said: ${said}` : '';
}

/** The headless browser process with its one DevTools connection. */
export class Browser {
  private constructor(
    private readonly child: ChildProcess,
    readonly cdp: Cdp,
    private readonly profile: string,
    readonly executable: string,
    readonly version: string,
  ) {}

  static async launch(executable: string): Promise<Browser> {
    await removeOrphanProfiles();
    const profile = await mkdtemp(join(tmpdir(), `${PROFILE_PREFIX}${process.pid}-`));
    const args = [
      '--headless=new', '--remote-debugging-port=0', `--user-data-dir=${profile}`,
      '--no-first-run', '--no-default-browser-check', '--disable-extensions', '--disable-sync',
      '--disable-background-networking', '--disable-component-update', '--mute-audio',
      // Render on the CPU, as a PC without a GPU does, so every machine draws alike.
      '--use-angle=swiftshader', '--enable-unsafe-swiftshader',
      // Compiled shaders would otherwise fill the throwaway profile.
      '--disable-gpu-shader-disk-cache',
      ...(process.platform === 'linux' && process.getuid?.() === 0 ? ['--no-sandbox'] : []),
      'about:blank',
    ];
    const child = spawn(executable, args, { stdio: ['ignore', 'ignore', 'pipe'], env: browserEnv() });
    let stderr = '';
    child.stderr?.on('data', (chunk) => { stderr = (stderr + String(chunk)).slice(-4000); });
    try {
      const exited = new Promise<never>((_, reject) => {
        child.once('error', error => reject(new Error(`could not start ${executable}: ${error.message}`)));
        child.once('exit', code => reject(new Error(`${executable} exited with code ${code}${browserSaid(stderr)}`)));
      });
      // Only raced during the start; a later exit shows as the closed connection.
      exited.catch(() => {});
      const endpoint = await Promise.race([
        readEndpoint(profile, 20_000).catch((error: Error) => { throw new Error(`${error.message}${browserSaid(stderr)}`); }),
        exited,
      ]);
      const ws = new WebSocket(endpoint, { perMessageDeflate: false, maxPayload: 512 * 1024 * 1024 });
      await Promise.race([new Promise<void>((resolve, reject) => { ws.once('open', () => resolve()); ws.once('error', reject); }), exited]);
      const cdp = new Cdp(ws);
      const { product } = await cdp.send<{ product: string }>('Browser.getVersion');
      return new Browser(child, cdp, profile, executable, product);
    } catch (error) {
      child.kill();
      await rm(profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 }).catch(() => {});
      throw error;
    }
  }

  newPage(width: number, height: number): Promise<Page> {
    return Page.create(this.cdp, width, height);
  }

  /**
   * Ends the GPU process, which the browser starts again. A shader that never
   * finishes keeps it busy, and every tab's drawing waits behind it; a tab's
   * page stays, its WebGL contexts are lost.
   */
  async restartGpu(): Promise<boolean> {
    const { processInfo } = await this.cdp.send<{ processInfo: Array<{ type: string; id: number }> }>('SystemInfo.getProcessInfo', {}, undefined, 5000);
    const gpu = processInfo.filter(info => info.type === 'GPU');
    for (const info of gpu) {
      try { process.kill(info.id); } catch { /* already gone */ }
    }
    return gpu.length > 0;
  }

  async close(): Promise<void> {
    await this.cdp.send('Browser.close', {}, undefined, 3000).catch(() => {});
    this.cdp.close();
    if (this.child.exitCode === null) {
      await new Promise<void>((resolve) => {
        const timer = setTimeout(() => { this.child.kill(); resolve(); }, 3000);
        this.child.once('exit', () => { clearTimeout(timer); resolve(); });
      });
    }
    await rm(this.profile, { recursive: true, force: true, maxRetries: 5, retryDelay: 200 }).catch(() => {});
  }

  /** For process exit, when there is no time to wait: the profile is left in the temp dir. */
  kill(): void {
    this.child.kill();
  }
}
