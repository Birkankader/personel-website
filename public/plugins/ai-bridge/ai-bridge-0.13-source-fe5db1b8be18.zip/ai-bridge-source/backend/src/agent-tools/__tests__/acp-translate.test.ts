import { join, resolve } from 'path';
import { describe, expect, it } from 'vitest';
import { readApiFailure } from '../../core/features/api-recovery';
import {
  harnessAgentEnv,
  harnessApiError,
  isCommandPrompt,
  parseBridgeArgs,
  pickEffortValue,
  pickModeValue,
  planToTodos,
  sameJson,
  toAcpPrompt,
  toClaudeTool,
  toolResultText,
  type ConfigOption,
} from '../acp/translate';

const effort = (values: string[]): ConfigOption => ({
  id: 'effort', category: 'thought_level', options: values.map(value => ({ value, name: value })),
});

describe('parseBridgeArgs', () => {
  it('reads the Claude flags the backend passes', () => {
    expect(parseBridgeArgs([
      '-p', '--output-format', 'stream-json', '--resume', 'abc', '--permission-mode', 'plan',
      '--model', 'm', '--effort', 'high', '--settings', 'x.json',
    ])).toEqual({ sessionId: 'abc', resume: true, noPersistence: false, permissionMode: 'plan', model: 'm', effort: 'high' });
  });

  it('takes the model from the environment, where Windows cannot mangle it', () => {
    expect(parseBridgeArgs(['--session-id', 's'], { AI_BRIDGE_HARNESS_MODEL: '["p","m"]' }).model).toBe('["p","m"]');
  });
});

describe('pickEffortValue', () => {
  it('uses an exact match and leaves auto to the harness', () => {
    expect(pickEffortValue('xhigh', effort(['low', 'xhigh']))).toBe('xhigh');
    expect(pickEffortValue('auto', effort(['low']))).toBeUndefined();
  });

  it('rounds to the nearest level, upward on a tie, and never to off', () => {
    expect(pickEffortValue('medium', effort(['off', 'low', 'high', 'max']))).toBe('high');
    expect(pickEffortValue('xhigh', effort(['off', 'low', 'high', 'max']))).toBe('max');
    expect(pickEffortValue('low', effort(['off', 'high']))).toBe('high');
  });
});

describe('pickModeValue', () => {
  const modes: ConfigOption = { id: 'mode', category: 'mode', currentValue: 'build', options: [{ value: 'build' }, { value: 'plan' }] };
  it('selects plan and returns to the base mode afterwards', () => {
    expect(pickModeValue('plan', modes, 'build')).toBe('plan');
    expect(pickModeValue('default', { ...modes, currentValue: 'plan' }, 'build')).toBe('build');
    expect(pickModeValue('default', modes, 'build')).toBeUndefined();
  });
});

describe('toClaudeTool', () => {
  const cwd = resolve('/', 'work');
  it('maps the exact correspondences', () => {
    expect(toClaudeTool({ toolCallId: '1', kind: 'read', rawInput: { path: 'a.txt' } }, cwd))
      .toEqual({ name: 'Read', input: { file_path: join(cwd, 'a.txt') } });
    expect(toClaudeTool({ toolCallId: '1', kind: 'execute', rawInput: { command: 'ls', description: 'list' } }, cwd))
      .toEqual({ name: 'Bash', input: { command: 'ls', description: 'list' } });
    expect(toClaudeTool({ toolCallId: '1', kind: 'edit', rawInput: { filePath: 'b.ts', oldString: 'x', newString: 'y' } }, cwd))
      .toEqual({ name: 'Edit', input: { file_path: join(cwd, 'b.ts'), old_string: 'x', new_string: 'y' } });
    expect(toClaudeTool({
      toolCallId: '1', kind: 'edit', locations: [{ path: join(cwd, 'c.ts') }],
      content: [{ type: 'diff', path: join(cwd, 'c.ts'), oldText: null, newText: 'new' }],
    }, cwd)).toEqual({ name: 'Write', input: { file_path: join(cwd, 'c.ts'), content: 'new' } });
  });

  it('keeps anything else under the harness own name and arguments', () => {
    expect(toClaudeTool({ toolCallId: '1', name: 'webfetch', kind: 'other', rawInput: { q: 1 } }, cwd))
      .toEqual({ name: 'webfetch', input: { q: 1 } });
  });

  // DeepSeek Harness reports every call as kind `other`, titled with its tool name.
  const dsh = (title: string, rawInput: Record<string, unknown>) =>
    toClaudeTool({ toolCallId: '1', title, kind: 'other', status: 'in_progress', rawInput }, cwd);

  it('recognises DeepSeek Harness tools by name when the kind is other', () => {
    expect(dsh('read', { file_path: 'a.txt', offset: 10, limit: 5 }))
      .toEqual({ name: 'Read', input: { file_path: join(cwd, 'a.txt'), offset: 10, limit: 5 } });
    expect(dsh('grep', { pattern: 'foo', path: 'src', include: '*.ts' }))
      .toEqual({ name: 'Grep', input: { pattern: 'foo', path: join(cwd, 'src'), glob: '*.ts' } });
    expect(dsh('glob', { pattern: '**/*.ts' }))
      .toEqual({ name: 'Glob', input: { pattern: '**/*.ts' } });
    expect(dsh('edit', { file_path: 'b.ts', old_string: 'x', new_string: 'y' }))
      .toEqual({ name: 'Edit', input: { file_path: join(cwd, 'b.ts'), old_string: 'x', new_string: 'y' } });
    expect(dsh('write', { file_path: 'c.ts', content: 'new' }))
      .toEqual({ name: 'Write', input: { file_path: join(cwd, 'c.ts'), content: 'new' } });
    expect(dsh('bash', { command: 'ls', description: 'list' }))
      .toEqual({ name: 'Bash', input: { command: 'ls', description: 'list' } });
    expect(dsh('pwsh', { command: 'Get-ChildItem', description: 'list' }))
      .toEqual({ name: 'PowerShell', input: { command: 'Get-ChildItem', description: 'list' } });
    expect(dsh('web_fetch', { url: 'https://example.com' }))
      .toEqual({ name: 'WebFetch', input: { url: 'https://example.com', prompt: '' } });
  });

  it('matches only exact tool names, and keeps a named tool without its arguments as is', () => {
    expect(dsh('Read a.txt', { file_path: 'a.txt' }))
      .toEqual({ name: 'Read a.txt', input: { file_path: 'a.txt' } });
    expect(dsh('read', {})).toEqual({ name: 'read', input: {} });
  });

  it('lets a specific kind win over the tool name', () => {
    expect(toClaudeTool({ toolCallId: '1', title: 'read', kind: 'execute', rawInput: { command: 'cat a' } }, cwd))
      .toEqual({ name: 'Bash', input: { command: 'cat a' } });
  });
});

describe('toolResultText', () => {
  it('joins text content and falls back to raw output', () => {
    expect(toolResultText({
      toolCallId: '1', content: [{ type: 'content', content: { type: 'text', text: 'a' } }, { type: 'diff', path: 'p' }],
    })).toBe('a\nUpdated p');
    expect(toolResultText({ toolCallId: '1', rawOutput: { output: 'out' } })).toBe('out');
    expect(toolResultText({ toolCallId: '1', status: 'failed' })).toBe('The tool failed.');
  });
});

describe('toAcpPrompt', () => {
  const image = { type: 'image', source: { type: 'base64', media_type: 'image/png', data: 'AAA' } };
  it('converts text and images, and says so when images cannot be sent', () => {
    expect(toAcpPrompt([{ type: 'text', text: 'hi' }, image], true))
      .toEqual([{ type: 'text', text: 'hi' }, { type: 'image', mimeType: 'image/png', data: 'AAA' }]);
    const without = toAcpPrompt([image], false);
    expect(without).toHaveLength(1);
    expect(without[0]).toMatchObject({ type: 'text' });
  });
});

describe('planToTodos / sameJson', () => {
  it('maps plan entries to TodoWrite todos', () => {
    expect(planToTodos([{ content: 'a', status: 'in_progress', priority: 'high' }, { content: 'b', status: 'weird' }]))
      .toEqual([{ content: 'a', status: 'in_progress', activeForm: 'a' }, { content: 'b', status: 'pending', activeForm: 'b' }]);
  });

  it('compares JSON regardless of key order', () => {
    expect(sameJson({ a: 1, b: [1, { c: 2 }] }, { b: [1, { c: 2 }], a: 1 })).toBe(true);
    expect(sameJson({ a: 1 }, { a: 2 })).toBe(false);
  });
});

describe('harnessAgentEnv', () => {
  it('makes OpenCode ask before anything but read-only tools', () => {
    const env = harnessAgentEnv('opencode', {});
    const config = JSON.parse(env.OPENCODE_CONFIG_CONTENT!);
    expect(config.permission['*']).toBe('ask');
    expect(config.permission.read).toBe('allow');
    expect(config.permission.bash).toBeUndefined();
  });

  it("keeps the user's own inline config and rules", () => {
    const env = harnessAgentEnv('opencode', {
      OPENCODE_CONFIG_CONTENT: JSON.stringify({ model: 'x/y', permission: { bash: { 'git *': 'allow' }, read: 'ask' } }),
    });
    const config = JSON.parse(env.OPENCODE_CONFIG_CONTENT!);
    expect(config.model).toBe('x/y');
    expect(config.permission).toEqual({
      '*': 'ask', read: 'ask', glob: 'allow', grep: 'allow', list: 'allow', todoread: 'allow', todowrite: 'allow',
      bash: { 'git *': 'allow' },
    });
  });

  it('leaves a blanket rule, unreadable config and other harnesses alone', () => {
    expect(harnessAgentEnv('opencode', { OPENCODE_CONFIG_CONTENT: '{"permission":"allow"}' })).toEqual({});
    expect(harnessAgentEnv('opencode', { OPENCODE_CONFIG_CONTENT: 'not json' })).toEqual({});
    expect(harnessAgentEnv('deepseek', {})).toEqual({});
  });
});

describe('harnessApiError', () => {
  const dsh = (text: string) => harnessApiError({ code: -32603, message: `Internal error: turn failed: ${text}` }, 'DeepSeek Harness');
  const opencode = (errorName: string, message: string) =>
    harnessApiError({ code: -32603, message: `Internal error: ${message}`, data: { service: 'session', errorName } }, 'OpenCode');
  /** What automatic recovery makes of the entry the bridge writes for [failure]. */
  const recovered = (failure: NonNullable<ReturnType<typeof harnessApiError>>) => readApiFailure({
    type: 'assistant', is_api_error_message: true, error: failure.error,
    ...(failure.status ? { api_error_status: failure.status } : {}),
    message: { content: [{ type: 'text', text: failure.text }] },
  })?.kind;

  it('reads the provider failure DeepSeek Harness names only in its message', () => {
    for (const [text, kind] of [
      ['Rate limit reached for requests', 'rate'],
      ['DeepSeek Messages request failed (429)', 'rate'],
      ['429 Too Many Requests', 'rate'],
      ['DeepSeek Messages request failed (503)', 'server'],
      ['The server is overloaded, please try again later.', 'server'],
      ['fetch failed: read ECONNRESET', 'network'],
      ["This model's maximum context length is 131072 tokens. However, you requested 140000 tokens.", 'context'],
    ] as const) {
      const failure = dsh(text);
      expect(failure, text).toMatchObject({ kind });
      expect(failure!.text).toBe(`API Error: DeepSeek Harness: Internal error: turn failed: ${text}`);
      // The entry must mean the same to recovery as it does here.
      expect(recovered(failure!), text).toBe(kind);
    }
    expect(dsh('DeepSeek Messages request failed (503)')).toMatchObject({ error: 'server_error', status: 503 });
  });

  it('reads the provider failure OpenCode names in data.errorName', () => {
    for (const [name, kind] of [
      ['provider.rate-limit', 'rate'], ['provider.transport', 'network'], ['provider.timeout', 'network'], ['provider.internal', 'server'],
    ] as const) {
      const failure = opencode(name, 'Provider request failed');
      expect(failure, name).toMatchObject({ kind });
      expect(recovered(failure!), name).toBe(kind);
    }
    expect(opencode('provider.transport', 'Provider request failed')!.text).toBe('API Error: Connection error. OpenCode: Internal error: Provider request failed');
  });

  it('never marks a rate limit as a Claude usage-limit notice', () => {
    // A 429 status or the CLI's `rate_limit` code would offer to switch Claude accounts.
    expect(dsh('429 Too Many Requests')).toEqual(expect.objectContaining({ error: 'rate_limit_error' }));
    expect(dsh('429 Too Many Requests')).not.toHaveProperty('status');
  });

  it('leaves failures that waiting does not heal, and faults of the agent itself, to the user', () => {
    for (const text of [
      'Insufficient Balance', '429 You exceeded your current quota, please check your plan', '401 Unauthorized',
      'invalid api key', 'assistant output delivery failed: boom', 'no API key for provider route deepseek-official',
    ]) expect(dsh(text), text).toBeNull();
    expect(opencode('provider.auth', 'Rate limit of the login service')).toBeNull();
    expect(opencode('provider.quota', 'Monthly limit reached')).toBeNull();
    expect(harnessApiError({ code: -32603, message: 'Internal error: prompt was not queued: busy' }, 'X')).toBeNull();
  });
});

describe('isCommandPrompt', () => {
  it('matches only the bare command', () => {
    expect(isCommandPrompt('/compact', 'compact')).toBe(true);
    expect(isCommandPrompt(' /compact\n', 'compact')).toBe(true);
    expect(isCommandPrompt([{ type: 'text', text: '/compact' }], 'compact')).toBe(true);
    expect(isCommandPrompt('/compact now', 'compact')).toBe(false);
    expect(isCommandPrompt([{ type: 'text', text: '/compact' }, { type: 'text', text: 'x' }], 'compact')).toBe(false);
    expect(isCommandPrompt('please /compact', 'compact')).toBe(false);
  });
});
