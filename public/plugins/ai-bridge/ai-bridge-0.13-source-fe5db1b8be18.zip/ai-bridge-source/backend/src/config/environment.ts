import { existsSync } from 'fs';
import { randomBytes } from 'crypto';
import { resolve } from 'path';
import { fileURLToPath } from 'url';

// ── Build environment ──────────────────────────────────
export const isDev = () => process.env.NODE_ENV !== 'production';
export const isProd = () => process.env.NODE_ENV === 'production';

// ── Runtime environment (injected at runtime) ───────────
// Injected by the launcher (JetBrains = Kotlin spawn, standalone = ccg). These keys
// do not go in .env — prefixing them with `_` bakes them into the build and defeats runtime injection.
export const isJetBrainsMode = process.env.JETBRAINS_MODE === 'true';
// Raw AI_BRIDGE_CLIENT_INFO string (IDE product, version, build) reported by the JetBrains launcher.
export const clientInfo = process.env.AI_BRIDGE_CLIENT_INFO ?? '';

// ── Dev/measurement only: disable idle shutdown ─────────
// A backend started directly in standalone mode (`pnpm dev`) is terminated by idle
// shutdown when the client briefly disconnects, and unlike the launchers (JetBrains/ccg)
// nothing respawns it, so it just dies. This dev-only switch keeps the backend alive
// during repeated browser measurements. It does not affect the shipped path (unset = existing behavior).
export const disableIdleShutdown = process.env.AI_BRIDGE_DISABLE_IDLE_SHUTDOWN === 'true';

// ── Server settings ────────────────────────────────────
const DEFAULT_PORT = 19846;
export const serverPort = parseInt(process.env.PORT ?? String(DEFAULT_PORT), 10);

// ── Server bind host ───────────────────────────────────
// Defaults to loopback (127.0.0.1) — not exposed to the external network. If the launcher
// (ccg `run -b <addr>` / JetBrains / another wrapper) injects an address via the AI_BRIDGE_BIND
// environment variable, the server binds to that address. A common name like `HOST` (as with
// PORT) could collide with unrelated shell variables, so the AI_BRIDGE_* prefix convention is used.
// A non-loopback bind means LAN exposure, so in that case ws-server also relaxes strict
// same-origin (ws-server.ts::startWebSocketServer).
const DEFAULT_HOST = '127.0.0.1';
export const serverHost = process.env.AI_BRIDGE_BIND?.trim() || DEFAULT_HOST;

// ── Control channel auth token ─────────────────────────
// Auth token that authenticates the /ws · /rpc · /logs control channels and /internal/* pushes.
// Without authentication, any client that can reach the port could start a Claude session
// with bypass permissions, i.e. RCE (background: a reported vulnerability).
//
// Ownership (important): the token is now a **STABLE per-machine token owned by the launcher
// (Kotlin plugin / ccg CLI)**. The launcher derives a stable token from a secret it persists
// on disk (→ HMAC derivation) and injects it into the backend via the AI_BRIDGE_AUTH_TOKEN env.
// The backend only consumes that value as-is; it never reads or creates the secret on disk
// (the on-disk secret logic belongs to the launcher). In production (JetBrains/ccg) the
// launcher always injects AI_BRIDGE_AUTH_TOKEN, so the randomBytes branch below is only a safety
// fallback for when no bootstrap provided a token. Like serverHost, it is a constant evaluated
// once at module load, so the same value is used for the whole process lifetime.
// Caution: never write this value to the logs.
//
// Dev convenience (without a footgun): in local Vite development there is no bootstrap
// (Kotlin/foreground.sh), so AI_BRIDGE_AUTH_TOKEN is not injected. In that case, for dev only,
// a fixed dev token is used as the default so it pairs with the webview (which uses the same
// constant when import.meta.env.VITE_AI_BRIDGE_DEV_TOKEN is unset). This fixed value is an
// intentionally insecure dev-only value; it is never used in production (no dev signal), which
// falls back to a random token. The dev signal is isDev() (NODE_ENV), and esbuild bakes
// NODE_ENV='production' into the shipped bundle (backend.mjs), so isDev() is reliably false in
// production (see backend/esbuild.mjs). The webview connection builder attaches this token in
// the Sec-WebSocket-Protocol header (`['ai-bridge-auth', token]`).
const DEV_INSECURE_AUTH_TOKEN = 'ai-bridge-dev-insecure-token';
export const authToken = process.env.AI_BRIDGE_AUTH_TOKEN?.trim()
  || (isDev() ? DEV_INSECURE_AUTH_TOKEN : randomBytes(32).toString('hex'));

// ── Restart signal ─────────────────────────────────────
// Unified signal for "restart the plugin". Regardless of the frontend runtime (browser/JetBrains)
// or the backend's managing process (Kotlin/ccg), when Node exits on its own with this exit code,
// the process that spawned it respawns it on the same port. A single rule with no branching.
//   - JetBrains: NodeProcessManager detects proc.waitFor()==this value and calls BackendInstance.restart()
//   - ccg standalone: cli/lib/spawn/foreground.sh respawns when the wait exit code == this value
//   - dev (be-dev, `node --watch`): a self-exit is not restarted automatically (only file changes
//     restart it), so restart is best-effort — a dev-only limitation; customer paths (JetBrains/ccg) are unaffected.
// If you change this value, also change the same literal in cli/lib/spawn/foreground.sh.
export const RESTART_EXIT_CODE = 75;

function resolveWebviewDir(): string | undefined {
  if (process.env.WEBVIEW_DIR) return process.env.WEBVIEW_DIR;
  if (isJetBrainsMode) return undefined;

  // Browser mode: ../../webview/dist relative to backend/dist/backend.mjs
  const currentFile = fileURLToPath(import.meta.url);
  // backend/dist/backend.mjs → ../../webview/dist (relative to the repo root)
  const candidate = resolve(currentFile, '..', '..', '..', 'webview', 'dist');
  return existsSync(resolve(candidate, 'index.html')) ? candidate : undefined;
}

export const webviewDir = resolveWebviewDir();
