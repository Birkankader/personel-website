import { EventEmitter } from 'node:events';
import { describe, expect, it, vi } from 'vitest';
import { LogWebSocketServer, LogLevel, type LogEntry } from '../log-ws';
import { MessageType } from '../../shared';

const transport = vi.hoisted(() => ({
  connect: undefined as ((socket: unknown) => void) | undefined,
  close: vi.fn(),
}));

vi.mock('ws', () => ({
  WebSocket: { OPEN: 1 },
  WebSocketServer: class {
    on(event: string, callback: (socket: unknown) => void) {
      if (event === 'connection') transport.connect = callback;
    }
    close = transport.close;
  },
}));

function socket() {
  return Object.assign(new EventEmitter(), { send: vi.fn(), close: vi.fn() });
}

describe('log WebSocket', () => {
  const entry: LogEntry = { level: LogLevel.LOG, source: 'webview', sessionId: null, message: 'hi', timestamp: 1 };

  it('hands webview batches to the logger and sends nothing back', () => {
    const onLogBatch = vi.fn();
    new LogWebSocketServer(onLogBatch);
    const ws = socket();
    transport.connect!(ws);

    ws.emit('message', Buffer.from(JSON.stringify({ type: MessageType.LOG_BATCH, entries: [entry] })));
    ws.emit('message', Buffer.from('not json'));
    ws.emit('message', Buffer.from(JSON.stringify({ type: MessageType.ACK, entries: [entry] })));

    expect(onLogBatch).toHaveBeenCalledExactlyOnceWith([entry]);
    expect(ws.send).not.toHaveBeenCalled();
  });

  it('closes the sockets still open when the server closes', async () => {
    const server = new LogWebSocketServer(vi.fn());
    const open = socket();
    const gone = socket();
    transport.connect!(open);
    transport.connect!(gone);
    gone.emit('close');

    await server.close();
    await server.close();

    expect(open.close).toHaveBeenCalledOnce();
    expect(gone.close).not.toHaveBeenCalled();
    expect(transport.close).toHaveBeenCalledOnce();
  });
});
