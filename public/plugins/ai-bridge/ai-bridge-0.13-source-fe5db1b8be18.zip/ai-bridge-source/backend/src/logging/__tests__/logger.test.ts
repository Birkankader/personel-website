import { mkdtemp, readFile, rm } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import { inspect } from 'util';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { Logger, formatLogArg, parseLogSource } from '../logger';
import { FileLogger } from '../file-logger';

// ES2020 lib typings have neither Error `cause` nor AggregateError, so build them through loose types.
function errorWithCause(message: string, cause: unknown): Error {
  return Object.assign(new Error(message), { cause });
}
type AggregateErrorCtor = new (errors: unknown[], message: string) => Error;
const AggregateErrorImpl = (globalThis as unknown as { AggregateError: AggregateErrorCtor }).AggregateError;

describe('formatLogArg', () => {
  it('returns strings unchanged', () => {
    expect(formatLogArg('plain text')).toBe('plain text');
  });

  it('renders an Error with its name, message and stack frames', () => {
    const out = formatLogArg(new Error('boom'));
    expect(out).toContain('Error: boom');
    expect(out).toMatch(/^ {4}at /m);
  });

  it('falls back to "name: message" when the stack is missing', () => {
    const err = new Error('no stack');
    Object.defineProperty(err, 'stack', { value: undefined });
    expect(formatLogArg(err)).toBe('Error: no stack');
  });

  it('shows the own enumerable extras of an Error such as code and syscall', () => {
    const err = Object.assign(new Error('open failed'), { code: 'ENOENT', errno: -2, syscall: 'open', path: '/x' });
    const out = formatLogArg(err);
    expect(out).toContain('"code":"ENOENT"');
    expect(out).toContain('"syscall":"open"');
    expect(out).toContain('"path":"/x"');
  });

  it('prints the cause chain after "Caused by:"', () => {
    const out = formatLogArg(errorWithCause('outer', errorWithCause('middle', new Error('inner'))));
    expect(out).toContain('Error: outer');
    expect(out.match(/Caused by: /g)).toHaveLength(2);
    expect(out).toContain('Error: middle');
    expect(out).toContain('Error: inner');
  });

  it('formats a cause that is not an Error', () => {
    expect(formatLogArg(errorWithCause('outer', 'just a string'))).toContain('Caused by: just a string');
    expect(formatLogArg(errorWithCause('outer', { reason: 'x' }))).toContain('Caused by: {"reason":"x"}');
  });

  it('terminates on a cause cycle', () => {
    const a = new Error('a');
    const b = errorWithCause('b', a);
    Object.assign(a, { cause: b });
    const out = formatLogArg(a);
    expect(out).toContain('Error: a');
    expect(out).toContain('Error: b');
    expect(out).toContain('[Circular]');
  });

  it('bounds the cause depth', () => {
    let err: Error = new Error('level-0');
    for (let i = 1; i < 20; i++) err = errorWithCause(`level-${i}`, err);
    const out = formatLogArg(err);
    expect(out).toContain('level-19');
    expect(out).not.toContain('level-0');
    expect(out.match(/Caused by: /g)!.length).toBeLessThanOrEqual(6);
  });

  it('appends every member of an AggregateError', () => {
    const out = formatLogArg(new AggregateErrorImpl([new Error('first'), new Error('second')], 'many'));
    expect(out).toContain('AggregateError');
    expect(out).toContain('Error: first');
    expect(out).toContain('Error: second');
  });

  it('marks a circular object instead of throwing', () => {
    const circular: Record<string, unknown> = { name: 'loop' };
    circular.self = circular;
    const out = formatLogArg(circular);
    expect(out).toContain('"name":"loop"');
    expect(out).toContain('[Circular]');
  });

  it('does not mark a repeated, non-circular reference', () => {
    const shared = { n: 1 };
    expect(formatLogArg({ a: shared, b: shared })).toBe('{"a":{"n":1},"b":{"n":1}}');
  });

  it('serializes an Error nested inside an object', () => {
    const out = formatLogArg({ failure: new Error('nested boom') });
    expect(out).toContain('"message":"nested boom"');
    expect(out).toContain('"name":"Error"');
    expect(out).toContain('"stack"');
  });

  it('renders bigint, symbol, function and undefined', () => {
    expect(formatLogArg(10n)).toBe('10n');
    expect(formatLogArg({ big: 5n })).toBe('{"big":"5n"}');
    expect(formatLogArg(Symbol('tag'))).toBe('Symbol(tag)');
    expect(formatLogArg(function namedFn() {})).toBe('[Function namedFn]');
    expect(formatLogArg(() => {})).toMatch(/^\[Function/);
    expect(formatLogArg(undefined)).toBe('undefined');
  });

  it('renders null, numbers and booleans', () => {
    expect(formatLogArg(null)).toBe('null');
    expect(formatLogArg(42)).toBe('42');
    expect(formatLogArg(false)).toBe('false');
  });

  it('keeps plain objects and arrays as compact JSON', () => {
    expect(formatLogArg({ a: 1, b: ['x'] })).toBe('{"a":1,"b":["x"]}');
  });

  it('never throws on a getter that throws', () => {
    const hostile = { get bad(): string { throw new Error('getter exploded'); } };
    let out = '';
    expect(() => { out = formatLogArg(hostile); }).not.toThrow();
    expect(out.length).toBeGreaterThan(0);
  });

  it('falls back to inspect when toJSON throws', () => {
    const hostile = { visible: 'yes', toJSON(): never { throw new Error('toJSON exploded'); } };
    expect(formatLogArg(hostile)).toContain('visible');
  });

  it('reports [Unserializable] when both JSON and inspect throw', () => {
    const hostile = {
      toJSON(): never { throw new Error('toJSON exploded'); },
      [inspect.custom](): never { throw new Error('inspect exploded'); },
    };
    expect(formatLogArg(hostile)).toBe('[Unserializable]');
  });
});

describe('parseLogSource', () => {
  it('takes a whole-argument tag as the source', () => {
    expect(parseLogSource(['[loadCliConfig]', 'probe finished', 3])).toEqual({
      source: 'loadCliConfig',
      messageArgs: ['probe finished', 3],
    });
  });

  it('tolerates whitespace around a whole-argument tag', () => {
    expect(parseLogSource(['  [x]  ', 'msg']).source).toBe('x');
  });

  it('takes a tag at the start of the first string as the source', () => {
    expect(parseLogSource(['[login] OAuth URL available', 'extra'])).toEqual({
      source: 'login',
      messageArgs: ['OAuth URL available', 'extra'],
    });
  });

  it('keeps a multi-line message after an embedded tag', () => {
    expect(parseLogSource(['[x] line one\nline two'])).toEqual({
      source: 'x',
      messageArgs: ['line one\nline two'],
    });
  });

  it('does not treat a progress counter such as [1/3] as a tag', () => {
    expect(parseLogSource(['[1/3] step', 'a'])).toEqual({
      source: 'node-backend',
      messageArgs: ['[1/3] step', 'a'],
    });
  });

  it('does not treat a bracket in the middle of a message as a tag', () => {
    expect(parseLogSource(['value is [x] here']).source).toBe('node-backend');
  });

  it('defaults to node-backend for untagged and non-string first arguments', () => {
    expect(parseLogSource(['hello'])).toEqual({ source: 'node-backend', messageArgs: ['hello'] });
    const err = new Error('boom');
    expect(parseLogSource([err, 'x'])).toEqual({ source: 'node-backend', messageArgs: [err, 'x'] });
    expect(parseLogSource([])).toEqual({ source: 'node-backend', messageArgs: [] });
  });

  it('leaves a double tag alone: the first arg is the source, the second is the message', () => {
    expect(parseLogSource(['[node-backend]', '[DEBUG:bridge.request] sending'])).toEqual({
      source: 'node-backend',
      messageArgs: ['[DEBUG:bridge.request] sending'],
    });
  });
});

describe('Logger console interception', () => {
  let directory: string;
  let logger: Logger;

  beforeEach(async () => {
    directory = await mkdtemp(join(tmpdir(), 'logger-intercept-'));
    // Silence the real console and keep the spies observable; the logger wraps these.
    for (const method of ['log', 'info', 'warn', 'error', 'debug'] as const) {
      vi.spyOn(console, method).mockImplementation(() => {});
    }
    logger = new Logger(directory);
    await logger.init();
  });

  afterEach(async () => {
    logger.restoreConsole();
    vi.restoreAllMocks();
    await rm(directory, { recursive: true, force: true });
  });

  async function readLog(): Promise<string> {
    await logger.close();
    return readFile(join(directory, 'server.log'), 'utf8');
  }

  it('records an Error with its stack and a circular object without throwing', async () => {
    logger.interceptConsole();
    const circular: Record<string, unknown> = { id: 7 };
    circular.self = circular;

    expect(() => console.error('[x]', new Error('boom'), circular)).not.toThrow();

    const log = await readLog();
    expect(log).toContain(' ERROR [x] ');
    expect(log).toContain('Error: boom');
    expect(log).toMatch(/ {4}at /);
    expect(log).toContain('[Circular]');
  });

  it('records the source from an embedded tag and from a whole-argument tag', async () => {
    logger.interceptConsole();
    console.warn('[login] embedded message');
    console.log('[loadCliConfig]', 'split message');
    console.info('untagged message');

    const log = await readLog();
    expect(log).toMatch(/ WARN \[login\] embedded message\n/);
    expect(log).toMatch(/ LOG \[loadCliConfig\] split message\n/);
    expect(log).toMatch(/ INFO \[node-backend\] untagged message\n/);
  });

  it('still calls the original console first and unchanged', () => {
    const original = vi.mocked(console.error);
    logger.interceptConsole();
    const err = new Error('forwarded');

    console.error('[x]', err);

    expect(original).toHaveBeenCalledWith('[x]', err);
  });

  it('never throws when recording fails, and reports the failure on the original console', () => {
    const original = vi.mocked(console.error);
    vi.spyOn(FileLogger.prototype, 'write').mockImplementation(() => { throw new Error('disk gone'); });
    logger.interceptConsole();

    expect(() => console.error('[x]', 'still fine')).not.toThrow();

    expect(original).toHaveBeenCalledWith('[x]', 'still fine');
    expect(original).toHaveBeenCalledWith(
      '[node-backend] logger failed to record a console call:',
      expect.stringContaining('disk gone'),
    );
  });

  it('keeps recording after a failure (the re-entrancy guard is released)', async () => {
    vi.spyOn(FileLogger.prototype, 'write').mockImplementationOnce(() => { throw new Error('disk gone'); });
    logger.interceptConsole();

    console.log('[x]', 'first');
    console.log('[x]', 'second');

    expect(await readLog()).toContain(' LOG [x] second\n');
  });

  it('does not recurse when a console call is made while recording', async () => {
    const write = FileLogger.prototype.write;
    vi.spyOn(FileLogger.prototype, 'write').mockImplementationOnce(function (this: FileLogger, line: string) {
      console.error('[x]', 'from inside write');
      write.call(this, line);
    });
    logger.interceptConsole();

    expect(() => console.error('[x]', 'outer')).not.toThrow();

    const log = await readLog();
    expect(log).toContain('outer');
    expect(log).not.toContain('from inside write');
  });

  it('restoreConsole puts the originals back and stops recording', async () => {
    const originals = (['log', 'info', 'warn', 'error', 'debug'] as const).map((method) => console[method]);
    logger.interceptConsole();
    expect(console.log).not.toBe(originals[0]);

    logger.restoreConsole();

    expect((['log', 'info', 'warn', 'error', 'debug'] as const).map((method) => console[method])).toEqual(originals);
    console.log('[x]', 'after restore');
    expect(await readLog()).not.toContain('after restore');
  });

  it('interceptConsole twice does not record a call twice', async () => {
    logger.interceptConsole();
    logger.interceptConsole();
    console.log('[x]', 'once');
    const log = await readLog();
    expect(log.match(/once/g)).toHaveLength(1);
  });
});
