import { inspect, types } from 'util';
import { FileLogger } from './file-logger';
import type { LogEntry } from './log-ws';

const CONSOLE_METHODS = ['log', 'info', 'warn', 'error', 'debug'] as const;
type ConsoleMethod = (typeof CONSOLE_METHODS)[number];

const LEVEL_MAP: Record<ConsoleMethod, string> = {
  log: 'LOG',
  info: 'INFO',
  warn: 'WARN',
  error: 'ERROR',
  debug: 'DEBUG',
};

// Whole-argument tag: '[node-backend]' passed as its own first argument (the canonical form)
const SOURCE_PREFIX_PATTERN = /^\[([^\]]+)\]$/;
// Safety net for a tag glued to the message: '[login] OAuth URL available'.
// The tight character class keeps progress counters such as '[1/3] step' out.
const EMBEDDED_SOURCE_PATTERN = /^\[([A-Za-z0-9._:-]+)\]\s+([\s\S]*)$/;
const DEFAULT_SOURCE = 'node-backend';

// How many `cause` links of one Error are followed before the chain is cut.
const MAX_CAUSE_DEPTH = 5;

type ErrorLike = Error & { cause?: unknown; errors?: unknown };

function isError(value: unknown): value is ErrorLike {
  return value instanceof Error || types.isNativeError(value);
}

/**
 * JSON.stringify that survives circular references, bigint and nested Errors.
 * A value is `[Circular]` only when it is already on the *current ancestor path*,
 * so the same object referenced twice side by side is serialized both times.
 * Returns undefined when JSON has no representation for the value.
 */
function safeStringify(value: unknown): string | undefined {
  const ancestors: unknown[] = [];
  return JSON.stringify(value, function (this: unknown, _key: string, current: unknown) {
    // `this` is the object holding this key: drop every ancestor deeper than it.
    ancestors.length = ancestors.lastIndexOf(this) + 1;

    if (typeof current === 'bigint') return `${current}n`;
    if (typeof current !== 'object' || current === null) return current;
    if (ancestors.includes(current)) return '[Circular]';

    // Children are visited with the *returned* object as `this`, so that is what goes on the path.
    const replacement = isError(current) ? { name: current.name, message: current.message, stack: current.stack } : current;
    ancestors.push(replacement);
    return replacement;
  });
}

function inspectFallback(value: unknown): string {
  try {
    return inspect(value, { depth: 4, breakLength: Infinity });
  } catch {
    return '[Unserializable]';
  }
}

function formatObject(value: object): string {
  try {
    const json = safeStringify(value);
    if (json !== undefined) return json;
  } catch {
    // A throwing getter or toJSON — fall through to util.inspect.
  }
  return inspectFallback(value);
}

function formatError(err: ErrorLike, path: Set<unknown>, depth: number): string {
  path.add(err);
  try {
    let text: string;
    try {
      text = typeof err.stack === 'string' && err.stack.length > 0 ? err.stack : `${err.name}: ${err.message}`;
    } catch {
      text = '[Error]';
    }

    // Own enumerable extras (code, errno, syscall, path, ...); the rest is already part of the text.
    try {
      const extras: Record<string, unknown> = {};
      for (const key of Object.keys(err)) {
        if (key === 'stack' || key === 'message' || key === 'cause' || key === 'errors') continue;
        extras[key] = (err as unknown as Record<string, unknown>)[key];
      }
      if (Object.keys(extras).length > 0) {
        const json = safeStringify(extras);
        if (json !== undefined) text += ` ${json}`;
      }
    } catch {
      // Extras are best-effort.
    }

    try {
      if (err.cause !== undefined) text += `\nCaused by: ${formatCause(err.cause, path, depth + 1)}`;
      if (Array.isArray(err.errors)) {
        err.errors.forEach((member: unknown, index: number) => {
          text += `\nAggregated error [${index}]: ${formatCause(member, path, depth + 1)}`;
        });
      }
    } catch {
      // A throwing `cause` getter must not lose the error that was already formatted.
    }
    return text;
  } finally {
    path.delete(err);
  }
}

function formatCause(value: unknown, path: Set<unknown>, depth: number): string {
  if (!isError(value)) return formatLogArg(value);
  if (path.has(value)) return '[Circular]';
  if (depth > MAX_CAUSE_DEPTH) return '[cause chain truncated]';
  return formatError(value, path, depth);
}

/** Turn any console argument into log text. Never throws. */
export function formatLogArg(value: unknown): string {
  try {
    switch (typeof value) {
      case 'string':
        return value;
      case 'bigint':
        return `${value}n`;
      case 'symbol':
        return value.toString();
      case 'function':
        return `[Function ${value.name || 'anonymous'}]`;
      case 'undefined':
        return 'undefined';
      case 'object':
        if (value === null) return 'null';
        return isError(value) ? formatError(value, new Set(), 0) : formatObject(value);
      default:
        // number, boolean
        return String(value);
    }
  } catch {
    return '[Unserializable]';
  }
}

/**
 * Split console arguments into the log source and the message arguments.
 * Canonical form: console.X('[source]', message, ...rest). A first string that merely
 * starts with a tag ('[source] message') is accepted too; anything else is 'node-backend'.
 */
export function parseLogSource(args: unknown[]): { source: string; messageArgs: unknown[] } {
  const first = args[0];
  if (typeof first === 'string') {
    const whole = SOURCE_PREFIX_PATTERN.exec(first.trim());
    if (whole) return { source: whole[1], messageArgs: args.slice(1) };

    const embedded = EMBEDDED_SOURCE_PATTERN.exec(first);
    if (embedded) return { source: embedded[1], messageArgs: [embedded[2], ...args.slice(1)] };
  }
  return { source: DEFAULT_SOURCE, messageArgs: args };
}

export class Logger {
  private readonly fileLogger: FileLogger;
  // Bound originals: what an intercepted call forwards to.
  private originalConsole: Record<string, (...args: unknown[]) => void> = {};
  // The exact functions that were on `console`, so restoreConsole() puts them back untouched.
  private replacedConsole: Partial<Record<ConsoleMethod, (...args: unknown[]) => void>> = {};
  private consoleIntercepted: boolean = false;
  private isIntercepting: boolean = false;

  constructor(logDir?: string) {
    this.fileLogger = new FileLogger(logDir);
  }

  async init(): Promise<void> {
    await this.fileLogger.init();
  }

  interceptConsole(): void {
    if (this.consoleIntercepted) return;
    this.consoleIntercepted = true;

    for (const method of CONSOLE_METHODS) {
      this.replacedConsole[method] = console[method];
      const original = console[method].bind(console);
      this.originalConsole[method] = original;

      console[method] = (...args: unknown[]) => {
        // Call the original function first — must be kept because JetBrains Kotlin reads stderr
        original(...args);

        // Re-entrancy guard — console.error may be called from inside FileLogger.write()
        if (this.isIntercepting) {
          return;
        }
        this.isIntercepting = true;

        try {
          const { source, messageArgs } = parseLogSource(args);
          const message = messageArgs.map((arg) => formatLogArg(arg)).join(' ');
          this.writeLog(LEVEL_MAP[method], source, null, message);
        } catch (err) {
          // Recording is best-effort: a console call must never throw because of the logger.
          this.originalConsole.error?.('[node-backend] logger failed to record a console call:', formatLogArg(err));
        } finally {
          this.isIntercepting = false;
        }
      };
    }
  }

  /** Put the console functions back as they were before interceptConsole() (tests, shutdown). */
  restoreConsole(): void {
    for (const method of CONSOLE_METHODS) {
      const replaced = this.replacedConsole[method];
      if (replaced) console[method] = replaced;
    }
    this.replacedConsole = {};
    this.originalConsole = {};
    this.consoleIntercepted = false;
  }

  handleWebViewLogs(entries: LogEntry[]): void {
    for (const entry of entries) {
      const line = this.formatLine(entry.level, entry.source, entry.sessionId, entry.message, entry.timestamp);
      this.fileLogger.write(line);
    }
  }

  private writeLog(
    level: string,
    source: string,
    sessionId: string | null,
    message: string,
  ): void {
    const line = this.formatLine(level, source, sessionId, message);
    this.fileLogger.write(line);
  }

  private formatLine(
    level: string,
    source: string,
    sessionId: string | null,
    message: string,
    timestamp?: number,
  ): string {
    const ts = timestamp ? new Date(timestamp).toISOString() : new Date().toISOString();
    const sessionPart = sessionId ? `[${sessionId}]` : '';
    return `${ts} ${level} [${source}]${sessionPart} ${message}\n`;
  }

  async close(): Promise<void> {
    await this.fileLogger.close();
  }
}

let logger: Logger;

export function initLogger(logDir?: string): Logger {
  logger = new Logger(logDir);
  return logger;
}

export function getLogger(): Logger {
  return logger;
}
