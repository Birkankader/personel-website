import { mkdtemp, readFile, readdir, rm, stat, writeFile } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { FileLogger } from '../file-logger';

describe('bounded diagnostic file logging', () => {
  let directory: string;
  beforeEach(async () => { directory = await mkdtemp(join(tmpdir(), 'logger-budget-')); });
  afterEach(async () => { await rm(directory, { recursive: true, force: true }); });

  it('drains accepted lines in order and awaits async rotation during close', async () => {
    const logger = new FileLogger(directory, { fileBytes: 12, totalBytes: 100 });
    await logger.init();
    logger.write('first\n'); logger.write('second\n'); logger.write('third\n');
    await logger.close();
    const names = (await readdir(directory)).filter(name => name !== 'server.log').sort();
    const lines = await Promise.all([...names, 'server.log'].map(name => readFile(join(directory, name), 'utf8')));
    expect(lines.join('')).toBe('first\nsecond\nthird\n');
    expect(logger.pendingBytes).toBe(0);
  });

  it('reports overload once without growing the queue or losing already accepted lines', async () => {
    const onError = vi.fn();
    const logger = new FileLogger(directory, { bufferBytes: 100, onError });
    await logger.init();
    logger.write('accepted\n');
    for (let index = 0; index < 1000; index++) logger.write('over budget\n');
    expect(logger.pendingBytes).toBeLessThanOrEqual(100);
    expect(onError).toHaveBeenCalledOnce();
    await logger.close();
    expect(await readFile(join(directory, 'server.log'), 'utf8')).toBe('accepted\n');
  });

  it('enforces archive plus live-file budget at startup and rotation, leaving other files untouched', async () => {
    await writeFile(join(directory, 'server-old.log'), 'x'.repeat(100));
    await writeFile(join(directory, 'conversation.jsonl'), 'preserved');
    const logger = new FileLogger(directory, { fileBytes: 10, totalBytes: 25 });
    await logger.init();
    for (let index = 0; index < 12; index++) logger.write(`${index}\n`);
    await logger.close();
    const logs = (await readdir(directory)).filter(name => name.endsWith('.log'));
    expect((await Promise.all(logs.map(name => stat(join(directory, name))))).reduce((total, info) => total + info.size, 0)).toBeLessThanOrEqual(25);
    expect(await readFile(join(directory, 'conversation.jsonl'), 'utf8')).toBe('preserved');
  });
});
