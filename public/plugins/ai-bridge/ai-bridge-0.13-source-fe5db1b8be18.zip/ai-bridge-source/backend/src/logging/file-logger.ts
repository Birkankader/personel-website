import { mkdir, stat, readdir, unlink, rename, open, type FileHandle } from 'fs/promises';
import { join } from 'path';
import { homedir } from 'os';

interface FileLoggerOptions {
  bufferBytes?: number;
  fileBytes?: number;
  totalBytes?: number;
  onError?: (error: Error) => void;
}

/** Diagnostic logs only; the CLI persists original conversation events.
 * Console cannot await disk pressure: stop this sink explicitly on overflow,
 * preserving accepted lines without building an unbounded queue. */
export class FileLogger {
  private handle?: FileHandle;
  private currentSize = 0;
  private readonly queue: Array<{ line: string; bytes: number }> = [];
  private queuedBytes = 0;
  private pumping?: Promise<void>;
  private closed = false;
  private failed = false;
  private sequence = 0;
  private readonly bufferBytes: number;
  private readonly fileBytes: number;
  private readonly totalBytes: number;

  constructor(private readonly logDir = join(homedir(), '.ai-bridge', 'logs'), private readonly options: FileLoggerOptions = {}) {
    this.bufferBytes = options.bufferBytes ?? 2 * 1024 * 1024;
    this.fileBytes = options.fileBytes ?? 50 * 1024 * 1024;
    this.totalBytes = options.totalBytes ?? 256 * 1024 * 1024;
  }

  async init(): Promise<void> {
    await mkdir(this.logDir, { recursive: true });
    this.handle = await open(join(this.logDir, 'server.log'), 'a');
    this.currentSize = (await this.handle.stat()).size;
    if (this.currentSize >= this.fileBytes) await this.rotate();
    await this.enforceCapLimit();
  }

  get pendingBytes(): number { return this.queuedBytes; }

  write(line: string): void {
    if (this.closed || this.failed || !this.handle) return;
    // Include the in-flight line and retained UTF-16 strings in the budget.
    const bytes = 64 + line.length * 2;
    if (this.queuedBytes + bytes > this.bufferBytes || Buffer.byteLength(line) > this.fileBytes) {
      this.fail(new Error('Diagnostic file logging stopped: buffer budget exceeded. Console and conversation events remain available.'));
      return;
    }
    this.queue.push({ line, bytes });
    this.queuedBytes += bytes;
    if (!this.pumping) this.pumping = this.flush().finally(() => { this.pumping = undefined; });
  }

  private async flush(): Promise<void> {
    try {
      while (this.queue.length) {
        const next = this.queue[0];
        const length = Buffer.byteLength(next.line);
        if (this.currentSize + length > this.fileBytes) await this.rotate();
        await this.handle!.writeFile(next.line, 'utf8');
        this.currentSize += length;
        this.queue.shift();
        this.queuedBytes -= next.bytes;
      }
    } catch (error) {
      this.queue.length = 0;
      this.queuedBytes = 0;
      this.fail(error instanceof Error ? error : new Error(String(error)));
    }
  }

  private fail(error: Error): void {
    if (this.failed) return;
    this.failed = true;
    // Bypass intercepted console to avoid recursion on disk failure.
    if (this.options.onError) this.options.onError(error);
    else process.stderr.write(`[FileLogger] ${error.message}\n`);
  }

  private async rotate(): Promise<void> {
    await this.handle?.close();
    const timestamp = new Date().toISOString().replace(/[:.]/g, '');
    await rename(join(this.logDir, 'server.log'), join(this.logDir, `server-${timestamp}-${process.pid}-${this.sequence++}.log`));
    this.handle = await open(join(this.logDir, 'server.log'), 'a');
    this.currentSize = 0;
    await this.enforceCapLimit();
  }

  private async enforceCapLimit(): Promise<void> {
    const archives: Array<{ name: string; size: number; modified: number }> = [];
    for (const name of await readdir(this.logDir)) {
      if (!/^server-.+\.log$/.test(name)) continue;
      try {
        const info = await stat(join(this.logDir, name));
        if (info.isFile()) archives.push({ name, size: info.size, modified: info.mtimeMs });
      } catch { /* An archive may already have been removed. */ }
    }
    archives.sort((a, b) => a.modified - b.modified || a.name.localeCompare(b.name));
    // Reserve a whole live file so continued writes cannot exceed the cap.
    let total = archives.reduce((sum, file) => sum + file.size, this.fileBytes);
    for (const archive of archives) {
      if (total <= this.totalBytes) break;
      await unlink(join(this.logDir, archive.name));
      total -= archive.size;
    }
  }

  async close(): Promise<void> {
    this.closed = true;
    await this.pumping;
    await this.handle?.close();
    this.handle = undefined;
  }
}
