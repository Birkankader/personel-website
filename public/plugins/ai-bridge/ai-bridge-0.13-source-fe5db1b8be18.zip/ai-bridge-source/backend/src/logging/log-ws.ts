import { WebSocketServer, WebSocket } from 'ws';
import type { IncomingMessage } from 'http';
import type { Duplex } from 'stream';
import { MessageType } from '../shared';

export enum LogLevel {
  LOG = 'log',
  INFO = 'info',
  WARN = 'warn',
  ERROR = 'error',
  DEBUG = 'debug',
}

export interface LogEntry {
  level: LogLevel;
  source: string;
  sessionId: string | null;
  message: string;
  timestamp: number;
}

interface LogBatchMessage {
  type: MessageType.LOG_BATCH;
  entries: LogEntry[];
}

/**
 * The `/logs` socket: webviews send their console output here in LOG_BATCH
 * messages. Nothing is sent back; the backend's own lines go to `server.log`.
 */
export class LogWebSocketServer {
  private readonly wss: WebSocketServer;
  private readonly clients: Set<WebSocket> = new Set();
  private closing: Promise<void> | undefined;
  private readonly onLogBatch: (entries: LogEntry[]) => void;

  constructor(onLogBatch: (entries: LogEntry[]) => void) {
    this.onLogBatch = onLogBatch;
    this.wss = new WebSocketServer({ noServer: true });

    this.wss.on('connection', (ws: WebSocket) => {
      this.clients.add(ws);

      ws.on('message', (data: Buffer) => {
        let parsed: LogBatchMessage;
        try {
          parsed = JSON.parse(data.toString()) as LogBatchMessage;
        } catch {
          return;
        }

        if (parsed.type === MessageType.LOG_BATCH) {
          this.onLogBatch(parsed.entries);
        }
      });

      ws.on('close', () => {
        this.clients.delete(ws);
      });
    });
  }

  handleUpgrade(request: IncomingMessage, socket: Duplex, head: Buffer): void {
    this.wss.handleUpgrade(request, socket, head, (ws) => {
      this.wss.emit('connection', ws, request);
    });
  }

  close(): Promise<void> {
    if (this.closing) return this.closing;
    for (const ws of this.clients) ws.close();
    this.clients.clear();
    this.wss.close();
    this.closing = Promise.resolve();
    return this.closing;
  }
}
