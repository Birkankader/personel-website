import { describe, it, expect, beforeAll, afterAll, vi } from 'vitest';
import { WebSocket } from 'ws';
import { startWebSocketServer, AUTH_SUBPROTOCOL, type MessageHandler } from '../ws-server';
import { handleMessage } from '../../core/handlers/index';
import { LogWebSocketServer } from '../../logging/log-ws';
import { authToken } from '../../config/environment';
import { ClientEnv, MessageType } from '../../shared';
import type { Bridge } from '../../bridge/bridge-interface';

// Error-ACK contract, end to end: boot a REAL server and talk to it over a real
// /ws socket. A request (a message carrying a requestId) must always get an
// answer — an unknown type or a throwing handler answers with ERROR instead of
// leaving the webview waiting for its timeout — and every reply names its
// request on the envelope as well as in the payload. Only side-effect-free
// types are used (no dialogs, no CLI spawn, no network).

const ALLOWED_ORIGIN = 'http://localhost';

function createMockBridge(): Bridge {
  return {
    openFile: vi.fn(),
    openDiff: vi.fn(),
    refreshFiles: vi.fn(),
    createSession: vi.fn(),
    openNewTab: vi.fn(),
    openSettings: vi.fn(),
    openTerminal: vi.fn(),
    openUrl: vi.fn(),
    pickFiles: vi.fn().mockResolvedValue({ paths: [] }),
    requiresRestart: vi.fn().mockResolvedValue(false),
  } as unknown as Bridge;
}

interface Frame {
  type: string;
  requestId?: string;
  payload?: Record<string, unknown>;
}

describe('ws-server error-ACK contract', () => {
  let close: () => void;
  let socket: WebSocket;
  const frames: Frame[] = [];

  /** Wait until a frame matching `predicate` has arrived (frames are kept in arrival order). */
  async function waitForFrame(predicate: (frame: Frame) => boolean, timeoutMs = 3000): Promise<Frame> {
    const deadline = Date.now() + timeoutMs;
    for (;;) {
      const found = frames.find(predicate);
      if (found) return found;
      if (Date.now() > deadline) throw new Error(`No matching frame within ${timeoutMs} ms; got ${JSON.stringify(frames)}`);
      await new Promise((resolve) => setTimeout(resolve, 10));
    }
  }

  function post(message: Record<string, unknown>): void {
    socket.send(JSON.stringify({ timestamp: Date.now(), payload: {}, ...message }));
  }

  beforeAll(async () => {
    const bridges = {
      [ClientEnv.BROWSER]: createMockBridge(),
      [ClientEnv.JETBRAINS]: createMockBridge(),
    };
    // 'TEST_THROW' is not a real type: it stands in for any handler that rejects.
    const handler: MessageHandler = (connectionId, message, connections, bridge, allBridges) => {
      if (message.type === 'TEST_THROW') throw new Error('kaboom');
      return handleMessage(connectionId, message, connections, bridge, allBridges);
    };
    const handle = await startWebSocketServer(0, '127.0.0.1', bridges, handler, undefined, new LogWebSocketServer(() => {}));
    close = handle.close;
    socket = new WebSocket(`ws://127.0.0.1:${handle.port}/ws`, [AUTH_SUBPROTOCOL, authToken], { origin: ALLOWED_ORIGIN });
    socket.on('message', (data) => frames.push(JSON.parse(String(data)) as Frame));
    await new Promise<void>((resolve, reject) => {
      socket.once('open', resolve);
      socket.once('error', reject);
    });
    await waitForFrame((frame) => frame.type === MessageType.BRIDGE_READY);
  });

  afterAll(() => {
    socket?.terminate();
    close?.();
  });

  it('answers an unknown type that carries a requestId with ERROR (envelope and payload)', async () => {
    // UPDATE_PLUGIN is a deleted type: the realistic stale-client case.
    post({ type: 'UPDATE_PLUGIN', requestId: 'r1' });
    const reply = await waitForFrame((frame) => frame.requestId === 'r1');
    expect(reply.type).toBe(MessageType.ERROR);
    expect(reply.payload).toEqual({ requestId: 'r1', error: 'Unknown message type: UPDATE_PLUGIN' });
  });

  it('only logs an unknown type without a requestId (fire-and-forget gets no reply)', async () => {
    const before = frames.length;
    post({ type: 'UPDATE_PLUGIN' });
    // A later unknown-with-requestId proves the first message was processed and nothing came back for it.
    post({ type: 'UPDATE_PLUGIN', requestId: 'r-after-fire-and-forget' });
    await waitForFrame((frame) => frame.requestId === 'r-after-fire-and-forget');
    const replies = frames.slice(before);
    expect(replies).toHaveLength(1);
    expect(replies[0].payload).toMatchObject({ requestId: 'r-after-fire-and-forget' });
  });

  it('answers a request whose handler throws with ERROR carrying the error message', async () => {
    post({ type: 'TEST_THROW', requestId: 'r2' });
    const reply = await waitForFrame((frame) => frame.requestId === 'r2');
    expect(reply.type).toBe(MessageType.ERROR);
    expect(reply.payload).toEqual({ requestId: 'r2', error: 'kaboom' });
  });

  it('does not reply to a throwing handler when the message has no requestId', async () => {
    const before = frames.length;
    post({ type: 'TEST_THROW' });
    post({ type: 'TEST_THROW', requestId: 'r-after-throw' });
    await waitForFrame((frame) => frame.requestId === 'r-after-throw');
    expect(frames.slice(before)).toHaveLength(1);
  });

  it('puts the requestId on the envelope of a normal ACK too, with the payload untouched', async () => {
    post({ type: MessageType.GET_RUNTIME_TASKS, requestId: 'r3' });
    const reply = await waitForFrame((frame) => frame.requestId === 'r3');
    expect(reply.type).toBe(MessageType.ACK);
    expect(reply.payload?.requestId).toBe('r3');
    expect(reply.payload).toMatchObject({ tasks: [] });
  });
});
