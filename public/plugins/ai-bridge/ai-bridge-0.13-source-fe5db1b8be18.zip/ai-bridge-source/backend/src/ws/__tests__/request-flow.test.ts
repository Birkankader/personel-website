import { describe, expect, it, vi } from 'vitest';
import { WebSocketRequestFlow } from '../request-flow';

async function settle(): Promise<void> {
  for (let i = 0; i < 8; i++) await Promise.resolve();
}

describe('WebSocket request flow', () => {
  it('pauses new reads, bounds active work and drains already-read requests in order', async () => {
    const socket = { pause: vi.fn(), resume: vi.fn() };
    const started: number[] = [];
    const finish: Array<() => void> = [];
    const flow = new WebSocketRequestFlow<number>(socket, message => {
      started.push(message);
      return new Promise(resolve => finish.push(resolve));
    }, vi.fn(), () => false, 2);
    for (let i = 0; i < 5; i++) flow.receive(i);
    await settle();
    expect(started).toEqual([0, 1]);
    expect(socket.pause).toHaveBeenCalledOnce();
    for (let i = 0; i < 5; i++) {
      finish[i]();
      await settle();
    }
    expect(started).toEqual([0, 1, 2, 3, 4]);
    expect(socket.resume).toHaveBeenCalledOnce();
  });

  it('runs a control message that answers a handler holding the only slot', async () => {
    const socket = { pause: vi.fn(), resume: vi.fn() };
    let finishWaiting!: () => void;
    const started: string[] = [];
    const flow = new WebSocketRequestFlow<string>(socket, message => {
      started.push(message);
      if (message === 'WAITING') return new Promise(resolve => { finishWaiting = resolve; });
      if (message === 'ANSWER') finishWaiting();
    }, vi.fn(), message => message === 'ANSWER', 1);
    flow.receive('WAITING');
    flow.receive('ANSWER');
    await settle();
    expect(started).toEqual(['WAITING', 'ANSWER']);
    expect(socket.resume).toHaveBeenCalledOnce();
  });

  it('waits for outgoing capacity and releases pending work after pressure clears', async () => {
    const socket = { pause: vi.fn(), resume: vi.fn() };
    const handle = vi.fn();
    const flow = new WebSocketRequestFlow<string>(socket, handle, vi.fn(), () => false);
    flow.setPressure(true);
    flow.receive('first');
    flow.receive('second');
    await settle();
    expect(handle).not.toHaveBeenCalled();
    flow.setPressure(false);
    await settle();
    expect(handle.mock.calls).toEqual([['first'], ['second']]);
    expect(socket.resume).toHaveBeenCalledOnce();
  });

  it('reports synchronous throws and discards queued work only on connection disposal', async () => {
    const socket = { pause: vi.fn(), resume: vi.fn() };
    const failure = new Error('handler failed');
    const onError = vi.fn();
    const handle = vi.fn(() => { throw failure; });
    const flow = new WebSocketRequestFlow<string>(socket, handle, onError, () => false, 1);
    flow.receive('first');
    flow.receive('queued');
    flow.dispose();
    await settle();
    expect(handle).toHaveBeenCalledOnce();
    expect(onError).toHaveBeenCalledWith(failure, 'first');
    expect(socket.resume).not.toHaveBeenCalled();
  });
});
