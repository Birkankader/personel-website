import type { WebSocket } from 'ws';
import { describe, expect, it, vi } from 'vitest';
import { ConnectionManager } from '../connection-manager';
import { MessageType } from '../../shared';

vi.mock('../../core/claude', () => ({
  Claude: { killTree: vi.fn(), killTreeNonBlocking: vi.fn(async () => {}) },
}));
vi.mock('../../core/features/runtime-tasks', () => ({
  runtimeTasks: () => ({ limiter: { shutdown: vi.fn(), cancelSession: vi.fn() } }),
}));

function socket(slow: boolean) {
  const callbacks: Array<(error?: Error) => void> = [];
  const ws = {
    readyState: 1,
    bufferedAmount: 0,
    close: vi.fn(),
    send: vi.fn((_data: string, callback: (error?: Error) => void) => {
      if (slow) callbacks.push(callback);
      else callback();
    }),
  };
  return { ws, callbacks, asSocket: ws as unknown as WebSocket };
}

describe('ConnectionManager outbound backpressure', () => {
  it('keeps every direct, session and global message in FIFO order without delaying a fast subscriber', async () => {
    const manager = new ConnectionManager(true);
    const slow = socket(true);
    const fast = socket(false);
    const slowId = manager.addConnection(slow.asSocket);
    const fastId = manager.addConnection(fast.asSocket);
    manager.subscribe(slowId, 'session-1');
    manager.subscribe(fastId, 'session-1');

    const permission = {
      type: 'control_request',
      request_id: 'permission-1',
      request: { subtype: 'can_use_tool', tool_name: 'Bash', input: { command: 'echo Türkçe 🧪' } },
      untouched: { futureField: [1, null, false] },
    };
    const originalPermission = structuredClone(permission);

    try {
      manager.sendTo(slowId, 'DIRECT_REPLY', { requestId: 'first', ok: true }, 'session-1');
      manager.sendTo(fastId, 'DIRECT_REPLY', { requestId: 'first', ok: true }, 'session-1');
      manager.broadcastToSession('session-1', MessageType.CLI_EVENT, permission);
      manager.broadcastToAll('SETTINGS_SAVED', { requestId: 'settings-1', saved: true });
      manager.broadcastToSession('session-1', MessageType.PERMISSION_RESOLVED, { controlRequestId: 'permission-1' });
      manager.sendTo(slowId, 'DIRECT_REPLY', { requestId: 'last', ok: true }, 'session-1');
      manager.sendTo(fastId, 'DIRECT_REPLY', { requestId: 'last', ok: true }, 'session-1');

      expect(fast.ws.send).toHaveBeenCalledTimes(5);
      expect(slow.ws.send).toHaveBeenCalledTimes(1);
      // Serialization takes a snapshot when queued; later producer mutation
      // must not alter the eventual permission event.
      permission.request.input.command = 'changed after enqueue';
      permission.untouched.futureField.push(2);

      for (let delivered = 1; delivered < 5; delivered++) {
        expect(slow.callbacks).toHaveLength(1);
        slow.callbacks.shift()!();
        const deadline = Date.now() + 2_000;
        while (slow.ws.send.mock.calls.length < delivered + 1) {
          if (Date.now() > deadline) throw new Error('Timed out waiting for asynchronous queued delivery');
          await new Promise<void>(resolve => setTimeout(resolve, 1));
        }
        expect(slow.ws.send).toHaveBeenCalledTimes(delivered + 1);
      }
      slow.callbacks.shift()!();

      const messages = slow.ws.send.mock.calls.map(([data]) => JSON.parse(data));
      const fastMessages = fast.ws.send.mock.calls.map(([data]) => JSON.parse(data));
      expect(messages.map(({ type, sessionId, payload }) => ({ type, sessionId, payload }))).toEqual([
        { type: 'DIRECT_REPLY', sessionId: 'session-1', payload: { requestId: 'first', ok: true } },
        { type: MessageType.CLI_EVENT, sessionId: 'session-1', payload: originalPermission },
        { type: 'SETTINGS_SAVED', sessionId: undefined, payload: { requestId: 'settings-1', saved: true } },
        { type: MessageType.PERMISSION_RESOLVED, sessionId: 'session-1', payload: { controlRequestId: 'permission-1' } },
        { type: 'DIRECT_REPLY', sessionId: 'session-1', payload: { requestId: 'last', ok: true } },
      ]);
      expect(messages.slice(1, 4)).toEqual(fastMessages.slice(1, 4));
      expect(messages.every(message => typeof message.timestamp === 'number')).toBe(true);
      expect(slow.ws.close).not.toHaveBeenCalled();
      expect(fast.ws.close).not.toHaveBeenCalled();
    } finally {
      await manager.shutdownAll();
    }
  });
});
