import { EventEmitter } from 'node:events';
import type { ChildProcess } from 'node:child_process';
import type { WebSocket } from 'ws';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { ConnectionManager } from '../connection-manager';
import { Claude } from '../../core/claude';

vi.mock('../../core/claude', () => ({ Claude: { killTree: vi.fn(), killTreeNonBlocking: vi.fn(async () => {}) } }));
vi.mock('../../core/features/runtime-tasks', () => ({ runtimeTasks: () => ({ limiter: { shutdown: vi.fn(), cancelSession: vi.fn() } }) }));
const child = (pid: number) => Object.assign(new EventEmitter(), { pid, exitCode: null as number | null, signalCode: null }) as ChildProcess;
const socket = () => ({
  close: vi.fn(),
  send: vi.fn((_data: string, callback?: (error?: Error) => void) => callback?.()),
  readyState: 1,
  bufferedAmount: 0,
}) as unknown as WebSocket;

describe('closed session process ownership', () => {
  beforeEach(() => { vi.useFakeTimers(); vi.clearAllMocks(); });
  afterEach(() => vi.useRealTimers());

  it('waits for child close after clearing connections and preserves the emergency exit sweep', async () => {
    const manager = new ConnectionManager(true);
    const proc = child(91001);
    manager.setProcess('one', proc);
    manager.shutdownAll();
    let done = false;
    const wait = manager.awaitSessionProcessExits(3000).then(() => { done = true; });
    await Promise.resolve();
    expect(done).toBe(false);
    expect(manager.killAllSessionProcesses('SIGKILL')).toBe(1);
    expect(Claude.killTree).toHaveBeenCalledWith(proc, 'SIGKILL');
    proc.emit('close', 0);
    await wait;
    expect(done).toBe(true);
    expect(manager.killAllSessionProcesses('SIGKILL')).toBe(0);
    expect(vi.getTimerCount()).toBe(0);
  });

  it('keeps a closed tab child until reaped, without blocking other connections', async () => {
    const manager = new ConnectionManager(true);
    const id = manager.addConnection(socket());
    const proc = child(91002);
    manager.subscribe(id, 'closed-tab');
    manager.setProcess('closed-tab', proc);
    manager.removeConnection(id);
    await vi.advanceTimersByTimeAsync(30000);
    expect(Claude.killTreeNonBlocking).toHaveBeenCalledWith(proc, 'SIGTERM');
    expect(Claude.killTree).not.toHaveBeenCalled();
    expect(manager.getSession('closed-tab')).toBeUndefined();
    expect(manager.killAllSessionProcesses('SIGKILL')).toBe(1);
    proc.emit('close', 0);
    expect(manager.killAllSessionProcesses('SIGKILL')).toBe(0);
  });

  it('does not repeat shutdown or rearm idle cleanup on delayed socket close', async () => {
    const manager = new ConnectionManager();
    const ws = socket();
    const id = manager.addConnection(ws);
    manager.setProcess('one', child(91003));
    manager.shutdownAll(); manager.shutdownAll();
    manager.removeConnection(id);
    expect(Claude.killTreeNonBlocking).toHaveBeenCalledTimes(1);
    expect(ws.close).toHaveBeenCalledTimes(1);
    expect(vi.getTimerCount()).toBe(0);
  });

  it('bounds the close wait and removes its temporary listener on timeout', async () => {
    const manager = new ConnectionManager(true);
    const proc = child(91004);
    manager.setProcess('one', proc);
    manager.shutdownAll();
    const baseline = proc.listenerCount('close');
    const wait = manager.awaitSessionProcessExits(3000);
    await vi.advanceTimersByTimeAsync(3000);
    await wait;
    expect(proc.listenerCount('close')).toBe(baseline);
    expect(manager.killAllSessionProcesses('SIGKILL')).toBe(1);
    proc.emit('close', 0);
  });

  it('terminates a late process registration after shutdown instead of resurrecting a session', () => {
    const manager = new ConnectionManager(true);
    manager.shutdownAll();
    const proc = child(91005);
    manager.setProcess('late', proc);
    expect(Claude.killTreeNonBlocking).toHaveBeenCalledWith(proc, 'SIGTERM');
    expect(manager.getProcess('late')).toBeNull();
    expect(manager.killAllSessionProcesses('SIGKILL')).toBe(1);
    proc.emit('close', 0);
  });
});
