import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { mkdtempSync, readdirSync, rmSync, statSync, writeFileSync } from 'fs';
import { join } from 'path';
import { tmpdir } from 'os';
import { BudgetedWebSocketSender } from '../budgeted-sender';

const io = vi.hoisted(() => ({ beforeWrite: undefined as undefined | (() => Promise<void>) }));
vi.mock('fs/promises', async importOriginal => {
  const actual = await importOriginal<typeof import('fs/promises')>();
  return {
    ...actual,
    open: async (...args: Parameters<typeof actual.open>) => {
      const handle = await actual.open(...args);
      const write = handle.write.bind(handle);
      handle.write = (async (...writeArgs: Parameters<typeof handle.write>) => {
        await io.beforeWrite?.();
        return write(...writeArgs);
      }) as typeof handle.write;
      return handle;
    },
  };
});

class Socket {
  readyState = 1;
  bufferedAmount = 0;
  sent: string[] = [];
  callbacks: Array<(error?: Error) => void> = [];
  send = vi.fn((data: string, callback: (error?: Error) => void) => {
    this.sent.push(data);
    this.callbacks.push(callback);
  });
  complete(error?: Error) { this.callbacks.shift()?.(error); }
}

const tick = () => new Promise<void>(resolve => setImmediate(resolve));
async function until(predicate: () => boolean, label: string) {
  const deadline = Date.now() + 2_000;
  let attempts = 0;
  while (!predicate()) {
    if (Date.now() > deadline) throw new Error(`Timed out waiting for ${label}`);
    // Yield to the real fs worker pool; fake timers would conceal I/O races.
    if (++attempts % 20 === 0) await new Promise(resolve => setTimeout(resolve, 1));
    else await tick();
  }
}

describe('BudgetedWebSocketSender', () => {
  let root: string;
  let senders: BudgetedWebSocketSender[];
  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), 'ws-budget-test-'));
    senders = [];
    io.beforeWrite = undefined;
  });
  afterEach(async () => {
    io.beforeWrite = undefined;
    await Promise.all(senders.map(sender => sender.dispose()));
    rmSync(root, { recursive: true, force: true });
  });
  function create(socket = new Socket(), memoryBytes = 256, diskBytes = 512) {
    const onError = vi.fn();
    const onPressureChange = vi.fn();
    const sender = new BudgetedWebSocketSender(socket, {
      memoryBytes, socketBytes: 128, diskBytes, spoolRoot: root, onError, onPressureChange,
    });
    senders.push(sender);
    return { socket, sender, onError, onPressureChange };
  }
  function files(): string[] {
    return readdirSync(root).flatMap(directory => readdirSync(join(root, directory)).map(file => join(root, directory, file)));
  }
  function diskFootprint(): number {
    try { return files().reduce((sum, file) => sum + statSync(file).size, 0); }
    catch (error) {
      // A completed asynchronous cleanup can remove a file between listing/stat.
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return 0;
      throw error;
    }
  }
  async function drain(socket: Socket, count: number) {
    await until(() => {
      socket.complete();
      return socket.sent.length === count && socket.callbacks.length === 0;
    }, `delivery of ${count} frames`);
  }

  it('sends an uncongested frame immediately without creating a spool', async () => {
    const { socket, sender } = create();
    await sender.send('{"type":"ready","original":true}');
    expect(socket.sent).toEqual(['{"type":"ready","original":true}']);
    expect(sender.pendingMemoryBytes).toBe(0);
    expect(sender.pendingDiskBytes).toBe(0);
    expect(readdirSync(root)).toEqual([]);
  });

  it('blocks the producer at capacity and reuses a bounded ring without losing or reordering mixed Unicode frames', async () => {
    const { socket, sender, onError } = create(new Socket(), 512, 768);
    const frames = Array.from({ length: 48 }, (_, n) => JSON.stringify({
      type: ['CLI_EVENT', 'PERMISSION_RESOLVED', 'SETTING_SAVED', 'STREAM_END'][n % 4],
      sessionId: 'session', timestamp: n, payload: { index: n, text: 'çığ 😀 漢字', untouched: [n, null] },
    }));
    let admitted = 0;
    const producer = (async () => {
      for (const frame of frames) {
        await sender.send(frame);
        admitted++;
        expect(sender.pendingMemoryBytes).toBeLessThanOrEqual(512);
        expect(sender.pendingDiskBytes).toBeLessThanOrEqual(768);
      }
    })();
    let occupied = 0;
    let diskRecords = 0;
    for (const frame of frames.slice(1)) {
      const bytes = Buffer.byteLength(frame) + 4;
      if (occupied + bytes > 768) break;
      occupied += bytes;
      diskRecords++;
    }
    // Each frame fits RAM alone. Capacity is one sending + disk + one RAM frame.
    const capacity = diskRecords + 2;
    await until(() => admitted === capacity, 'full RAM and disk budget');
    await tick();
    expect(admitted).toBe(capacity);
    expect(admitted).toBeLessThan(frames.length);
    expect(socket.sent).toHaveLength(1);
    let largestFile = 0;
    await until(() => {
      largestFile = Math.max(largestFile, diskFootprint());
      expect(sender.pendingMemoryBytes).toBeLessThanOrEqual(512);
      expect(sender.pendingDiskBytes).toBeLessThanOrEqual(768);
      expect(largestFile).toBeLessThanOrEqual(768);
      socket.complete();
      return socket.sent.length === frames.length && socket.callbacks.length === 0;
    }, 'bounded ring wrap and ordered delivery');
    await producer;
    expect(largestFile).toBeGreaterThan(0);
    expect(socket.sent).toEqual(frames);
    expect(onError).not.toHaveBeenCalled();
    expect(sender.pendingMemoryBytes).toBe(0);
    expect(sender.pendingDiskBytes).toBe(0);
  });

  it('honors bufferedAmount and resumes once the socket drains', async () => {
    const { socket, sender } = create();
    socket.bufferedAmount = 128;
    for (const frame of ['one', 'two', 'three']) await sender.send(frame);
    expect(socket.send).not.toHaveBeenCalled();
    socket.bufferedAmount = 0;
    await drain(socket, 3);
    expect(socket.sent).toEqual(['one', 'two', 'three']);
  });

  it('delivers one oversized frame intact without exceeding the disk quota', async () => {
    const { socket, sender } = create();
    await sender.send('first');
    const large = JSON.stringify({ type: 'SESSION_LOADED', payload: { text: '😀çok'.repeat(2000) } });
    let finished = false;
    const producer = (async () => {
      await sender.send(large);
      await sender.send('last');
      finished = true;
    })();
    await tick();
    expect(sender.pendingDiskBytes).toBe(0);
    expect(diskFootprint()).toBe(0);
    await drain(socket, 3);
    await producer;
    expect(finished).toBe(true);
    expect(socket.sent).toEqual(['first', large, 'last']);
  });

  it('admits a blocked frame exactly once when send completion is synchronous', async () => {
    const { socket, sender, onError } = create();
    await sender.send('first');
    const large = 'oversized'.repeat(100);
    const pending = sender.send(large);
    await tick();
    expect(socket.sent).toEqual(['first']);
    socket.send.mockImplementation((data, callback) => {
      socket.sent.push(data);
      callback();
    });
    socket.complete();
    await pending;
    await sender.send('last');
    await until(() => socket.sent.length >= 3, 'synchronous callback admission');
    expect(socket.sent).toEqual(['first', large, 'last']);
    expect(onError).not.toHaveBeenCalled();
  });

  it('keeps the event loop responsive while an asynchronous disk write is stalled', async () => {
    const { socket, sender, onError } = create();
    await sender.send('first');
    let entered = false;
    let release!: () => void;
    const gate = new Promise<void>(resolve => { release = resolve; });
    io.beforeWrite = async () => { entered = true; await gate; };
    const frames = Array.from({ length: 10 }, (_, i) => `${i}:` + 'x'.repeat(78));
    const producer = (async () => { for (const frame of frames) await sender.send(frame); })();
    try {
      await until(() => entered, 'stalled asynchronous write');
      let timerRan = false;
      await new Promise<void>(resolve => setTimeout(() => { timerRan = true; resolve(); }, 1));
      expect(timerRan).toBe(true);
      expect(sender.pendingMemoryBytes).toBeLessThanOrEqual(256);
      expect(socket.sent).toEqual(['first']);
    } finally {
      io.beforeWrite = undefined;
      release();
    }
    await drain(socket, frames.length + 1);
    await producer;
    expect(socket.sent).toEqual(['first', ...frames]);
    expect(onError).not.toHaveBeenCalled();
  });

  it('disposes during an unfinished disk write and releases blocked producers without leaking files', async () => {
    const { socket, sender, onError } = create();
    await sender.send('in-flight');
    let entered = false;
    let release!: () => void;
    const gate = new Promise<void>(resolve => { release = resolve; });
    io.beforeWrite = async () => { entered = true; await gate; };
    const producer = (async () => {
      for (let i = 0; i < 12; i++) await sender.send('x'.repeat(80));
    })();
    try {
      await until(() => entered, 'in-progress spool write');
      const disposed = sender.dispose();
      const disposedAgain = sender.dispose();
      io.beforeWrite = undefined;
      release();
      await Promise.all([disposed, disposedAgain, producer]);
    } finally { io.beforeWrite = undefined; release(); }
    socket.complete();
    await sender.send('after-close');
    expect(socket.sent).toEqual(['in-flight']);
    expect(readdirSync(root)).toEqual([]);
    expect(sender.pendingMemoryBytes).toBe(0);
    expect(sender.pendingDiskBytes).toBe(0);
    expect(onError).not.toHaveBeenCalled();
  });

  it('stops draining when a socket closes while buffered', async () => {
    const { socket, sender } = create();
    socket.bufferedAmount = 128;
    await sender.send('pending');
    socket.readyState = 3;
    await until(() => sender.pendingMemoryBytes === 0, 'closed socket cleanup');
    await sender.dispose();
    expect(socket.sent).toEqual([]);
    expect(readdirSync(root)).toEqual([]);
  });

  it('reports a callback failure once and releases queued data', async () => {
    const { socket, sender, onError } = create();
    await sender.send('in-flight');
    await sender.send('queued');
    const error = new Error('socket write failed');
    socket.complete(error);
    await sender.dispose();
    await sender.send('after-failure');
    expect(onError).toHaveBeenCalledExactlyOnceWith(error);
    expect(readdirSync(root)).toEqual([]);
  });

  it('settles a blocked admission when its direct socket send throws', async () => {
    const { socket, sender, onError } = create();
    await sender.send('in-flight');
    const pending = sender.send('oversized'.repeat(100));
    socket.send.mockImplementationOnce(() => { throw new Error('write failed during admission'); });
    expect(() => socket.complete()).not.toThrow();
    await pending;
    await sender.dispose();
    expect(onError).toHaveBeenCalledOnce();
    expect(sender.isBackpressured).toBe(false);
  });

  it('reports synchronous send and asynchronous disk-write failures explicitly', async () => {
    const first = create();
    first.socket.send.mockImplementationOnce(() => { throw new Error('send failure'); });
    await first.sender.send('test');
    expect(first.onError).toHaveBeenCalledOnce();

    const socket = new Socket();
    const onError = vi.fn();
    const sender = new BudgetedWebSocketSender(socket, { memoryBytes: 256, diskBytes: 512, spoolRoot: join(root, 'missing'), onError });
    senders.push(sender);
    await sender.send('first');
    const producer = (async () => { for (let i = 0; i < 8; i++) await sender.send('x'.repeat(80)); })();
    await until(() => onError.mock.calls.length > 0, 'disk failure');
    await producer;
    await sender.dispose();
    expect(onError).toHaveBeenCalledOnce();
    expect(socket.sent).toEqual(['first']);
  });

  it('rejects a corrupt spool record without allocating its claimed length', async () => {
    const { socket, sender, onError } = create();
    await sender.send('first');
    const producer = (async () => { for (let i = 0; i < 8; i++) await sender.send('x'.repeat(80)); })();
    await until(() => sender.pendingDiskBytes > 0 && diskFootprint() > 0, 'spool record');
    const path = files()[0];
    writeFileSync(path, Buffer.from([255, 255, 255, 255]));
    await until(() => {
      socket.complete();
      return onError.mock.calls.length > 0;
    }, 'corrupt spool error');
    await producer;
    await sender.dispose();
    expect(onError).toHaveBeenCalledOnce();
    expect(readdirSync(root)).toEqual([]);
  });
});
