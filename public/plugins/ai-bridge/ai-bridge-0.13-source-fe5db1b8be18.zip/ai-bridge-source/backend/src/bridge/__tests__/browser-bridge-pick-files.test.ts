import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

vi.mock('child_process', () => ({
  execFile: vi.fn(),
  spawn: vi.fn(() => ({ unref: vi.fn() })),
}));

vi.mock('../../core/features/settings', () => ({
  readMergedSettings: vi.fn(),
}));

vi.mock('../../core/features/detectEditors', () => ({
  detectInstalledEditors: vi.fn(),
}));

import { execFile } from 'child_process';
import { BrowserBridge } from '../browser-bridge';

type ExecCallback = (err: (Error & { code?: unknown }) | null, stdout: string, stderr: string) => void;

/** What one fake picker binary does when it is run. */
type PickerOutcome =
  | { stdout: string }
  | { error: Error & { code?: unknown } };

/** An `execFile` failure the way Node reports it: `code` is the exit status or an errno string. */
function failure(code: number | string, message = `exit ${String(code)}`): Error & { code?: unknown } {
  return Object.assign(new Error(message), { code });
}

/**
 * Route the mocked `execFile` by binary name. A binary missing from the table is
 * reported as not installed, which is what a real `execFile` does for an unknown
 * command. No picker is ever started.
 */
function fakePickers(table: Record<string, PickerOutcome>): void {
  vi.mocked(execFile).mockImplementation(((cmd: string, _args: string[], cb: ExecCallback) => {
    const outcome = table[cmd];
    if (!outcome) {
      cb(failure('ENOENT', `spawn ${cmd} ENOENT`), '', '');
    } else if ('error' in outcome) {
      cb(outcome.error, '', '');
    } else {
      cb(null, outcome.stdout, '');
    }
  }) as never);
}

function callsTo(binary: string): Array<[string, string[]]> {
  return vi.mocked(execFile).mock.calls
    .filter((call) => call[0] === binary)
    .map((call) => [call[0] as string, call[1] as string[]]);
}

describe('BrowserBridge.pickFiles on Linux', () => {
  let originalPlatform: PropertyDescriptor | undefined;

  beforeEach(() => {
    vi.clearAllMocks();
    vi.spyOn(console, 'error').mockImplementation(() => {});
    originalPlatform = Object.getOwnPropertyDescriptor(process, 'platform');
    Object.defineProperty(process, 'platform', { value: 'linux' });
  });

  afterEach(() => {
    vi.restoreAllMocks();
    if (originalPlatform) {
      Object.defineProperty(process, 'platform', originalPlatform);
    }
  });

  it('uses zenity when it is installed and never touches kdialog', async () => {
    fakePickers({ zenity: { stdout: '/home/me/project\n' } });

    const result = await new BrowserBridge().pickFiles({ mode: 'folders', multiple: false });

    expect(result).toEqual({ paths: ['/home/me/project'] });
    expect(callsTo('zenity')).toHaveLength(1);
    expect(callsTo('kdialog')).toHaveLength(0);
  });

  /** zenity answers exit 1 when the user closes the dialog: that is an answer, not a missing tool. */
  it('treats a zenity cancel as an empty pick and does not fall back to kdialog', async () => {
    fakePickers({ zenity: { error: failure(1) }, kdialog: { stdout: '/should/not/be/used\n' } });

    const result = await new BrowserBridge().pickFiles({ mode: 'folders', multiple: false });

    expect(result).toEqual({ paths: [] });
    expect(callsTo('kdialog')).toHaveLength(0);
  });

  /**
   * The old backend-side folder dialog fell back to kdialog; moving the dialog onto
   * the bridge must not strand KDE users who have no zenity.
   */
  it('falls back to kdialog for a folder when zenity is not installed', async () => {
    fakePickers({ kdialog: { stdout: '/home/me/kde-project\n' } });

    const result = await new BrowserBridge().pickFiles({ mode: 'folders', multiple: false });

    expect(result).toEqual({ paths: ['/home/me/kde-project'] });
    expect(callsTo('zenity')).toHaveLength(1);
    expect(callsTo('kdialog')).toEqual([['kdialog', ['--getexistingdirectory']]]);
  });

  it('treats a kdialog cancel (exit 1) as an empty pick', async () => {
    fakePickers({ kdialog: { error: failure(1) } });

    const result = await new BrowserBridge().pickFiles({ mode: 'folders', multiple: false });

    expect(result).toEqual({ paths: [] });
  });

  it('asks kdialog for a single file with --getopenfilename', async () => {
    fakePickers({ kdialog: { stdout: '/home/me/a.txt\n' } });

    const result = await new BrowserBridge().pickFiles({ mode: 'files', multiple: false });

    expect(result).toEqual({ paths: ['/home/me/a.txt'] });
    expect(callsTo('kdialog')).toEqual([['kdialog', ['--getopenfilename', '.']]]);
  });

  it('asks kdialog for several files with --multiple --separate-output and splits the lines', async () => {
    fakePickers({ kdialog: { stdout: '/home/me/a.txt\n/home/me/b.txt\n' } });

    const result = await new BrowserBridge().pickFiles({ mode: 'files', multiple: true });

    expect(result).toEqual({ paths: ['/home/me/a.txt', '/home/me/b.txt'] });
    expect(callsTo('kdialog')).toEqual([
      ['kdialog', ['--getopenfilename', '.', '--multiple', '--separate-output']],
    ]);
  });

  it('uses the file chooser for mode "both" on the kdialog fallback', async () => {
    fakePickers({ kdialog: { stdout: '/home/me/a.txt\n' } });

    await new BrowserBridge().pickFiles({ mode: 'both', multiple: false });

    expect(callsTo('kdialog')).toEqual([['kdialog', ['--getopenfilename', '.']]]);
  });

  it('resolves to an empty pick when neither picker is installed', async () => {
    fakePickers({});

    const result = await new BrowserBridge().pickFiles({ mode: 'folders', multiple: false });

    expect(result).toEqual({ paths: [] });
    expect(callsTo('zenity')).toHaveLength(1);
    expect(callsTo('kdialog')).toHaveLength(1);
  });
});
