/**
 * BrowserBridge.openUrl: a failed launch must not put the URL in the log.
 *
 * execFile builds its error message from the command line (`Command failed:
 * xdg-open <url>`), so logging `err.message` writes the URL. The URL can be an
 * MCP server's OAuth authorization URL, whose `state` and PKCE `code_challenge`
 * are live while the CLI waits for the redirect.
 */
import { describe, it, expect, vi, afterEach } from 'vitest';

vi.mock('child_process', async (importOriginal) => {
  const actual = await importOriginal<typeof import('child_process')>();
  return { ...actual, execFile: vi.fn() };
});

vi.mock('../../core/features/settings', () => ({
  readMergedSettings: vi.fn(),
}));

vi.mock('../../core/features/detectEditors', () => ({
  detectInstalledEditors: vi.fn(),
}));

import { execFile } from 'child_process';
import { BrowserBridge } from '../browser-bridge';

const AUTH_URL =
  'https://auth.example.com/authorize?response_type=code&state=STATE_SECRET&code_challenge=CHALLENGE_SECRET';

function failLaunchWith(message: string): void {
  vi.mocked(execFile).mockImplementation(((...args: unknown[]) => {
    const callback = args[args.length - 1] as (err: Error | null) => void;
    callback(new Error(message));
  }) as unknown as typeof execFile);
}

describe('BrowserBridge.openUrl', () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('logs a failed launch without the URL, and still resolves', async () => {
    const logged = vi.spyOn(console, 'error').mockImplementation(() => undefined);
    failLaunchWith(`Command failed: xdg-open ${AUTH_URL}\nxdg-open: no method available`);

    await expect(new BrowserBridge().openUrl(AUTH_URL)).resolves.toBeUndefined();

    const text = JSON.stringify(logged.mock.calls);
    expect(text).toContain('Failed to open URL');
    expect(text).toContain('xdg-open: no method available');
    expect(text).not.toContain('STATE_SECRET');
    expect(text).not.toContain('CHALLENGE_SECRET');
    expect(text).not.toContain('auth.example.com');
  });

  it('hands the full URL to the OS opener', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    vi.mocked(execFile).mockImplementation(((...args: unknown[]) => {
      (args[args.length - 1] as (err: Error | null) => void)(null);
    }) as unknown as typeof execFile);

    await new BrowserBridge().openUrl(AUTH_URL);

    const passed = vi.mocked(execFile).mock.calls[0][1] as string[];
    expect(passed).toContain(AUTH_URL);
  });
});
