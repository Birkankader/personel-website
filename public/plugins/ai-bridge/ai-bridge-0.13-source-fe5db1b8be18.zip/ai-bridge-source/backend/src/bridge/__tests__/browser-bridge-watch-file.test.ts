/**
 * BrowserBridge.watchFile against the real file system.
 *
 * Standalone has no host that publishes save events, so the bridge watches the
 * file itself. The case that used to fall through was a file that does not
 * exist yet — a Write creating a new file — because `fs.watch` on a missing
 * path throws, and the early warning (#359) was silently dropped. These tests
 * run on a real temp directory with real timers: `fs.watch` is exactly the part
 * a mock would hide.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { mkdtemp, mkdir, rename, rm, writeFile } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';

vi.mock('../../core/features/settings', () => ({
  readMergedSettings: vi.fn(),
}));

vi.mock('../../core/features/detectEditors', () => ({
  detectInstalledEditors: vi.fn(),
}));

import { BrowserBridge } from '../browser-bridge';

const WAIT = { timeout: 3000, interval: 20 };

/** Long enough for any further event of an already-finished write to arrive. */
const settle = () => new Promise<void>((resolve) => setTimeout(resolve, 250));

describe('BrowserBridge.watchFile', () => {
  let dir: string;
  let target: string;
  let stops: Array<() => void>;
  let bridge: BrowserBridge;

  /** Start a watch and remember its stop function so afterEach always releases it. */
  async function watch(path: string, onChanged: () => void): Promise<() => void> {
    const stop = await bridge.watchFile(path, onChanged);
    stops.push(stop);
    return stop;
  }

  beforeEach(async () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    dir = await mkdtemp(join(tmpdir(), 'bridge-watch-file-'));
    target = join(dir, 'config.txt');
    stops = [];
    bridge = new BrowserBridge();
  });

  afterEach(async () => {
    for (const stop of stops) stop();
    vi.restoreAllMocks();
    await rm(dir, { recursive: true, force: true });
  });

  it('reports a file that did not exist when the watch started, once it is created', async () => {
    const onChanged = vi.fn();
    await watch(target, onChanged);

    await writeFile(target, 'created\n', 'utf8');

    await vi.waitFor(() => expect(onChanged).toHaveBeenCalledTimes(1), WAIT);
    // Several fs events may follow one create; the content comparison keeps it at one.
    await settle();
    expect(onChanged).toHaveBeenCalledTimes(1);
  });

  it('reports a later change to a file that was created after the watch started', async () => {
    const onChanged = vi.fn();
    await watch(target, onChanged);
    await writeFile(target, 'created\n', 'utf8');
    await vi.waitFor(() => expect(onChanged).toHaveBeenCalledTimes(1), WAIT);
    await settle();

    await writeFile(target, 'edited\n', 'utf8');

    await vi.waitFor(() => expect(onChanged).toHaveBeenCalledTimes(2), WAIT);
  });

  it('stays quiet when an existing file is rewritten with identical bytes, and reports different bytes', async () => {
    await writeFile(target, 'same\n', 'utf8');
    const onChanged = vi.fn();
    await watch(target, onChanged);

    await writeFile(target, 'same\n', 'utf8');
    await settle();
    expect(onChanged).not.toHaveBeenCalled();

    await writeFile(target, 'different\n', 'utf8');
    await vi.waitFor(() => expect(onChanged).toHaveBeenCalledTimes(1), WAIT);
  });

  it('is not fooled by a sibling file changing', async () => {
    await writeFile(target, 'mine\n', 'utf8');
    const onChanged = vi.fn();
    await watch(target, onChanged);

    await writeFile(join(dir, 'other.txt'), 'one\n', 'utf8');
    await writeFile(join(dir, 'other.txt'), 'two\n', 'utf8');
    await settle();
    expect(onChanged).not.toHaveBeenCalled();

    // The watch is still alive for its own file afterwards.
    await writeFile(target, 'mine, edited\n', 'utf8');
    await vi.waitFor(() => expect(onChanged).toHaveBeenCalledTimes(1), WAIT);
  });

  it('does not report a sibling that appears while the watched file is still missing', async () => {
    const onChanged = vi.fn();
    await watch(target, onChanged);

    await writeFile(join(dir, 'other.txt'), 'one\n', 'utf8');
    await settle();

    expect(onChanged).not.toHaveBeenCalled();
  });

  it('survives an editor that saves by renaming a temp file over the target', async () => {
    await writeFile(target, 'before\n', 'utf8');
    const onChanged = vi.fn();
    await watch(target, onChanged);

    // A watch on the file itself would have been left on the replaced inode.
    const temp = join(dir, 'config.txt.tmp');
    await writeFile(temp, 'after\n', 'utf8');
    await rename(temp, target);
    await vi.waitFor(() => expect(onChanged).toHaveBeenCalledTimes(1), WAIT);
    await settle();

    await writeFile(target, 'after, again\n', 'utf8');
    await vi.waitFor(() => expect(onChanged).toHaveBeenCalledTimes(2), WAIT);
  });

  it('does not call back after stop()', async () => {
    const onChanged = vi.fn();
    const stop = await watch(target, onChanged);

    stop();
    await writeFile(target, 'too late\n', 'utf8');
    await settle();

    expect(onChanged).not.toHaveBeenCalled();
  });

  it('resolves to a harmless stop function when the parent directory does not exist', async () => {
    const onChanged = vi.fn();

    const stop = await watch(join(dir, 'no-such-dir', 'file.txt'), onChanged);

    expect(typeof stop).toBe('function');
    expect(() => stop()).not.toThrow();
    expect(onChanged).not.toHaveBeenCalled();

    // Creating the directory afterwards does not resurrect the watch.
    await mkdir(join(dir, 'no-such-dir'));
    await writeFile(join(dir, 'no-such-dir', 'file.txt'), 'late\n', 'utf8');
    await settle();
    expect(onChanged).not.toHaveBeenCalled();
  });
});
