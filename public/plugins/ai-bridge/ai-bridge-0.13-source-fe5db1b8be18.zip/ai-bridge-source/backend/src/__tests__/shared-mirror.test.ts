import { describe, expect, it } from 'vitest';
import { readdirSync, readFileSync } from 'node:fs';
import { join } from 'node:path';

/**
 * `backend/src/shared/` and `webview/src/shared/` are two copies of one folder
 * (the two workspaces cannot import from each other), kept in sync by hand.
 * Nothing but this test notices when an edit lands on one side only — the
 * build of each workspace is happy with its own copy — so a drifted enum or
 * helper would surface later as a message type one side does not understand.
 *
 * The rule covers the whole tree: `__tests__/` and `CLAUDE.md` included.
 */
const backendShared = join(__dirname, '..', 'shared');
const webviewShared = join(__dirname, '..', '..', '..', 'webview', 'src', 'shared');

/** Every file under `root`, as sorted POSIX-style paths relative to it. */
function listFiles(root: string, dir = root): string[] {
  const files: string[] = [];
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const full = join(dir, entry.name);
    if (entry.isDirectory()) {
      files.push(...listFiles(root, full));
    } else {
      files.push(full.slice(root.length + 1).split('\\').join('/'));
    }
  }
  return files.sort();
}

describe('shared dirs', () => {
  it('backend and webview shared dirs are byte-identical', () => {
    const backendFiles = listFiles(backendShared);
    const webviewFiles = listFiles(webviewShared);

    const missingInWebview = backendFiles.filter((f) => !webviewFiles.includes(f));
    const missingInBackend = webviewFiles.filter((f) => !backendFiles.includes(f));
    expect({ missingInWebview, missingInBackend }).toEqual({
      missingInWebview: [],
      missingInBackend: [],
    });

    const differing = backendFiles.filter(
      (f) => !readFileSync(join(backendShared, f)).equals(readFileSync(join(webviewShared, f))),
    );
    expect(differing).toEqual([]);
  });
});
