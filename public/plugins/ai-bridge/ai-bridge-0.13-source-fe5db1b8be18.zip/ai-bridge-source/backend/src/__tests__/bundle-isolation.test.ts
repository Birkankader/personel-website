import { afterEach, describe, expect, it } from 'vitest';
import { spawn, type ChildProcess } from 'child_process';
import { existsSync } from 'fs';
import { mkdtemp, mkdir, writeFile, readFile, chmod, rm } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import { pathToFileURL } from 'url';
import { WebSocket } from 'ws';

const bundle = join(__dirname, '..', '..', 'dist', 'backend.mjs');
let fixture = '';
let processFixture: ChildProcess | null = null;
let socket: WebSocket | null = null;
afterEach(async () => {
  socket?.terminate(); socket = null;
  if (processFixture && processFixture.exitCode === null) {
    const proc = processFixture;
    await new Promise<void>((resolve) => {
      const timeout = setTimeout(() => { proc.kill('SIGKILL'); }, 2000);
      proc.once('exit', () => { clearTimeout(timeout); resolve(); });
      proc.kill('SIGTERM');
    });
  }
  processFixture = null;
  if (fixture) await rm(fixture, { recursive: true, force: true });
});

describe.skipIf(!existsSync(bundle))('built backend isolation', () => {
  it('boots offline without upstream calls or data migration', async () => {
    fixture = await mkdtemp(join(tmpdir(), 'ai-bridge-bundle-isolation-'));
    const current = join(fixture, '.ai-bridge');
    const previous = join(fixture, '.claude-code-gui');
    const official = join(fixture, '.claude');
    const project = join(fixture, 'project');
    await Promise.all([mkdir(current), mkdir(previous), mkdir(official), mkdir(project)]);
    const networkLog = join(fixture, 'network-attempts.log');
    const cliScript = 'if (process.argv[2] === "--version") console.log("2.1.0 (Claude Code)"); else process.exitCode=2;\n';
    let cli = join(fixture, 'fixture-claude');
    if (process.platform === 'win32') {
      // Windows cannot start an extensionless script; a .cmd wrapper stands in for the npm shim.
      await writeFile(`${cli}.js`, cliScript);
      cli = `${cli}.cmd`;
      await writeFile(cli, '@node "%~dp0fixture-claude.js" %*\r\n');
    } else {
      await writeFile(cli, `#!/usr/bin/env node\n${cliScript}`);
      await chmod(cli, 0o700);
    }
    // The format the backend writes and parses (features/settings.ts).
    await writeFile(join(current, 'settings.js'), `export default ${JSON.stringify({ cliPath: cli })};\n`);
    const protectedFiles = new Map([
      [join(previous, 'license.json'), '{"licenseKey":"must-not-be-read","status":"active"}'],
      [join(previous, 'settings.js'), 'module.exports = { fontSize: 29 };'],
      [join(official, 'settings.json'), '{"model":"provider-model","fontSize":28}'],
    ]);
    await Promise.all([...protectedFiles].map(([path, content]) => writeFile(path, content)));
    const preload = join(fixture, 'isolate.mjs');
    await writeFile(preload, `import os from 'node:os';
import { syncBuiltinESMExports } from 'node:module';
import { appendFileSync } from 'node:fs';
os.homedir = () => process.env.AI_BRIDGE_FIXTURE_HOME;
syncBuiltinESMExports();
globalThis.fetch = (target) => { appendFileSync(process.env.AI_BRIDGE_NETWORK_AUDIT, String(target) + '\\n'); return Promise.reject(new Error('External network forbidden in fixture')); };
`);
    let stderr = '';
    const proc = spawn(process.execPath, ['--import', pathToFileURL(preload).href, bundle], {
      cwd: project,
      env: { ...process.env, AI_BRIDGE_FIXTURE_HOME: fixture, AI_BRIDGE_NETWORK_AUDIT: networkLog,
        AI_BRIDGE_AUTH_TOKEN: 'fixture-isolated-token', AI_BRIDGE_RUNTIME_SCOPE: project, AI_BRIDGE_DISABLE_IDLE_SHUTDOWN: 'true',
        CLAUDE_CONFIG_DIR: official, JETBRAINS_MODE: 'false', PORT: '0', NODE_ENV: 'production',
        CCG_WWW_API_BASE: 'https://upstream.invalid/api', CCG_ANNOUNCE_URL: 'https://upstream.invalid/announcements' },
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    processFixture = proc;
    proc.stderr!.on('data', (data) => { stderr = (stderr + data.toString()).slice(-64 * 1024); });
    const port = await new Promise<number>((resolve, reject) => {
      let stdout = '';
      const timeout = setTimeout(() => reject(new Error(`Backend did not become ready: ${stderr}`)), 7000);
      proc.once('error', (error) => { clearTimeout(timeout); reject(error); });
      proc.once('exit', (code) => { clearTimeout(timeout); reject(new Error(`Backend exited ${code}: ${stderr}`)); });
      proc.stdout!.on('data', (data) => {
        stdout += data.toString(); const match = /PORT:(\d+)/.exec(stdout);
        if (match) { clearTimeout(timeout); resolve(Number(match[1])); }
      });
    });
    const health = await fetch(`http://127.0.0.1:${port}/version`).then((response) => response.json());
    expect(health).toMatchObject({ appId: 'com.birkankader.ai-bridge', appName: 'AI Bridge', vendor: 'Birkan Kader' });
    socket = new WebSocket(`ws://127.0.0.1:${port}/ws`, ['ai-bridge-auth', 'fixture-isolated-token']);
    await new Promise<void>((resolve, reject) => { socket!.once('open', resolve); socket!.once('error', reject); });
    let sequence = 0;
    // Resolves the whole reply frame (envelope included) for the request id it sent.
    const requestFrame = (type: string) => new Promise<{ requestId: string; frame: { type: unknown; requestId: unknown; payload: Record<string, unknown> } }>((resolve, reject) => {
      const requestId = `smoke-${++sequence}`;
      const timeout = setTimeout(() => reject(new Error(`No reply for ${type}: ${stderr}`)), 4000);
      const listener = (data: unknown) => {
        const message = JSON.parse(String(data));
        if (message.payload?.requestId !== requestId) return;
        clearTimeout(timeout); socket!.off('message', listener); resolve({ requestId, frame: message });
      };
      socket!.on('message', listener);
      socket!.send(JSON.stringify({ type, requestId, timestamp: Date.now(), payload: { workingDir: project, accepted: true, enabled: true, licenseKey: 'not-used' } }));
    });
    // Error-ACK contract against the shipped bundle: a type this backend no longer handles
    // (the removed plugin self-update, the upstream sponsor, telemetry, CCB and dictation
    // services, the GUI login check) rejects at once, with the request id on the envelope.
    for (const type of ['UPDATE_PLUGIN', 'GET_SPONSOR_STATUS', 'VERIFY_LICENSE', 'GET_ANNOUNCEMENTS', 'SET_TELEMETRY_CONSENT', 'INSTALL_CCB', 'GET_DICTATION_AVAILABILITY', 'GET_ACCOUNT']) {
      const unknown = await requestFrame(type);
      expect(unknown.frame.type).toBe('ERROR');
      expect(unknown.frame.requestId).toBe(unknown.requestId);
      expect(unknown.frame.payload.error).toContain('Unknown message type');
    }
    expect(existsSync(networkLog)).toBe(false);
    for (const [path, content] of protectedFiles) expect(await readFile(path, 'utf8')).toBe(content);
  }, 15_000);
});
