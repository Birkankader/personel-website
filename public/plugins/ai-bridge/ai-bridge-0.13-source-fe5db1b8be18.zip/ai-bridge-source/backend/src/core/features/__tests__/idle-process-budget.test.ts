import { afterEach, describe, expect, it, vi } from 'vitest';
import { IdleProcessBudget } from '../idle-process-budget';

describe('warm idle CLI budget', () => {
  afterEach(() => vi.useRealTimers());
  it('keeps the two most recent eligible CLIs and protects busy, permission, recovery or background entries', async () => {
    vi.useFakeTimers();
    const budget = new IdleProcessBudget<string>(2, 100, 1000);
    const retired: string[] = [];
    for (const key of ['old', 'permission', 'recovery', 'background', 'recent', 'newest']) {
      budget.idle(key, () => !['permission', 'recovery', 'background'].includes(key), async () => { retired.push(key); });
      await vi.advanceTimersByTimeAsync(1);
    }
    await vi.advanceTimersByTimeAsync(200);
    expect(retired).toEqual(['old']);
    budget.active('recent');
    await vi.advanceTimersByTimeAsync(1000);
    expect(retired).toEqual(['old', 'newest']);
    for (const key of ['permission', 'recovery', 'background']) budget.active(key);
    expect(vi.getTimerCount()).toBe(0);
  });

  it('checks safety again at retirement and cancels timers for closed/active processes', async () => {
    vi.useFakeTimers();
    const budget = new IdleProcessBudget<string>(0, 100, 1000);
    let safe = true;
    const retire = vi.fn(async () => {});
    budget.idle('process', () => safe, retire);
    safe = false;
    await vi.advanceTimersByTimeAsync(200);
    expect(retire).not.toHaveBeenCalled();
    budget.active('process');
    expect(vi.getTimerCount()).toBe(0);
  });
});
