import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { ClientEnv, MessageType } from '../../shared';
import { readMergedSettings, readSettingsFile, readProjectSettings, getSettingsFileProblem, refreshSettingsFileProblem } from '../features/settings';
import { getSettingsWatcher } from '../features/settings-watcher';
import { clientInfo } from '../../config/environment';

/**
 * Extract a short, human-readable IDE product name out of the raw client-info
 * string the JetBrains host reports (e.g. "IntelliJ IDEA 2024.1.4 (IC-241...)"
 * or "WebStorm 2024.1 (WS-...)"). Strips the version-and-after suffix, leaving
 * just the product name for display in settings.
 */
export function parseIdeProductName(info: string): string {
  if (!info) return '';
  return info.replace(/\s+\d[\d.]*.*$/, '').trim();
}

export async function getSettingsHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
  bridges: Record<ClientEnv, Bridge>,
): Promise<void> {
  const workingDir = message.payload?.workingDir as string | undefined;
  const scope = message.payload?.scope as 'global' | 'project' | 'merged' | undefined;

  if (workingDir) {
    getSettingsWatcher()?.registerProject(workingDir);
  }

  let settings: Record<string, unknown>;
  let overrides: string[] = [];

  if (scope === 'global') {
    settings = await readSettingsFile();
  } else if (scope === 'project' && workingDir) {
    settings = await readProjectSettings(workingDir);
    // Project scope does not touch the global file, so learn its state here
    // rather than reporting a stale one.
    await refreshSettingsFileProblem();
  } else {
    // Default: merged (for runtime use)
    const result = await readMergedSettings(workingDir);
    settings = result.settings;
    overrides = result.overrides;
  }

  const ideAttached = bridges[ClientEnv.JETBRAINS]?.isConnected?.() ?? false;
  const ideProduct = parseIdeProductName(clientInfo);

  await connections.sendTo(connectionId, MessageType.ACK, {
    requestId: message.requestId,
    status: 'ok',
    settings,
    overrides,
    ideAttached,
    ideProduct,
  });

  // After the ACK, so a client that just mounted has its subscription in place.
  // Every settings read refreshes the problem first, so this both raises the
  // warning on load and clears it once the file is readable again.
  const problem = getSettingsFileProblem();
  await connections.sendTo(connectionId, MessageType.SETTINGS_FILE_STATUS, problem
    ? { unreadable: true, filePath: problem.filePath, reason: problem.reason }
    : { unreadable: false });
}
