import { open } from 'fs/promises';
import { StringDecoder } from 'string_decoder';
import { resolveBackgroundTaskOutput } from './loadBackgroundTaskOutput';

export interface OutputUpdate {
  kind: 'snapshot' | 'append' | 'reset';
  offset: number;
  endOffset: number;
  text: string;
  truncated: boolean;
}

/** Byte offsets belong to the file, not decoded UTF-16 text. Decoder state
 * holds incomplete UTF-8 code points until the next append. */
export class BackgroundOutputReader {
  private identity?: string;
  private offset = 0;
  private anchor = Buffer.alloc(0);
  private decoder = new StringDecoder('utf8');
  private initialized = false;
  more = false;

  async read(outputFile: string): Promise<OutputUpdate | undefined> {
    const real = await resolveBackgroundTaskOutput(outputFile);
    if (!real) {
      if (this.initialized && !this.identity) return;
      const kind = this.initialized ? 'reset' : 'snapshot';
      this.initialized = true;
      this.identity = undefined;
      this.offset = 0;
      this.anchor = Buffer.alloc(0);
      this.decoder = new StringDecoder('utf8');
      this.more = false;
      return { kind, offset: 0, endOffset: 0, text: '', truncated: false };
    }
    const file = await open(real, 'r');
    try {
      const info = await file.stat();
      const identity = `${real}:${info.dev}:${info.ino}`;
      let reset = identity !== this.identity || info.size < this.offset;
      if (!reset && this.anchor.length) {
        const check = Buffer.alloc(this.anchor.length);
        const read = await file.read(check, 0, check.length, this.offset - check.length);
        reset = read.bytesRead !== check.length || !check.equals(this.anchor);
      }
      if (!reset && info.size === this.offset) { this.more = false; return; }
      const kind = !this.initialized ? 'snapshot' : reset ? 'reset' : 'append';
      if (reset) {
        this.offset = Math.max(0, info.size - 600_000);
        this.decoder = new StringDecoder('utf8');
        this.anchor = Buffer.alloc(0);
      }
      const start = this.offset;
      const buffer = Buffer.alloc(Math.min(info.size - start, reset ? 600_000 : 64 * 1024));
      let length = 0;
      while (length < buffer.length) {
        const read = await file.read(buffer, length, buffer.length - length, start + length);
        if (!read.bytesRead) break;
        length += read.bytesRead;
      }
      this.offset += length;
      this.identity = identity;
      this.initialized = true;
      this.more = this.offset < info.size && length > 0;
      let skip = 0;
      if (reset && start > 0) while (skip < length && (buffer[skip] & 0xc0) === 0x80) skip++;
      const text = this.decoder.write(buffer.subarray(skip, length));
      this.anchor = Buffer.from(buffer.subarray(Math.max(0, length - 64), length));
      return { kind, offset: start, endOffset: this.offset, text, truncated: reset && start > 0 };
    } finally { await file.close(); }
  }
}
