import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { setBrowserClient } from '../features/telemetry';

/**
 * Stores the navigator.userAgent the webview (browser) reports on connect, for the "IDE / Browser" line in About.
 * Only meaningful in standalone (browser) mode — in JetBrains mode the AI_BRIDGE_CLIENT_INFO env takes precedence.
 */
export function clientInfoHandler(
  _connectionId: string,
  message: IPCMessage,
  _connections: ConnectionManager,
  _bridge: Bridge,
): void {
  const userAgent = message.payload?.userAgent as string | undefined;
  if (typeof userAgent === 'string' && userAgent.length > 0) {
    setBrowserClient(userAgent);
  }
}
