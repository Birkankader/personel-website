import { spawn as cpSpawn, spawnSync, type ChildProcess, type SpawnOptions } from 'child_process';
import { existsSync } from 'fs';
import { homedir } from 'os';
import { join } from 'path';
import { fileURLToPath } from 'url';

/**
 * win32 chat-CLI spawn through a Job Object wrapper — the Windows equivalent of the
 * POSIX "detached process-group leader + signal the whole group" design.
 *
 * The problem it solves: `taskkill /F /T` walks the LIVE parent-child tree, but
 * git-bash (MSYS) launches its workers under a fork helper that exits immediately,
 * detaching them from the cmd->claude->bash tree (they even reparent to ppid 1).
 * Windows never reparents to a reaper, so those workers survive every tree-kill as
 * headless orphans that keep running and billing. A Job Object with
 * KILL_ON_JOB_CLOSE keeps every descendant in the job regardless of PPID
 * reparenting; killing the wrapper (or the backend dying) closes the job handle and
 * the kernel tears the whole tree down.
 *
 * Two wrappers keep the same contract: the native helper `ai-bridge-job.exe`
 * (backend/native/win-job), and win-job-wrapper.ps1 as its fallback. The helper is
 * preferred because the PowerShell wrapper holds a whole PowerShell (~85 MB) open
 * for every chat just to keep the job handle.
 */

/**
 * The exact `cmd /d /s /c "<...>"` payload. Mirrors Node's own win32 shell:true
 * construction: command + args joined by spaces with NO per-arg re-quoting, wrapped
 * as a single verbatim string by the wrapper. Reproducing that byte-for-byte keeps
 * the CLI's argv identical to the pre-job spawn (chat args are simple tokens).
 */
export function buildWin32CmdLine(command: string, args: string[]): string {
  return [command, ...args].join(' ');
}

/** Absolute path to the shipped wrapper, resolved next to the running bundle. */
export function jobWrapperPath(): string {
  return fileURLToPath(new URL('./win-job-wrapper.ps1', import.meta.url));
}

/**
 * Absolute path to the native helper, resolved next to the running bundle. Only the
 * build ships it there: a source run (`pnpm dev`) and a build made without a Rust
 * toolchain have none, and use the PowerShell wrapper.
 */
export function jobHelperPath(): string {
  return fileURLToPath(new URL('./ai-bridge-job.exe', import.meta.url));
}

let jobHelperUsable: boolean | undefined;

/**
 * Whether chats can go through the native helper, decided once per backend: it has
 * to be shipped, and its `--probe` has to run and create a job. Application control
 * or an antivirus can refuse an unsigned exe that a file check still sees, and a
 * helper that cannot start would fail the chat instead of degrading it — so on any
 * doubt every chat keeps the PowerShell wrapper.
 */
function canUseJobHelper(helper: string): boolean {
  if (jobHelperUsable === undefined) {
    jobHelperUsable = false;
    if (existsSync(helper)) {
      const probe = spawnSync(helper, ['--probe'], { stdio: 'ignore', windowsHide: true, timeout: 5000 });
      jobHelperUsable = probe.status === 0;
      if (!jobHelperUsable) {
        const reason = probe.error?.message ?? `exit ${probe.status ?? probe.signal}`;
        console.error('[node-backend]', `Job helper probe failed (${reason}) — using the PowerShell wrapper`);
      }
    }
  }
  return jobHelperUsable;
}

/** Forget the helper probe's verdict, so the next chat start probes again. */
export function resetJobHelperProbe(): void {
  jobHelperUsable = undefined;
}

/**
 * Where the wrapper keeps its compiled Job Object interop between launches, so only
 * the first chat start on a machine pays for csc.exe (see win-job-wrapper.ps1).
 */
export function jobCacheDir(): string {
  return join(homedir(), '.ai-bridge', 'win-job-cache');
}

/**
 * Spawn the chat CLI inside a Job Object: through the native helper when it can run
 * here, else through the PowerShell wrapper. `sessionId` is passed as a wrapper argv
 * token ONLY so the on-disk registry's sessionId-keyed orphan sweep can find and
 * kill this wrapper (its death closes the job). If neither wrapper is available,
 * fall back to the plain shell spawn so chat never breaks — a missing job only
 * reopens the orphan gap, it must never block the user.
 */
export function spawnWin32JobCli(
  command: string,
  args: string[],
  sessionId: string,
  options: SpawnOptions,
): ChildProcess {
  const cmdline = buildWin32CmdLine(command, args);
  // Both wrappers read the same environment. The helper has no use for the
  // interop cache; the CLI inherits it either way, as it always has.
  const env = { ...options.env, AI_BRIDGE_JOB_CMDLINE: cmdline, AI_BRIDGE_JOB_CACHE_DIR: jobCacheDir() };
  const helper = jobHelperPath();
  if (canUseJobHelper(helper)) {
    const proc = cpSpawn(helper, [sessionId], { ...options, shell: false, env });
    // A helper removed or blocked after the probe fails this start; later ones
    // take the PowerShell wrapper.
    proc.once('error', () => { jobHelperUsable = false; });
    return proc;
  }
  const wrapper = jobWrapperPath();
  if (!existsSync(wrapper)) {
    console.error('[node-backend]', `Job wrapper not found at ${wrapper} — spawning without a job (orphan guard degraded)`);
    return cpSpawn(command, args, { ...options, shell: true });
  }
  return cpSpawn(
    'powershell.exe',
    ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', wrapper, sessionId],
    { ...options, shell: false, env },
  );
}

/** Absolute path to the shipped BASH_ENV script, resolved next to the running bundle. */
export function bashEnvScriptPath(): string {
  return fileURLToPath(new URL('./win-bash-env.sh', import.meta.url));
}

/**
 * Rewrite a win32 path into the MSYS form git-bash understands (`C:\a\b` -> `/c/a/b`).
 * bash reads $BASH_ENV with its own path rules, so a drive-letter path would not resolve.
 */
export function toMsysPath(win32Path: string): string {
  const drive = /^([A-Za-z]):[\\/]/.exec(win32Path);
  if (!drive) return win32Path.split('\\').join('/');
  return `/${drive[1].toLowerCase()}/${win32Path.slice(3).split('\\').join('/')}`;
}

/**
 * The BASH_ENV overrides that make the CLI's Bash tool emit UTF-8 (see win-bash-env.sh).
 *
 * Returns nothing off win32, or when the script is missing — a missing script must never
 * break chat, it only lets the garbling back in. Any BASH_ENV the user already set is
 * carried in AI_BRIDGE_PREV_BASH_ENV so the script can source it instead of silently dropping it.
 */
export function utf8BashEnv(env: NodeJS.ProcessEnv): NodeJS.ProcessEnv {
  if (process.platform !== 'win32') return {};
  const script = bashEnvScriptPath();
  if (!existsSync(script)) return {};
  const current = toMsysPath(script);
  const isCurrent = (value: string | undefined) =>
    value !== undefined && toMsysPath(value).toLowerCase() === current.toLowerCase();
  // The IDE can inherit an environment produced by an earlier plugin child.
  // Reapplying this adapter must retain the user's original hook, never make
  // the wrapper source itself on every non-interactive Bash startup.
  const previous = isCurrent(env.BASH_ENV) ? env.AI_BRIDGE_PREV_BASH_ENV : env.BASH_ENV;
  return {
    AI_BRIDGE_PREV_BASH_ENV: previous && !isCurrent(previous) ? previous : undefined,
    BASH_ENV: current,
  };
}
