import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { MessageType } from '../../shared';

/**
 * Pick one folder through the bridge and answer on the ACK: `{ requestId, path }`,
 * with `path` null when the user cancelled.
 *
 * The backend used to spawn the OS dialog itself (osascript, zenity, PowerShell),
 * which made it the one place that reached the environment without the bridge. The
 * bridge is the only path from the backend to the environment, so the dialog is now
 * the host's to draw: in JetBrains mode it is the IDE's own chooser, in standalone
 * the BrowserBridge's OS dialog.
 *
 * The path is returned exactly as the bridge gives it. JetBrains spells paths with
 * forward slashes (like `project.basePath`), which is already the norm in that mode.
 */
export async function openFolderDialogHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  bridge: Bridge,
): Promise<void> {
  try {
    const { paths } = await bridge.pickFiles({ mode: 'folders', multiple: false });
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      path: paths[0] ?? null,
    });
  } catch (err) {
    await connections.sendTo(connectionId, MessageType.ERROR, {
      requestId: message.requestId,
      error: err instanceof Error ? err.message : String(err),
    });
  }
}
