import { randomUUID } from 'crypto';
import type { QueuedMessage, QueuedPrompt, RuntimeTask, RuntimeTaskSnapshot, RuntimeTaskState } from '../../shared/runtime-resources';

// Return true only once the prompt was actually written to the CLI. A user
// send asks isCancelled() last thing before it writes; a false answer claims
// the turn for the CLI.
type Work = (isCancelled: () => boolean) => Promise<boolean> | boolean;
interface Steering { validate: () => void; write: (messageId: string) => Promise<boolean>; accepted: () => void }
interface PendingMessage { prompt: QueuedPrompt; updated: () => void }
interface Entry { task: RuntimeTask; work: Work; onError: (error: unknown) => void; cancelled: boolean; claimed?: boolean; processId?: number; message?: PendingMessage; steering?: Steering; pendingSteers?: Set<string>; resultPending?: boolean }

/** Limits active turns, not retained idle CLI processes. All mutations are synchronous. */
export class TaskLimiter {
  private entries = new Map<string, Entry>();
  private active = new Map<string, Entry>();
  private pumping = false;
  private closed = false;
  constructor(private limit = 2, private readonly changed: (snapshot: RuntimeTaskSnapshot) => void = () => {}) {
    this.validateLimit(limit);
  }

  snapshot(): RuntimeTaskSnapshot {
    return { limit: this.limit, tasks: [...this.entries.values()].map(({ task }) => ({ ...task })) };
  }

  setLimit(limit: number): void {
    this.validateLimit(limit);
    this.limit = limit;
    this.emit();
    this.pump(); // Lowering the limit never interrupts a running turn.
  }

  enqueue(sessionId: string, workingDir: string, work: Work, onError: (error: unknown) => void): RuntimeTask {
    return this.admit(sessionId, workingDir, work, onError);
  }

  /** Every user send gets its own FIFO slot without interrupting active work. */
  enqueueUser(sessionId: string, workingDir: string, work: Work, onError: (error: unknown) => void, userMessageId: string, steering?: Steering, message?: PendingMessage): RuntimeTask {
    return this.admit(sessionId, workingDir, work, onError, userMessageId, steering, message);
  }

  private admit(sessionId: string, workingDir: string, work: Work, onError: (error: unknown) => void, userMessageId?: string, steering?: Steering, message?: PendingMessage): RuntimeTask {
    if (this.closed) throw new Error('The backend is shutting down.');
    if (this.entries.size >= 128) throw new Error('The local task queue is full. Cancel a queued task before sending again.');
    const entry: Entry = {
      task: { id: randomUUID(), sessionId, workingDir, state: 'queued', createdAt: Date.now(), ...(userMessageId ? { userMessageId } : {}) },
      work, onError, steering, message, cancelled: false,
    };
    this.entries.set(entry.task.id, entry);
    this.emit(entry.task);
    this.pump();
    return { ...entry.task };
  }

  queuedMessages(sessionId: string): QueuedMessage[] {
    return [...this.entries.values()].filter(entry => entry.task.sessionId === sessionId
      && entry.task.userMessageId && entry.message && ['queued', 'starting'].includes(entry.task.state))
      .map(entry => ({ ...entry.message!.prompt, sessionId, userMessageId: entry.task.userMessageId! }));
  }

  private editableEntries(sessionId: string): Entry[] {
    return [...this.entries.values()].filter(entry => entry.task.sessionId === sessionId
      && entry.task.state === 'queued' && !entry.task.steering && entry.task.userMessageId);
  }

  /** Reuse only this session's user slots, preserving other sessions and internal work. */
  reorderQueued(sessionId: string, taskIds: string[]): void {
    const entries = this.editableEntries(sessionId);
    const byId = new Map(entries.map(entry => [entry.task.id, entry]));
    if (taskIds.length !== entries.length || new Set(taskIds).size !== entries.length || taskIds.some(id => !byId.has(id))) {
      throw new Error('The queue changed. Try reordering again.');
    }
    let index = 0;
    this.entries = new Map([...this.entries.values()].map(entry => {
      const next = byId.has(entry.task.id) ? byId.get(taskIds[index++])! : entry;
      return [next.task.id, next];
    }));
    this.emit();
  }

  /** Validate everything before changing anything; merge in the visible queue order. */
  mergeQueued(sessionId: string, taskIds: string[]): void {
    const selected = new Set(taskIds);
    const entries = this.editableEntries(sessionId).filter(entry => selected.has(entry.task.id));
    if (selected.size < 2 || selected.size !== taskIds.length || entries.length !== selected.size || entries.some(entry => !entry.message)) {
      throw new Error('Select at least two messages that are still queued.');
    }
    const target = entries[0];
    const prompt = target.message!.prompt;
    if (entries.some(entry => entry.message!.prompt.inputMode !== prompt.inputMode || entry.message!.prompt.model !== prompt.model)) {
      throw new Error('Messages must use the same model and permission mode to merge.');
    }
    if (entries.some(entry => entry.message!.prompt.content.trimStart().startsWith('/'))) {
      throw new Error('Slash commands must run separately.');
    }
    const content = entries.map(entry => entry.message!.prompt.content).filter(Boolean).join('\n\n');
    const attachments = entries.flatMap(entry => entry.message!.prompt.attachments ?? []);
    prompt.content = content;
    prompt.attachments = attachments.length ? attachments : undefined;
    // Remove every merged slot before publishing any event. No partial queue
    // can be observed or admitted, even by another view of this session.
    for (const entry of entries.slice(1)) this.entries.delete(entry.task.id);
    for (const entry of entries.slice(1)) {
      entry.cancelled = true;
      entry.task.replacedBy = target.task.id;
      this.finish(entry, 'cancelled');
    }
    target.message!.updated();
    this.emit(target.task);
  }

  /** Claim before writing so two views cannot deliver the same message twice. */
  async steerQueued(taskId: string): Promise<void> {
    const entry = this.entries.get(taskId);
    if (!entry || entry.task.state !== 'queued') throw new Error('The message has already left the queue.');
    const owner = this.active.get(entry.task.sessionId);
    if (entry.task.steering) throw new Error('This message is already being delivered.');
    if (this.closed || !entry.steering || owner?.task.state !== 'running') throw new Error('Wait until Claude is running before steering.');
    entry.steering.validate();
    entry.task.steering = true;
    (owner.pendingSteers ??= new Set()).add(taskId);
    this.emit(entry.task);
    try {
      if (!await entry.steering.write(taskId)) throw new Error('Claude could not accept the message.');
    } catch (error) {
      owner.pendingSteers?.delete(taskId);
      // A pipe failure can be ambiguous; never automatically send it again.
      if (this.entries.has(taskId)) this.finish(entry, 'failed', error instanceof Error ? error.message : String(error));
      if (owner.resultPending && !owner.pendingSteers?.size && this.active.get(entry.task.sessionId) === owner) {
        this.release(entry.task.sessionId, 'failed', owner.task.id);
      }
      throw error;
    }
  }

  hasPendingSteering(sessionId: string): boolean {
    return !!this.active.get(sessionId)?.pendingSteers?.size;
  }

  /** A late steer can become a separate CLI turn. Retain its slot across the first result. */
  holdForSteering(sessionId: string): boolean {
    const owner = this.active.get(sessionId);
    if (!owner?.pendingSteers?.size || owner.cancelled) return false;
    owner.resultPending = true;
    return true;
  }

  /** Replay acknowledges consumption at a safe assistant/tool boundary. */
  acceptSteering(sessionId: string, processId: number | undefined, messageId: string): boolean {
    const owner = this.active.get(sessionId);
    if (!owner || owner.processId !== processId || !owner.pendingSteers?.delete(messageId)) return false;
    owner.resultPending = false;
    const entry = this.entries.get(messageId);
    if (entry) {
      if (!owner.cancelled) entry.steering?.accepted();
      this.finish(entry, owner.cancelled ? 'cancelled' : 'completed');
    }
    return true;
  }

  /** Completion is signalled by the CLI result/close event, never by stdin.write. */
  release(sessionId: string, state: 'completed' | 'failed' | 'cancelled' = 'completed', expectedTaskId?: string): void {
    const entry = this.active.get(sessionId);
    if (!entry || (expectedTaskId !== undefined && entry.task.id !== expectedTaskId)) return;
    this.finish(entry, state);
    this.pump();
  }

  cancelQueued(taskId: string): boolean {
    const entry = this.entries.get(taskId);
    if (!entry || entry.task.state !== 'queued' || entry.task.steering) return false;
    entry.cancelled = true;
    this.finish(entry, 'cancelled');
    this.pump();
    return true;
  }

  cancelSession(sessionId: string): boolean {
    let cancelled = false;
    for (const entry of [...this.entries.values()]) {
      if (entry.task.sessionId !== sessionId || entry.task.state !== 'queued' || entry.task.steering) continue;
      entry.cancelled = true;
      this.finish(entry, 'cancelled');
      cancelled = true;
    }
    const active = this.active.get(sessionId);
    if (active) this.markStopping(active.task.id);
    return cancelled;
  }

  /** A task-row stop leaves other queued prompts in the same session intact. */
  markStopping(taskId: string): boolean {
    const entry = this.entries.get(taskId);
    if (!entry || this.active.get(entry.task.sessionId) !== entry) return false;
    entry.cancelled = true;
    // A user send that has not claimed its turn wrote nothing, so it is over
    // now rather than once the CLI it waits for has started — that can take
    // seconds, and Stop looked ignored meanwhile. The startup still finishes
    // and its CLI is kept; a resend shares it (ensureClaudeProcess). Internal
    // work writes without asking, so it always waits for its result.
    if (entry.task.state === 'starting' && entry.task.userMessageId && !entry.claimed) {
      this.finish(entry, 'cancelled');
      this.pump();
      return true;
    }
    entry.task.state = 'stopping';
    this.emit(entry.task);
    return true;
  }

  get(taskId: string): RuntimeTask | undefined {
    const task = this.entries.get(taskId)?.task;
    return task ? { ...task } : undefined;
  }

  setProcess(sessionId: string, processId: number | undefined): void {
    const entry = this.active.get(sessionId);
    if (entry) entry.processId = processId;
  }

  taskForProcess(sessionId: string, processId: number | undefined): string | undefined {
    const entry = this.active.get(sessionId);
    return processId !== undefined && entry?.processId === processId ? entry.task.id : undefined;
  }

  shutdown(): void {
    this.closed = true;
    for (const entry of [...this.entries.values()]) {
      entry.cancelled = true;
      if (entry.task.state === 'queued') this.finish(entry, 'cancelled');
    }
  }

  private validateLimit(limit: number): void {
    if (!Number.isInteger(limit) || limit < 1 || limit > 16) throw new Error('Concurrent tasks must be between 1 and 16.');
  }

  private emit(changedTask?: RuntimeTask): void {
    this.changed({ ...this.snapshot(), ...(changedTask ? { changedTask: { ...changedTask } } : {}) });
  }

  private finish(entry: Entry, state: RuntimeTaskState, error?: string): void {
    if (this.active.get(entry.task.sessionId) === entry) {
      this.active.delete(entry.task.sessionId);
      for (const id of entry.pendingSteers ?? []) {
        const pending = this.entries.get(id);
        if (pending) this.finish(pending, entry.cancelled ? 'cancelled' : 'failed', 'Claude stopped before consuming the message.');
      }
    }
    this.entries.delete(entry.task.id);
    entry.task.state = state;
    if (error) entry.task.error = error;
    this.emit(entry.task);
  }

  private pump(): void {
    if (this.pumping || this.closed) return;
    this.pumping = true;
    try {
      for (const entry of this.entries.values()) {
        if (this.active.size >= this.limit) break;
        if (entry.task.state !== 'queued' || entry.task.steering || this.active.has(entry.task.sessionId)) continue;
        this.active.set(entry.task.sessionId, entry);
        entry.task.state = 'starting';
        entry.task.startedAt = Date.now();
        this.emit(entry.task);
        void Promise.resolve().then(async () => {
          if (this.active.get(entry.task.sessionId) !== entry) return;
          const started = !entry.cancelled && await entry.work(() => {
            if (!entry.cancelled) entry.claimed = true;
            return entry.cancelled;
          });
          if (this.active.get(entry.task.sessionId) !== entry) return;
          if (!started) {
            this.finish(entry, 'cancelled');
            this.pump();
          } else {
            entry.task.state = entry.cancelled ? 'stopping' : 'running';
            this.emit(entry.task);
          }
        }).catch((error: unknown) => {
          if (this.entries.has(entry.task.id)) {
            this.finish(entry, 'failed', error instanceof Error ? error.message : String(error));
            this.pump();
          }
          entry.onError(error);
        });
      }
    } finally {
      this.pumping = false;
    }
  }
}
