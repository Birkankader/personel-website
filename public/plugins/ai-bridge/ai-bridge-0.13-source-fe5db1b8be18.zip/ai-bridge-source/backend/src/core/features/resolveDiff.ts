/**
 * Answer a pending file-edit permission request from a review diff, with the
 * hunks the user kept (#109).
 *
 * Shared by both review surfaces — the IDE's native diff and the webview's own
 * — because a review is a review wherever it is drawn, and a second decision
 * path would let the two disagree about what an answer means.
 *
 * The selection is made in the diff, which is where the change is legible. An
 * untouched review sends back only hunk ranges, and the backend rebuilds from
 * the change it still holds, so what gets written is the text that was
 * reviewed.
 *
 * A reviewer who edits the proposed side sends that text instead (#305). Once
 * they have typed over the proposal, no set of ranges into the original
 * proposal can describe what is now on screen — so the screen wins.
 */
import type { ConnectionManager } from '../../ws/connection-manager';
import { MessageType, buildUserDeclinedContent, buildSessionPermissionUpdate } from '../../shared';
import { takePreview, peekPreview, closeDiffTabForPermission, type StoredPreview } from './diffPreview';
import { holdApprovalIfBaseMoved } from './reviewBase';
import type { Bridge } from '../../bridge/bridge-interface';
import { buildPartialApproval, narrowToDifference } from './partialApproval';
import { buildEditedProposalNotice, type EditedProposalChange } from './editedProposalNotice';
import { declinedAnything } from './declinedHunks';
import type { AcceptedRange } from './hunks';
import { sendControlResponseToProcess } from '../claude-process';
import { sendAfterTurn } from './afterTurn';

export interface ResolveDiffParams {
  toolUseId: string;
  controlRequestId: string;
  sessionId: string;
  /**
   * Regions of the proposal the user kept, as the review surface split them.
   * Empty means they rejected the whole change.
   */
  acceptedRanges: AcceptedRange[];
  /**
   * The proposed side as the reviewer left it, when they edited it (#305).
   *
   * Absent means they did not type anything, and the ranges above describe the
   * answer on their own. Present, it IS the answer — it already contains the
   * result of every checkbox they unticked before typing.
   */
  editedContent?: string;
  /**
   * The reviewer pressed "Allow all edits" rather than plain Apply (#393).
   *
   * Answers this request exactly as Apply does, and installs the session rule
   * alongside it so the edits that follow are not asked about at all. Only
   * meaningful on an approval: a refusal grants nothing.
   */
  allowAllEditsThisSession?: boolean;
}

/**
 * Parse an answer payload, or null when it is not usable.
 *
 * Reached from a JSON-RPC notification (the IDE) and from a webview request
 * alike, so it trusts neither and validates the same way for both.
 */
export function parseResolveDiffParams(
  params: Record<string, unknown>,
): ResolveDiffParams | null {
  const toolUseId = params.toolUseId;
  const controlRequestId = params.controlRequestId;
  const sessionId = params.sessionId;
  if (typeof toolUseId !== 'string' || !toolUseId) return null;
  if (typeof controlRequestId !== 'string' || !controlRequestId) return null;
  if (typeof sessionId !== 'string' || !sessionId) return null;

  const raw = params.acceptedRanges;
  const acceptedRanges = Array.isArray(raw)
    ? raw.filter(isAcceptedRange)
    : [];

  const edited = params.editedContent;
  const editedContent = typeof edited === 'string' ? edited : undefined;

  // Strictly `=== true`: this grants standing permission, so anything other
  // than the flag being sent on purpose has to read as "not asked for".
  const allowAllEditsThisSession = params.allowAllEditsThisSession === true;

  return {
    toolUseId,
    controlRequestId,
    sessionId,
    acceptedRanges,
    editedContent,
    allowAllEditsThisSession,
  };
}

/** Whether a wire value is a usable line range; anything else is dropped. */
function isAcceptedRange(value: unknown): value is AcceptedRange {
  if (typeof value !== 'object' || value === null) return false;
  const r = value as Record<string, unknown>;
  return (['oldStart', 'oldEnd', 'newStart', 'newEnd'] as const).every(
    (k) => typeof r[k] === 'number' && Number.isInteger(r[k]),
  );
}

/**
 * How a review ended up:
 *  - `answered`:    the answer reached the CLI and the review is settled.
 *  - `held`:        the base-moved gate kept the review open for the user to
 *                   refresh and answer again; nothing was sent.
 *  - `undelivered`: the CLI is gone, so the answer reached nobody. The review is
 *                   kept open and nothing was announced as settled.
 */
export type ResolveDiffOutcome = 'answered' | 'held' | 'undelivered';

/**
 * Turn the reviewer's answer into the CLI's `control_response`.
 *
 * Keeping every hunk sends the request through untouched, so an Edit stays the
 * Edit Claude wrote. Keeping some rewrites the tool input to exactly that
 * subset. Keeping none is a denial — writing the file back unchanged would
 * report success for an edit that never happened.
 */
export async function resolveDiffReview(
  connections: ConnectionManager,
  params: ResolveDiffParams,
  bridge?: Bridge,
): Promise<ResolveDiffOutcome> {
  /*
   * Peeked, not taken, until the answer has really gone out.
   *
   * The gate below can refuse to answer and hand the review back to the user,
   * and a review whose entry had already been consumed could never be answered
   * again — the approval buttons would be live with nothing behind them. The
   * same holds when the CLI is gone: the answer reaches nobody, so the entry
   * and the window stay for as long as the user has them open.
   */
  const preview = peekPreview(params.toolUseId);

  /** Sends the answer; true when it reached the CLI. */
  const respond = (response: Record<string, unknown>): boolean => {
    // Sent first. Only an answer that was delivered settles the review; consuming
    // the entry and closing the window before knowing would strand the user with
    // a review that has gone while the CLI never heard.
    const delivered = sendControlResponseToProcess(connections, params.sessionId, {
      subtype: 'success' as const,
      request_id: params.controlRequestId,
      response,
    });
    if (!delivered) {
      console.error(
        '[node-backend]',
        `Diff resolved for ${params.toolUseId}: the CLI is gone, review kept open`,
      );
      return false;
    }
    // Settled for real now, so the entry goes and the window with it. No await
    // between the send and the take: nothing can interleave between them.
    takePreview(params.toolUseId);
    // Both surfaces: whichever drew this review, it is settled now. An unknown
    // id is a no-op on either side.
    if (bridge) void closeDiffTabForPermission(bridge, params.toolUseId);
    return true;
  };

  // Nothing stored means we never previewed this request (or it was already
  // answered). Let it through as an ordinary approval rather than inventing a
  // decision the user did not make.
  if (!preview) {
    // Logged because everything downstream — the picking, the edit, the notice
    // to Claude — depends on this being present, and its absence is silent
    // otherwise: the write goes through as proposed and nothing says why.
    console.error(
      '[node-backend]',
      `Diff resolved for ${params.toolUseId}: no stored preview, letting the original call through`,
    );
    if (!respond({ behavior: 'allow', updatedInput: {} })) return 'undelivered';
    notifyResolved(connections, params);
    return 'answered';
  }

  // An edited proposal answers on its own: the reviewer's text already reflects
  // whatever they unticked before typing, so "kept no ranges" is not a denial
  // here the way it is for an untouched diff.
  const edited = params.editedContent;
  const keptNothing =
    edited !== undefined ? edited === preview.oldContent : params.acceptedRanges.length === 0;

  if (keptNothing) {
    if (!respond({ behavior: 'deny', message: buildUserDeclinedContent() })) return 'undelivered';
    console.error('[node-backend]', `Diff resolved for ${params.toolUseId}: kept nothing (denied)`);
    notifyResolved(connections, params);
    return 'answered';
  }

  /*
   * The gate (#359).
   *
   * Everything below builds what gets written from `preview.oldContent` — the
   * file as it was when the request arrived. If disk has moved since, that
   * content is a claim about a file that no longer exists, and writing from it
   * silently discards whatever arrived in the meantime. That is the data loss:
   * a 1090-line file came back as the one line that had been proposed.
   *
   * Checked here rather than trusting the save notifications, because those are
   * an early warning that can miss — a host with no IDE, a save the IDE does
   * not report, a write by another process. This is the last point before the
   * answer goes out, so it is the only place the check is a guarantee.
   *
   * Refusing to answer is safe: the CLI holds a permission request open
   * indefinitely (measured at over three minutes with no answer and no
   * timeout), so the request is still there when the user comes back to it.
   */
  // Deliberately no `respond` when this holds: the request stays open and the
  // entry stays stored, so the review can be refreshed and answered again.
  const held = await holdApprovalIfBaseMoved({
    connections,
    sessionId: params.sessionId,
    toolUseId: params.toolUseId,
    preview,
    accepted: params.acceptedRanges,
    // Told as well as the webview: with the IDE viewer chosen, the review on
    // screen is the host's, and a webview-only message reaches nothing.
    bridge,
  });
  if (held) return 'held';

  const amended = buildPartialApproval(preview, params.acceptedRanges, edited);
  const delivered = respond({
    behavior: 'allow',
    updatedInput: amended ? amended.input : {},
    // Built from the tool that asked, so the IDE's button and the chat's
    // "yes, allow all edits this session" install the very same rule.
    ...(params.allowAllEditsThisSession
      ? { updatedPermissions: buildSessionPermissionUpdate(preview.toolName) }
      : {}),
  });
  if (!delivered) return 'undelivered';
  console.error(
    '[node-backend]',
    edited !== undefined
      ? `Diff resolved for ${params.toolUseId}: applied the reviewer's edited text`
      : `Diff resolved for ${params.toolUseId}: kept ${params.acceptedRanges.length} region(s)`,
  );

  notifyResolved(connections, params);

  /*
   * Told whenever what landed is not what was proposed — edited, picked, or
   * both. Silence is the exception, and it has exactly one case: the whole
   * proposal went in untouched, where Claude's own account of it is already
   * true.
   *
   * `amended` is that test, and a precise one: buildPartialApproval returns
   * null when the answer reproduces the proposal exactly, and an input to send
   * in its place otherwise. So it is null on a full accept, and on an edit that
   * was typed and then undone.
   *
   * Reporting only edits was too narrow. A reviewer who denies half a change
   * leaves Claude believing all of it was written, and the next turn is built
   * on a file that does not exist — measured with an edit before this existed:
   * the model kept reporting the value it had proposed (20000) after the
   * reviewer applied 15000, and a denied hunk is the same mistake in a form
   * nothing corrected.
   */
  if (amended !== null) {
    /*
     * Whether the reviewer turned parts down, as opposed to rewriting them.
     *
     * Told apart by what the applied text kept: a declined hunk leaves the file
     * exactly as it was, so its old lines are still there. A rewritten one does
     * not, since the reviewer typed something of their own.
     *
     * Counting hunks against accepted ranges was tried and does not work. The
     * two number different things -- the backend's own split against the split
     * the IDE made, which HunkSelection already says can differ (two against
     * four on a real file) -- so the comparison read as a decline whenever the
     * IDE merely split more finely, and missed real declines when it split less.
     */
    const declinedParts = declinedAnything(preview, params.acceptedRanges);
    tellClaudeAboutTheEdit(
      connections,
      params.sessionId,
      preview,
      amended.content,
      declinedParts,
    );
  }
  return 'answered';
}

/**
 * Report a corrected proposal to Claude, once the turn that proposed it is over.
 *
 * Held rather than sent (see afterTurn). Answering a permission request happens
 * mid-turn by definition — the CLI is blocked on the control_response — and the
 * CLI clears its pending-message queue as that turn ends, so a notice written
 * to stdin now is enqueued and then discarded. Measured: written at .477,
 * enqueued at .586, removed at .769, while an ordinary user message in the same
 * session went enqueue → dequeue. The model never read it, and went on
 * describing the value it had proposed rather than the one the reviewer applied.
 */
function tellClaudeAboutTheEdit(
  _connections: ConnectionManager,
  sessionId: string,
  preview: StoredPreview,
  applied: string,
  declinedParts: boolean,
): void {
  /*
   * What the diff in the notice is measured against.
   *
   * A rewrite is measured against the PROPOSAL: the model knows what it asked
   * for and needs to see where the result departs from it.
   *
   * A decline is measured against the FILE AS IT WAS. Measuring it against the
   * proposal reverses the change on screen -- the reviewer declined lowering a
   * threshold from 50000 to 30000, and the notice read "-30000 +50000", which
   * says the reviewer WROTE 50000. They wrote nothing; 50000 was already there.
   * Against the original the same decline renders as no change at all for that
   * hunk, and only the parts that really landed appear.
   */
  const baseline = declinedParts ? preview.oldContent : preview.newContent;
  const notice = buildEditedProposalNotice(
    describeCorrection(baseline, applied),
    declinedParts,
  );
  if (!notice) {
    // Nothing to report means the applied text matched the proposal exactly.
    // Logged because "the reminder never arrived" and "there was nothing to
    // say" look identical from the chat, and only one of them is a bug.
    console.error('[node-backend]', `Edit notice for ${sessionId}: nothing to report`);
    return;
  }
  sendAfterTurn(sessionId, notice);
  console.error('[node-backend]', `Edit notice for ${sessionId}: held until the turn ends`);
}

/**
 * What the reviewer changed about the PROPOSAL, narrowed to the lines that
 * actually differ.
 *
 * Measured against `newContent` — what the model proposed — rather than against
 * the file on disk, because that is the correction being reported: the model
 * knows what it asked for, and needs to be told where the result departs from
 * it. Diffing against the file instead would restate the whole edit, most of
 * which the model already wrote itself.
 *
 * That also keeps a Write's notice short. Its amended input carries the entire
 * file, so quoting it verbatim sent 3.7KB to say one number had changed.
 */
function describeCorrection(proposed: string, applied: string): EditedProposalChange | null {
  const pair = narrowToDifference(proposed, applied);
  if (!pair) return null;
  return { oldText: pair.oldText, newText: pair.newText };
}

/**
 * Tell the chat its prompt is settled.
 *
 * Without this the approval panel stays up after the IDE answered, and pressing
 * Yes there sends a second decision for a request the CLI has already moved on
 * from — the user sees their edit apply, then a dead prompt they still have to
 * dismiss.
 */
function notifyResolved(connections: ConnectionManager, params: ResolveDiffParams): void {
  connections.broadcastToSession(params.sessionId, MessageType.PERMISSION_RESOLVED, {
    toolUseId: params.toolUseId,
    controlRequestId: params.controlRequestId,
  });
}
