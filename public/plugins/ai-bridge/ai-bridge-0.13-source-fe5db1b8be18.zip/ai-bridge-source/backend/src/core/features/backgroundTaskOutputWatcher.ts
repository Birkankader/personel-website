import { watch, type FSWatcher } from 'fs';
import { resolve } from 'path';
import type { ConnectionManager } from '../../ws/connection-manager';
import { MessageType } from '../../shared';
import { BackgroundOutputReader } from './background-output-reader';

interface Subscriber { connectionId: string; outputFile: string; connections: ConnectionManager; initialized: boolean }
interface Watcher {
  reader: BackgroundOutputReader;
  subscribers: Map<string, Subscriber>;
  fsWatcher?: FSWatcher;
  debounceTimer?: ReturnType<typeof setTimeout>;
  retryTimer?: ReturnType<typeof setTimeout>;
  reading?: boolean;
  pendingRead?: boolean;
  text: string;
  truncated: boolean;
  endOffset: number;
}

// One watcher/read/decoder per path, regardless of the number of open viewers.
const watchers = new Map<string, Watcher>();
const MAX_CHARS = 200_000;
function tail(text: string): string {
  const start = Math.max(0, text.length - MAX_CHARS);
  return text.slice(start + (start && /[\uDC00-\uDFFF]/.test(text[start]) ? 1 : 0));
}

async function pushOutput(path: string, entry: Watcher): Promise<void> {
  if (watchers.get(path) !== entry) return;
  if (entry.reading) { entry.pendingRead = true; return; }
  entry.reading = true;
  try {
    do {
      entry.pendingRead = false;
      const update = await entry.reader.read(path);
      if (watchers.get(path) !== entry) return;
      if (update) {
        const text = update.kind === 'append' ? entry.text + update.text : update.text;
        entry.truncated = (update.kind === 'append' && entry.truncated) || update.truncated || text.length > MAX_CHARS;
        entry.text = tail(text);
        entry.endOffset = update.endOffset;
      }
      await Promise.all([...entry.subscribers.values()].map(async subscriber => {
        if (entry.subscribers.get(subscriber.connectionId) !== subscriber) return;
        if (!update && subscriber.initialized) return;
        const payload = subscriber.initialized && update ? { ...update, truncated: entry.truncated } : {
          kind: 'snapshot', offset: 0, endOffset: entry.endOffset, text: entry.text, truncated: entry.truncated,
        };
        subscriber.initialized = true;
        await subscriber.connections.sendTo(subscriber.connectionId, MessageType.BACKGROUND_TASK_OUTPUT_CHANGED, {
          outputFile: subscriber.outputFile, ...payload,
        });
      }));
    } while ((entry.pendingRead || entry.reader.more) && watchers.get(path) === entry);
  } catch {
    // A rename can race open/read. Retry through the same bounded scheduler;
    // the reader will publish an explicit reset when the replacement exists.
    scheduleRetry(path, entry);
  } finally { entry.reading = false; }
}

function scheduleRetry(path: string, entry: Watcher): void {
  if (watchers.get(path) !== entry || entry.retryTimer) return;
  entry.retryTimer = setTimeout(() => {
    entry.retryTimer = undefined;
    if (watchers.get(path) !== entry) return;
    tryStartWatching(path, entry);
    void pushOutput(path, entry);
  }, 500);
  entry.retryTimer.unref?.();
}

function tryStartWatching(path: string, entry: Watcher): void {
  if (entry.fsWatcher) return;
  try {
    const fsWatcher = watch(path, event => {
      if (watchers.get(path) !== entry) return;
      if (event === 'rename') {
        fsWatcher.close();
        if (entry.fsWatcher === fsWatcher) entry.fsWatcher = undefined;
        scheduleRetry(path, entry);
      }
      if (entry.debounceTimer) return;
      // Do not reset the deadline: continuous output still updates at 5 Hz.
      entry.debounceTimer = setTimeout(() => {
        entry.debounceTimer = undefined;
        void pushOutput(path, entry);
      }, 200);
      entry.debounceTimer.unref?.();
    });
    entry.fsWatcher = fsWatcher;
    fsWatcher.on('error', () => {
      if (watchers.get(path) !== entry || entry.fsWatcher !== fsWatcher) return;
      fsWatcher.close();
      entry.fsWatcher = undefined;
      scheduleRetry(path, entry);
    });
  } catch { scheduleRetry(path, entry); }
}

export function watchBackgroundTaskOutput(connectionId: string, outputFile: string, connections: ConnectionManager): void {
  const path = resolve(outputFile);
  let entry = watchers.get(path);
  if (!entry) {
    entry = { reader: new BackgroundOutputReader(), subscribers: new Map(), text: '', truncated: false, endOffset: 0 };
    watchers.set(path, entry);
  }
  if (entry.subscribers.has(connectionId)) return;
  entry.subscribers.set(connectionId, { connectionId, outputFile, connections, initialized: false });
  void pushOutput(path, entry);
  tryStartWatching(path, entry);
}

export function unwatchBackgroundTaskOutput(connectionId: string, outputFile: string): void {
  const path = resolve(outputFile);
  const entry = watchers.get(path);
  if (!entry) return;
  entry.subscribers.delete(connectionId);
  if (entry.subscribers.size) return;
  if (entry.debounceTimer) clearTimeout(entry.debounceTimer);
  if (entry.retryTimer) clearTimeout(entry.retryTimer);
  entry.fsWatcher?.close();
  watchers.delete(path);
}

export function unwatchAllForConnection(connectionId: string): void {
  for (const path of watchers.keys()) unwatchBackgroundTaskOutput(connectionId, path);
}
