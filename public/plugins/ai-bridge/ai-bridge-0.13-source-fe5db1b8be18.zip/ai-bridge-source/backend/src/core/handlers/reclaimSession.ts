import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { markSessionAsSpawned } from '../claude-process';
import { Claude } from '../claude';
import { MessageType } from '../../shared';
import { loadAndSendSession } from './loadAndSendSession';

export async function reclaimSessionHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const sessionId = message.payload?.sessionId as string;
  const workingDir = message.payload?.workingDir as string | undefined;
  const limit = message.payload?.limit as number | undefined;

  if (!sessionId) {
    await connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId });
    return;
  }

  if (!workingDir) {
    await connections.sendTo(connectionId, MessageType.ERROR, {
      requestId: message.requestId,
      error: 'workingDir is required',
    });
    return;
  }

  console.error('[node-backend]', `Reclaiming session: ${sessionId}`);

  // 1. Kill the internal process
  const session = connections.getSession(sessionId);
  if (session?.process) {
    console.error('[node-backend]', `Killing internal process for session ${sessionId}`);
    Claude.killTree(session.process);
    connections.setProcess(sessionId, null);
    await new Promise(resolve => setTimeout(resolve, 500));
  }

  // 2. Mark the session so the next spawn uses --resume
  markSessionAsSpawned(sessionId);

  // 3. Load & send the session messages
  // Forward the pagination limit so a reclaim honors the user's "Paginate chat
  // history" setting exactly like the initial load (loadSessionHandler).
  connections.subscribe(connectionId, sessionId);
  try {
    await loadAndSendSession(connectionId, connections, workingDir, sessionId, { limit });
  } catch (err) {
    // The transcript could not be read: tell the caller instead of ACKing an
    // empty history it would take for a real one.
    console.error('[node-backend]', 'Failed to reclaim session:', err);
    await connections.sendTo(connectionId, MessageType.ERROR, {
      requestId: message.requestId,
      error: err instanceof Error ? err.message : String(err),
    });
    return;
  }

  console.error('[node-backend]', `Session ${sessionId} reclaimed successfully`);
  await connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId });
}
