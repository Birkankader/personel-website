import { execFile } from 'child_process';
import { existsSync } from 'fs';
import { jobHelperPath } from './win-job';

export type WindowsProcessSnapshot = Map<number, string | null>;

/** Set once the native helper failed a scan; this backend then keeps to PowerShell. */
let helperFailed = false;

/**
 * One bounded, asynchronous scan for a startup sweep or a resume's conflict check,
 * rather than one PowerShell startup per registry entry and question. Two programs
 * give the same `[{ProcessId, CommandLine}]` rows: the native helper
 * (`ai-bridge-job.exe --processes`, backend/native/win-job) in ~30 ms when it is
 * shipped, and a PowerShell CIM scan (~0.4 s warm) as its fallback. Command lines
 * stay in memory only.
 */
export async function readWindowsProcessSnapshot(): Promise<WindowsProcessSnapshot | null> {
  const helper = jobHelperPath();
  if (!helperFailed && existsSync(helper)) {
    const snapshot = await scan(helper, ['--processes']);
    if (snapshot) return snapshot;
    // A scan only reads, so repeating it elsewhere is harmless.
    helperFailed = true;
    console.error('[node-backend]', 'Process scan helper failed \u2014 using PowerShell');
  }
  return scan('powershell.exe', [
    '-NoProfile', '-NonInteractive', '-Command',
    '[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false); ' +
    'Get-CimInstance Win32_Process | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress',
  ]);
}

function scan(file: string, args: string[]): Promise<WindowsProcessSnapshot | null> {
  return new Promise((resolve) => {
    try {
      execFile(file, args, { encoding: 'utf8', windowsHide: true, timeout: 5000, maxBuffer: 8 * 1024 * 1024 }, (error, stdout) => {
        if (error) { resolve(null); return; }
        try {
          const data: unknown = JSON.parse(stdout.replace(/^\uFEFF/, '').trim());
          if (!data || typeof data !== 'object') { resolve(null); return; }
          const rows: unknown[] = Array.isArray(data) ? data : [data];
          const snapshot: WindowsProcessSnapshot = new Map();
          for (const row of rows) {
            if (!row || typeof row !== 'object') { resolve(null); return; }
            const { ProcessId: pid, CommandLine: command } = row as Record<string, unknown>;
            if (typeof pid !== 'number' || !Number.isInteger(pid) || pid < 0 ||
                (command !== null && typeof command !== 'string')) { resolve(null); return; }
            snapshot.set(pid, typeof command === 'string' && command.length > 0 ? command : null);
          }
          resolve(snapshot);
        } catch { resolve(null); }
      });
    } catch {
      resolve(null);
    }
  });
}

export function windowsSessionProcessIds(snapshot: WindowsProcessSnapshot, sessionId: string): number[] {
  if (!/^[A-Za-z0-9._-]+$/.test(sessionId)) return [];
  return [...snapshot].filter(([pid, command]) => pid > 1 && pid !== process.pid &&
    command?.includes(sessionId) && !command.includes('Get-CimInstance')).map(([pid]) => pid);
}

/** Await tree termination without stopping the backend's event loop. */
export function terminateWindowsTree(pid: number): Promise<boolean> {
  if (!Number.isInteger(pid) || pid <= 1 || pid === process.pid) return Promise.resolve(false);
  return new Promise((resolve) => {
    try {
      execFile('taskkill', ['/F', '/T', '/PID', String(pid)],
        { windowsHide: true, timeout: 5000 }, (error) => {
          if (!error) { resolve(true); return; }
          try { process.kill(pid, 0); resolve(false); } catch (probeError) {
            // Access denied does not prove that the writer exited. Only the
            // explicit no-such-process result permits clearing its registry.
            resolve((probeError as NodeJS.ErrnoException).code === 'ESRCH');
          }
        });
    } catch {
      resolve(false);
    }
  });
}
