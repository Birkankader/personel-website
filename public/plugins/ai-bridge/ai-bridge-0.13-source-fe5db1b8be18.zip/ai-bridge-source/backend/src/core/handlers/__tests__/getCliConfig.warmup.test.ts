import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { EventEmitter } from 'events';
import { Readable, Writable } from 'stream';
import type { ChildProcess } from 'child_process';

vi.mock('../../claude', () => ({
  Claude: {
    command: 'claude',
    env: { PATH: '/fixture/bin' },
    // Like the real one, projects the project's own config dir onto process.env,
    // which is part of the catalogue cache key.
    applyConfigDir: vi.fn(async (workingDir?: string) => {
      process.env.CLAUDE_CONFIG_DIR = workingDir ? `${workingDir}/claude-config` : '/global/claude-config';
    }),
    spawnAuthed: vi.fn(),
    spawnAuthedWith: vi.fn(),
    killTreeNonBlocking: vi.fn(),
  },
}));
vi.mock('../../features/settings', () => ({
  readMergedSettings: vi.fn(),
}));
vi.mock('../../harness-launch', () => ({
  harnessLaunch: vi.fn(() => ({ command: 'acp-bridge', args: [], env: {} })),
}));
vi.mock('../../features/harness-locator', () => ({
  harnessCommandEnv: vi.fn(async () => ({})),
}));

import { Claude } from '../../claude';
import { readMergedSettings } from '../../features/settings';
import { _resetCliConfigCache } from '../../features/loadCliConfig';
import { cliConfigWarmupDir, getCliConfigHandler, warmCliConfig } from '../getCliConfig';
import { MessageType } from '../../../shared';
import type { ConnectionManager } from '../../../ws/connection-manager';
import type { Bridge } from '../../../bridge/bridge-interface';

/** A probe that answers only when [answer] is called. */
function makeProbe(): { proc: ChildProcess; answer: (commandName: string) => void } {
  const proc = new EventEmitter() as unknown as ChildProcess;
  const stdout = new Readable({ read() {} });
  Object.assign(proc, {
    stdout,
    stderr: new Readable({ read() {} }),
    stdin: new Writable({ write(_c, _e, cb) { cb(); } }),
    pid: 1234,
    kill: () => {},
  });
  setImmediate(() => proc.emit('spawn'));
  const answer = (commandName: string) => {
    stdout.push(JSON.stringify({
      type: 'control_response',
      response: {
        subtype: 'success',
        request_id: 'config_init',
        response: {
          commands: [{ name: commandName, description: '', argumentHint: '' }],
          agents: [],
          output_style: 'default',
          available_output_styles: [],
          models: [],
          account: { email: '', subscriptionType: '' },
          pid: 1,
        },
      },
    }) + '\n');
  };
  return { proc, answer };
}

/** Every probe answers at once with [commandName]. */
function probesAnswer(spawn: typeof Claude.spawnAuthed | typeof Claude.spawnAuthedWith, commandName: string): void {
  vi.mocked(spawn).mockImplementation(async () => {
    const probe = makeProbe();
    setImmediate(() => setImmediate(() => probe.answer(commandName)));
    return probe.proc;
  });
}

/** The page's request, as the handler answers it. */
async function pageRequest(workingDir: string): Promise<Record<string, unknown>> {
  const sendTo = vi.fn();
  await getCliConfigHandler(
    'conn-1',
    { type: MessageType.GET_CLI_CONFIG, requestId: 'req-1', payload: { workingDir }, timestamp: 0 },
    { sendTo } as unknown as ConnectionManager,
    {} as Bridge,
  );
  expect(sendTo).toHaveBeenCalledTimes(1);
  return sendTo.mock.calls[0][2] as Record<string, unknown>;
}

function commandOf(ack: Record<string, unknown>): string | undefined {
  const controlResponse = ack.controlResponse as { response: { response: { commands: { name: string }[] } } } | null;
  return controlResponse?.response.response.commands[0]?.name;
}

describe('warmCliConfig', () => {
  const inheritedConfigDir = process.env.CLAUDE_CONFIG_DIR;

  beforeEach(() => {
    _resetCliConfigCache();
    vi.mocked(Claude.spawnAuthed).mockReset();
    vi.mocked(Claude.spawnAuthedWith).mockReset();
    vi.mocked(Claude.applyConfigDir).mockClear();
    vi.mocked(readMergedSettings).mockReset();
    vi.mocked(readMergedSettings).mockResolvedValue({ settings: {}, overrides: [] });
    // What startup leaves behind: the global config dir, not the project's.
    process.env.CLAUDE_CONFIG_DIR = '/global/claude-config';
  });
  afterEach(() => {
    if (inheritedConfigDir === undefined) delete process.env.CLAUDE_CONFIG_DIR;
    else process.env.CLAUDE_CONFIG_DIR = inheritedConfigDir;
  });

  it('lets the page join the probe it started instead of starting another CLI', async () => {
    const probe = makeProbe();
    vi.mocked(Claude.spawnAuthed).mockResolvedValueOnce(probe.proc);

    const warming = warmCliConfig('/project/a');
    await vi.waitFor(() => expect(Claude.spawnAuthed).toHaveBeenCalledTimes(1));
    const request = pageRequest('/project/a');
    probe.answer('from-warm-up');

    expect(commandOf(await request)).toBe('from-warm-up');
    await warming;
    expect(Claude.spawnAuthed).toHaveBeenCalledTimes(1);
  });

  it('answers a later page request from what it loaded', async () => {
    probesAnswer(Claude.spawnAuthed, 'from-warm-up');

    await warmCliConfig('/project/a');
    const ack = await pageRequest('/project/a');

    expect(commandOf(ack)).toBe('from-warm-up');
    expect(Claude.spawnAuthed).toHaveBeenCalledTimes(1);
  });

  it('probes with the project\'s own config dir, the one the page asks under', async () => {
    probesAnswer(Claude.spawnAuthed, 'from-warm-up');

    await warmCliConfig('/project/a');
    await pageRequest('/project/a');

    // Under the global config dir it would have filled a different cache entry.
    expect(Claude.spawnAuthed).toHaveBeenCalledTimes(1);
  });

  it('loads the catalogue of the harness new chats start on, as the page does', async () => {
    vi.mocked(readMergedSettings).mockResolvedValue({ settings: { harness: 'deepseek' }, overrides: [] });
    probesAnswer(Claude.spawnAuthedWith, 'from-harness');

    await warmCliConfig('/project/a');
    const ack = await pageRequest('/project/a');

    expect(commandOf(ack)).toBe('from-harness');
    expect(Claude.spawnAuthedWith).toHaveBeenCalledTimes(1);
    expect(Claude.spawnAuthed).not.toHaveBeenCalled();
  });

  it('never throws, and leaves the page to probe again when it fails', async () => {
    vi.mocked(Claude.spawnAuthed).mockRejectedValueOnce(new Error('spawn EACCES'));

    await expect(warmCliConfig('/project/a')).resolves.toBeUndefined();

    probesAnswer(Claude.spawnAuthed, 'from-page');
    expect(commandOf(await pageRequest('/project/a'))).toBe('from-page');
    expect(Claude.spawnAuthed).toHaveBeenCalledTimes(2);
  });
});

describe('cliConfigWarmupDir', () => {
  it('is the project root the plugin started the backend for', () => {
    expect(cliConfigWarmupDir({ AI_BRIDGE_RUNTIME_SCOPE: 'C:/work/app' }, true)).toBe('C:/work/app');
  });

  it('is none for a WSL backend, whose root is not the path the page asks with', () => {
    expect(cliConfigWarmupDir({ AI_BRIDGE_RUNTIME_SCOPE: '/home/me/app', WSL_DISTRO_NAME: 'Ubuntu' }, true)).toBeUndefined();
  });

  it('is none outside JetBrains, or without a project root', () => {
    expect(cliConfigWarmupDir({ AI_BRIDGE_RUNTIME_SCOPE: '/work/app' }, false)).toBeUndefined();
    expect(cliConfigWarmupDir({}, true)).toBeUndefined();
    expect(cliConfigWarmupDir({ AI_BRIDGE_RUNTIME_SCOPE: '' }, true)).toBeUndefined();
  });
});
