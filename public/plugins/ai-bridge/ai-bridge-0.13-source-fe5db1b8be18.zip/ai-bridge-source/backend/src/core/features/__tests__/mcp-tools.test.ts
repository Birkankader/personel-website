import { describe, it, expect } from 'vitest';
import { mapMcpTool, buildTransport, isMcpAuthError } from '../mcp-tools';
import { McpTransportType } from '../../../shared';
import type { McpServerConfig } from '../../../shared';

describe('mapMcpTool', () => {
  it('keeps only the name when no annotations are present', () => {
    expect(mapMcpTool({ name: 'playwright_navigate' })).toEqual({ name: 'playwright_navigate' });
  });

  it('omits the annotations object when annotations is empty', () => {
    expect(mapMcpTool({ name: 't', annotations: {} })).toEqual({ name: 't' });
  });

  it('maps readOnlyHint -> readOnly', () => {
    expect(mapMcpTool({ name: 't', annotations: { readOnlyHint: true } })).toEqual({
      name: 't',
      annotations: { readOnly: true },
    });
  });

  it('maps destructiveHint -> destructive', () => {
    expect(mapMcpTool({ name: 't', annotations: { destructiveHint: true } })).toEqual({
      name: 't',
      annotations: { destructive: true },
    });
  });

  it('maps both hints together', () => {
    expect(
      mapMcpTool({ name: 't', annotations: { readOnlyHint: false, destructiveHint: true } }),
    ).toEqual({ name: 't', annotations: { readOnly: false, destructive: true } });
  });
});

describe('buildTransport', () => {
  // Expansion source; empty because these cases only assert transport selection.
  const noEnv = {};

  it('returns a transport for a stdio server with a command', async () => {
    const config: McpServerConfig = {
      type: McpTransportType.STDIO,
      command: 'npx',
      args: ['@executeautomation/playwright-mcp-server'],
    };
    expect(await buildTransport(config, noEnv)).not.toBeNull();
  });

  it('returns null for a stdio server without a command', async () => {
    expect(await buildTransport({ type: McpTransportType.STDIO }, noEnv)).toBeNull();
  });

  // `type` is optional for a stdio server in .mcp.json and routinely omitted —
  // the docs' examples and the report in #364 both list only command/args/env.
  // Falling through to `default` returned no transport, so the panel showed a
  // connected server with an empty tool list and no error (verified in browser).
  it('treats a server with no explicit type as stdio when it has a command', async () => {
    const config: McpServerConfig = { command: 'npx', args: ['some-mcp-server'] };
    expect(await buildTransport(config, noEnv)).not.toBeNull();
  });

  it('still returns null when there is neither a type nor a command', async () => {
    expect(await buildTransport({}, noEnv)).toBeNull();
  });

  it('returns a transport for an http server with a url', async () => {
    expect(await buildTransport({ type: McpTransportType.HTTP, url: 'http://localhost:8000/mcp' }, noEnv)).not.toBeNull();
  });

  it('returns a transport for an sse server with a url', async () => {
    expect(await buildTransport({ type: McpTransportType.SSE, url: 'http://localhost:64342/sse' }, noEnv)).not.toBeNull();
  });

  it('returns null for http/sse without a url', async () => {
    expect(await buildTransport({ type: McpTransportType.HTTP }, noEnv)).toBeNull();
    expect(await buildTransport({ type: McpTransportType.SSE }, noEnv)).toBeNull();
  });

  it('returns null for claudeai-proxy (needs OAuth, not directly probeable)', async () => {
    expect(await buildTransport({ type: McpTransportType.CLAUDEAI_PROXY, url: 'https://example' }, noEnv)).toBeNull();
  });
});

/**
 * The distinction the detail view needs: an OAuth server answering 401 must not
 * be reported as a plain connection failure, because the user cannot retry it
 * away at this layer. Sign-in belongs to the CLI.
 */
describe('isMcpAuthError', () => {
  it('recognises the 401 the StreamableHTTP transport reports', () => {
    // Measured message shape from the SDK for an OAuth-protected endpoint.
    expect(isMcpAuthError(new Error('Error POSTing to endpoint (HTTP 401): Unauthorized'))).toBe(true);
  });

  it('recognises a bare 401 on an error code', () => {
    expect(isMcpAuthError(Object.assign(new Error('bad status'), { code: 401 }))).toBe(true);
  });

  it('recognises the OAuth vocabulary without a status code', () => {
    for (const message of [
      'Unauthorized',
      'unauthenticated: token expired',
      'invalid_token',
      'invalid_grant',
      'server needs-auth',
      'authentication required',
      '401',
    ]) {
      expect(isMcpAuthError(new Error(message))).toBe(true);
    }
  });

  it('does not treat a 403 as a sign-in problem', () => {
    // A 403 is a permission/policy answer; telling the user to sign in again
    // would be a fresh wrong explanation in place of the old generic one.
    expect(isMcpAuthError(new Error('Error POSTing to endpoint (HTTP 403): Forbidden'))).toBe(false);
  });

  it('leaves ordinary failures alone', () => {
    for (const error of [
      new Error('MCP connect timed out after 15000ms'),
      new Error('connect ECONNREFUSED 127.0.0.1:8080'),
      'ENOENT',
      null,
      undefined,
    ]) {
      expect(isMcpAuthError(error)).toBe(false);
    }
  });
});
