import { afterAll, afterEach, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { spawn, spawnSync, type ChildProcess } from 'child_process';
import {
  chmodSync, mkdirSync, mkdtempSync, readFileSync, readdirSync, rmSync, statSync, utimesSync, writeFileSync,
} from 'fs';
import { tmpdir } from 'os';
import { basename, join } from 'path';
import { fileURLToPath } from 'url';
import { spawnWin32JobCli } from '../win-job';

// win-job-wrapper.ps1 runs in front of every chat CLI start on Windows. These suites
// drive the real script through a real PowerShell, which is the only way to learn
// whether it parses, which build path it takes, and whether it stays off stdout.

const wrapper = fileURLToPath(new URL('../win-job-wrapper.ps1', import.meta.url));
const CACHED = /^CcgJobNative-[0-9a-f]{16}\.dll$/;

/**
 * Production runs Windows PowerShell 5.1 (win-job.ts spawns powershell.exe), so on
 * Windows that is what runs here. Elsewhere PowerShell 7's `pwsh` runs the same cache
 * logic, with Roslyn standing in for csc.exe; AI_BRIDGE_TEST_PWSH names a binary that is
 * not on PATH. With neither, the suites that need one skip.
 */
function findPowerShell(): string | null {
  const candidates = process.env.AI_BRIDGE_TEST_PWSH
    ? [process.env.AI_BRIDGE_TEST_PWSH]
    : process.platform === 'win32' ? ['powershell.exe'] : ['pwsh'];
  for (const candidate of candidates) {
    const probe = spawnSync(candidate, ['-NoProfile', '-NonInteractive', '-Command', 'exit 0'],
      { stdio: 'ignore', timeout: 60_000 });
    if (probe.status === 0) return candidate;
  }
  return null;
}

const powershell = findPowerShell();

interface Exited { code: number | null; stdout: string; stderr: string }

function collect(proc: ChildProcess): Promise<Exited> {
  return new Promise((resolve, reject) => {
    let stdout = '';
    let stderr = '';
    proc.stdout?.on('data', (data: Buffer) => { stdout += data.toString(); });
    proc.stderr?.on('data', (data: Buffer) => { stderr += data.toString(); });
    proc.on('error', reject);
    proc.on('close', (code) => resolve({ code, stdout, stderr }));
  });
}

describe('win-job-wrapper.ps1 source', () => {
  it('stays ASCII, since Windows PowerShell 5.1 reads a BOM-less script in the ANSI code page', () => {
    expect([...readFileSync(wrapper)].findIndex((byte) => byte > 0x7f)).toBe(-1);
  });
});

/**
 * Loads only the wrapper's functions and interop source (via the PowerShell parser,
 * so the main body never runs), wraps Add-Type to record which build path the
 * wrapper takes, and prints one JSON line describing the type it obtained.
 */
const HARNESS = String.raw`
$ErrorActionPreference = 'Stop'
$tokens = $null
$errors = $null
$ast = [System.Management.Automation.Language.Parser]::ParseFile($env:CCG_TEST_WRAPPER, [ref]$tokens, [ref]$errors)
if ($errors.Count -gt 0) { throw ('wrapper does not parse: ' + ($errors -join '; ')) }
$definitions = $ast.FindAll({
  param($node)
  ($node -is [System.Management.Automation.Language.FunctionDefinitionAst]) -or
    (($node -is [System.Management.Automation.Language.AssignmentStatementAst]) -and
      ($node.Left.Extent.Text -eq '$CcgJobNativeSource'))
}, $false)
foreach ($definition in $definitions) { . ([scriptblock]::Create($definition.Extent.Text)) }

$calls = New-Object System.Collections.Generic.List[string]
function Add-Type {
  param([string]$TypeDefinition, [string]$OutputAssembly, [string[]]$LiteralPath, [switch]$PassThru)
  $kind = 'compile-memory'
  if ($LiteralPath) { $kind = 'load' } elseif ($OutputAssembly) { $kind = 'compile-file' }
  $calls.Add($kind)
  if (@($env:CCG_TEST_FAIL -split ',') -contains $kind) { throw "injected $kind failure" }
  if ($LiteralPath) {
    Microsoft.PowerShell.Utility\Add-Type -LiteralPath $LiteralPath -PassThru:$PassThru
  } elseif ($OutputAssembly) {
    Microsoft.PowerShell.Utility\Add-Type -TypeDefinition $TypeDefinition -OutputAssembly $OutputAssembly -PassThru:$PassThru
  } else {
    Microsoft.PowerShell.Utility\Add-Type -TypeDefinition $TypeDefinition -PassThru:$PassThru
  }
}

$type = Get-CcgNativeType -Source ($CcgJobNativeSource + $env:CCG_TEST_SOURCE_SUFFIX) -TypeName 'CcgJobNative' -CacheDir $env:CCG_TEST_CACHE_DIR
$location = ''
if ($type -is [type]) { $location = $type.Assembly.Location }
[Console]::Out.Write((ConvertTo-Json -Compress -InputObject @{ isType = ($type -is [type]); location = $location; calls = $calls.ToArray() }))
`;

interface Acquired { isType: boolean; location: string; calls: string[] }

describe.skipIf(!powershell)('win-job-wrapper.ps1 interop cache', () => {
  let harnessDir: string;
  let harness: string;
  let root: string;

  beforeAll(() => {
    harnessDir = mkdtempSync(join(tmpdir(), 'ccg-job-harness-'));
    harness = join(harnessDir, 'harness.ps1');
    writeFileSync(harness, HARNESS);
  });
  afterAll(() => rmSync(harnessDir, { recursive: true, force: true }));
  beforeEach(() => { root = mkdtempSync(join(tmpdir(), 'ccg-job-cache-')); });
  afterEach(() => rmSync(root, { recursive: true, force: true, maxRetries: 5 }));

  const cacheDir = () => join(root, 'win-job-cache');
  const files = () => readdirSync(cacheDir()).sort();
  /** The single published build in the cache dir. */
  const published = () => {
    const names = files();
    expect(names).toHaveLength(1);
    expect(names[0]).toMatch(CACHED);
    return join(cacheDir(), names[0]);
  };

  async function acquire(cache: string | undefined, env: Record<string, string> = {}): Promise<Acquired> {
    const proc = spawn(powershell!, ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', harness], {
      env: { ...process.env, CCG_TEST_WRAPPER: wrapper, CCG_TEST_CACHE_DIR: cache ?? '', ...env },
      windowsHide: true,
    });
    const { code, stdout, stderr } = await collect(proc);
    expect({ code, stderr }).toEqual({ code: 0, stderr: '' });
    // All of stdout must be the harness's own JSON: in production any byte the
    // wrapper's functions print lands in the chat's stream-json protocol.
    return JSON.parse(stdout) as Acquired;
  }

  it('compiles once into the cache, then later launches only load it', async () => {
    const first = await acquire(cacheDir());
    expect(first.calls).toEqual(['compile-file', 'load']);
    const dll = published();
    expect(basename(first.location)).toBe(basename(dll));
    const written = statSync(dll).mtimeMs;

    const second = await acquire(cacheDir());
    expect(second.calls).toEqual(['load']);
    expect(basename(second.location)).toBe(basename(dll));
    expect(statSync(dll).mtimeMs).toBe(written);
    expect(files()).toEqual([basename(dll)]);
  });

  it('keys the build by its source, so an edited interop never loads a stale one', async () => {
    await acquire(cacheDir());
    const edited = await acquire(cacheDir(), { CCG_TEST_SOURCE_SUFFIX: ' // edited' });
    expect(edited.calls).toEqual(['compile-file', 'load']);
    expect(files().filter((name) => CACHED.test(name))).toHaveLength(2);
  });

  it('replaces a damaged build once instead of compiling in memory on every launch', async () => {
    await acquire(cacheDir());
    const dll = published();
    writeFileSync(dll, Buffer.alloc(4096)); // what a torn write can leave after a power loss

    const healed = await acquire(cacheDir());
    expect(healed.isType).toBe(true);
    // Windows CLR may cache the failed LoadFrom for this path for the lifetime
    // of the repairing process. The repaired on-disk cache must still be used
    // without compilation by the next process (asserted below).
    if (process.platform === 'win32' && healed.location === '') {
      expect(healed.calls).toEqual(['load', 'compile-file', 'load', 'compile-memory']);
    } else {
      expect(healed.calls).toEqual(['load', 'compile-file', 'load']);
      expect(basename(healed.location)).toBe(basename(dll));
    }
    expect((await acquire(cacheDir())).calls).toEqual(['load']);
  });

  it.skipIf(process.platform === 'win32' || process.getuid?.() === 0)(
    'leaves a build it is refused alone and compiles in memory, without recompiling into the cache',
    async () => {
      await acquire(cacheDir());
      const dll = published();
      chmodSync(dll, 0o000);
      try {
        const refused = await acquire(cacheDir());
        expect(refused).toEqual({ isType: true, location: '', calls: ['load', 'compile-memory'] });
        expect(files()).toEqual([basename(dll)]);
      } finally {
        chmodSync(dll, 0o644);
      }
    },
  );

  it('uses its own fresh build when the published name cannot be taken', async () => {
    await acquire(cacheDir());
    const dll = published();
    rmSync(dll);
    mkdirSync(dll); // File.Move can neither replace this nor report the name as a file

    const result = await acquire(cacheDir());
    expect(result.isType).toBe(true);
    expect(result.calls).toEqual(['compile-file', 'load']);
    expect(basename(result.location)).toMatch(/\.tmp\.dll$/);
  });

  it('reaps temp files abandoned by a killed compile, but not one that may still be written', async () => {
    mkdirSync(cacheDir(), { recursive: true });
    const abandoned = join(cacheDir(), 'CcgJobNative-0000000000000000-dead.tmp.dll');
    const inFlight = join(cacheDir(), 'CcgJobNative-0000000000000000-live.tmp.dll');
    writeFileSync(abandoned, '');
    writeFileSync(inFlight, '');
    const hourAgo = new Date(Date.now() - 60 * 60 * 1000);
    utimesSync(abandoned, hourAgo, hourAgo);

    await acquire(cacheDir());
    expect(files()).toContain(basename(inFlight));
    expect(files()).not.toContain(basename(abandoned));
  });

  it('publishes exactly one build when several first launches race', async () => {
    const results = await Promise.all(Array.from({ length: 4 }, () => acquire(cacheDir())));
    const dll = published();
    for (const result of results) {
      expect(result.isType).toBe(true);
      expect(basename(result.location)).toBe(basename(dll));
    }
  });

  it('compiles in memory, as before the cache existed, without a cache dir', async () => {
    expect(await acquire(undefined)).toEqual({ isType: true, location: '', calls: ['compile-memory'] });
  });

  it('compiles in memory when the cache dir cannot be created', async () => {
    writeFileSync(join(root, 'file'), '');
    expect(await acquire(join(root, 'file', 'win-job-cache')))
      .toEqual({ isType: true, location: '', calls: ['compile-memory'] });
  });

  it('compiles in memory when compiling into the cache fails', async () => {
    expect(await acquire(cacheDir(), { CCG_TEST_FAIL: 'compile-file' }))
      .toEqual({ isType: true, location: '', calls: ['compile-file', 'compile-memory'] });
  });

  it('reports no type, quietly, when no build is possible at all', async () => {
    expect(await acquire(cacheDir(), { CCG_TEST_FAIL: 'compile-file,compile-memory' }))
      .toEqual({ isType: false, location: '', calls: ['compile-file', 'compile-memory'] });
  });
});

/**
 * The wrapper's main body off Windows, with a stand-in `cmd.exe` on PATH. There is no
 * kernel32 here, so the interop loads but every Job Object call throws: exactly the
 * failure the wrapper must survive by launching the CLI without a job.
 */
describe.skipIf(!powershell || process.platform === 'win32')('win-job-wrapper.ps1 main body (stand-in cmd.exe)', () => {
  let root: string;

  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), 'ccg-job-main-'));
    mkdirSync(join(root, 'bin'));
    const cmd = join(root, 'bin', 'cmd.exe');
    writeFileSync(cmd, [
      '#!/bin/sh',
      '[ "$1 $2 $3" = "/d /s /c" ] || { echo "unexpected cmd.exe argv: $*" >&2; exit 99; }',
      'exec /bin/sh -c "$4"',
      '',
    ].join('\n'));
    chmodSync(cmd, 0o755);
  });
  afterEach(() => rmSync(root, { recursive: true, force: true }));

  const run = (env: NodeJS.ProcessEnv) => collect(spawn(powershell!,
    ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', wrapper, 'ccg-test-session'],
    { env: { ...process.env, PATH: `${join(root, 'bin')}:${process.env.PATH}`, ...env } }));

  it('passes stdout and the exit code through untouched when the job cannot be created, and says so on stderr', async () => {
    const env = { AI_BRIDGE_JOB_CMDLINE: 'printf ccg-job-ok; exit 7', AI_BRIDGE_JOB_CACHE_DIR: join(root, 'cache') };
    // The degradation is reported the way ai-bridge-job.exe reports it: one [ccg-job]
    // line on stderr, never on stdout (the chat's stream-json protocol).
    const unavailable = expect.stringContaining('[ccg-job] Job Object unavailable');
    expect(await run(env)).toEqual({ code: 7, stdout: 'ccg-job-ok', stderr: unavailable });
    expect(readdirSync(join(root, 'cache'))).toEqual([expect.stringMatching(CACHED)]);
    const second = await run(env);
    expect(second).toEqual({ code: 7, stdout: 'ccg-job-ok', stderr: unavailable });
    expect(second.stderr).toContain('running without the orphan guard');
  });

  it('refuses to start without AI_BRIDGE_JOB_CMDLINE, on stderr only', async () => {
    const result = await run({ AI_BRIDGE_JOB_CMDLINE: '', AI_BRIDGE_JOB_CACHE_DIR: join(root, 'cache') });
    expect(result).toEqual({ code: 210, stdout: '', stderr: expect.stringContaining('AI_BRIDGE_JOB_CMDLINE not set') });
  });

  it('exits 211 with a [ccg-job] line when cmd.exe cannot be started', async () => {
    const result = await run({
      AI_BRIDGE_JOB_CMDLINE: 'printf never-runs',
      AI_BRIDGE_JOB_CACHE_DIR: join(root, 'cache'),
      ComSpec: '/nonexistent/cmd.exe',
    });
    expect(result.code).toBe(211);
    expect(result.stdout).toBe('');
    expect(result.stderr).toContain('[ccg-job] could not start /nonexistent/cmd.exe');
  });
});

/**
 * The whole wrapper, end to end, as the backend launches it. Windows only: it needs
 * cmd.exe, kernel32's Job Object API and Windows PowerShell 5.1.
 */
describe.skipIf(process.platform !== 'win32')('win-job-wrapper.ps1 under Windows PowerShell 5.1', () => {
  let root: string;
  const wrappers: ChildProcess[] = [];
  const standIns: number[] = [];

  beforeEach(() => { root = mkdtempSync(join(tmpdir(), 'ccg-job-e2e-')); });
  afterEach(() => {
    // Only what is provably still ours: a wrapper Node has not seen exit, a stand-in
    // that is still alive (a failed test leaves it sleeping). A PID that already died
    // may belong to an unrelated process by now.
    for (const proc of wrappers.splice(0)) {
      if (proc.exitCode === null && proc.signalCode === null && proc.pid) {
        spawnSync('taskkill', ['/F', '/T', '/PID', String(proc.pid)], { stdio: 'ignore' });
      }
    }
    for (const pid of standIns.splice(0)) {
      if (alive(pid)) spawnSync('taskkill', ['/F', '/PID', String(pid)], { stdio: 'ignore' });
    }
    rmSync(root, { recursive: true, force: true, maxRetries: 10, retryDelay: 200 });
  });

  const cacheDir = () => join(root, 'win-job-cache');
  const alive = (pid: number) => {
    try {
      process.kill(pid, 0);
      return true;
    } catch {
      return false;
    }
  };

  function launch(cmdline: string | undefined, cache: string | undefined, extraEnv: Record<string, string> = {}): ChildProcess {
    const env: NodeJS.ProcessEnv = { ...process.env };
    // Windows names are case-insensitive, but a plain object is not: a shell that
    // exported COMSPEC (Git Bash does) would otherwise leave both spellings in the
    // block and the child could read either one.
    for (const name of Object.keys(extraEnv)) {
      for (const existing of Object.keys(env)) {
        if (existing.toLowerCase() === name.toLowerCase()) delete env[existing];
      }
    }
    Object.assign(env, extraEnv);
    delete env.AI_BRIDGE_JOB_CMDLINE;
    delete env.AI_BRIDGE_JOB_CACHE_DIR;
    if (cmdline !== undefined) env.AI_BRIDGE_JOB_CMDLINE = cmdline;
    if (cache !== undefined) env.AI_BRIDGE_JOB_CACHE_DIR = cache;
    const proc = spawn('powershell.exe',
      ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-File', wrapper, 'ccg-test-session'],
      { env, windowsHide: true });
    wrappers.push(proc);
    return proc;
  }

  function firstLine(proc: ChildProcess): Promise<string> {
    return new Promise((resolve, reject) => {
      let buffered = '';
      proc.stdout?.on('data', (data: Buffer) => {
        buffered += data.toString();
        const end = buffered.indexOf('\n');
        if (end >= 0) resolve(buffered.slice(0, end).trim());
      });
      proc.on('error', reject);
      proc.on('close', () => reject(new Error(`wrapper exited before the stand-in printed: "${buffered}"`)));
    });
  }

  /**
   * Starts a CLI stand-in that prints its PID and sleeps, then kills ONLY the wrapper,
   * which is what the backend dying amounts to. KILL_ON_JOB_CLOSE must end the stand-in
   * at once; without a job it would sleep on for two minutes. The ping first lets the
   * wrapper's AssignProcessToJobObject land before cmd creates the stand-in, so only
   * the job (not that pre-existing Start/Assign race) decides the outcome.
   */
  async function standInDiesWithWrapper(cache: string | undefined): Promise<boolean> {
    const proc = launch(
      'ping -n 2 127.0.0.1 >nul & powershell -NoProfile -NonInteractive -Command "[Console]::Out.WriteLine($PID); Start-Sleep 120"',
      cache,
    );
    const pid = Number(await firstLine(proc));
    standIns.push(pid);
    expect(alive(pid)).toBe(true);
    proc.kill();
    const deadline = Date.now() + 10_000;
    while (Date.now() < deadline) {
      if (!alive(pid)) return true;
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    return false;
  }

  it('passes the CLI exit code through and adds nothing to its stdout', async () => {
    expect(await collect(launch('echo ccg-job-ok& exit 7', cacheDir())))
      .toEqual({ code: 7, stdout: 'ccg-job-ok\r\n', stderr: '' });
    expect(await collect(launch('echo ccg-job-ok& exit 7', cacheDir())))
      .toEqual({ code: 7, stdout: 'ccg-job-ok\r\n', stderr: '' });
  }, 120_000);

  it('refuses to start without AI_BRIDGE_JOB_CMDLINE', async () => {
    const result = await collect(launch(undefined, cacheDir()));
    expect(result.code).toBe(210);
    expect(result.stdout).toBe('');
    expect(result.stderr).toContain('AI_BRIDGE_JOB_CMDLINE not set');
  }, 120_000);

  // The native helper answers a failed start with `[ccg-job] could not start <cmd>` and
  // exit 211. Without that the wrapper died with a PowerShell stack trace and exit 1,
  // which the backend could not tell from the CLI itself exiting 1.
  it('exits 211 with a [ccg-job] line, and nothing on stdout, when cmd.exe cannot be started', async () => {
    const missing = join(root, 'missing', 'cmd.exe');
    const result = await collect(launch('echo never-runs', cacheDir(), { ComSpec: missing }));
    expect(result.code).toBe(211);
    expect(result.stdout).toBe('');
    expect(result.stderr).toContain('[ccg-job] could not start');
    expect(result.stderr).toContain(missing);
  }, 120_000);

  it('falls back to the System32 cmd.exe when ComSpec is not an absolute path', async () => {
    expect(await collect(launch('echo ccg-job-ok& exit 7', cacheDir(), { ComSpec: 'cmd.exe' })))
      .toEqual({ code: 7, stdout: 'ccg-job-ok\r\n', stderr: '' });
  }, 120_000);

  it('kills the CLI tree with the wrapper from a cold cache and from the build it published', async () => {
    expect(await standInDiesWithWrapper(cacheDir())).toBe(true);
    expect(readdirSync(cacheDir())).toEqual([expect.stringMatching(CACHED)]);
    expect(await standInDiesWithWrapper(cacheDir())).toBe(true);
  }, 120_000);

  it('keeps the job when the cached build is damaged, and repairs it', async () => {
    expect(await collect(launch('exit 0', cacheDir()))).toMatchObject({ code: 0 });
    const [name] = readdirSync(cacheDir());
    writeFileSync(join(cacheDir(), name), Buffer.alloc(4096));
    expect(await standInDiesWithWrapper(cacheDir())).toBe(true);
    expect(readFileSync(join(cacheDir(), name)).subarray(0, 2).toString()).toBe('MZ');
  }, 120_000);

  it('keeps the job when the cache dir is unusable, or not given at all', async () => {
    writeFileSync(join(root, 'file'), '');
    expect(await standInDiesWithWrapper(join(root, 'file', 'win-job-cache'))).toBe(true);
    expect(await standInDiesWithWrapper(undefined)).toBe(true);
  }, 120_000);

  it('lets simultaneous first launches share one published build', async () => {
    const results = await Promise.all([1, 2, 3].map(() => collect(launch('exit 3', cacheDir()))));
    expect(results.map((result) => result.code)).toEqual([3, 3, 3]);
    expect(readdirSync(cacheDir())).toEqual([expect.stringMatching(CACHED)]);
  }, 120_000);

  it('finds the cache in the data dir when launched through spawnWin32JobCli', async () => {
    const profile = process.env.USERPROFILE;
    process.env.USERPROFILE = root; // os.homedir() reads it on Windows
    try {
      const proc = spawnWin32JobCli('exit', ['5'], 'ccg-test-session', { env: process.env, windowsHide: true });
      wrappers.push(proc);
      expect(await collect(proc)).toEqual({ code: 5, stdout: '', stderr: '' });
      expect(readdirSync(join(root, '.ai-bridge', 'win-job-cache')))
        .toEqual([expect.stringMatching(CACHED)]);
    } finally {
      if (profile === undefined) delete process.env.USERPROFILE;
      else process.env.USERPROFILE = profile;
    }
  }, 120_000);
});
