import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { watch } from 'fs';
import type { ConnectionManager } from '../../../ws/connection-manager';
import type { OutputUpdate } from '../background-output-reader';
import { watchBackgroundTaskOutput, unwatchAllForConnection, unwatchBackgroundTaskOutput } from '../backgroundTaskOutputWatcher';

vi.mock('fs', () => ({ watch: vi.fn() }));
const { loadBackgroundTaskOutput } = vi.hoisted(() => ({ loadBackgroundTaskOutput: vi.fn() }));
vi.mock('../background-output-reader', () => ({ BackgroundOutputReader: class { read = loadBackgroundTaskOutput; more = false; } }));
const update = (text: string): OutputUpdate => ({ kind: 'snapshot', text, offset: 0, endOffset: text.length, truncated: false });

describe('background output scheduling', () => {
  let changed: () => void;
  let watcherError: () => void;
  const sendTo = vi.fn();
  const connections = { sendTo } as unknown as ConnectionManager;

  beforeEach(() => {
    vi.useFakeTimers();
    vi.clearAllMocks();
    vi.mocked(loadBackgroundTaskOutput).mockResolvedValue(update('current'));
    vi.mocked(watch).mockImplementation(((_file: string, callback: () => void) => {
      changed = callback;
      return {
        close: vi.fn(),
        on: (_event: string, callback: () => void) => { watcherError = callback; },
      };
    }) as unknown as typeof watch);
  });

  afterEach(() => {
    unwatchAllForConnection('conn');
    unwatchAllForConnection('other');
    vi.useRealTimers();
  });

  it('keeps a continuous log live while limiting updates to five per second', async () => {
    watchBackgroundTaskOutput('conn', '/task.output', connections);
    await vi.advanceTimersByTimeAsync(0);
    sendTo.mockClear();
    for (let i = 0; i < 20; i++) {
      changed();
      await vi.advanceTimersByTimeAsync(50);
    }

    expect(sendTo).toHaveBeenCalledTimes(5);
  });

  it('coalesces changes into one follow-up while a slow read is in flight', async () => {
    let finish!: (output: OutputUpdate) => void;
    vi.mocked(loadBackgroundTaskOutput).mockImplementationOnce(() => new Promise((resolve) => { finish = resolve; }));
    watchBackgroundTaskOutput('conn', '/task.output', connections);
    for (let i = 0; i < 20; i++) {
      changed();
      await vi.advanceTimersByTimeAsync(50);
    }
    expect(loadBackgroundTaskOutput).toHaveBeenCalledOnce();

    finish(update('earlier'));
    await vi.advanceTimersByTimeAsync(0);
    expect(loadBackgroundTaskOutput).toHaveBeenCalledTimes(2);
    expect(sendTo.mock.calls.map((call) => call[2].text)).toEqual(['earlier', 'current']);
  });

  it('does not emit a read that finishes after unwatch and resubscribe', async () => {
    let finish!: (output: OutputUpdate) => void;
    vi.mocked(loadBackgroundTaskOutput).mockImplementationOnce(() => new Promise((resolve) => { finish = resolve; }));
    watchBackgroundTaskOutput('conn', '/task.output', connections);
    const oldError = watcherError;
    unwatchBackgroundTaskOutput('conn', '/task.output');
    watchBackgroundTaskOutput('conn', '/task.output', connections);
    await vi.advanceTimersByTimeAsync(0);

    finish(update('stale'));
    oldError(); // A late old-watcher error cannot tear down the new subscription.
    await vi.advanceTimersByTimeAsync(0);
    changed();
    await vi.advanceTimersByTimeAsync(200);
    expect(sendTo.mock.calls.map((call) => call[2].text)).toEqual(['current', 'current']);
  });

  it('waits for outgoing capacity before reading another snapshot', async () => {
    let sent!: () => void;
    sendTo.mockImplementationOnce(() => new Promise<void>(resolve => { sent = resolve; }));
    watchBackgroundTaskOutput('conn', '/task.output', connections);
    await vi.advanceTimersByTimeAsync(0);
    for (let i = 0; i < 10; i++) {
      changed();
      await vi.advanceTimersByTimeAsync(200);
    }
    expect(loadBackgroundTaskOutput).toHaveBeenCalledOnce();
    expect(sendTo).toHaveBeenCalledOnce();
    sent();
    await vi.advanceTimersByTimeAsync(0);
    expect(loadBackgroundTaskOutput).toHaveBeenCalledTimes(2);
    expect(sendTo).toHaveBeenCalledTimes(2);
  });

  it('loads a short task that completed before its output file was created', async () => {
    vi.mocked(watch).mockImplementationOnce(() => { throw new Error('ENOENT'); });
    vi.mocked(loadBackgroundTaskOutput).mockResolvedValueOnce(update(''));
    watchBackgroundTaskOutput('conn', '/task.output', connections);
    await vi.advanceTimersByTimeAsync(500);

    expect(sendTo.mock.calls.map((call) => call[2].text)).toEqual(['', 'current']);
    expect(watch).toHaveBeenCalledTimes(2);
  });

  it('shares one file watcher and reader between viewers, with a snapshot for a late viewer', async () => {
    watchBackgroundTaskOutput('conn', '/task.output', connections);
    await vi.advanceTimersByTimeAsync(0);
    loadBackgroundTaskOutput.mockResolvedValue(undefined);
    watchBackgroundTaskOutput('other', '/task.output', connections);
    await vi.advanceTimersByTimeAsync(0);
    expect(watch).toHaveBeenCalledOnce();
    expect(sendTo.mock.calls.at(-1)?.slice(0, 1)).toEqual(['other']);
    expect(sendTo.mock.calls.at(-1)?.[2]).toMatchObject({ kind: 'snapshot', text: 'current' });
    unwatchAllForConnection('conn');
    loadBackgroundTaskOutput.mockResolvedValue({ kind: 'append', offset: 7, endOffset: 8, text: '!', truncated: false });
    changed(); await vi.advanceTimersByTimeAsync(200);
    expect(sendTo.mock.calls.at(-1)?.[2]).toMatchObject({ kind: 'append', text: '!', offset: 7 });
  });
});
