import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { prewarmClaudeProcess } from '../claude-process';
import { MessageType } from '../../shared';

/**
 * PREWARM_SESSION — the composer has a draft, so start the session's CLI now
 * and let the coming send skip the startup. Acknowledged before any work so
 * typing never waits on it; failures are only logged (the send reports them).
 */
export async function prewarmSessionHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  bridge: Bridge,
): Promise<void> {
  await connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId });
  const payload = message.payload ?? {};
  const sessionId = typeof payload.sessionId === 'string' ? payload.sessionId : '';
  const workingDir = typeof payload.workingDir === 'string' ? payload.workingDir : '';
  if (!sessionId || !workingDir) return;
  const inputMode = typeof payload.inputMode === 'string' ? payload.inputMode : undefined;
  const model = typeof payload.model === 'string' ? payload.model : undefined;
  try {
    const started = await prewarmClaudeProcess(connections, connectionId, workingDir, sessionId, inputMode, bridge, model);
    if (started) console.error('[node-backend]', `Prewarmed CLI for session ${sessionId}`);
  } catch (error) {
    console.error('[node-backend]', `Prewarm for session ${sessionId} failed:`, error instanceof Error ? error.message : error);
  }
}
