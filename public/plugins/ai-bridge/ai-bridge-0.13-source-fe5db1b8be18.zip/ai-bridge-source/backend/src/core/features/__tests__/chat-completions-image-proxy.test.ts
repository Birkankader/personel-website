import { createServer, request as httpRequest, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { chatCompletionsImageEnv, closeChatCompletionsImageProxy } from '../chat-completions-image-proxy';

type Seen = { method?: string; url?: string; headers: IncomingMessage['headers']; body: string };

let gateway: Server;
let seen: Seen[];
let answer: (req: IncomingMessage, res: ServerResponse, body: string) => void;

beforeEach(async () => {
  seen = [];
  answer = (_req, res) => res.end('{}');
  gateway = createServer(async (req, res) => {
    const chunks: Buffer[] = [];
    for await (const chunk of req) chunks.push(chunk as Buffer);
    const body = Buffer.concat(chunks).toString('utf8');
    seen.push({ method: req.method, url: req.url, headers: req.headers, body });
    answer(req, res, body);
  });
  await new Promise<void>(resolve => gateway.listen(0, '127.0.0.1', resolve));
});

afterEach(async () => {
  await closeChatCompletionsImageProxy();
  gateway.closeAllConnections();
  await new Promise<void>(resolve => gateway.close(() => resolve()));
});

const gatewayUrl = () => `http://127.0.0.1:${(gateway.address() as { port: number }).port}/gateway`;
const launch = async (models: string[] = ['glm-*']) => {
  const env = await chatCompletionsImageEnv(models, { ANTHROPIC_BASE_URL: `${gatewayUrl()}/` });
  expect(env).not.toBeNull();
  return env!.ANTHROPIC_BASE_URL;
};
const headers = { 'content-type': 'application/json', authorization: 'Bearer fixture-only-token', 'anthropic-version': '2023-06-01', 'anthropic-beta': 'x', 'x-office-tenant': 'dev' };
const imageMessage = (model: string, stream: boolean) => ({
  model, max_tokens: 64, stream,
  messages: [{ role: 'user', content: [{ type: 'image', source: { type: 'base64', media_type: 'image/png', data: 'iVBORw0K' } }, { type: 'text', text: 'Color?' }] }],
});

describe('chatCompletionsImageEnv', () => {
  it('applies only to a non-empty list and a gateway that is not Anthropic, Bedrock, Vertex or Foundry', async () => {
    const gatewayEnv = { ANTHROPIC_BASE_URL: 'https://gateway.example' };
    expect(await chatCompletionsImageEnv([], gatewayEnv)).toBeNull();
    expect(await chatCompletionsImageEnv(undefined, gatewayEnv)).toBeNull();
    expect(await chatCompletionsImageEnv(['glm-*'], {})).toBeNull();
    expect(await chatCompletionsImageEnv(['glm-*'], { ANTHROPIC_BASE_URL: 'https://api.anthropic.com/' })).toBeNull();
    expect(await chatCompletionsImageEnv(['glm-*'], { ANTHROPIC_BASE_URL: 'file:///etc' })).toBeNull();
    expect(await chatCompletionsImageEnv(['glm-*'], { ...gatewayEnv, CLAUDE_CODE_USE_BEDROCK: '1' })).toBeNull();
    const first = await chatCompletionsImageEnv(['glm-*'], gatewayEnv);
    expect(first?.ANTHROPIC_BASE_URL).toMatch(/^http:\/\/127\.0\.0\.1:\d+\/[0-9a-f]{32}$/);
    expect(first).not.toHaveProperty('NO_PROXY');
    expect(await chatCompletionsImageEnv(['glm-*'], { ...gatewayEnv, CLAUDE_CODE_USE_BEDROCK: '0' })).toEqual(first);
    expect((await chatCompletionsImageEnv(['other'], gatewayEnv))?.ANTHROPIC_BASE_URL).not.toBe(first?.ANTHROPIC_BASE_URL);
  });

  it('keeps an HTTP proxy away from 127.0.0.1', async () => {
    const env = await chatCompletionsImageEnv(['glm-*'], { ANTHROPIC_BASE_URL: 'https://gateway.example', HTTPS_PROXY: 'http://proxy:3128', NO_PROXY: '.corp' });
    expect(env).toMatchObject({ NO_PROXY: '.corp,127.0.0.1,localhost', no_proxy: '.corp,127.0.0.1,localhost' });
  });
});

describe('image proxy', () => {
  it('passes a request without an image through untouched, query and headers included', async () => {
    answer = (_req, res) => { res.writeHead(200, { 'content-type': 'text/event-stream', 'request-id': 'req_1' }); res.end('event: message_stop\ndata: {"type":"message_stop"}\n\n'); };
    const body = JSON.stringify({ model: 'GLM-5.3-Flash', stream: true, messages: [{ role: 'user', content: 'hi' }] });
    const response = await fetch(`${await launch()}/v1/messages?beta=true`, { method: 'POST', headers, body });
    expect(response.status).toBe(200);
    expect(response.headers.get('request-id')).toBe('req_1');
    expect(await response.text()).toBe('event: message_stop\ndata: {"type":"message_stop"}\n\n');
    expect(seen).toHaveLength(1);
    expect(seen[0]).toMatchObject({ method: 'POST', url: '/gateway/v1/messages?beta=true', body });
    expect(seen[0].headers).toMatchObject({ authorization: 'Bearer fixture-only-token', 'anthropic-version': '2023-06-01', 'x-office-tenant': 'dev' });
  });

  it('passes an image request through when its model is not listed', async () => {
    answer = (_req, res) => res.end('{"type":"message"}');
    await fetch(`${await launch(['glm-*'])}/v1/messages`, { method: 'POST', headers, body: JSON.stringify(imageMessage('claude-sonnet-4-5', false)) });
    expect(seen[0].url).toBe('/gateway/v1/messages');
  });

  it('sends a listed model\'s image request to /v1/chat/completions and streams the answer back as Messages events', async () => {
    answer = (_req, res) => {
      res.writeHead(200, { 'content-type': 'text/event-stream' });
      res.write('data: {"id":"chatcmpl-1","model":"GLM-5.3-Flash","choices":[{"delta":{"role":"assistant"}}]}\n\n');
      res.write('data: {"choices":[{"delta":{"content":"Gr"}}]}\r\n\r\ndata: {"choices":[{"delta":{"con');
      res.end('tent":"een"},"finish_reason":"stop"}]}\n\ndata: {"choices":[],"usage":{"prompt_tokens":90,"completion_tokens":2}}\n\ndata: [DONE]\n\n');
    };
    const response = await fetch(`${await launch(['GLM-5.3-flash'])}/v1/messages?beta=true`, { method: 'POST', headers, body: JSON.stringify(imageMessage('GLM-5.3-Flash', true)) });
    expect(response.headers.get('content-type')).toBe('text/event-stream');
    const text = await response.text();
    expect(seen[0].url).toBe('/gateway/v1/chat/completions');
    expect(seen[0].headers.authorization).toBe('Bearer fixture-only-token');
    expect(seen[0].headers['x-office-tenant']).toBe('dev');
    expect(seen[0].headers).not.toHaveProperty('anthropic-version');
    expect(JSON.parse(seen[0].body)).toEqual({
      model: 'GLM-5.3-Flash', max_tokens: 64, stream: true, stream_options: { include_usage: true },
      messages: [{ role: 'user', content: [{ type: 'image_url', image_url: { url: 'data:image/png;base64,iVBORw0K' } }, { type: 'text', text: 'Color?' }] }],
    });
    const deltas = text.split('\n').filter(line => line.startsWith('data: ')).map(line => JSON.parse(line.slice(6)));
    expect(deltas.map(e => e.type)).toEqual(['message_start', 'content_block_start', 'content_block_delta', 'content_block_delta', 'content_block_stop', 'message_delta', 'message_stop']);
    expect(deltas.filter(e => e.type === 'content_block_delta').map(e => e.delta.text).join('')).toBe('Green');
    expect(deltas[5]).toMatchObject({ delta: { stop_reason: 'end_turn' }, usage: { input_tokens: 90, output_tokens: 2 } });
  });

  it('answers a non-streaming image request with a Messages answer, and an x-api-key becomes a Bearer token', async () => {
    answer = (_req, res) => res.end(JSON.stringify({ id: 'chatcmpl-2', choices: [{ finish_reason: 'stop', message: { content: 'Green' } }], usage: { prompt_tokens: 5, completion_tokens: 1 } }));
    const response = await fetch(`${await launch()}/v1/messages`, {
      method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': 'fixture-key' }, body: JSON.stringify(imageMessage('glm-5.3-flash', false)),
    });
    expect(await response.json()).toMatchObject({ type: 'message', content: [{ type: 'text', text: 'Green' }], stop_reason: 'end_turn' });
    expect(seen[0].headers.authorization).toBe('Bearer fixture-key');
    expect(seen[0].headers).not.toHaveProperty('x-api-key');
  });

  it('returns a gateway error as a Messages error with its status and Retry-After', async () => {
    answer = (_req, res) => { res.writeHead(429, { 'content-type': 'application/json', 'retry-after': '20' }); res.end('{"error":{"message":"Per-minute rate limit exceeded."}}'); };
    const response = await fetch(`${await launch()}/v1/messages`, { method: 'POST', headers, body: JSON.stringify(imageMessage('glm-5.3-flash', true)) });
    expect(response.status).toBe(429);
    expect(response.headers.get('retry-after')).toBe('20');
    expect(await response.json()).toEqual({ type: 'error', error: { type: 'rate_limit_error', message: 'Per-minute rate limit exceeded.' } });
  });

  it('refuses unknown routes and foreign Host headers', async () => {
    const base = new URL(await launch());
    expect((await fetch(`${base.origin}/0123456789abcdef0123456789abcdef/v1/messages`, { method: 'POST', body: '{}' })).status).toBe(404);
    const status = await new Promise<number>((resolve, reject) => {
      const req = httpRequest({ host: '127.0.0.1', port: base.port, path: `${base.pathname}/v1/messages`, method: 'POST', headers: { host: 'evil.example' } }, (res) => { res.resume(); resolve(res.statusCode ?? 0); });
      req.on('error', reject);
      req.end('{}');
    });
    expect(status).toBe(403);
    expect(seen).toHaveLength(0);
  });
});
