import { execFileSync, type ChildProcess } from 'child_process';
import { mkdirSync, readdirSync, readFileSync, rmSync, writeFileSync } from 'fs';
import { homedir } from 'os';
import { basename, join } from 'path';
import { readWindowsProcessSnapshot, windowsSessionProcessIds, terminateWindowsTree, type WindowsProcessSnapshot } from './windows-processes';

/**
 * On-disk registry of live chat CLI processes.
 *
 * The process-group hard-binding covers every backend death that still runs
 * JS, but a hard SIGKILL of the backend bypasses all of it — the CLI survives as
 * an orphan, invisible to any later backend. This registry closes that loop: every chat CLI spawn writes a small
 * entry file, every clean CLI exit removes it, and a fresh backend can then
 * (a) sweep orphans at startup and (b) refuse/kill a conflicting live writer
 * before `--resume` (two CLIs appending to one session JSONL branch its history
 * and emit false task verdicts).
 *
 * Layout: one JSON file per CLI pid under ~/.ai-bridge/cli-registry/.
 * Per-entry files avoid read-modify-write races between concurrently running
 * backends (JetBrains mode legitimately runs one backend per project).
 *
 * PID reuse safety: a pid alone is not an identity. Before acting on an entry we
 * re-read the live process argv (`ps -o args=` on POSIX, the CommandLine of a
 * windows-processes.ts scan on win32) and require it to still contain the entry's
 * sessionId (the chat spawn always passes `--session-id <id>` or `--resume <id>`).
 * If the argv is unreadable (e.g. a failed scan) identity stays unknown and nothing
 * is auto-killed — the conservative fallback, never a reused pid casualty.
 */

export interface CliRegistryEntry {
  pid: number;
  sessionId: string;
  workingDir: string;
  startedAt: string;
  /** The backend that spawned the CLI; argv1 lets liveness checks survive pid reuse. */
  owner: { pid: number; argv1: string };
  /**
   * Ids of the MCP docker containers this CLI started, recorded shortly after
   * the spawn (see mcp-container-reclaimer).
   *
   * Present so a container survives the same hole this registry exists for: the
   * reclaim normally runs when the CLI exits, but a SIGKILLed backend never gets
   * to run it, and the container then belongs to nobody (#363). Written here
   * rather than derived at sweep time because by then there is no way to tell
   * which containers were this CLI's — Docker records nothing about who started
   * one, and a diff taken later would also catch containers a DIFFERENT live
   * CLI is still using.
   */
  mcpContainers?: string[];
}

function registryDir(): string {
  return join(homedir(), '.ai-bridge', 'cli-registry');
}

/**
 * A sessionId identifies a CLI by appearing in its command line, which is safe only
 * for a non-empty, simple token: an empty id is part of every command line and would
 * turn the orphan kill into a machine-wide taskkill. Claude session ids are simple
 * tokens (uuid-like, and the test fixtures use `sess-*`), so restrict to
 * [A-Za-z0-9._-]. Reject everything else — a malformed id means "match nothing".
 */
export function isValidSessionId(sessionId: string): boolean {
  return /^[A-Za-z0-9._-]+$/.test(sessionId);
}

/**
 * POSIX: live argv of [pid] as one string, or null when unknown (dead pid /
 * unreadable). win32 reads argv from a process scan instead (windowsOwnerAlive).
 */
function processArgs(pid: number): string | null {
  if (!Number.isInteger(pid) || pid <= 1) return null;
  try {
    return execFileSync('ps', ['-o', 'args=', '-p', String(pid)], { encoding: 'utf8' }).trim();
  } catch {
    return null; // ps exits non-zero for a dead pid
  }
}

function pidAlive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

/** Tree kill with plain-signal fallback — pid-based twin of Claude.killTree. */
function killPidTree(pid: number, signal: NodeJS.Signals): void {
  // process.kill(-0)/process.kill(-1) would signal our own (or every) process
  // group — in JetBrains mode that can include the IDE JVM. Never let a corrupt
  // or bogus registry pid reach the group signal.
  if (!Number.isInteger(pid) || pid <= 1) return;
  if (process.platform === 'win32') {
    // No process groups on win32; `taskkill /T` walks the child tree, `/F` forces.
    // `signal` is irrelevant here (taskkill always terminates) — both the SIGTERM
    // and the escalated SIGKILL caller in killRegisteredCli map to the same tree
    // kill. That collapses the grace ladder to an immediate hard kill, which is
    // correct for an orphan (its owning backend is already gone). taskkill on an
    // already-dead pid exits non-zero and is swallowed by the catch.
    try {
      execFileSync('taskkill', ['/F', '/T', '/PID', String(pid)], { windowsHide: true });
    } catch {
      // Already gone or not killable — ignore
    }
    return;
  }
  try {
    process.kill(-pid, signal);
  } catch {
    try {
      process.kill(pid, signal);
    } catch {
      // Already gone
    }
  }
}

const delay = (ms: number) => new Promise<void>((resolve) => setTimeout(resolve, ms));

export function registerCliProcess(proc: ChildProcess, sessionId: string, workingDir: string): void {
  if (!proc.pid) return;
  const entry: CliRegistryEntry = {
    pid: proc.pid,
    sessionId,
    workingDir,
    startedAt: new Date().toISOString(),
    owner: { pid: process.pid, argv1: process.argv[1] ?? '' },
  };
  try {
    mkdirSync(registryDir(), { recursive: true });
    writeFileSync(join(registryDir(), `${proc.pid}.json`), JSON.stringify(entry, null, 2) + '\n');
  } catch (err) {
    // Best-effort: a failed registry write must never block the chat itself.
    console.error('[node-backend]', 'CLI registry write failed:', err);
  }
}

/**
 * Attach the ids of the MCP containers a registered CLI started.
 *
 * A no-op when the pid has no entry, which is how short-lived CLIs (`--version`,
 * `auth status`, the `mcp` commands) opt out: they are not registered, and they
 * finish long before a backend could be killed mid-flight.
 *
 * Merges rather than replaces, so a second observation can add a server that was
 * slower to start without dropping the first.
 */
export function recordCliContainers(pid: number | undefined, ids: string[]): void {
  if (!pid || ids.length === 0) return;
  const file = join(registryDir(), `${pid}.json`);
  try {
    const entry = JSON.parse(readFileSync(file, 'utf-8')) as CliRegistryEntry;
    const merged = [...new Set([...(entry.mcpContainers ?? []), ...ids])];
    if (merged.length === (entry.mcpContainers?.length ?? 0)) return;
    writeFileSync(file, JSON.stringify({ ...entry, mcpContainers: merged }, null, 2) + '\n');
  } catch {
    // No entry (unregistered CLI) or a racing removal — nothing to attach to.
  }
}

export function unregisterCliProcess(pid: number | undefined): void {
  if (!pid) return;
  try {
    rmSync(join(registryDir(), `${pid}.json`), { force: true });
  } catch (err) {
    console.error('[node-backend]', 'CLI registry remove failed:', err);
  }
}

function readEntries(): CliRegistryEntry[] {
  let files: string[];
  try {
    files = readdirSync(registryDir()).filter((f) => f.endsWith('.json'));
  } catch {
    return []; // No registry dir yet — clean world
  }
  const entries: CliRegistryEntry[] = [];
  for (const file of files) {
    try {
      const parsed = JSON.parse(readFileSync(join(registryDir(), file), 'utf8')) as CliRegistryEntry;
      if (Number.isInteger(parsed.pid) && parsed.pid > 1 && typeof parsed.sessionId === 'string' && parsed.owner) {
        entries.push(parsed);
      } else {
        rmSync(join(registryDir(), file), { force: true });
      }
    } catch {
      rmSync(join(registryDir(), file), { force: true }); // Corrupt entry — drop it
    }
  }
  return entries;
}

/**
 * POSIX identity-checked liveness of an entry's CLI:
 * 'live' — the stored pid still carries the sessionId;
 * 'dead' — the pid is gone, or was reused by an unrelated process.
 *
 * POSIX spawns the CLI directly (no shell) and detached, so the stored pid IS the
 * CLI — argv identity on that pid is exact. A transient argv-read failure resolves
 * to 'dead' (GC the record) rather than risk killing a reused pid. win32 decides
 * from a process scan instead (findLiveCliForSession, the sweep).
 */
function cliState(entry: CliRegistryEntry): 'live' | 'dead' {
  // A malformed sessionId can never identify a live CLI: on POSIX an empty id makes
  // `args.includes('')` always true, mis-declaring an unrelated pid 'live'. Treat any
  // invalid entry as dead so it gets garbage-collected instead of falsely resurrected.
  if (!isValidSessionId(entry.sessionId)) return 'dead';
  if (!pidAlive(entry.pid)) return 'dead';
  const args = processArgs(entry.pid);
  if (args === null) return 'dead';
  return args.includes(entry.sessionId) ? 'live' : 'dead';
}

/**
 * Is the backend that spawned this CLI still alive (and not us)? Conservative on
 * ambiguity: when the owner pid is alive but its argv is unreadable, assume alive
 * — never kill a CLI that might belong to a living backend.
 */
function ownerAlive(entry: CliRegistryEntry): boolean {
  if (entry.owner.pid === process.pid) return false; // our own stale record
  if (!pidAlive(entry.owner.pid)) return false;
  const args = processArgs(entry.owner.pid);
  if (args === null) return true;
  const hint = basename(entry.owner.argv1 || '');
  return hint === '' || args.includes(hint);
}

export interface CliConflict {
  entry: CliRegistryEntry;
  ownerAlive: boolean;
}

/**
 * A live, identity-checked CLI already attached to [sessionId], if any.
 * Cleans up dead entries it encounters along the way.
 *
 * win32 keys on the session id across ALL live processes, not the stored pid: that
 * pid is the cmd.exe shell (win32 needs a shell to resolve the `.cmd`/`.ps1`
 * launcher), which dies with the backend while the real `claude` grandchild orphans
 * on. Both carry the id in `--session-id`/`--resume`, so matching on it finds the
 * survivor. One process scan answers that and the owner check for every entry, as in
 * the startup sweep. A failed scan finds no carrier, so the entries are collected as
 * dead, as a failed argv read is on POSIX.
 */
export async function findLiveCliForSession(sessionId: string): Promise<CliConflict | null> {
  const entries = readEntries().filter((entry) => entry.sessionId === sessionId);
  if (process.platform === 'win32' && entries.length > 0) {
    const snapshot = (await readWindowsProcessSnapshot()) ?? new Map();
    for (const entry of entries) {
      if (windowsSessionProcessIds(snapshot, entry.sessionId).length === 0) {
        unregisterCliProcess(entry.pid);
        continue;
      }
      return { entry, ownerAlive: windowsOwnerAlive(entry, snapshot) };
    }
    return null;
  }
  for (const entry of entries) {
    const state = cliState(entry);
    if (state === 'dead') {
      unregisterCliProcess(entry.pid);
      continue;
    }
    return { entry, ownerAlive: ownerAlive(entry) };
  }
  return null;
}

function windowsOwnerAlive(entry: CliRegistryEntry, snapshot: WindowsProcessSnapshot): boolean {
  if (entry.owner.pid === process.pid || !pidAlive(entry.owner.pid)) return false;
  const args = snapshot.get(entry.owner.pid);
  if (!args) return true;
  const hint = basename(entry.owner.argv1 || '');
  return hint === '' || args.includes(hint);
}

async function killWindowsRegistryEntry(entry: CliRegistryEntry): Promise<boolean> {
  // Refresh identity immediately before termination. A snapshot used to classify
  // earlier entries is not sufficient evidence to kill a potentially reused PID.
  const fresh = await readWindowsProcessSnapshot();
  if (!fresh || windowsOwnerAlive(entry, fresh)) return false;
  const pids = windowsSessionProcessIds(fresh, entry.sessionId);
  if (pids.length === 0 && pidAlive(entry.pid) && !fresh.get(entry.pid)) return false;
  for (const [index, pid] of pids.entries()) {
    if (index > 0) {
      // /T can already terminate the later children in this list. During its
      // asynchronous completion their PIDs may be reused by unrelated apps.
      // Recheck each remaining identity before acting on that numeric PID.
      const latest = await readWindowsProcessSnapshot();
      if (!latest || windowsOwnerAlive(entry, latest)) return false;
      if (!windowsSessionProcessIds(latest, entry.sessionId).includes(pid)) {
        if (pidAlive(pid) && !latest.get(pid)) return false;
        continue;
      }
    }
    if (!(await terminateWindowsTree(pid))) return false;
  }
  unregisterCliProcess(entry.pid);
  return true;
}

/** SIGTERM the entry's process group, escalate to SIGKILL after [graceMs]. */
export async function killRegisteredCli(entry: CliRegistryEntry, graceMs = 3_000): Promise<void> {
  if (process.platform === 'win32') {
    if (!(await killWindowsRegistryEntry(entry))) {
      throw new Error('Could not verify termination of the previous Claude process; refusing a second writer.');
    }
    return;
  }
  killPidTree(entry.pid, 'SIGTERM');
  const deadline = Date.now() + graceMs;
  while (Date.now() < deadline && cliState(entry) === 'live') {
    await delay(100);
  }
  if (cliState(entry) === 'live') {
    console.error('[node-backend]', `Orphaned CLI ${entry.pid} ignored SIGTERM — escalating to SIGKILL`);
    killPidTree(entry.pid, 'SIGKILL');
  }
  unregisterCliProcess(entry.pid);
}

/**
 * Startup orphan sweep: kill every registered CLI whose owning backend is gone.
 * Entries owned by other LIVE backends are left alone (multi-backend setups are
 * legitimate); dead/reused entries are garbage-collected.
 */
export async function sweepOrphanCliProcesses(): Promise<{
  killed: number;
  skipped: number;
  /**
   * MCP containers belonging to CLIs that are gone by the end of this sweep.
   *
   * Returned rather than removed here so this module stays free of any docker
   * knowledge; the caller hands them to the reclaimer. Entries owned by a LIVE
   * backend are skipped, exactly as their processes are, so a container another
   * backend's session is still using is never listed.
   */
  mcpContainers: string[];
}> {
  let killed = 0;
  let skipped = 0;
  const mcpContainers: string[] = [];
  const entries = readEntries();
  if (process.platform === 'win32' && entries.length > 0) {
    const snapshot = await readWindowsProcessSnapshot();
    // Unknown identity must not erase records or trigger orphan cleanup.
    if (!snapshot) return { killed: 0, skipped: entries.length, mcpContainers: [] };
    for (const entry of entries) {
      const pids = windowsSessionProcessIds(snapshot, entry.sessionId);
      if (pids.length === 0) {
        if (pidAlive(entry.pid) && !snapshot.get(entry.pid)) { skipped++; continue; }
        mcpContainers.push(...(entry.mcpContainers ?? []));
        unregisterCliProcess(entry.pid);
      } else if (windowsOwnerAlive(entry, snapshot)) {
        skipped++;
      } else if (await killWindowsRegistryEntry(entry)) {
        mcpContainers.push(...(entry.mcpContainers ?? []));
        killed++;
      } else {
        skipped++;
      }
    }
    return { killed, skipped, mcpContainers: [...new Set(mcpContainers)] };
  }
  for (const entry of entries) {
    const state = cliState(entry);
    if (state === 'dead') {
      // The CLI is gone, so whatever it started is unreachable — collect it even
      // though nothing needs killing.
      mcpContainers.push(...(entry.mcpContainers ?? []));
      unregisterCliProcess(entry.pid);
      continue;
    }
    if (ownerAlive(entry)) {
      skipped++;
      continue;
    }
    mcpContainers.push(...(entry.mcpContainers ?? []));
    console.error(
      '[node-backend]',
      `Orphan sweep: killing orphaned CLI ${entry.pid} (session ${entry.sessionId}, dead owner ${entry.owner.pid})`,
    );
    await killRegisteredCli(entry);
    killed++;
  }
  if (killed > 0 || skipped > 0) {
    console.error('[node-backend]', `Orphan sweep done: killed ${killed}, skipped ${skipped}`);
  }
  return { killed, skipped, mcpContainers: [...new Set(mcpContainers)] };
}
