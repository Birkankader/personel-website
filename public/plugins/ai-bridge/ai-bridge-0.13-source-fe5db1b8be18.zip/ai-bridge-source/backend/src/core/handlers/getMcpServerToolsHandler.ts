import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { MessageType } from '../../shared';
import type { McpServerConfig, McpServerTool } from '../../shared';
import { fetchServerTools, isMcpAuthError } from '../features/mcp-tools';
import { fetchMcpStatus } from '../features/mcp-status';

/**
 * GET_MCP_SERVER_TOOLS — the tool list of one MCP server, for the detail view.
 *
 * Two sources, in this order:
 *
 * 1. A LIVE CLI for the same workspace. Its `mcp_status` reply already carries
 *    each server's `tools`, so asking it is both the cheapest answer and the
 *    only one that is authenticated: the CLI holds the OAuth token it stored at
 *    `claude mcp login` and refreshes it itself. This sits inside the recorded
 *    `mcp_status` exception (#363): it asks a CLI that is already running and
 *    nothing is spawned on this path.
 * 2. Otherwise, our own MCP SDK connection (`tools/list`), which is the
 *    CLI-equivalent for a server nobody has a running CLI for. `config` comes
 *    along because the WebView already holds it from the list, so there is no
 *    need to re-run `claude mcp get`.
 *
 * The second source cannot sign in. It sends only `config.headers`, so an
 * OAuth-protected server answers 401 and the detail view used to report that as
 * the generic "Couldn't load tools" — a real failure message for a state that is
 * not a failure. We do not read the CLI's credential store to fix that (that
 * would mean depending on an undocumented format, and reimplementing refresh),
 * so the ACK names the situation instead: `status: 'needs-auth'` tells the
 * WebView to explain that the sign-in belongs to the Claude CLI and the tools
 * appear once a chat is open. Every other error keeps `status: 'error'` and its
 * message.
 *
 * `workingDir` decides which project-scope config files define the environment
 * the server is spawned with, which values its `${VAR}` placeholders resolve to,
 * and which running CLI holds the matching session.
 */
export async function getMcpServerToolsHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const payload = message.payload as {
    name?: string;
    config?: McpServerConfig | null;
    workingDir?: string;
  };
  const config = payload?.config ?? null;
  const name = payload?.name;
  const workingDir = payload?.workingDir;

  const liveTools = name ? await toolsFromLiveCli(connections, workingDir, name) : null;
  if (liveTools) {
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'ok',
      tools: liveTools,
    });
    return;
  }

  try {
    const tools = await fetchServerTools(config, workingDir);
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'ok',
      tools,
    });
  } catch (err) {
    const error = err instanceof Error ? err.message : String(err);
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      // Not an error the user can retry away: the sign-in lives with the CLI.
      status: isMcpAuthError(err) ? 'needs-auth' : 'error',
      error,
    });
  }
}

/**
 * The tools a running CLI already reported for `name`, or null when there is no
 * live CLI, it did not answer, or it does not know a tool list for this server.
 *
 * An empty array is a real answer ("asked, this server exposes none") and is
 * returned as such; only a missing list means "ask the server yourself". Null is
 * also what every failure yields, so the SDK path stays the guaranteed route.
 */
async function toolsFromLiveCli(
  connections: ConnectionManager,
  workingDir: string | undefined,
  name: string,
): Promise<McpServerTool[] | null> {
  const entries = await fetchMcpStatus(connections, workingDir);
  const entry = entries?.find((candidate) => candidate.name === name);
  return Array.isArray(entry?.tools) ? entry.tools : null;
}
