import { connectionSettingsHandler } from './connectionSettings';
import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { ClientEnv, MessageType } from '../../shared';
import { Claude } from '../claude';
import { sendMessageHandler } from './sendMessage';
import { runtimeResourcesHandler } from './runtimeResources';
import { stopSessionHandler } from './stopSession';
import { sendControlRequestHandler } from './sendControlRequest';
import { prewarmSessionHandler } from './prewarmSession';
import { toolResponseHandler } from './toolResponse';
import { getSessionsHandler } from './getSessions';
import { loadSessionHandler } from './loadSession';
import { loadPromptHistoryHandler } from './loadPromptHistory';
import { deleteSessionHandler } from './deleteSession';
import { rewindCodeHandler } from './rewindCode';
import { forkSessionHandler } from './forkSession';
import { renameSessionHandler } from './renameSession';
import { getAgentTranscriptHandler } from './getAgentTranscript';
import { watchBackgroundTaskOutputHandler, unwatchBackgroundTaskOutputHandler } from './watchBackgroundTaskOutput';
import { getSettingsHandler } from './getSettings';
import { saveSettingsHandler } from './saveSettings';
import { getClaudeConfigDirHandler } from './getClaudeConfigDir';
import { saveClaudeConfigDirHandler } from './saveClaudeConfigDir';
import { conversationToolsHandler } from './conversationTools';
import { getProjectsHandler } from './getProjects';
import { setProjectFavoriteHandler } from './projectFavorite';
import { deleteProjectHandler } from './deleteProject';
import { setProjectMetaHandler } from './projectMeta';
import { openFileHandler } from './openFile';
import { openDiffHandler } from './openDiff';
import { openDiffTabHandler } from './openDiffTab';
import { getDiffPreviewHandler } from './getDiffPreview';
import { resolveDiffHandler } from './resolveDiff';
import { refreshDiffPreviewHandler } from './refreshDiffPreview';
import { createSessionHandler } from './createSession';
import { openNewTabHandler } from './openNewTab';
import { openSessionHandler } from './openSession';
import { setTabNameHandler } from './setTabName';
import { openSettingsHandler } from './openSettings';
import { restartBackendHandler } from './restartBackend';
import { openTerminalHandler } from './openTerminal';
import { openDevToolsHandler } from './openDevTools';
import { getVersionHandler } from './getVersion';
import { getCliUpdateInfoHandler } from './getCliUpdateInfo';
import { updateCliHandler } from './updateCli';
import { reclaimSessionHandler } from './reclaimSession';
import {
  scheduleMessageHandler,
  cancelScheduledMessageHandler,
  updateScheduledMessageHandler,
  getScheduledMessagesHandler,
  scheduledMessageDeliveredHandler,
} from './scheduleMessage';
import { openUrlHandler } from './openUrl';
import { getAvailableTerminalsHandler } from './getAvailableTerminals';
import { getAvailableEditorsHandler } from './getAvailableEditors';
import { getDetectedCliPathHandler } from './getDetectedCliPath';
import { getDetectedNodePathHandler } from './getDetectedNodePath';
import { pickFilesHandler } from './pickFiles';
import { nativeDropFlushHandler } from './nativeDropFlush';
import { getClaudeSettingsHandler } from './getClaudeSettings';
import { saveClaudeSettingsHandler } from './saveClaudeSettings';
import { setModelHandler } from './setModel';
import { setPermissionModeHandler } from './setPermissionMode';
import { probeFableAvailabilityHandler } from './probeFableAvailability';
import { getIdeRootHandler } from './getIdeRoot';
import { getHarnessStatusHandler } from './getHarnessStatus';
import { installHarnessHandler } from './installHarness';
import { listProjectFilesHandler } from './listProjectFiles';
import { getCliConfigHandler } from './getCliConfig';
import { openFolderDialogHandler } from './openFolderDialog';
import { findBackgroundTaskOutputPathHandler } from './findBackgroundTaskOutputPathHandler';
import { listSystemSoundsHandler } from './listSystemSounds';
import { playSystemSoundHandler } from './playSystemSound';
import { clientInfoHandler } from './clientInfo';
import { clientErrorHandler } from './clientError';
import { panelFocusedHandler } from './panelFocused';
import { getMcpServersHandler } from './getMcpServersHandler';
import { getMcpServerToolsHandler } from './getMcpServerToolsHandler';
import {
  reconnectMcpServerHandler,
  authenticateMcpServerHandler,
  cancelMcpServerAuthenticationHandler,
  clearMcpServerAuthHandler,
  setMcpServerEnabledHandler,
  submitMcpOauthCallbackUrlHandler,
  addMcpServerHandler,
  removeMcpServerHandler,
  searchMcpRegistryHandler,
} from './mcpActionsHandler';

export async function handleMessage(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  bridge: Bridge,
  bridges: Record<ClientEnv, Bridge>,
): Promise<void> {
  console.error('[node-backend]', `Received: ${message.type}`);

  // Project the active context's CLAUDE_CONFIG_DIR onto process.env up front, so every
  // handler that reads Claude data (sessions, projects) or spawns a child (claude/ccb)
  // resolves the right profile for this workingDir. Messages without a workingDir leave
  // the current context untouched — the project picker (getProjects) sets global itself,
  // and usage/account intentionally keep whatever context is already active. (#123)
  const ctxWorkingDir = (message.payload as { workingDir?: string } | undefined)?.workingDir;
  if (ctxWorkingDir) await Claude.applyConfigDir(ctxWorkingDir);

  switch (message.type) {
    case MessageType.GET_WINDOWS_USER_ENV:
    case MessageType.SAVE_WINDOWS_USER_ENV:
    case MessageType.TEST_CONNECTION:
      await connectionSettingsHandler(connectionId, message, connections);
      break;
    case MessageType.GET_RUNTIME_RESOURCES:
    case MessageType.GET_RUNTIME_TASKS:
    case MessageType.SET_TASK_CONCURRENCY:
    case MessageType.STEER_QUEUED_TASK:
    case MessageType.REORDER_QUEUED_TASKS:
    case MessageType.MERGE_QUEUED_TASKS:
    case MessageType.CANCEL_QUEUED_TASK:
    case MessageType.STOP_RUNTIME_TASK:
      await runtimeResourcesHandler(connectionId, message, connections);
      break;
    case MessageType.SEND_MESSAGE:
      await sendMessageHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.STOP_SESSION:
      await stopSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.PREWARM_SESSION:
      await prewarmSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.TOOL_RESPONSE:
      await toolResponseHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SEND_CONTROL_REQUEST:
      await sendControlRequestHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_SESSIONS:
      await getSessionsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.LOAD_SESSION:
    case MessageType.LOAD_OLDER_MESSAGES:
      await loadSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.LOAD_PROMPT_HISTORY:
      await loadPromptHistoryHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.DELETE_SESSION:
      await deleteSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.REWIND_CODE:
      await rewindCodeHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.FORK_SESSION:
      await forkSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.RENAME_SESSION:
      await renameSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_AGENT_TRANSCRIPT:
      await getAgentTranscriptHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.WATCH_BACKGROUND_TASK_OUTPUT:
      watchBackgroundTaskOutputHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.UNWATCH_BACKGROUND_TASK_OUTPUT:
      unwatchBackgroundTaskOutputHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_SETTINGS:
      await getSettingsHandler(connectionId, message, connections, bridge, bridges);
      break;
    case MessageType.SAVE_SETTINGS:
      await saveSettingsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_CLAUDE_CONFIG_DIR:
      await getClaudeConfigDirHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SAVE_CLAUDE_CONFIG_DIR:
      await saveClaudeConfigDirHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SEARCH_CONVERSATIONS:
    case MessageType.CANCEL_CONVERSATION_SEARCH:
    case MessageType.GET_CONVERSATION_ANNOTATIONS:
    case MessageType.SAVE_CONVERSATION_ANNOTATION:
      await conversationToolsHandler(connectionId, message, connections);
      break;
    case MessageType.GET_PROJECTS:
      await getProjectsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_PROJECT_FAVORITE:
      await setProjectFavoriteHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.DELETE_PROJECT:
      await deleteProjectHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_PROJECT_META:
      await setProjectMetaHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_FILE:
      await openFileHandler(connectionId, message, connections, bridge, bridges);
      break;
    case MessageType.OPEN_DIFF:
      await openDiffHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_DIFF_TAB:
      await openDiffTabHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_DIFF_PREVIEW:
      await getDiffPreviewHandler(connectionId, message, connections);
      break;
    case MessageType.RESOLVE_DIFF:
      await resolveDiffHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.REFRESH_DIFF_PREVIEW:
      await refreshDiffPreviewHandler(connectionId, message, connections);
      break;
    case MessageType.CREATE_SESSION:
      await createSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_NEW_TAB:
      await openNewTabHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_SESSION:
      await openSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_TAB_NAME:
      await setTabNameHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_SETTINGS:
      await openSettingsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.RESTART_BACKEND:
      await restartBackendHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_TERMINAL:
      await openTerminalHandler(connectionId, message, connections, bridge);
      break;

    case MessageType.OPEN_DEV_TOOLS:
      await openDevToolsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_VERSION:
      await getVersionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_CLI_UPDATE_INFO:
      await getCliUpdateInfoHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.UPDATE_CLI:
      await updateCliHandler(connectionId, message, connections, bridge);
      break;

    case MessageType.RECLAIM_SESSION:
      await reclaimSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SCHEDULE_MESSAGE:
      await scheduleMessageHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.CANCEL_SCHEDULED_MESSAGE:
      await cancelScheduledMessageHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.UPDATE_SCHEDULED_MESSAGE:
      await updateScheduledMessageHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_SCHEDULED_MESSAGES:
      await getScheduledMessagesHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SCHEDULED_MESSAGE_DELIVERED:
      await scheduledMessageDeliveredHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_URL:
      await openUrlHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_AVAILABLE_TERMINALS:
      await getAvailableTerminalsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_AVAILABLE_EDITORS:
      await getAvailableEditorsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_DETECTED_CLI_PATH:
      await getDetectedCliPathHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_DETECTED_NODE_PATH:
      await getDetectedNodePathHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.PICK_FILES:
      await pickFilesHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.NATIVE_DROP_FLUSH:
      await nativeDropFlushHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_CLAUDE_SETTINGS:
      await getClaudeSettingsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SAVE_CLAUDE_SETTINGS:
      await saveClaudeSettingsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_MODEL:
      await setModelHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_PERMISSION_MODE:
      await setPermissionModeHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.PROBE_FABLE_AVAILABILITY:
      await probeFableAvailabilityHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_IDE_ROOT:
      await getIdeRootHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_HARNESS_STATUS:
      await getHarnessStatusHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.INSTALL_HARNESS:
      await installHarnessHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.LIST_PROJECT_FILES:
      await listProjectFilesHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_CLI_CONFIG:
      await getCliConfigHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_FOLDER_DIALOG:
      await openFolderDialogHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.FIND_BG_TASK_OUTPUT_PATH:
      await findBackgroundTaskOutputPathHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.LIST_SYSTEM_SOUNDS:
      await listSystemSoundsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.PLAY_SYSTEM_SOUND:
      await playSystemSoundHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.CLIENT_INFO:
      clientInfoHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.CLIENT_ERROR:
      clientErrorHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.PANEL_FOCUSED:
      panelFocusedHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_MCP_SERVERS:
      await getMcpServersHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.RECONNECT_MCP_SERVER:
      await reconnectMcpServerHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.AUTHENTICATE_MCP_SERVER:
      await authenticateMcpServerHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.CANCEL_MCP_SERVER_AUTHENTICATION:
      await cancelMcpServerAuthenticationHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.CLEAR_MCP_SERVER_AUTH:
      await clearMcpServerAuthHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_MCP_SERVER_ENABLED:
      await setMcpServerEnabledHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SUBMIT_MCP_OAUTH_CALLBACK_URL:
      await submitMcpOauthCallbackUrlHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.ADD_MCP_SERVER:
      await addMcpServerHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.REMOVE_MCP_SERVER:
      await removeMcpServerHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SEARCH_MCP_REGISTRY:
      await searchMcpRegistryHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_MCP_SERVER_TOOLS:
      await getMcpServerToolsHandler(connectionId, message, connections, bridge);
      break;
    default:
      console.error('[node-backend]', `Unknown message type: ${message.type}`);
      // Error-ACK contract: a request (it carries a requestId) always gets an
      // answer, so a type this backend does not handle rejects at once on the
      // webview instead of timing out there. Fire-and-forget messages only log.
      if (message.requestId) {
        await connections.sendTo(connectionId, MessageType.ERROR, {
          requestId: message.requestId,
          error: `Unknown message type: ${message.type}`,
        });
      }
  }
}
