import { describe, expect, it } from 'vitest';
import { hasImage, MessagesEventStream, toChatCompletionsRequest, toMessagesError, toMessagesResponse } from '../chat-completions-translate';

const png = { type: 'image', source: { type: 'base64', media_type: 'image/png', data: 'iVBORw0K' } };

type StreamEvent = {
  type: string;
  index?: number;
  message?: Record<string, unknown>;
  content_block?: Record<string, unknown>;
  delta: { type?: string; text?: string; partial_json?: string; stop_reason?: string };
  usage?: Record<string, number>;
  error?: Record<string, string>;
};

/** The parsed events of an SSE text. */
function events(sse: string): StreamEvent[] {
  return sse.split('\n\n').filter(Boolean).map((frame) => {
    const [eventLine, dataLine] = frame.split('\n');
    const data = JSON.parse(dataLine.slice('data: '.length)) as StreamEvent;
    expect(eventLine).toBe(`event: ${data.type}`);
    return data;
  });
}

describe('hasImage', () => {
  it('finds images in a message and inside a tool result, and nothing in text', () => {
    expect(hasImage({ messages: [{ role: 'user', content: [{ type: 'text', text: 'hi' }, png] }] })).toBe(true);
    expect(hasImage({ messages: [{ role: 'user', content: [{ type: 'tool_result', tool_use_id: 't1', content: [png] }] }] })).toBe(true);
    expect(hasImage({ messages: [{ role: 'user', content: 'hi' }, { role: 'assistant', content: [{ type: 'text', text: 'yo' }] }] })).toBe(false);
    expect(hasImage({})).toBe(false);
  });
});

describe('toChatCompletionsRequest', () => {
  it('translates a whole tool-using conversation with images', () => {
    const request = toChatCompletionsRequest({
      model: 'GLM-5.3-Flash',
      max_tokens: 32000,
      temperature: 1,
      stream: true,
      stop_sequences: ['END'],
      thinking: { type: 'enabled', budget_tokens: 1024 },
      metadata: { user_id: 'u' },
      system: [{ type: 'text', text: 'You are Claude Code.' }, { type: 'text', text: 'Be brief.', cache_control: { type: 'ephemeral' } }],
      tools: [
        { name: 'Read', description: 'Read a file', input_schema: { type: 'object', properties: { file_path: { type: 'string' } } } },
        { type: 'web_search_20250305', name: 'web_search' },
      ],
      tool_choice: { type: 'any', disable_parallel_tool_use: true },
      messages: [
        { role: 'user', content: [{ type: 'text', text: 'What is in this picture?' }, png] },
        { role: 'assistant', content: [
          { type: 'thinking', thinking: 'hmm', signature: 'sig' },
          { type: 'text', text: 'Let me read the screenshot.' },
          { type: 'tool_use', id: 'call_1', name: 'Read', input: { file_path: 'a.png' } },
        ] },
        { role: 'user', content: [
          { type: 'tool_result', tool_use_id: 'call_1', content: [{ type: 'image', source: { type: 'url', url: 'https://example.com/a.png' } }] },
          { type: 'text', text: '<system-reminder>ok</system-reminder>' },
        ] },
      ],
    });
    expect(request).toEqual({
      model: 'GLM-5.3-Flash',
      max_tokens: 32000,
      temperature: 1,
      stop: ['END'],
      stream: true,
      stream_options: { include_usage: true },
      tools: [{ type: 'function', function: { name: 'Read', description: 'Read a file', parameters: { type: 'object', properties: { file_path: { type: 'string' } } } } }],
      tool_choice: 'required',
      parallel_tool_calls: false,
      messages: [
        { role: 'system', content: 'You are Claude Code.\n\nBe brief.' },
        { role: 'user', content: [{ type: 'text', text: 'What is in this picture?' }, { type: 'image_url', image_url: { url: 'data:image/png;base64,iVBORw0K' } }] },
        { role: 'assistant', content: 'Let me read the screenshot.', tool_calls: [{ id: 'call_1', type: 'function', function: { name: 'Read', arguments: '{"file_path":"a.png"}' } }] },
        { role: 'tool', tool_call_id: 'call_1', content: '(an image, attached below)' },
        { role: 'user', content: [
          { type: 'text', text: 'Images from the tool results above:' },
          { type: 'image_url', image_url: { url: 'https://example.com/a.png' } },
          { type: 'text', text: '<system-reminder>ok</system-reminder>' },
        ] },
      ],
    });
  });

  it('keeps string contents, text tool results and tool calls without text', () => {
    const request = toChatCompletionsRequest({
      model: 'm', system: 'Be brief.',
      tools: [{ name: 'Bash', input_schema: { type: 'object' } }], tool_choice: { type: 'tool', name: 'Bash' },
      messages: [
        { role: 'user', content: 'run ls' },
        { role: 'assistant', content: [{ type: 'tool_use', id: 't', name: 'Bash', input: { command: 'ls' } }] },
        { role: 'user', content: [{ type: 'tool_result', tool_use_id: 't', content: 'a.txt' }, { type: 'tool_result', tool_use_id: 'u', content: [{ type: 'text', text: 'x' }, { type: 'text', text: 'y' }] }] },
      ],
    });
    expect(request.messages).toEqual([
      { role: 'system', content: 'Be brief.' },
      { role: 'user', content: 'run ls' },
      { role: 'assistant', content: null, tool_calls: [{ id: 't', type: 'function', function: { name: 'Bash', arguments: '{"command":"ls"}' } }] },
      { role: 'tool', tool_call_id: 't', content: 'a.txt' },
      { role: 'tool', tool_call_id: 'u', content: 'x\ny' },
    ]);
    expect(request.tool_choice).toEqual({ type: 'function', function: { name: 'Bash' } });
    expect(request).not.toHaveProperty('stream');
  });
});

describe('toMessagesResponse', () => {
  it('turns text, tool calls and usage into a Messages answer', () => {
    const answer = toMessagesResponse({
      id: 'chatcmpl-1', model: 'GLM-5.3-Flash',
      choices: [{ finish_reason: 'tool_calls', message: { role: 'assistant', content: 'Reading.', reasoning_content: 'private', tool_calls: [
        { id: 'call_9', type: 'function', function: { name: 'Read', arguments: '{"file_path":"b.ts"}' } },
        { id: 'call_10', type: 'function', function: { name: 'Glob', arguments: 'not json' } },
      ] } }],
      usage: { prompt_tokens: 120, completion_tokens: 7 },
    }, 'fallback');
    expect(answer).toEqual({
      id: 'msg_chatcmpl-1', type: 'message', role: 'assistant', model: 'GLM-5.3-Flash',
      content: [
        { type: 'text', text: 'Reading.' },
        { type: 'tool_use', id: 'call_9', name: 'Read', input: { file_path: 'b.ts' } },
        { type: 'tool_use', id: 'call_10', name: 'Glob', input: {} },
      ],
      stop_reason: 'tool_use', stop_sequence: null, usage: { input_tokens: 120, output_tokens: 7 },
    });
  });

  it.each([['stop', 'end_turn'], ['length', 'max_tokens'], ['content_filter', 'end_turn']])('maps finish_reason %s to %s', (finish, stop) => {
    expect(toMessagesResponse({ choices: [{ finish_reason: finish, message: { content: 'x' } }] }, 'm').stop_reason).toBe(stop);
  });
});

describe('MessagesEventStream', () => {
  it('streams text as it comes and sends interleaved tool calls whole at the end', () => {
    const stream = new MessagesEventStream('GLM-5.3-Flash');
    const lines = [
      'data: {"id":"chatcmpl-7","model":"GLM-5.3-Flash","choices":[{"delta":{"role":"assistant","content":""}}]}',
      'data: {"choices":[{"delta":{"reasoning_content":"thinking..."}}]}',
      'data: {"choices":[{"delta":{"content":"Gr"}}]}',
      ': keep-alive',
      'data: {"choices":[{"delta":{"content":"een"}}]}',
      'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"id":"call_a","function":{"name":"Read","arguments":"{\\"file_"}}]}}]}',
      'data: {"choices":[{"delta":{"tool_calls":[{"index":1,"id":"call_b","function":{"name":"Glob","arguments":"{\\"pattern\\":\\"*.ts\\"}"}}]}}]}',
      'data: {"choices":[{"delta":{"tool_calls":[{"index":0,"function":{"arguments":"path\\":\\"a.png\\"}"}}]}}]}',
      'data: {"choices":[{"delta":{},"finish_reason":"tool_calls"}]}',
      'data: {"choices":[],"usage":{"prompt_tokens":128,"completion_tokens":12}}',
      'data: [DONE]',
    ];
    const out = events(lines.map(line => stream.line(line)).join('') + stream.end());
    expect(out.map(e => e.type)).toEqual([
      'message_start',
      'content_block_start', 'content_block_delta', 'content_block_delta', 'content_block_stop',
      'content_block_start', 'content_block_delta', 'content_block_stop',
      'content_block_start', 'content_block_delta', 'content_block_stop',
      'message_delta', 'message_stop',
    ]);
    expect(out[0].message).toMatchObject({ id: 'msg_chatcmpl-7', role: 'assistant', model: 'GLM-5.3-Flash', content: [] });
    expect(out.filter(e => e.delta?.type === 'text_delta').map(e => e.delta.text).join('')).toBe('Green');
    expect(out[5]).toEqual({ type: 'content_block_start', index: 1, content_block: { type: 'tool_use', id: 'call_a', name: 'Read', input: {} } });
    expect(JSON.parse(out[6].delta.partial_json ?? '')).toEqual({ file_path: 'a.png' });
    expect(out[8].content_block).toMatchObject({ id: 'call_b', name: 'Glob' });
    expect(out[9].index).toBe(2);
    expect(out[11]).toEqual({ type: 'message_delta', delta: { stop_reason: 'tool_use', stop_sequence: null }, usage: { input_tokens: 128, output_tokens: 12 } });
  });

  it('closes an empty stream as a valid empty message, and passes a stream error on', () => {
    const empty = new MessagesEventStream('m');
    expect(events(empty.end()).map(e => e.type)).toEqual(['message_start', 'message_delta', 'message_stop']);
    const failing = new MessagesEventStream('m');
    const out = events(failing.line('data: {"error":{"message":"engine died","code":500}}'));
    expect(out[1]).toEqual({ type: 'error', error: { type: 'api_error', message: 'engine died' } });
  });
});

describe('toMessagesError', () => {
  it('keeps the server message and maps the status to a Messages error type', () => {
    expect(toMessagesError(429, '{"error":{"message":"Per-minute rate limit exceeded. Retry after 20 seconds."}}'))
      .toEqual({ type: 'error', error: { type: 'rate_limit_error', message: 'Per-minute rate limit exceeded. Retry after 20 seconds.' } });
    expect(toMessagesError(502, 'Bad Gateway')).toEqual({ type: 'error', error: { type: 'api_error', message: 'Bad Gateway' } });
    expect(toMessagesError(422, '{"detail":"x"}').error).toEqual({ type: 'invalid_request_error', message: '{"detail":"x"}' });
  });
});
