import { createServer, type IncomingHttpHeaders, type IncomingMessage, type Server, type ServerResponse } from 'node:http';
import type { AddressInfo } from 'node:net';
import { randomBytes } from 'node:crypto';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { modelListMatches, validModelList } from './model-list';
import { hasImage, MessagesEventStream, toChatCompletionsRequest, toMessagesError, toMessagesResponse } from './chat-completions-translate';

/**
 * The chatCompletionsImageModels setting: for these models the Claude CLI
 * talks to a local server here instead of the gateway in ANTHROPIC_BASE_URL.
 *
 * Everything goes on to the gateway unchanged, except a /v1/messages request
 * for a listed model that carries an image: that one goes to the gateway's
 * /v1/chat/completions, translated both ways (chat-completions-translate.ts).
 * It is for gateways whose /v1/messages fails on images while their Chat
 * Completions endpoint reads them. The transcript the CLI writes is the same
 * either way, since only the wire to the gateway changes.
 *
 * The server listens on 127.0.0.1 only, answers only a Host of 127.0.0.1 or
 * localhost on its port (no DNS rebinding from a web page), and only under a
 * random path per gateway, so it relays to the gateways a launch configured
 * and nowhere else. It adds no credentials: the CLI's own headers go on.
 */

type Route = { upstream: string; models: string[] };

const routes = new Map<string, Route>();
const routeIds = new Map<string, string>();
let listening: Promise<number> | null = null;
let server: Server | null = null;

const MAX_BODY_BYTES = 256 * 1024 * 1024;
// Hop-by-hop headers, and the ones fetch sets itself. accept-encoding goes too:
// fetch decodes a compressed answer, which would then be passed on mislabelled.
const DROPPED_REQUEST_HEADERS = new Set([
  'host', 'connection', 'keep-alive', 'proxy-connection', 'proxy-authorization', 'transfer-encoding',
  'te', 'trailer', 'upgrade', 'content-length', 'accept-encoding', 'expect',
]);
const DROPPED_RESPONSE_HEADERS = new Set(['connection', 'keep-alive', 'transfer-encoding', 'content-encoding', 'content-length']);

function forwardHeaders(headers: IncomingHttpHeaders): Record<string, string> {
  const out: Record<string, string> = {};
  for (const [name, value] of Object.entries(headers)) {
    if (value === undefined || DROPPED_REQUEST_HEADERS.has(name)) continue;
    out[name] = Array.isArray(value) ? value.join(', ') : value;
  }
  return out;
}

function responseHeaders(headers: Headers): Record<string, string> {
  const out: Record<string, string> = {};
  headers.forEach((value, name) => { if (!DROPPED_RESPONSE_HEADERS.has(name)) out[name] = value; });
  return out;
}

function replyJson(res: ServerResponse, status: number, body: unknown, headers: Record<string, string> = {}): void {
  res.writeHead(status, { ...headers, 'content-type': 'application/json' });
  res.end(JSON.stringify(body));
}

async function readBody(req: IncomingMessage): Promise<Buffer | null> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of req) {
    size += (chunk as Buffer).length;
    if (size > MAX_BODY_BYTES) return null;
    chunks.push(chunk as Buffer);
  }
  return Buffer.concat(chunks);
}

/** Abort the gateway request when the CLI goes away first. */
function abortOnClose(res: ServerResponse): AbortController {
  const controller = new AbortController();
  res.on('close', () => { if (!res.writableFinished) controller.abort(); });
  return controller;
}

function gatewayUnreachable(res: ServerResponse, error: unknown): void {
  if (res.headersSent) { res.destroy(); return; }
  const cause = error as { message?: string; cause?: { code?: string; message?: string } };
  replyJson(res, 502, { type: 'error', error: { type: 'api_error',
    message: `AI Bridge could not reach the gateway: ${cause.cause?.code ?? cause.cause?.message ?? cause.message ?? String(error)}` } });
}

async function passThrough(req: IncomingMessage, res: ServerResponse, target: string, body: Buffer): Promise<void> {
  const controller = abortOnClose(res);
  try {
    const response = await fetch(target, {
      method: req.method, headers: forwardHeaders(req.headers), redirect: 'manual', signal: controller.signal,
      body: req.method === 'GET' || req.method === 'HEAD' ? undefined : new Uint8Array(body),
    });
    res.writeHead(response.status, responseHeaders(response.headers));
    if (response.body) await pipeline(Readable.fromWeb(response.body as import('node:stream/web').ReadableStream), res);
    else res.end();
  } catch (error) {
    if (!controller.signal.aborted) gatewayUnreachable(res, error);
  }
}

async function viaChatCompletions(req: IncomingMessage, res: ServerResponse, upstream: string, body: Record<string, unknown>): Promise<void> {
  const model = typeof body.model === 'string' ? body.model : '';
  const stream = body.stream === true;
  console.error('[node-backend]', `Image request for ${model} sent to ${upstream}/v1/chat/completions`);
  const headers = forwardHeaders(req.headers);
  for (const name of Object.keys(headers)) if (name.startsWith('anthropic-') || name === 'x-api-key') delete headers[name];
  const apiKey = req.headers['x-api-key'];
  if (!headers.authorization && typeof apiKey === 'string') headers.authorization = `Bearer ${apiKey}`;
  headers['content-type'] = 'application/json';
  headers.accept = stream ? 'text/event-stream' : 'application/json';
  const controller = abortOnClose(res);
  try {
    const response = await fetch(`${upstream}/v1/chat/completions`, {
      method: 'POST', headers, redirect: 'manual', signal: controller.signal, body: JSON.stringify(toChatCompletionsRequest(body)),
    });
    if (!response.ok) {
      const retryAfter = response.headers.get('retry-after');
      replyJson(res, response.status, toMessagesError(response.status, await response.text()), retryAfter ? { 'retry-after': retryAfter } : {});
      return;
    }
    const isStream = (response.headers.get('content-type') ?? '').includes('text/event-stream');
    if (!stream) {
      replyJson(res, 200, toMessagesResponse(await response.json() as Record<string, unknown>, model));
      return;
    }
    res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-cache' });
    const events = new MessagesEventStream(model);
    if (!isStream || !response.body) {
      // A server that ignored stream:true: its one answer becomes one chunk.
      const completion = await response.json() as Record<string, unknown>;
      const choice = (Array.isArray(completion.choices) ? completion.choices[0] : undefined) as Record<string, unknown> | undefined;
      res.write(events.push({ ...completion, choices: [{ delta: choice?.message, finish_reason: choice?.finish_reason }] }));
      res.end(events.end());
      return;
    }
    const decoder = new TextDecoder();
    let pending = '';
    try {
      for await (const chunk of response.body as unknown as AsyncIterable<Uint8Array>) {
        pending += decoder.decode(chunk, { stream: true });
        const lines = pending.split(/\r?\n/);
        pending = lines.pop() ?? '';
        const out = lines.map(line => events.line(line)).join('');
        if (out) res.write(out);
      }
      res.end(events.line(pending + decoder.decode()) + events.end());
    } catch (error) {
      if (controller.signal.aborted) return;
      res.end(`event: error\ndata: ${JSON.stringify({ type: 'error', error: { type: 'api_error', message: `The gateway stream broke off: ${(error as Error).message}` } })}\n\n`);
    }
  } catch (error) {
    if (!controller.signal.aborted) gatewayUnreachable(res, error);
  }
}

async function handle(req: IncomingMessage, res: ServerResponse, port: number): Promise<void> {
  const host = (req.headers.host ?? '').toLowerCase();
  if (host !== `127.0.0.1:${port}` && host !== `localhost:${port}`) {
    replyJson(res, 403, { type: 'error', error: { type: 'permission_error', message: 'Forbidden' } });
    return;
  }
  const url = new URL(req.url ?? '/', `http://127.0.0.1:${port}`);
  const [, id = '', ...rest] = url.pathname.split('/');
  const route = routes.get(id);
  if (!route) {
    replyJson(res, 404, { type: 'error', error: { type: 'not_found_error', message: 'Not found' } });
    return;
  }
  const body = await readBody(req);
  if (!body) {
    replyJson(res, 413, { type: 'error', error: { type: 'request_too_large', message: 'Request too large' } });
    return;
  }
  const path = `/${rest.join('/')}`;
  if (req.method === 'POST' && /^\/v1\/messages\/?$/.test(path)) {
    let json: Record<string, unknown> | null = null;
    try { json = JSON.parse(body.toString('utf8')) as Record<string, unknown>; } catch { /* not ours to judge */ }
    if (json && typeof json.model === 'string' && hasImage(json) && modelListMatches(route.models, [json.model])) {
      await viaChatCompletions(req, res, route.upstream, json);
      return;
    }
  }
  await passThrough(req, res, `${route.upstream}${path}${url.search}`, body);
}

function listen(): Promise<number> {
  listening ??= new Promise<number>((resolve, reject) => {
    const created = createServer((req, res) => {
      const port = (created.address() as AddressInfo).port;
      handle(req, res, port).catch((error) => {
        console.error('[node-backend]', 'Image proxy request failed:', error);
        if (!res.headersSent) replyJson(res, 500, { type: 'error', error: { type: 'api_error', message: 'AI Bridge image proxy failed' } });
        else res.destroy();
      });
    });
    created.once('error', (error) => { listening = null; reject(error); });
    created.listen(0, '127.0.0.1', () => {
      created.unref();
      server = created;
      resolve((created.address() as AddressInfo).port);
    });
  });
  return listening;
}

/** The local base URL that stands for this gateway and model list; same inputs, same URL. */
export async function proxyBaseUrl(upstream: string, models: string[]): Promise<string> {
  const port = await listen();
  const key = JSON.stringify([upstream, models]);
  let id = routeIds.get(key);
  if (!id) {
    id = randomBytes(16).toString('hex');
    routeIds.set(key, id);
    routes.set(id, { upstream, models: [...models] });
  }
  return `http://127.0.0.1:${port}/${id}`;
}

const truthy = (value: unknown) => typeof value === 'string' && value !== '' && value !== '0' && value.toLowerCase() !== 'false';

/**
 * The environment a chat launch gets for the chatCompletionsImageModels
 * setting, or null when it does not apply: an empty list, no gateway in
 * ANTHROPIC_BASE_URL (the CLI's own resolution: process env under the env of
 * the Claude settings), or Bedrock, Vertex or Foundry.
 */
export async function chatCompletionsImageEnv(models: unknown, env: Record<string, unknown>): Promise<Record<string, string> | null> {
  if (!validModelList(models) || models.length === 0) return null;
  if (truthy(env.CLAUDE_CODE_USE_BEDROCK) || truthy(env.CLAUDE_CODE_USE_VERTEX) || truthy(env.CLAUDE_CODE_USE_FOUNDRY)) return null;
  const upstream = (typeof env.ANTHROPIC_BASE_URL === 'string' ? env.ANTHROPIC_BASE_URL : '').trim().replace(/\/+$/, '');
  if (!upstream || /^https:\/\/api\.anthropic\.com$/i.test(upstream)) return null;
  try {
    if (!['http:', 'https:'].includes(new URL(upstream).protocol)) return null;
  } catch { return null; }
  const launch: Record<string, string> = { ANTHROPIC_BASE_URL: await proxyBaseUrl(upstream, models) };
  // An HTTP proxy in the environment must not be asked for 127.0.0.1.
  const proxied = ['HTTPS_PROXY', 'https_proxy', 'HTTP_PROXY', 'http_proxy'].some(name => truthy(env[name]));
  if (proxied) {
    const existing = [env.NO_PROXY, env.no_proxy].find(value => typeof value === 'string' && value.trim()) as string | undefined;
    launch.NO_PROXY = launch.no_proxy = [existing?.trim(), '127.0.0.1', 'localhost'].filter(Boolean).join(',');
  }
  return launch;
}

/** For tests: close the server and forget every route. */
export async function closeChatCompletionsImageProxy(): Promise<void> {
  const current = server;
  server = null;
  listening = null;
  routes.clear();
  routeIds.clear();
  if (current) await new Promise<void>((resolve) => { current.close(() => resolve()); current.closeAllConnections(); });
}
