/**
 * Tell an open review that the file under it has moved (#359).
 *
 * Watching starts when a review is stored and stops when it is answered, so the
 * window being watched is exactly the window in which the base can go stale.
 *
 * HOW the change is noticed is the bridge's business, not this module's: in an
 * IDE the host reports saves it already sees, and standalone the bridge watches
 * the file itself. Asking `bridge.watchFile` rather than reaching for `fs.watch`
 * is what keeps both environments covered — the first cut of this feature wired
 * the IDE path straight through and left standalone with nothing.
 *
 * This is the early-warning half. It can miss, so it is deliberately NOT what
 * keeps the file safe: the approval gate re-reads the file at the moment of
 * writing. Detection is a convenience; the gate is the guarantee.
 */
import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import { MessageType } from '../../shared';
import { peekPreview, onPreviewConsumed } from './diffPreview';
import { compareReviewBase } from './reviewBase';

interface ReviewWatch {
  stop?: () => void;
  checking: boolean;
  pending: boolean;
}

/** One check/delivery and one reread flag per still-open review. */
const watching = new Map<string, ReviewWatch>();

// Release the watch as soon as the review it belongs to is answered. Registered
// here rather than called from takePreview so the dependency points one way:
// this module knows about previews, previews know nothing about watching.
onPreviewConsumed((toolUseId) => stopWatchingReviewBase(toolUseId));

/**
 * Start watching the file [toolUseId]'s review is about.
 *
 * Never throws and never blocks: the permission prompt is what the user is
 * waiting on, and a watch we could not start must not hold it up. Returns
 * quietly when there is nothing to watch.
 */
export async function watchReviewBase(
  bridge: Bridge,
  connections: ConnectionManager,
  toolUseId: string,
  filePath: string,
): Promise<void> {
  // Replace any watch left from a retried edit on the same request, so a
  // superseded one cannot outlive it.
  stopWatchingReviewBase(toolUseId);
  const entry: ReviewWatch = { checking: false, pending: false };
  watching.set(toolUseId, entry);

  try {
    const stop = await bridge.watchFile(filePath, () => {
      if (watching.get(toolUseId) !== entry) return;
      entry.pending = true;
      if (entry.checking) return;
      entry.checking = true;
      void (async () => {
        try {
          do {
            entry.pending = false;
            await reportIfBaseMoved(connections, toolUseId, bridge, entry);
          } while (entry.pending && watching.get(toolUseId) === entry);
        } finally {
          entry.checking = false;
        }
      })();
    });
    if (watching.get(toolUseId) === entry) entry.stop = stop;
    else stop();
  } catch (err) {
    if (watching.get(toolUseId) === entry) watching.delete(toolUseId);
    console.error('[node-backend]', `Could not watch the review base for ${toolUseId}:`, err);
  }
}

/** Stop watching, once the review is answered or replaced. */
export function stopWatchingReviewBase(toolUseId: string): void {
  const entry = watching.get(toolUseId);
  if (!entry) return;
  watching.delete(toolUseId);
  try {
    entry.stop?.();
  } catch (err) {
    console.error('[node-backend]', `Failed to stop watching for ${toolUseId}:`, err);
  }
}

/** Exposed for tests; production stops watches as reviews are answered. */
export function stopAllReviewBaseWatches(): void {
  for (const toolUseId of [...watching.keys()]) stopWatchingReviewBase(toolUseId);
}

/**
 * Check the review against disk and tell the surface when it has moved.
 *
 * The preview is peeked, not taken: the question is still open, and the answer
 * still needs the entry.
 */
async function reportIfBaseMoved(
  connections: ConnectionManager,
  toolUseId: string,
  bridge: Bridge,
  entry: ReviewWatch,
): Promise<void> {
  if (watching.get(toolUseId) !== entry) return;
  const preview = peekPreview(toolUseId);
  if (!preview) {
    // Answered while the notification was in flight — nothing to warn about.
    stopWatchingReviewBase(toolUseId);
    return;
  }

  try {
    // No selection is passed: the reviewer has not answered yet, so every change
    // is worth reporting. Which regions they end up keeping is the gate's
    // question, not this one's.
    const comparison = await compareReviewBase(preview);
    if (watching.get(toolUseId) !== entry) return;
    if (comparison.status !== 'changed') return;

    /*
     * Sent to every connection, for the same reason the gate is (see
     * holdApprovalIfBaseMoved): the window drawing the review may never have
     * subscribed to the session. Our diff page opens as its own editor tab and
     * addresses everything by tool_use_id, so a session-addressed message
     * reached the chat panel and missed the tab that had the review on screen.
     *
     * The payload carries its own address, so every other window ignores it.
     */
    await connections.broadcastToAll(MessageType.REVIEW_BASE_CHANGED, {
      toolUseId,
      filePath: preview.filePath,
      reason: 'changed',
      overlapsAccepted: comparison.overlapsAccepted,
      // Not the gate: nothing was blocked, the reviewer is simply being warned
      // while they still have time to act on it.
      blockedApproval: false,
    });
    // The host too. Keep only this check in flight until both recipients have
    // accepted it; a failed host notification must not take the watch down.
    await bridge
      .notifyReviewBaseChanged({
        toolUseId,
        filePath: preview.filePath,
        reason: 'changed',
        overlapsAccepted: comparison.overlapsAccepted,
        blockedApproval: false,
      })
      .catch((err) => {
        console.error('[node-backend]', 'Could not warn the host its review base moved:', err);
      });

    console.error(
      '[node-backend]',
      `Review base changed for ${toolUseId} (${preview.filePath}); told the review surface`,
    );
  } catch (err) {
    console.error('[node-backend]', `Failed to check the review base for ${toolUseId}:`, err);
  }
}
