/**
 * GET_MCP_SERVER_TOOLS: where the answer comes from, and how an auth wall is
 * reported.
 *
 * Two sources, in this order. A running CLI for the workspace already knows each
 * server's tools (and holds the OAuth token), so its `mcp_status` answer wins;
 * with no such session the backend connects itself. That second path cannot sign
 * in, so a 401 must come back as something the detail view can explain rather
 * than as the generic load failure.
 *
 * `fetchServerTools` is mocked because it starts a real MCP server; everything
 * else (the ACK shape, the `needs-auth` decision) is the code under test.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';

vi.mock('../../features/mcp-tools', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../../features/mcp-tools')>();
  return { ...actual, fetchServerTools: vi.fn() };
});
vi.mock('../../features/mcp-status', () => ({ fetchMcpStatus: vi.fn() }));

import { getMcpServerToolsHandler } from '../getMcpServerToolsHandler';
import { fetchServerTools } from '../../features/mcp-tools';
import { fetchMcpStatus } from '../../features/mcp-status';
import type { ConnectionManager } from '../../../ws/connection-manager';
import type { Bridge } from '../../../bridge/bridge-interface';
import type { IPCMessage } from '../../types';
import { MessageType, McpTransportType } from '../../../shared';

const fetchTools = vi.mocked(fetchServerTools);
const status = vi.mocked(fetchMcpStatus);
const bridge = {} as Bridge;

const CONFIG = { type: McpTransportType.HTTP, url: 'https://mcp.example.test/mcp' } as const;

function connectionsMock() {
  return {
    sendTo: vi.fn(async () => undefined),
  } as unknown as ConnectionManager & { sendTo: ReturnType<typeof vi.fn> };
}

function message(payload: Record<string, unknown>): IPCMessage {
  return { type: MessageType.GET_MCP_SERVER_TOOLS, requestId: 'req-1', payload, timestamp: 0 };
}

const ackOf = (connections: { sendTo: ReturnType<typeof vi.fn> }) => {
  const acks = connections.sendTo.mock.calls.filter((call) => call[1] === MessageType.ACK);
  expect(acks).toHaveLength(1);
  return acks[0][2] as Record<string, unknown>;
};

beforeEach(() => {
  vi.clearAllMocks();
});

describe('getMcpServerToolsHandler', () => {
  it('answers from the running CLI, without opening another connection', async () => {
    const connections = connectionsMock();
    status.mockResolvedValue([
      { name: 'github', status: 'connected', scope: 'user', tools: [{ name: 'search_issues' }] },
    ]);

    await getMcpServerToolsHandler(
      'conn-1',
      message({ name: 'github', config: CONFIG, workingDir: 'C:\\proj' }),
      connections,
      bridge,
    );

    // The live CLI is asked for this workspace specifically: the same server name
    // can be configured differently per project.
    expect(status).toHaveBeenCalledWith(connections, 'C:\\proj');
    expect(ackOf(connections)).toEqual({
      requestId: 'req-1',
      status: 'ok',
      tools: [{ name: 'search_issues' }],
    });
    expect(fetchTools).not.toHaveBeenCalled();
  });

  it('treats an empty list from the live CLI as an answer, not as a gap', async () => {
    const connections = connectionsMock();
    status.mockResolvedValue([{ name: 'github', status: 'connected', scope: 'user', tools: [] }]);

    await getMcpServerToolsHandler(
      'conn-1',
      message({ name: 'github', config: CONFIG, workingDir: 'C:\\proj' }),
      connections,
      bridge,
    );

    expect(ackOf(connections)).toEqual({ requestId: 'req-1', status: 'ok', tools: [] });
    expect(fetchTools).not.toHaveBeenCalled();
  });

  it('falls back to our own connection when the live CLI does not know this server', async () => {
    const connections = connectionsMock();
    status.mockResolvedValue([{ name: 'other', status: 'connected', scope: 'user', tools: [] }]);
    fetchTools.mockResolvedValue([{ name: 'open_pr' }]);

    await getMcpServerToolsHandler(
      'conn-1',
      message({ name: 'github', config: CONFIG, workingDir: 'C:\\proj' }),
      connections,
      bridge,
    );

    expect(fetchTools).toHaveBeenCalledWith(CONFIG, 'C:\\proj');
    expect(ackOf(connections)).toEqual({
      requestId: 'req-1',
      status: 'ok',
      tools: [{ name: 'open_pr' }],
    });
  });

  it('falls back when the live CLI has no tool list for the server yet', async () => {
    const connections = connectionsMock();
    status.mockResolvedValue([{ name: 'github', status: 'pending', scope: 'user' }]);
    fetchTools.mockResolvedValue([]);

    await getMcpServerToolsHandler(
      'conn-1',
      message({ name: 'github', config: CONFIG, workingDir: 'C:\\proj' }),
      connections,
      bridge,
    );

    expect(fetchTools).toHaveBeenCalledTimes(1);
    expect(ackOf(connections)).toEqual({ requestId: 'req-1', status: 'ok', tools: [] });
  });

  it('falls back when there is no live CLI at all, which is the settings case', async () => {
    const connections = connectionsMock();
    status.mockResolvedValue(null);
    fetchTools.mockResolvedValue([{ name: 'open_pr' }]);

    await getMcpServerToolsHandler(
      'conn-1',
      message({ name: 'github', config: CONFIG, workingDir: 'C:\\proj' }),
      connections,
      bridge,
    );

    expect(fetchTools).toHaveBeenCalledWith(CONFIG, 'C:\\proj');
    expect(ackOf(connections).status).toBe('ok');
  });

  it('does not ask a CLI when the payload carries no server name', async () => {
    const connections = connectionsMock();
    fetchTools.mockResolvedValue([]);

    await getMcpServerToolsHandler(
      'conn-1',
      message({ config: CONFIG, workingDir: 'C:\\proj' }),
      connections,
      bridge,
    );

    expect(status).not.toHaveBeenCalled();
    expect(fetchTools).toHaveBeenCalledTimes(1);
  });

  it('names the auth wall instead of reporting a load failure', async () => {
    const connections = connectionsMock();
    status.mockResolvedValue(null);
    fetchTools.mockRejectedValue(
      new Error('Error POSTing to endpoint (HTTP 401): Unauthorized'),
    );

    await getMcpServerToolsHandler(
      'conn-1',
      message({ name: 'notion', config: CONFIG, workingDir: 'C:\\proj' }),
      connections,
      bridge,
    );

    // `needs-auth` is what lets the detail view explain that the sign-in lives
    // with the CLI; `error` would keep the old, wrong "Couldn't load tools".
    expect(ackOf(connections)).toEqual({
      requestId: 'req-1',
      status: 'needs-auth',
      error: 'Error POSTing to endpoint (HTTP 401): Unauthorized',
    });
  });

  it('keeps the existing failure message for a real failure', async () => {
    const connections = connectionsMock();
    status.mockResolvedValue(null);
    fetchTools.mockRejectedValue(new Error('connect ECONNREFUSED 127.0.0.1:8080'));

    await getMcpServerToolsHandler(
      'conn-1',
      message({ name: 'github', config: CONFIG, workingDir: 'C:\\proj' }),
      connections,
      bridge,
    );

    expect(ackOf(connections)).toEqual({
      requestId: 'req-1',
      status: 'error',
      error: 'connect ECONNREFUSED 127.0.0.1:8080',
    });
  });
});
