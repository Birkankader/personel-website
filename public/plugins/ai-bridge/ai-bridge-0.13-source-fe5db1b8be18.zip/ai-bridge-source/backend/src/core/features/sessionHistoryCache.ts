/** Estimated retained payload budget, not a process RSS or in-flight read limit. */
export const SESSION_HISTORY_CACHE_MAX_BYTES = 64 * 1024 * 1024;

/** Walk parsed JSON without serializing/copying its strings. Stop at the budget. */
export function estimateHistoryBytes(value: unknown, limit: number): number {
  const pending = [value];
  const seen = new Set<object>();
  let bytes = 0;
  while (pending.length) {
    const current = pending.pop();
    if (typeof current === 'string') bytes += 24 + current.length * 2;
    else if (current && typeof current === 'object') {
      if (seen.has(current)) continue;
      seen.add(current);
      bytes += 32;
      if (Array.isArray(current)) {
        bytes += current.length * 8;
        if (bytes > limit) return limit + 1;
        for (const item of current) pending.push(item);
      } else {
        for (const key in current) {
          if (!Object.prototype.hasOwnProperty.call(current, key)) continue;
          bytes += 48 + key.length * 2;
          if (bytes > limit) return limit + 1;
          pending.push((current as Record<string, unknown>)[key]);
        }
      }
    } else bytes += 8;
    if (bytes > limit) return limit + 1;
  }
  return bytes;
}

interface Snapshot<T> { fingerprint: string; value: T; bytes: number }
interface Loading<T> { fingerprint: string; promise: Promise<T> }

/** LRU for completed snapshots, with one shared read per current file version. */
export class SessionHistoryCache<T> {
  private readonly snapshots = new Map<string, Snapshot<T>>();
  private readonly loading = new Map<string, Loading<T>>();
  private bytes = 0;

  constructor(
    private readonly maxBytes = SESSION_HISTORY_CACHE_MAX_BYTES,
    private readonly maxSessions = 4,
  ) {}

  get estimatedBytes(): number { return this.bytes; }

  invalidate(key: string): void {
    const snapshot = this.snapshots.get(key);
    if (snapshot) this.bytes -= snapshot.bytes;
    this.snapshots.delete(key);
    // Existing callers still receive their result; it can no longer repopulate
    // the cache after a missing/unreadable file or a newer request supersedes it.
    this.loading.delete(key);
  }

  getOrLoad(
    key: string,
    fingerprint: string,
    load: () => Promise<{ value: T; cacheable: boolean }>,
  ): Promise<T> {
    const cached = this.snapshots.get(key);
    if (cached?.fingerprint === fingerprint) {
      this.snapshots.delete(key);
      this.snapshots.set(key, cached);
      return Promise.resolve(cached.value);
    }
    const pending = this.loading.get(key);
    if (pending?.fingerprint === fingerprint) return pending.promise;
    this.invalidate(key);

    // Defer execution until the identity guard has been installed. A rejected
    // load must not become a permanently cached rejection.
    const promise: Promise<T> = Promise.resolve().then(load).then(({ value, cacheable }) => {
      if (cacheable && this.loading.get(key)?.promise === promise) {
        const bytes = estimateHistoryBytes(value, this.maxBytes);
        // Oversized histories remain complete for the caller, but do not evict
        // useful small snapshots just to be immediately evicted themselves.
        if (bytes <= this.maxBytes && this.maxSessions > 0) {
          while (this.snapshots.size >= this.maxSessions || this.bytes + bytes > this.maxBytes) {
            const oldest = this.snapshots.keys().next().value;
            if (oldest === undefined) break;
            this.invalidate(oldest);
          }
          this.snapshots.set(key, { fingerprint, value, bytes });
          this.bytes += bytes;
        }
      }
      return value;
    }).finally(() => {
      if (this.loading.get(key)?.promise === promise) this.loading.delete(key);
    });
    this.loading.set(key, { fingerprint, promise });
    return promise;
  }
}
