import { ContextBudget, estimatePromptTokens } from './context-budget';
import { AUTO_CONTINUE_PROMPT, OUTPUT_CONTINUE_PROMPT, classifyApiFailure, isAcpHarness, type ApiFailureKind } from '../../shared';

export type RecoveryPhase = 'waiting' | 'compacting' | 'continuing' | 'idle' | 'failed';
export interface RecoveryStatus {
  phase: RecoveryPhase;
  attempt: number;
  retryAt?: number;
  /** The failure being recovered from. Absent for compaction the budget asked for. */
  kind?: ApiFailureKind;
  /** Automatic attempts allowed for this kind of failure, when bounded per kind. */
  maxAttempts?: number;
}
export interface ApiFailure { kind: ApiFailureKind; retryMs: number; text: string }
type TransientKind = Exclude<ApiFailureKind, 'context' | 'output'>;
const isTransient = (kind: ApiFailureKind): kind is TransientKind => kind !== 'context' && kind !== 'output';

/** First retry delay per kind; transient kinds double from here on each attempt. */
const BASE_RETRY_MS: Record<ApiFailureKind, number> = { network: 2000, server: 5000, rate: 60000, context: 2000, output: 0 };
/** Network drops (VPN, Wi-Fi, proxies closing idle sockets) usually heal within a couple of minutes. */
export const MAX_TRANSIENT_ATTEMPTS: Record<TransientKind, number> = { network: 8, server: 6, rate: 4 };
const MAX_RETRY_MS: Record<TransientKind, number> = { network: 30000, server: 60000, rate: 300000 };
/**
 * Output-limit recoveries per user message. Each failure already stands for
 * the CLI's own resume attempts, so a reply that keeps outgrowing the limit
 * after these needs the user to split the work.
 */
export const MAX_OUTPUT_ATTEMPTS = 3;

/** Delay before transient attempt `attempt` (1-based), never earlier than the provider asked. */
export function transientRetryDelay(failure: ApiFailure, attempt: number): number {
  if (!isTransient(failure.kind)) return failure.retryMs;
  const base = BASE_RETRY_MS[failure.kind];
  // Rate limits wait as long as the provider says, without compounding it.
  const grown = failure.kind === 'rate' ? base : base * 2 ** Math.max(0, attempt - 1);
  return Math.max(failure.retryMs, Math.min(grown, MAX_RETRY_MS[failure.kind]));
}
export interface RecoveryPrompt {
  content: string;
  /** Preflight-delayed user messages are already visible in the chat. */
  echo?: boolean;
  attachments?: Array<
    | { type: 'image'; fileName: string; mimeType: string; base64: string }
    | { type: 'file'; fileName: string; absolutePath: string }
    | { type: 'folder'; folderName: string; absolutePath: string }
  >;
}

function errorText(event: Record<string, unknown>): string {
  const error = event.error;
  const message = event.message as { content?: unknown } | undefined;
  const content = message?.content;
  // A result's `result` is the final reply text. It names the failure only when
  // the turn ended on one; otherwise a reply that merely discusses a refused
  // connection would read as a network failure.
  const resultText = typeof event.result === 'string' && (event.type !== 'result' || /^\s*API Error/i.test(event.result))
    ? event.result : undefined;
  return [typeof error === 'string' ? error : (error as { message?: string } | undefined)?.message,
    resultText, ...(Array.isArray(event.errors) ? event.errors : []),
    ...(Array.isArray(content) ? content.filter(b => b?.type === 'text').map(b => b.text) : typeof content === 'string' ? [content] : []),
  ].filter(v => typeof v === 'string').join('\n');
}

/** Only actual API failure envelopes are eligible. Quoted errors in normal
 * assistant replies and failed tool results must never restart a conversation. */
export function readApiFailure(event: Record<string, unknown>): ApiFailure | null {
  if (event.parent_tool_use_id || event.parentToolUseID) return null;
  const text = errorText(event);
  const marked = event.is_api_error_message === true || event.isApiErrorMessage === true ||
    (event.type === 'result' && event.is_error === true) || event.type === 'error' ||
    (event.type === 'assistant' && typeof event.error === 'string');
  if (!marked) return null;
  const error = event.error && typeof event.error === 'object' ? event.error as Record<string, unknown> : {};
  const code = typeof event.error === 'string' ? event.error : error.type ?? error.code;
  const status = Number(event.api_error_status ?? event.apiErrorStatus ?? event.status ?? error.status ??
    /(?:API\s*Error|HTTP(?:\s*Error)?)\s*:\s*(\d{3})/i.exec(text)?.[1]);
  const kind = classifyApiFailure(text, code, Number.isFinite(status) ? status : undefined);
  if (!kind) return null;
  // The existing quota-reset scheduler owns subscription limits with a reset
  // time. Do not race it with an independent retry timer.
  if (kind === 'rate' && /resets?\s+(?:at\s+)?(?:\d|in\s+\d)/i.test(text)) return null;
  let retryMs = BASE_RETRY_MS[kind];
  const headers = event.headers as Record<string, unknown> | undefined;
  const retryAfter = headers?.['retry-after'] ?? event.retry_after ?? /retry[- ]after\s*[:=]?\s*(\d+(?:\.\d+)?)/i.exec(text)?.[1];
  if (typeof retryAfter === 'number' || typeof retryAfter === 'string') {
    const seconds = Number(retryAfter);
    const delay = Number.isFinite(seconds) ? seconds * 1000 : Date.parse(String(retryAfter)) - Date.now();
    // setTimeout overflows above this value. Leave exceptionally long limits to
    // a manual retry instead of retrying earlier than the provider permits.
    if (delay > 2147483647) return null;
    if (Number.isFinite(delay) && delay > 0) retryMs = Math.max(retryMs, delay);
  }
  return { kind, retryMs, text };
}

interface RecoveryDeps {
  valid: () => boolean;
  send: (prompt: RecoveryPrompt) => Promise<void>;
  status: (status: RecoveryStatus) => void;
  /**
   * `kind` is present when retries of a temporary failure were exhausted, and
   * `cause` when an automatic send was rejected: it is what `send` threw.
   */
  failed: (message: string, kind?: ApiFailureKind, cause?: unknown) => void;
}

/** Bounds alternating failure kinds, which each keep their own budget. */
const MAX_TOTAL_TRANSIENT_ATTEMPTS = 12;

type Progress = Required<Pick<RecoveryStatus, 'kind' | 'attempt' | 'maxAttempts'>>;

/** One bounded cycle per admitted user message. Retains the same queue slot
 * across resume → compact → continue, so queued user input cannot overtake it.
 *
 * Temporary failures (network, server, rate) are retried with growing delays
 * up to a per-kind limit, by asking Claude to continue where it stopped. A
 * context failure escalates to compaction, which rewrites the conversation. A
 * reply cut off by the output limit is compacted at once, then resumed in
 * smaller steps. */
export class ApiRecovery {
  private timer?: ReturnType<typeof setTimeout>;
  private generation = 0;
  private stage: 'normal' | 'resume' | 'compact' | 'continued' = 'normal';
  private active = false;
  private compacted = false;
  private compactConfirmed = false;
  private lastFailure: ApiFailure | null = null;
  private deferred?: RecoveryPrompt;
  private manualCommand = false;
  private attempt = 0;
  private transientAttempts: Partial<Record<TransientKind, number>> = {};
  private totalTransientAttempts = 0;
  private outputAttempts = 0;
  /**
   * Whether `/compact` compacts this conversation. An ACP harness compacts its
   * context by itself and takes `/compact` only when it offers that command;
   * any other would get it as an ordinary message for the model.
   */
  private compactable = true;
  constructor(public budget: ContextBudget, private readonly deps: RecoveryDeps) {}

  begin(prompt: RecoveryPrompt): RecoveryPrompt {
    this.cancel();
    this.deps.status({ phase: 'idle', attempt: 0 });
    this.active = true;
    this.stage = 'normal';
    this.compacted = this.compactConfirmed = false;
    this.lastFailure = null;
    this.attempt = 0;
    this.transientAttempts = {};
    this.totalTransientAttempts = 0;
    this.outputAttempts = 0;
    this.manualCommand = prompt.content.trimStart().startsWith('/');
    if (this.manualCommand) return prompt;
    const estimate = estimatePromptTokens(prompt.content, prompt.attachments);
    // Never silently truncate the user's instructions or attachments.
    if (this.budget.window && estimate >= this.budget.window - this.budget.maxOutput - 8000) {
      this.active = false;
      throw new Error('This message may exceed the model context budget on its own. Shorten it or attach files by path.');
    }
    if (this.compactable && this.budget.shouldCompact(estimate)) {
      this.deferred = { ...prompt, echo: false };
      this.stage = 'compact';
      this.compacted = true;
      this.deps.status({ phase: 'compacting', attempt: ++this.attempt });
      return { content: '/compact' };
    }
    return prompt;
  }

  observe(event: Record<string, unknown>): void {
    this.budget.observe(event);
    if (event.parent_tool_use_id || event.parentToolUseID) return;
    if (event.type === 'system' && event.subtype === 'init') {
      this.compactable = !isAcpHarness(event.harness) ||
        (Array.isArray(event.slash_commands) && event.slash_commands.includes('compact'));
    }
    if (event.type === 'system' && event.subtype === 'compact_boundary') this.compactConfirmed = true;
    const failure = readApiFailure(event);
    if (failure) { this.lastFailure = failure; this.budget.learnError(failure.text); }
    // Native retries may already have recovered before the enclosing result.
    else if (event.type === 'assistant' && !event.error && !event.is_api_error_message && !event.isApiErrorMessage) this.lastFailure = null;
  }

  /** Return true while an intermediate result is held for recovery. */
  result(event: Record<string, unknown>): boolean {
    if (!this.active || !this.deps.valid()) { this.cancel(); return false; }
    if (this.waiting) return true;
    const failed = event.is_error === true || !!this.lastFailure;
    const failure = this.lastFailure;
    if (this.stage === 'compact') {
      // A dropped connection during compaction retries the compaction itself;
      // the user's held message stays deferred until it succeeds.
      if (failed && failure && this.retryTransient(failure, 'compact', { content: '/compact' })) return true;
      if (failed || !this.compactConfirmed) {
        this.finishFailure('Automatic compaction did not complete. The conversation is preserved; retry /compact when the API is available.');
        return false;
      }
      const next = this.deferred ?? { content: 'continue' };
      this.deferred = undefined;
      this.schedule('continued', next, 0);
      return true;
    }
    if (failed) {
      if (!failure || this.manualCommand) { this.cancel(); return false; }
      if (failure.kind === 'output') return this.recoverOutput(failure);
      if (failure.kind !== 'context') {
        if (this.retryTransient(failure, 'resume', { content: AUTO_CONTINUE_PROMPT })) return true;
        const attempts = this.transientAttempts[failure.kind] ?? 0;
        this.finishFailure(`Automatic retry stopped after ${attempts} attempts. The ${failure.kind} error is still present; the conversation is preserved.`, failure.kind);
        return false;
      }
      if (this.stage === 'normal') {
        this.schedule('resume', { content: 'continue' }, failure.retryMs);
        return true;
      }
      if (this.stage === 'resume' && !this.compacted && this.compactable) {
        this.compacted = true;
        this.schedule('compact', { content: '/compact' }, Math.min(failure.retryMs * 2, 2147483647));
        return true;
      }
      this.finishFailure(this.compactable
        ? 'Automatic recovery stopped after resume and compaction attempts. The API error is still present.'
        : 'Automatic recovery stopped after a resume attempt. The context is still full; the conversation is preserved.');
      return false;
    }
    if (!this.manualCommand && this.compactable && !this.compacted && !this.compactConfirmed && this.budget.shouldCompact()) {
      this.compacted = true;
      this.schedule('compact', { content: '/compact' }, 0);
      return true;
    }
    this.cancel();
    return false;
  }

  get canSteer(): boolean { return this.active && this.stage === 'normal' && !this.waiting && !this.manualCommand && !this.lastFailure; }
  get waiting(): boolean { return this.timer !== undefined; }
  cancel(): void {
    this.generation++;
    if (this.timer !== undefined) clearTimeout(this.timer);
    this.timer = undefined;
    this.deferred = undefined;
    if (this.active) this.deps.status({ phase: 'idle', attempt: this.attempt });
    this.active = false;
  }
  private finishFailure(message: string, kind?: ApiFailureKind, cause?: unknown): void {
    this.cancel();
    this.deps.status({ phase: 'failed', attempt: this.attempt, ...(kind ? { kind } : {}) });
    this.deps.failed(message, kind, cause);
  }
  /**
   * Resume a reply the output limit cut off. The first time, compact first: a
   * nearly full context also shrinks the output budget the CLI is started
   * with, and once compaction frees room the CLI restarts with the larger
   * budget before the reply continues.
   */
  private recoverOutput(failure: ApiFailure): boolean {
    const attempt = ++this.outputAttempts;
    if (attempt > MAX_OUTPUT_ATTEMPTS) {
      this.finishFailure(`Automatic recovery stopped after ${MAX_OUTPUT_ATTEMPTS} attempts. Claude's reply still exceeds the output token limit; the conversation is preserved.`, 'output');
      return false;
    }
    const progress = { kind: failure.kind, attempt, maxAttempts: MAX_OUTPUT_ATTEMPTS };
    if (this.compactable && !this.compacted) {
      this.compacted = true;
      this.deferred = { content: OUTPUT_CONTINUE_PROMPT };
      this.schedule('compact', { content: '/compact' }, failure.retryMs, progress);
    } else {
      this.schedule('resume', { content: OUTPUT_CONTINUE_PROMPT }, failure.retryMs, progress);
    }
    return true;
  }
  /** Schedule the next attempt for a temporary failure, or return false once its budget is spent. */
  private retryTransient(failure: ApiFailure, stage: 'resume' | 'compact', prompt: RecoveryPrompt): boolean {
    if (!isTransient(failure.kind)) return false;
    const maxAttempts = MAX_TRANSIENT_ATTEMPTS[failure.kind];
    const attempt = (this.transientAttempts[failure.kind] ?? 0) + 1;
    if (attempt > maxAttempts || this.totalTransientAttempts >= MAX_TOTAL_TRANSIENT_ATTEMPTS) return false;
    this.transientAttempts[failure.kind] = attempt;
    this.totalTransientAttempts++;
    this.schedule(stage, prompt, transientRetryDelay(failure, attempt), { kind: failure.kind, attempt, maxAttempts });
    return true;
  }
  private schedule(stage: 'resume' | 'compact' | 'continued', prompt: RecoveryPrompt, delay: number, progress?: Progress): void {
    this.stage = stage;
    this.lastFailure = null;
    this.compactConfirmed = false;
    const generation = this.generation;
    this.attempt++;
    const shown = progress ?? { attempt: this.attempt };
    this.deps.status({ phase: 'waiting', ...shown, retryAt: Date.now() + delay });
    this.timer = setTimeout(() => {
      this.timer = undefined;
      if (generation !== this.generation || !this.deps.valid()) { this.cancel(); return; }
      this.lastFailure = null;
      this.deps.status({ phase: stage === 'compact' ? 'compacting' : 'continuing', ...shown });
      void this.deps.send(prompt).catch((error: unknown) => {
        if (generation === this.generation) this.finishFailure(error instanceof Error ? error.message : String(error), undefined, error);
      });
    }, delay);
    this.timer.unref?.();
  }
}
