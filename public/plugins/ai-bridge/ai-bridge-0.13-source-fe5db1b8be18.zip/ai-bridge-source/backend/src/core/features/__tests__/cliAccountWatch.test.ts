import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { join } from 'path';

// The watch and the file are both stand-ins, so each step runs in order: the
// test fires the directory event and decides what the next read returns.
const fake = vi.hoisted(() => ({
  files: new Map<string, string | Error>(),
  events: [] as { dir: string; fire: (filename: string | null) => void }[],
}));
vi.mock('fs', () => ({
  watch: vi.fn((dir: string, _options: unknown, callback: (event: string, filename: string | null) => void) => {
    fake.events.push({ dir, fire: (filename) => callback('rename', filename) });
    return { on: vi.fn(), close: vi.fn() };
  }),
}));
vi.mock('fs/promises', () => ({
  readFile: vi.fn(async (path: string) => {
    const content = fake.files.get(path);
    if (content instanceof Error) throw content;
    if (content === undefined) throw Object.assign(new Error('missing'), { code: 'ENOENT' });
    return content;
  }),
}));

import { watch } from 'fs';
import { readFile } from 'fs/promises';
import { onCliAccountChanged, stopCliAccountWatches, watchCliAccount } from '../cliAccountWatch';

const configFile = join('/cli-home', '.claude.json');

function signedIn(accountUuid: string, extra: Record<string, unknown> = {}): string {
  return JSON.stringify({
    numStartups: 3,
    oauthAccount: { accountUuid, emailAddress: `${accountUuid}@example.com`, organizationUuid: 'org-1', displayName: 'Ada', ...extra },
  });
}

/** Run every read the watch has started; they resolve on microtasks only. */
const settle = () => new Promise((resolve) => setImmediate(resolve));

/** The CLI rewrote the file: fire the directory event and let the debounce run. */
async function rewrite(content: string | Error | undefined): Promise<void> {
  if (content === undefined) fake.files.delete(configFile);
  else fake.files.set(configFile, content);
  fake.events[0].fire('.claude.json');
  await vi.advanceTimersByTimeAsync(500);
  await settle();
}

describe('watchCliAccount', () => {
  const changed = vi.fn();
  let stopListening: () => void;

  beforeEach(async () => {
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout'] });
    fake.files.clear();
    fake.events.length = 0;
    vi.mocked(watch).mockClear();
    vi.mocked(readFile).mockClear();
    changed.mockReset();
    stopListening = onCliAccountChanged(changed);
  });
  afterEach(() => {
    stopListening();
    stopCliAccountWatches();
    vi.useRealTimers();
  });

  async function start(content: string | undefined): Promise<void> {
    if (content !== undefined) fake.files.set(configFile, content);
    watchCliAccount(configFile);
    await settle();
  }

  it('watches the directory of each file once', async () => {
    await start(signedIn('a'));
    watchCliAccount(configFile);
    expect(watch).toHaveBeenCalledTimes(1);
    expect(fake.events[0].dir).toBe(join('/cli-home'));
  });

  it('reports a switch to another account once, however many events the write makes', async () => {
    await start(signedIn('a'));
    fake.files.set(configFile, signedIn('b'));
    fake.events[0].fire('.claude.json');
    fake.events[0].fire('.claude.json');
    await vi.advanceTimersByTimeAsync(500);
    await settle();
    expect(changed).toHaveBeenCalledTimes(1);
  });

  // The CLI rewrites the file on every start and refreshes the profile in place.
  it('ignores rewrites that keep the same account', async () => {
    await start(signedIn('a'));
    await rewrite(JSON.stringify({ ...JSON.parse(signedIn('a', { displayName: 'Ada L.' })), numStartups: 4 }));
    expect(changed).not.toHaveBeenCalled();
  });

  it('reports a logout and the next login', async () => {
    await start(signedIn('a'));
    await rewrite(JSON.stringify({ numStartups: 3 }));
    expect(changed).toHaveBeenCalledTimes(1);
    await rewrite(signedIn('a'));
    expect(changed).toHaveBeenCalledTimes(2);
  });

  it('reports the first login when the file did not exist yet', async () => {
    await start(undefined);
    await rewrite(signedIn('a'));
    expect(changed).toHaveBeenCalledTimes(1);
  });

  it('concludes nothing from a file caught mid-write or one it cannot read', async () => {
    await start(signedIn('a'));
    await rewrite('{"numStartups": 3, "oauthAcc');
    await rewrite(Object.assign(new Error('busy'), { code: 'EBUSY' }));
    expect(changed).not.toHaveBeenCalled();
    await rewrite(signedIn('a'));
    expect(changed).not.toHaveBeenCalled();
    await rewrite(signedIn('b'));
    expect(changed).toHaveBeenCalledTimes(1);
  });

  it('does not read the file for other files in the directory', async () => {
    await start(signedIn('a'));
    vi.mocked(readFile).mockClear();
    fake.events[0].fire('settings.json');
    await vi.advanceTimersByTimeAsync(500);
    await settle();
    expect(readFile).not.toHaveBeenCalled();
  });

  it('stops reporting once the watch is stopped', async () => {
    await start(signedIn('a'));
    fake.files.set(configFile, signedIn('b'));
    fake.events[0].fire('.claude.json');
    stopCliAccountWatches();
    await vi.advanceTimersByTimeAsync(500);
    await settle();
    expect(changed).not.toHaveBeenCalled();
  });
});
