import { homedir } from 'os';
import { join } from 'path';
import { readFile } from 'fs/promises';
import type { ConversationAnnotation, ConversationAnnotationPage, ConversationTarget } from '../../shared/conversation-tools';
import { updateJsonFile } from './atomic-json';

const ID = /^[a-zA-Z0-9_-]{1,160}$/;
const MAX_ANNOTATIONS = 5000;

export function validateConversationTarget(value: ConversationTarget): void {
  if (!value || typeof value.sessionId !== 'string' || typeof value.messageUuid !== 'string' || !ID.test(value.sessionId) || !ID.test(value.messageUuid) ||
    typeof value.workingDir !== 'string' || !value.workingDir || value.workingDir.length > 4096 || value.workingDir.includes('\0')) {
    throw new Error('Invalid conversation target');
  }
}

function annotationKey(value: ConversationTarget): string {
  return JSON.stringify([value.workingDir, value.sessionId, value.messageUuid]);
}

/** User annotations are kept separately; Claude JSONL is never rewritten. */
export class ConversationAnnotationStore {
  constructor(private readonly path = join(homedir(), '.ai-bridge', 'conversation-annotations.json')) {}

  async list(options: { workingDir?: string; sessionId?: string; messageUuid?: string; offset?: number; limit?: number } = {}): Promise<ConversationAnnotationPage> {
    let data: Record<string, unknown>;
    try { data = JSON.parse(await readFile(this.path, 'utf8')); }
    catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') return { annotations: [], nextOffset: null };
      throw new Error('Could not read saved bookmarks and notes', { cause: error });
    }
    if (!data || typeof data !== 'object' || Array.isArray(data)) throw new Error('Invalid annotation file');
    const entries = Object.values(data).filter((value): value is ConversationAnnotation => {
      try { validateConversationTarget(value as ConversationTarget); }
      catch { return false; }
      const a = value as ConversationAnnotation;
      return typeof a.note === 'string' && typeof a.bookmarked === 'boolean' && typeof a.updatedAt === 'string' &&
        (!options.workingDir || a.workingDir === options.workingDir) && (!options.sessionId || a.sessionId === options.sessionId) &&
        (!options.messageUuid || a.messageUuid === options.messageUuid);
    }).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
    const offset = Math.max(0, Math.floor(options.offset ?? 0));
    const limit = Math.max(1, Math.min(100, Math.floor(options.limit ?? 50)));
    return { annotations: entries.slice(offset, offset + limit), nextOffset: offset + limit < entries.length ? offset + limit : null };
  }

  async save(value: ConversationTarget & { bookmarked: boolean; note: string }): Promise<ConversationAnnotation | null> {
    validateConversationTarget(value);
    if (typeof value.note !== 'string' || value.note.length > 4000 || typeof value.bookmarked !== 'boolean') throw new Error('A note may contain at most 4000 characters');
    const annotation: ConversationAnnotation = { workingDir: value.workingDir, sessionId: value.sessionId, messageUuid: value.messageUuid,
      bookmarked: value.bookmarked, note: value.note.trim(), updatedAt: new Date().toISOString() };
    const key = annotationKey(annotation);
    const remove = !annotation.bookmarked && !annotation.note;
    const outcome = await updateJsonFile(this.path, (current) => {
      if (remove) { delete current[key]; return current; }
      if (!Object.prototype.hasOwnProperty.call(current, key) && Object.keys(current).length >= MAX_ANNOTATIONS) throw new Error('Bookmark limit reached; remove an old bookmark first');
      current[key] = annotation;
      return current;
    });
    if (outcome.status === 'error') throw new Error(outcome.error);
    return remove ? null : annotation;
  }
}

export const conversationAnnotations = new ConversationAnnotationStore();
