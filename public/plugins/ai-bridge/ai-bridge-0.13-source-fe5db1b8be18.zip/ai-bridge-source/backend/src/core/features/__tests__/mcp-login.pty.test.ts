/**
 * `mcp-login.ts` against the REAL `@lydell/node-pty`, with a stand-in for `claude`
 * that prints the CLI's own login sequence. Opt-in because it needs the native
 * addon for this platform and spawns a process tree:
 *
 *   AI_BRIDGE_PTY_SMOKE=1 bash ./scripts/build.sh be-test src/core/features/__tests__/mcp-login.pty.test.ts
 *
 * The stand-in lives in a directory whose name holds a space and is started with a
 * name full of shell metacharacters, so the quoting that gets a launcher through
 * cmd.exe (Windows) is exercised for real: the stand-in reports the argv it
 * received inside the authorization URL, and the test compares it exactly.
 *
 * If this hangs on exit, a conpty worker thread is still alive; run the file with
 * `--pool=forks`.
 */
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { chmod, mkdtemp, rm, writeFile } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import {
  cancelMcpLogin,
  setMcpLoginDepsForTesting,
  startMcpLogin,
  submitMcpLoginCallbackUrl,
} from '../mcp-login';
import { McpAuthenticationState, type McpServerAuthenticationStatus } from '../../../shared';

const SERVER_NAME = 'claude.ai Q&A & echo INJECTED';

// The stand-in, as a CommonJS script. It prints what the real CLI prints (an OSC 8
// link followed by the visible URL, the cancel hint, the paste prompt), then reads
// raw keystrokes until Enter: a line holding `code=` completes the sign-in, any
// other line is refused with the CLI's own sentence and the prompt comes back.
const FAKE_CLAUDE = String.raw`
const argv = process.argv.slice(2);
const name = argv[3];
const url = 'http://127.0.0.1:19900/authorize?state=abc&pid=' + process.pid +
  '&argv=' + encodeURIComponent(JSON.stringify(argv));
const out = (s) => process.stdout.write(s);
out('Starting authentication for "' + name + '"…\r\n');
out('Visit this URL to authorize:\r\n  \x1b[94m\x1b]8;id=1-1;' + url + '\x1b\\' + url + '\x1b[m\x1b]8;;\x1b\\\r\n');
out('Waiting for authorization… (^C to cancel)\r\nOr paste the redirect URL here: ');
if (process.stdin.isTTY) process.stdin.setRawMode(true);
process.stdin.resume();
let line = '';
process.stdin.on('data', (chunk) => {
  for (const ch of chunk.toString()) {
    if (ch === '\x03') { out('\r\n'); process.exit(130); }
    if (ch !== '\r' && ch !== '\n') { line += ch; out(ch); continue; }
    const answer = line;
    line = '';
    if (answer.includes('code=')) {
      out('\r\nAuthenticated with "' + name + '". Its tools are now available in Claude Code.\r\n');
      process.exit(0);
    }
    out('\r\nThat doesn\'t look like a redirect URL for this sign-in — paste the full address from the browser page this sign-in opened.\r\n');
    out('Or paste the redirect URL here: ');
  }
});
setInterval(() => {}, 1 << 30);
`;

function isAlive(pid: number): boolean {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

async function until<T>(read: () => T | undefined, what: string, ms = 20_000): Promise<T> {
  const deadline = Date.now() + ms;
  for (;;) {
    const value = read();
    if (value !== undefined) return value;
    if (Date.now() > deadline) throw new Error(`timed out waiting for ${what}`);
    await new Promise((r) => setTimeout(r, 50));
  }
}

describe.runIf(process.env.AI_BRIDGE_PTY_SMOKE === '1')('mcp-login over a real PTY', () => {
  let dir: string;
  let launcher: string;

  beforeAll(async () => {
    dir = await mkdtemp(join(tmpdir(), 'aib pty smoke '));
    if (process.platform === 'win32') {
      const script = join(dir, 'fake-claude.cjs');
      await writeFile(script, FAKE_CLAUDE);
      launcher = join(dir, 'fake-claude.cmd');
      await writeFile(launcher, `@node "${script}" %*\r\n`);
    } else {
      launcher = join(dir, 'fake-claude');
      await writeFile(launcher, `#!/usr/bin/env node\n${FAKE_CLAUDE}`);
      await chmod(launcher, 0o755);
    }
    setMcpLoginDepsForTesting({
      resolveLauncher: async () => launcher,
      baseEnv: () => ({ ...process.env }),
      timeoutMs: 60_000,
      cancelGraceMs: 3_000,
    });
  });

  afterAll(async () => {
    setMcpLoginDepsForTesting(null);
    await rm(dir, { recursive: true, force: true });
  });

  function begin() {
    const updates: McpServerAuthenticationStatus[] = [];
    const started = startMcpLogin({
      connectionId: 'smoke',
      name: SERVER_NAME,
      workingDir: dir,
      onUpdate: (u) => updates.push({ ...u }),
    });
    const lastState = () => updates[updates.length - 1]?.state;
    return { updates, started, lastState };
  }

  it('signs in through a refused paste and a good one, handing the stand-in the exact name', async () => {
    const { updates, started, lastState } = begin();
    expect(await started).toEqual({ status: 'started' });

    const awaiting = await until(
      () => updates.find((u) => u.state === McpAuthenticationState.AWAITING_CALLBACK),
      'the authorization URL',
    );
    const auth = new URL(awaiting.url!);
    expect(JSON.parse(auth.searchParams.get('argv')!)).toEqual(['mcp', 'login', '--no-browser', SERVER_NAME]);

    expect(submitMcpLoginCallbackUrl('smoke', SERVER_NAME, 'http://localhost:1/callback?nothing=here')).toEqual({ status: 'ok' });
    expect(lastState()).toBe(McpAuthenticationState.VERIFYING);
    const refused = await until(
      () => updates.find((u) => u.state === McpAuthenticationState.AWAITING_CALLBACK && u.error),
      'the refusal',
    );
    expect(refused.error).toContain("doesn't look like a redirect URL");
    expect(refused.url).toBe(awaiting.url);

    expect(submitMcpLoginCallbackUrl('smoke', SERVER_NAME, 'http://localhost:1/callback?code=ok&state=abc')).toEqual({ status: 'ok' });
    const done = await until(
      () => updates.find((u) => u.state === McpAuthenticationState.SUCCEEDED),
      'SUCCEEDED',
    );
    expect(done.exitCode).toBe(0);
  }, 40_000);

  it('cancel ends the process', async () => {
    const { updates, started } = begin();
    await started;
    const awaiting = await until(
      () => updates.find((u) => u.state === McpAuthenticationState.AWAITING_CALLBACK),
      'the authorization URL',
    );
    const pid = Number(new URL(awaiting.url!).searchParams.get('pid'));
    expect(isAlive(pid)).toBe(true);

    expect(cancelMcpLogin('smoke', SERVER_NAME)).toBe(true);

    await until(() => updates.find((u) => u.state === McpAuthenticationState.CANCELLED), 'CANCELLED');
    await until(() => (isAlive(pid) ? undefined : true), 'the stand-in to exit', 10_000);
  }, 40_000);
});
