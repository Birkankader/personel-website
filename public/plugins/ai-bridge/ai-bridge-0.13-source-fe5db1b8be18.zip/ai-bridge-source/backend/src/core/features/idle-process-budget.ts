/** Separate from concurrent task admission. Only callers that can prove an
 * idle process is resumable may retire it; busy/protected entries do not count. */
export class IdleProcessBudget<T> {
  private readonly entries = new Map<T, { since: number; canRetire: () => boolean; retire: () => Promise<void> }>();
  private timer?: ReturnType<typeof setTimeout>;
  constructor(private readonly warmCount = 2, private readonly idleMs = 5 * 60_000, private readonly maxIdleMs = 15 * 60_000) {}

  idle(key: T, canRetire: () => boolean, retire: () => Promise<void>): void {
    this.entries.delete(key);
    this.entries.set(key, { since: Date.now(), canRetire, retire });
    this.schedule();
  }

  active(key: T): void {
    this.entries.delete(key);
    if (!this.entries.size && this.timer) { clearTimeout(this.timer); this.timer = undefined; }
  }

  private schedule(): void {
    if (this.timer || !this.entries.size) return;
    this.timer = setTimeout(() => { this.timer = undefined; this.sweep(); }, Math.min(this.idleMs, 60_000));
    this.timer.unref?.();
  }

  private sweep(): void {
    // Runs on a timer: a failing check must keep that process warm, not throw
    // out of the timer callback and take the backend down with it.
    const eligible = [...this.entries].filter(([, entry]) => {
      try { return entry.canRetire(); } catch (error) {
        console.error('[node-backend]', 'Idle CLI check failed:', error);
        return false;
      }
    });
    let excess = Math.max(0, eligible.length - this.warmCount);
    for (const [key, entry] of eligible) {
      const age = Date.now() - entry.since;
      if (age < this.idleMs || (excess <= 0 && age < this.maxIdleMs)) continue;
      this.entries.delete(key);
      excess--;
      void entry.retire().catch(error => console.error('[node-backend]', 'Idle CLI cleanup failed:', error));
    }
    this.schedule();
  }
}
