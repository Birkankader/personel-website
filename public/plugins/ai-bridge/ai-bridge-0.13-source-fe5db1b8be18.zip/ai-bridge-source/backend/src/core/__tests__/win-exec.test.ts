import { describe, it, expect, vi, afterEach, beforeAll, afterAll } from 'vitest';
import { mkdtempSync, mkdirSync, writeFileSync, existsSync, rmSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';

// Mock child_process so we can inspect what execViaCmdArgv hands to execFile
// without launching a real process. The callback fires synchronously with a
// benign result unless a test overrides it. The real-process suite at the bottom
// flips `mode.real` to reach the genuine execFile instead.
const mode = vi.hoisted(() => ({ real: false }));

vi.mock('child_process', async (importOriginal) => {
  const actual = await importOriginal<typeof import('child_process')>();
  return {
    ...actual,
    execFile: vi.fn(
      (
        cmd: string,
        args: string[],
        opts: unknown,
        cb?: (err: unknown, stdout: string, stderr: string) => void,
      ) => {
        if (mode.real) return (actual.execFile as (...a: unknown[]) => unknown)(cmd, args, opts, cb);
        cb?.(null, 'ok', '');
        return { on: vi.fn() };
      },
    ),
  };
});

import { execFile as cpExecFile } from 'child_process';
import {
  execViaCmdArgv,
  assertNoCmdPercentExpansion,
  assertResolvedWindowsLauncher,
  buildCmdCommandLine,
  planWindowsLaunch,
  quoteWindowsArg,
} from '../win-exec';

describe('execViaCmdArgv', () => {
  const originalComSpec = process.env.ComSpec;

  afterEach(() => {
    vi.clearAllMocks();
    if (originalComSpec === undefined) delete process.env.ComSpec;
    else process.env.ComSpec = originalComSpec;
  });

  it('spawns cmd.exe (ComSpec) as the executed file, not the launcher directly', async () => {
    process.env.ComSpec = 'C:\\Windows\\System32\\cmd.exe';
    await execViaCmdArgv('C:\\Program Files\\nodejs\\npm.cmd', ['view', '@x/y', 'dist-tags']);

    const call = vi.mocked(cpExecFile).mock.calls[0];
    expect((call[0] as string).toLowerCase()).toContain('cmd.exe');
  });

  it('hands a .cmd launcher to cmd.exe as ONE pre-quoted line after /d /v:off /s /c', async () => {
    const launcher = 'C:\\Program Files\\nodejs\\npm.cmd';
    const argv = ['view', '@anthropic-ai/claude-code', 'dist-tags', '--json'];
    await execViaCmdArgv(launcher, argv);

    const args = vi.mocked(cpExecFile).mock.calls[0][1] as string[];
    expect(args.slice(0, 4)).toEqual(['/d', '/v:off', '/s', '/c']);
    expect(args).toHaveLength(5);
    expect(args[4]).toBe(buildCmdCommandLine(launcher, argv));
    // The launcher path with a space is caret-escaped inside the line, never split.
    expect(args[4]).toContain('C:\\Program^ Files\\nodejs\\npm.cmd');
  });

  it('runs a .cmd launcher with shell:false and windowsVerbatimArguments:true (the line is pre-quoted)', async () => {
    await execViaCmdArgv('npm.cmd', ['view', 'pkg']);

    const opts = vi.mocked(cpExecFile).mock.calls[0][2] as {
      shell?: boolean;
      windowsVerbatimArguments?: boolean;
    };
    expect(opts.shell).toBe(false);
    expect(opts.windowsVerbatimArguments).toBe(true);
  });

  it('runs a .bat launcher the same way as a .cmd', async () => {
    await execViaCmdArgv('C:\\tools\\launch.bat', ['a b']);

    const call = vi.mocked(cpExecFile).mock.calls[0];
    expect((call[1] as string[])[4]).toBe(buildCmdCommandLine('C:\\tools\\launch.bat', ['a b']));
    expect((call[2] as { windowsVerbatimArguments?: boolean }).windowsVerbatimArguments).toBe(true);
  });

  it('runs a .exe directly: no cmd.exe, args untouched, standard Node quoting', async () => {
    const exe = 'C:\\Users\\me\\.local\\bin\\claude.exe';
    const argv = ['mcp', 'add-json', 'srv', '{"a":"b & c"}'];
    await execViaCmdArgv(exe, argv);

    const call = vi.mocked(cpExecFile).mock.calls[0];
    expect(call[0]).toBe(exe);
    expect(call[1]).toEqual(argv);
    const opts = call[2] as { shell?: boolean; windowsVerbatimArguments?: boolean };
    expect(opts.shell).toBe(false);
    expect(opts.windowsVerbatimArguments).toBe(false);
  });

  it('keeps the legacy cmd.exe argv shape for a bare launcher name (escaping level unknowable)', async () => {
    process.env.ComSpec = 'C:\\Windows\\System32\\cmd.exe';
    await execViaCmdArgv('npm', ['view', 'pkg']);

    const call = vi.mocked(cpExecFile).mock.calls[0];
    expect((call[0] as string).toLowerCase()).toContain('cmd.exe');
    expect(call[1]).toEqual(['/d', '/s', '/c', 'npm', 'view', 'pkg']);
    const opts = call[2] as { shell?: boolean; windowsVerbatimArguments?: boolean };
    expect(opts.shell).toBe(false);
    expect(opts.windowsVerbatimArguments).toBe(false);
  });

  it('lets callers override the default timeout (e.g. a long update)', async () => {
    await execViaCmdArgv('claude.cmd', ['update'], { timeout: 180000 });

    const opts = vi.mocked(cpExecFile).mock.calls[0][2] as { timeout?: number };
    expect(opts.timeout).toBe(180000);
  });

  it('applies a 10s default timeout when the caller passes none', async () => {
    await execViaCmdArgv('claude.cmd', ['update']);

    const opts = vi.mocked(cpExecFile).mock.calls[0][2] as { timeout?: number };
    expect(opts.timeout).toBe(10000);
  });

  it('resolves with err=null and captured output on success', async () => {
    const result = await execViaCmdArgv('npm.cmd', ['view', 'pkg']);
    expect(result.err).toBeNull();
    expect(result.stdout).toBe('ok');
  });

  it('resolves with the error (does not throw) when the command fails', async () => {
    vi.mocked(cpExecFile).mockImplementationOnce(((
      _cmd: string,
      _args: unknown,
      _opts: unknown,
      cb?: (e: unknown, o: string, s: string) => void,
    ) => {
      cb?.(new Error('exit 1'), '', 'boom');
      return { on: vi.fn() };
    }) as unknown as typeof cpExecFile);
    const result = await execViaCmdArgv('npm.cmd', ['view', 'pkg']);
    expect(result.err).toBeInstanceOf(Error);
    expect(result.stderr).toBe('boom');
  });

  it('throws before running when a .cmd arg contains `%` (cmd would expand it)', async () => {
    await expect(execViaCmdArgv('npm.cmd', ['view', '%PKG%'])).rejects.toThrow(/%/);
    expect(vi.mocked(cpExecFile)).not.toHaveBeenCalled();
  });

  it('throws when the .cmd launcher path itself contains `%`', async () => {
    await expect(execViaCmdArgv('%LAUNCHER%.cmd', ['update'])).rejects.toThrow(/%/);
    expect(vi.mocked(cpExecFile)).not.toHaveBeenCalled();
  });

  it('throws before running when a bare-name launcher is given a `%` arg', async () => {
    await expect(execViaCmdArgv('npm', ['view', '%PKG%'])).rejects.toThrow(/%/);
    expect(vi.mocked(cpExecFile)).not.toHaveBeenCalled();
  });

  it('does NOT reject `%` for a .exe launcher (no cmd.exe, nothing expands it)', async () => {
    await expect(execViaCmdArgv('C:\\bin\\tool.exe', ['--token', '%API_KEY%'])).resolves.toMatchObject({ err: null });
    expect(vi.mocked(cpExecFile).mock.calls[0][1]).toEqual(['--token', '%API_KEY%']);
  });

  // A line break ends a `cmd /c` command line: the rest of the line, and every argument
  // after it, is silently dropped. That would turn `mcp remove "a\nb" -s project` into
  // `mcp remove a`, so it fails loudly before anything runs.
  it('throws before running when an arg for cmd.exe contains a line break', async () => {
    await expect(execViaCmdArgv('npm.cmd', ['view', 'a\nb'])).rejects.toThrow(/line break/i);
    await expect(execViaCmdArgv('npm', ['view', 'a\rb'])).rejects.toThrow(/line break/i);
    expect(vi.mocked(cpExecFile)).not.toHaveBeenCalled();
  });

  it('does not echo the offending value in the line-break error', async () => {
    const secret = 'sk-secret\nvalue';
    const error = await execViaCmdArgv('npm.cmd', [secret]).catch((e: unknown) => e as Error);
    expect(error).toBeInstanceOf(Error);
    expect((error as Error).message).not.toContain('sk-secret');
  });

  it('hands the executor the planned file and args, with the planned options', async () => {
    const executor = vi.fn(async () => ({ stdout: 'from-executor', stderr: '' }));
    const result = await execViaCmdArgv('C:\\Program Files\\claude.cmd', ['mcp', 'get', 'aib spaced'], { cwd: 'C:\\w' }, executor);

    expect(result).toEqual({ err: null, stdout: 'from-executor', stderr: '' });
    expect(vi.mocked(cpExecFile)).not.toHaveBeenCalled();
    const [file, args, options] = executor.mock.calls[0] as unknown as [string, string[], Record<string, unknown>];
    expect(file.toLowerCase()).toContain('cmd');
    expect(args.slice(0, 4)).toEqual(['/d', '/v:off', '/s', '/c']);
    expect(args[4]).toBe(buildCmdCommandLine('C:\\Program Files\\claude.cmd', ['mcp', 'get', 'aib spaced']));
    expect(options).toMatchObject({ cwd: 'C:\\w', shell: false, windowsVerbatimArguments: true, encoding: 'buffer', timeout: 10000 });
  });

  it('returns the executor error with its captured output instead of throwing', async () => {
    const failure = Object.assign(new Error('exit 3'), { stdout: 'so', stderr: 'se' });
    const result = await execViaCmdArgv('x.cmd', [], undefined, async () => { throw failure; });
    expect(result).toEqual({ err: failure, stdout: 'so', stderr: 'se' });
  });

  // cmd.exe writes non-ASCII on stdout in the system's legacy OEM codepage, not UTF-8.
  // Taking Node's default utf8 decoding turns a Korean/Chinese install path into U+FFFD,
  // so we must receive raw bytes and decode them ourselves (see console-encoding.ts).
  it('asks execFile for raw bytes instead of Node default utf8 decoding', async () => {
    await execViaCmdArgv('npm.cmd', ['view', 'pkg']);

    const opts = vi.mocked(cpExecFile).mock.calls[0][2] as { encoding?: string };
    expect(opts.encoding).toBe('buffer');
  });

  it('decodes a Buffer stdout rather than returning "[object Object]"', async () => {
    vi.mocked(cpExecFile).mockImplementationOnce(((
      _cmd: string,
      _args: unknown,
      _opts: unknown,
      cb?: (e: unknown, o: Buffer, s: Buffer) => void,
    ) => {
      cb?.(null, Buffer.from('C:\\tools\\claude.cmd', 'utf8'), Buffer.alloc(0));
      return { on: vi.fn() };
    }) as unknown as typeof cpExecFile);

    const result = await execViaCmdArgv('where.exe', ['claude']);
    expect(result.stdout).toBe('C:\\tools\\claude.cmd');
    expect(result.stderr).toBe('');
  });

  it('keeps valid UTF-8 bytes intact (locale-independent)', async () => {
    const text = 'C:\\Kullanıcılar\\Görkem\\claude.cmd';
    vi.mocked(cpExecFile).mockImplementationOnce(((
      _cmd: string,
      _args: unknown,
      _opts: unknown,
      cb?: (e: unknown, o: Buffer, s: Buffer) => void,
    ) => {
      cb?.(null, Buffer.from(text, 'utf8'), Buffer.alloc(0));
      return { on: vi.fn() };
    }) as unknown as typeof cpExecFile);

    const result = await execViaCmdArgv('where.exe', ['claude']);
    expect(result.stdout).toBe(text);
  });
});

describe('planWindowsLaunch', () => {
  const originalComSpec = process.env.ComSpec;

  afterEach(() => {
    if (originalComSpec === undefined) delete process.env.ComSpec;
    else process.env.ComSpec = originalComSpec;
  });

  it('runs .exe and .com files directly, case-insensitively', () => {
    expect(planWindowsLaunch('C:\\bin\\CLAUDE.EXE', ['a b'])).toEqual({
      file: 'C:\\bin\\CLAUDE.EXE', args: ['a b'], windowsVerbatimArguments: false,
    });
    expect(planWindowsLaunch('tool.com', [])).toEqual({ file: 'tool.com', args: [], windowsVerbatimArguments: false });
  });

  it('wraps .cmd and .bat launchers in one verbatim cmd.exe line', () => {
    process.env.ComSpec = 'C:\\Windows\\System32\\cmd.exe';
    for (const launcher of ['C:\\x y\\a.cmd', 'C:\\x y\\a.CMD', 'C:\\x y\\a.bat']) {
      expect(planWindowsLaunch(launcher, ['mcp', 'get', 'n'])).toEqual({
        file: 'C:\\Windows\\System32\\cmd.exe',
        args: ['/d', '/v:off', '/s', '/c', buildCmdCommandLine(launcher, ['mcp', 'get', 'n'])],
        windowsVerbatimArguments: true,
      });
    }
  });

  it('falls back to a plain cmd.exe when ComSpec is unset', () => {
    delete process.env.ComSpec;
    expect(planWindowsLaunch('a.cmd', []).file).toBe('cmd.exe');
    expect(planWindowsLaunch('npm', []).file).toBe('cmd.exe');
  });

  it('keeps the legacy shape for an extension-less name or any other extension (e.g. .ps1)', () => {
    process.env.ComSpec = 'cmd.exe';
    expect(planWindowsLaunch('claude', ['x'])).toEqual({
      file: 'cmd.exe', args: ['/d', '/s', '/c', 'claude', 'x'], windowsVerbatimArguments: false,
    });
    expect(planWindowsLaunch('tool.ps1', ['x'])).toEqual({
      file: 'cmd.exe', args: ['/d', '/s', '/c', 'tool.ps1', 'x'], windowsVerbatimArguments: false,
    });
  });

  // A resolution that failed leaves a bare name or an extension-less path, and the
  // legacy route would let cmd.exe act on the arguments. Calling this on the
  // resolved launcher makes the caller fail closed (Claude.execViaCmd and the MCP
  // sign-in both do) instead of guessing that PATHEXT found a batch file.
  describe('assertResolvedWindowsLauncher', () => {
    it('accepts the launchers win-exec can start through a safe route', () => {
      for (const launcher of [
        'claude.cmd',
        'C:\\Program Files\\nodejs\\claude.cmd',
        'C:\\Users\\me\\.local\\bin\\claude.exe',
        'C:\\tools\\CLAUDE.BAT',
        'C:\\tools\\claude.com',
      ]) {
        expect(() => assertResolvedWindowsLauncher(launcher)).not.toThrow();
      }
    });

    it('refuses a bare name and an extension-less path', () => {
      for (const launcher of ['claude', 'C:\\tools\\claude', 'C:\\a.b\\claude', 'claude.ps1']) {
        expect(() => assertResolvedWindowsLauncher(launcher))
          .toThrow(/Could not resolve the claude launcher.*Claude CLI path/);
      }
    });
  });

  // Node quotes an argument only when it holds a space, tab or `"`, so on the legacy
  // `cmd /c <name> ...args` shape a bare `a&calc` reaches cmd.exe as an operator and a
  // `"` breaks out of Node's own quoting. Callers (updateCli's version, a configured
  // harness path) can carry such values, so the shape refuses them instead of running them.
  it('refuses a cmd operator or quote in an argument Node would leave unquoted (legacy shape)', () => {
    process.env.ComSpec = 'cmd.exe';
    for (const hostile of ['pkg@1&calc', 'a|b', 'a<b', 'a>b', 'a^b', 'x"y', 'x" & calc & "']) {
      expect(() => planWindowsLaunch('npm', ['install', hostile])).toThrow(/#3.*cmd\.exe/);
      expect(() => planWindowsLaunch('tool.ps1', [hostile])).toThrow(/#2/);
    }
    expect(() => planWindowsLaunch('C:\\a&b\\tool', [])).toThrow(/#1/);
  });

  it('does not echo the refused value', () => {
    const message = (() => {
      try { planWindowsLaunch('npm', ['sk-secret&calc']); return ''; } catch (e) { return (e as Error).message; }
    })();
    expect(message).not.toBe('');
    expect(message).not.toContain('sk-secret');
  });

  it('lets a legacy-shape argument through when Node quotes it (it holds a space) or has no operator', () => {
    process.env.ComSpec = 'cmd.exe';
    expect(planWindowsLaunch('npm', ['install', '--prefix', 'C:\\Users\\A & B\\harness', '@x/y@1.2.3-beta.1+build']).args)
      .toEqual(['/d', '/s', '/c', 'npm', 'install', '--prefix', 'C:\\Users\\A & B\\harness', '@x/y@1.2.3-beta.1+build']);
  });

  it('does not apply the operator refusal to the .exe and batch routes (they have their own escaping)', () => {
    expect(() => planWindowsLaunch('C:\\bin\\claude.exe', ['a&b', 'x"y'])).not.toThrow();
    expect(() => planWindowsLaunch('C:\\bin\\claude.cmd', ['a&b', 'x"y'])).not.toThrow();
  });
});

describe('quoteWindowsArg (CommandLineToArgvW rules)', () => {
  it('leaves a plain argument alone', () => {
    expect(quoteWindowsArg('plain')).toBe('plain');
    expect(quoteWindowsArg('--flag=value')).toBe('--flag=value');
    expect(quoteWindowsArg('C:\\no\\spaces\\here')).toBe('C:\\no\\spaces\\here');
    // A trailing backslash only matters once a closing quote follows it.
    expect(quoteWindowsArg('trail\\')).toBe('trail\\');
  });

  it('quotes the empty string so it survives as an argument', () => {
    expect(quoteWindowsArg('')).toBe('""');
  });

  it('wraps an argument with spaces or tabs in double quotes', () => {
    expect(quoteWindowsArg('aib spaced')).toBe('"aib spaced"');
    expect(quoteWindowsArg('a\tb')).toBe('"a\tb"');
  });

  it('escapes an embedded double quote', () => {
    expect(quoteWindowsArg('a"b')).toBe('"a\\"b"');
  });

  it('doubles backslashes that precede a double quote, and escapes the quote', () => {
    expect(quoteWindowsArg('a\\"b')).toBe('"a\\\\\\"b"');
    expect(quoteWindowsArg('a\\\\"b')).toBe('"a\\\\\\\\\\"b"');
  });

  it('doubles a backslash run at the end of a quoted argument', () => {
    expect(quoteWindowsArg('C:\\path with space\\')).toBe('"C:\\path with space\\\\"');
    expect(quoteWindowsArg('a b\\\\')).toBe('"a b\\\\\\\\"');
  });

  it('leaves backslashes elsewhere untouched', () => {
    expect(quoteWindowsArg('C:\\a b\\c')).toBe('"C:\\a b\\c"');
  });
});

describe('buildCmdCommandLine', () => {
  it('wraps the whole line in one pair of quotes for `cmd /s /c`', () => {
    const line = buildCmdCommandLine('claude.cmd', ['mcp', 'list']);
    expect(line).toBe('"claude.cmd mcp list"');
  });

  it('caret-escapes the metacharacters of a launcher path with spaces and parentheses', () => {
    const line = buildCmdCommandLine('C:\\Program Files (x86)\\Tools\\claude.cmd', ['mcp', 'list']);
    expect(line).toBe('"C:\\Program^ Files^ ^(x86^)\\Tools\\claude.cmd mcp list"');
  });

  it('escapes each metacharacter of a plain argument twice (cmd /c, then the launcher %*)', () => {
    const line = buildCmdCommandLine('a.cmd', ['a&b']);
    expect(line).toBe('"a.cmd a^^^&b"');
    for (const meta of ['|', '<', '>', '^', '(', ')', ';', ',', '*', '?', '!', '`', '[', ']']) {
      const escaped = buildCmdCommandLine('a.cmd', [`x${meta}y`]);
      expect(escaped).toBe(`"a.cmd x^^^${meta}y"`);
    }
  });

  it('quotes an argument with spaces and escapes the quotes and spaces twice', () => {
    const line = buildCmdCommandLine('a.cmd', ['aib spaced']);
    expect(line).toBe('"a.cmd ^^^"aib^^^ spaced^^^""');
  });

  it('never leaves an unescaped quote or operator in the argument part of the line', () => {
    const hostile = [
      '{"command":"npx","env":{"K":"a & echo INJECTED & b"}}',
      'x" & echo INJECTED "y',
      '| calc',
      '> out.txt',
      '^ & ^',
      '(echo INJECTED)',
    ];
    const body = buildCmdCommandLine('C:\\Program Files\\claude.cmd', hostile).slice(1, -1);
    // Every metacharacter must be preceded by a caret (the first parse), so cmd.exe
    // never sees an operator and never toggles quote mode.
    expect(body.replace(/\^./g, '')).not.toMatch(/[&|<>()"]/);
  });

  it('keeps empty arguments', () => {
    expect(buildCmdCommandLine('a.cmd', [''])).toBe('"a.cmd ^^^"^^^""');
  });

  it('rejects `%` anywhere, without echoing the value', () => {
    // Positions are 1-based and count the launcher as #1.
    expect(() => buildCmdCommandLine('a.cmd', ['ok', 'x%PATH%y'])).toThrow(/#3/);
    expect(() => buildCmdCommandLine('%X%.cmd', [])).toThrow(/#1/);
    const message = (() => {
      try { buildCmdCommandLine('a.cmd', ['x%SECRET%']); return ''; } catch (e) { return (e as Error).message; }
    })();
    expect(message).toContain('%');
    expect(message).not.toContain('SECRET');
  });

  it('rejects a line break anywhere', () => {
    expect(() => buildCmdCommandLine('a.cmd', ['a\nb'])).toThrow(/line break/i);
    expect(() => buildCmdCommandLine('a.cmd', ['a\rb'])).toThrow(/line break/i);
    expect(() => buildCmdCommandLine('a\n.cmd', [])).toThrow(/line break/i);
  });
});

describe('assertNoCmdPercentExpansion', () => {
  it('is a no-op when no arg contains `%`', () => {
    expect(() => assertNoCmdPercentExpansion(['view', 'pkg', '--json'])).not.toThrow();
  });

  it('throws naming the 1-based position of the offending arg', () => {
    expect(() => assertNoCmdPercentExpansion(['a', 'b%c'])).toThrow(/#2/);
  });

  it('does not echo the full offending value in the message', () => {
    const secret = 'super-secret-%TOKEN%';
    try {
      assertNoCmdPercentExpansion([secret]);
      throw new Error('should have thrown');
    } catch (e) {
      expect((e as Error).message).toContain('%');
      expect((e as Error).message).not.toContain(secret);
    }
  });
});

// The only evidence that the quoting is right is a real cmd.exe running a real batch
// launcher, because the line is parsed twice: by `cmd /c`, then again when the launcher
// expands `%*`. Windows only; process.platform is NOT mocked here.
describe.runIf(process.platform === 'win32')('execViaCmdArgv with a real cmd.exe and a real launcher', () => {
  let root: string;
  let argvScript: string;
  let fakeCmd: string;

  beforeAll(() => {
    mode.real = true;
    // A directory containing a space: the launcher path itself needs quoting.
    root = mkdtempSync(join(tmpdir(), 'aib win-exec '));
    const launcherDir = join(root, 'with space');
    mkdirSync(launcherDir);
    argvScript = join(launcherDir, 'argv.cjs');
    writeFileSync(argvScript, 'process.stdout.write(JSON.stringify(process.argv.slice(2)));\n');
    fakeCmd = join(launcherDir, 'fake.cmd');
    writeFileSync(fakeCmd, `@node "${argvScript}" %*\r\n`);
  });

  afterAll(() => {
    mode.real = false;
    rmSync(root, { recursive: true, force: true });
  });

  const never = (n: number): string => join(root, `never-${n}.txt`);

  const cases = (): string[] => [
    JSON.stringify({ command: 'npx', args: ['-y', 'pkg'], env: { K: 'a & echo INJECTED & b' } }),
    JSON.stringify({ env: { K: 'x & echo INJECTED2' } }),
    'claude.ai Gmail',
    'aib spaced',
    '',
    'C:\\path with space\\',
    'trail\\',
    'a"b',
    'a\\"b',
    'a b\\\\',
    'paren (x) | y > z < w ^ caret',
    'Ünïcødé ışık',
    'plain',
    'a&b',
    'a|b',
    'a>b',
    'a<b',
    '!VAR!',
    'semi;colon,comma',
    'star*q?[x]',
    '`tick`',
    "it's",
    'tab\there',
    '--flag=value with space',
    '-s',
    // Not data, an attack: if any layer leaves `&` live this creates the sentinel file.
    `x" & type nul > "${never(1)}" & "`,
    `x & type nul > "${never(2)}"`,
  ];

  const parse = (stdout: string): string[] => JSON.parse(stdout) as string[];

  it('round-trips every argument exactly through a .cmd launcher in a directory with a space', async () => {
    const input = cases();
    const { err, stdout, stderr } = await execViaCmdArgv(fakeCmd, input, { timeout: 30000 });

    expect({ err: err?.message ?? null, stderr }).toEqual({ err: null, stderr: '' });
    expect(parse(stdout)).toEqual(input);
    // Had any layer left an `&` live, cmd.exe would have created these files (and the
    // parse above would have failed on the extra output).
    expect(existsSync(never(1))).toBe(false);
    expect(existsSync(never(2))).toBe(false);
  }, 60000);

  it('round-trips the same arguments through the .exe route (node.exe, no cmd.exe)', async () => {
    const input = cases();
    const { err, stdout, stderr } = await execViaCmdArgv(process.execPath, [argvScript, ...input], { timeout: 30000 });

    expect({ err: err?.message ?? null, stderr }).toEqual({ err: null, stderr: '' });
    expect(parse(stdout)).toEqual(input);
  }, 60000);

  it('keeps `%` literal on the .exe route even though the .cmd route refuses it', async () => {
    const viaExe = await execViaCmdArgv(process.execPath, [argvScript, '%PATH%', '100%'], { timeout: 30000 });
    expect(parse(viaExe.stdout)).toEqual(['%PATH%', '100%']);
    await expect(execViaCmdArgv(fakeCmd, ['%PATH%'])).rejects.toThrow(/%/);
  }, 60000);

  it('keeps the arguments that follow an argument with a trailing backslash', async () => {
    const input = ['mcp', 'remove', 'C:\\dir with space\\', '-s', 'project'];
    const { stdout } = await execViaCmdArgv(fakeCmd, input, { timeout: 30000 });
    expect(parse(stdout)).toEqual(input);
  }, 60000);
});
