import { afterEach, describe, expect, it, vi } from 'vitest';
import type { ConnectionManager } from '../../../ws/connection-manager';
import { cpuPercent, parseCpuTime, parseProcessSamples, processTree, RuntimeResourceSampler } from '../runtime-resources';

vi.mock('../runtime-tasks', () => ({ runtimeTasks: () => ({ ready: Promise.resolve(), limiter: { snapshot: () => ({ limit: 2, tasks: [] }) } }) }));

describe('runtime resource measurements', () => {
  afterEach(() => { vi.useRealTimers(); vi.restoreAllMocks(); });
  it.each([['00:00.25', 0.25], ['01:02:03', 3723], ['2-01:02:03', 176523]])('parses native CPU time %s', (text, seconds) => {
    expect(parseCpuTime(text as string)).toBe(seconds);
  });
  it('rejects invalid samples instead of displaying zero usage', () => {
    expect(parseCpuTime('unknown')).toBeNull();
    expect(parseProcessSamples('PID PPID RSS TIME\ninvalid row')).toEqual([]);
  });
  it('converts KiB RSS and includes only the selected process tree', () => {
    const samples = parseProcessSamples('10 1 1024 00:01.00\n11 10 512 00:00.50\n12 11 256 00:00.25\n20 1 9999 00:30.00');
    expect(processTree(10, samples).map((item) => item.pid)).toEqual([10, 11, 12]);
    expect(samples[0].rssBytes).toBe(1024 * 1024);
  });
  it('uses cumulative CPU deltas and permits more than one busy core', () => {
    expect(cpuPercent(1, 3, 1000)).toBe(200);
    expect(cpuPercent(3, 1, 1000)).toBeNull();
    expect(cpuPercent(1, 2, 0)).toBeNull();
  });
  it('does not attach an older Windows process to a reused parent PID', () => {
    const samples = [
      {pid: 10, ppid: 1, rssBytes: 1024, cpuSeconds: 1, identity: '134000000000000100'},
      {pid: 11, ppid: 10, rssBytes: 1024, cpuSeconds: 1, identity: '134000000000000099'},
      {pid: 12, ppid: 11, rssBytes: 1024, cpuSeconds: 1, identity: '134000000000000101'},
      {pid: 13, ppid: 10, rssBytes: 1024, cpuSeconds: 1, identity: '134000000000000101'},
    ];
    expect(processTree(10, samples).map(item => item.pid)).toEqual([10, 13]);
  });
  it('does not start a sampler timer and deduplicates simultaneous and rapid panel requests', async () => {
    vi.useFakeTimers();
    const read = vi.fn(async () => [{ pid: 10, ppid: 1, rssBytes: 1024, cpuSeconds: 1 }]);
    const sampler = new RuntimeResourceSampler(read);
    const connections = { getConnectionStats: () => ({ total: 3 }), getRuntimeSessions: () => [{ pid: 10, sessionId: 's', workingDir: '/project' }] } as unknown as ConnectionManager;
    expect(read).not.toHaveBeenCalled();
    const [first, duplicate] = await Promise.all([sampler.sample(connections), sampler.sample(connections)]);
    expect(read).toHaveBeenCalledOnce();
    expect(first).toEqual(duplicate); expect(first.cli[0].cpuPercent).toBeNull(); expect(first.cli[0].rssBytes).toBe(1024);
    await sampler.sample(connections); expect(read).toHaveBeenCalledOnce();
    await vi.advanceTimersByTimeAsync(10_000); expect(read).toHaveBeenCalledOnce();
    await sampler.sample(connections); expect(read).toHaveBeenCalledTimes(2);
  });
  it('reports unavailable CLI metrics while retaining actual backend memory', async () => {
    const sampler = new RuntimeResourceSampler(async () => { throw new Error('measurement unavailable'); });
    const connections = { getConnectionStats: () => ({ total: 3 }), getRuntimeSessions: () => [{ pid: 10, sessionId: 's', workingDir: '/project' }] } as unknown as ConnectionManager;
    const result = await sampler.sample(connections);
    expect(result.cli[0].cpuPercent).toBeNull(); expect(result.cli[0].rssBytes).toBeNull();
    expect(result.measurementError).toBe('measurement unavailable'); expect(result.backend.rssBytes).toBeGreaterThan(0);
  });

  it('passes only live CLI roots to the reader and does no scan when none exist', async () => {
    const read = vi.fn(async () => []);
    const empty = {getConnectionStats: () => ({total: 1}), getRuntimeSessions: () => []} as unknown as ConnectionManager;
    await new RuntimeResourceSampler(read).sample(empty);
    expect(read).not.toHaveBeenCalled();
    const active = {...empty, getRuntimeSessions: () => [{pid: 10, sessionId: 's', workingDir: '/project'}]} as unknown as ConnectionManager;
    await new RuntimeResourceSampler(read).sample(active);
    expect(read).toHaveBeenCalledWith([10]);
  });

  it('does not present a partial tree or an absent root as complete memory usage', async () => {
    const connections = {getConnectionStats: () => ({total: 1}), getRuntimeSessions: () => [{pid: 10, sessionId: 's', workingDir: '/project'}]} as unknown as ConnectionManager;
    const missingChild = new RuntimeResourceSampler(async () => [
      {pid: 10, ppid: 1, rssBytes: 1024, cpuSeconds: 1},
      {pid: 11, ppid: 10, rssBytes: null, cpuSeconds: null},
    ]);
    const partial = await missingChild.sample(connections);
    expect(partial.cli[0]).toMatchObject({rssBytes: null, cpuPercent: null, processCount: 2});
    const missingRoot = new RuntimeResourceSampler(async () => [{pid: 11, ppid: 10, rssBytes: 1024, cpuSeconds: 1}]);
    expect((await missingRoot.sample(connections)).cli[0].rssBytes).toBeNull();
  });

  it('starts a fresh CPU pair when Windows reuses a process ID', async () => {
    vi.useFakeTimers();
    const now = vi.spyOn(performance, 'now').mockReturnValue(1000);
    let identity = '100000000000000001';
    const read = vi.fn(async () => [{pid: 10, ppid: 1, rssBytes: 1024, cpuSeconds: 2, identity}]);
    const sampler = new RuntimeResourceSampler(read);
    const connections = {getConnectionStats: () => ({total: 1}), getRuntimeSessions: () => [{pid: 10, sessionId: 's', workingDir: '/project'}]} as unknown as ConnectionManager;
    await sampler.sample(connections);
    await vi.advanceTimersByTimeAsync(1100); now.mockReturnValue(2100);
    identity = '100000000000000002';
    expect((await sampler.sample(connections)).cli[0].cpuPercent).toBeNull();
    await vi.advanceTimersByTimeAsync(1100); now.mockReturnValue(3200);
    expect((await sampler.sample(connections)).cli[0].cpuPercent).toBe(0);
  });

  it('uses a fresh CPU sample pair after a hidden interval and refreshes connected view count on cached reads', async () => {
    vi.useFakeTimers();
    const now = vi.spyOn(performance, 'now').mockReturnValue(1000);
    const usage = vi.spyOn(process, 'cpuUsage').mockReturnValue({ user: 1_000_000, system: 0 });
    let cpuSeconds = 1;
    const read = vi.fn(async () => [{ pid: 10, ppid: 1, rssBytes: 1024, cpuSeconds }]);
    const sampler = new RuntimeResourceSampler(read);
    let views = 1;
    const connections = { getConnectionStats: () => ({ total: views }), getRuntimeSessions: () => [{ pid: 10, sessionId: 's', workingDir: '/project' }] } as unknown as ConnectionManager;
    const first = await sampler.sample(connections);
    expect(first.backend.cpuPercent).toBeNull(); expect(first.cli[0].cpuPercent).toBeNull();
    views = 3;
    expect((await sampler.sample(connections)).connectedViews).toBe(3);
    expect(read).toHaveBeenCalledOnce();
    await vi.advanceTimersByTimeAsync(2000); now.mockReturnValue(3000); usage.mockReturnValue({ user: 2_000_000, system: 0 }); cpuSeconds = 2;
    const second = await sampler.sample(connections);
    expect(second.backend.cpuPercent).toBe(50); expect(second.cli[0].cpuPercent).toBe(50);
    await vi.advanceTimersByTimeAsync(10_000); now.mockReturnValue(13_000); cpuSeconds = 10;
    const resumed = await sampler.sample(connections);
    expect(resumed.backend.cpuPercent).toBeNull(); expect(resumed.cli[0].cpuPercent).toBeNull();
    await vi.advanceTimersByTimeAsync(2000); now.mockReturnValue(15_000); usage.mockReturnValue({ user: 3_000_000, system: 0 }); cpuSeconds = 11;
    const freshPair = await sampler.sample(connections);
    expect(freshPair.backend.cpuPercent).toBe(50); expect(freshPair.cli[0].cpuPercent).toBe(50);
  });
});
