import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { reportBackendError } from '../features/telemetry';

/**
 * Receives the CLIENT_ERROR sent by the webview's (React) single error boundary and hands it to
 * the backend's single error reporting point (reportBackendError) (the frontend boundary →
 * backend transport of the 3-layer error boundary model), which logs it locally.
 *
 * payload: { message, stack?, componentStack?, source? }
 *   - source: which frontend hook caught it, e.g. 'render' | 'window.onerror' | 'unhandledrejection'
 *     (original preserved — put into the context as-is, without renaming/filtering).
 */
export function clientErrorHandler(
  _connectionId: string,
  message: IPCMessage,
  _connections: ConnectionManager,
  _bridge: Bridge,
): void {
  const payload = message.payload ?? {};
  const text = typeof payload.message === 'string' ? payload.message : 'Unknown client error';
  const error = new Error(text);
  // Carry the webview's own stack rather than this handler's synthetic one.
  if (typeof payload.stack === 'string' && payload.stack.length > 0) {
    error.stack = payload.stack;
  }

  const context: Record<string, string> = { origin: 'webview', layer: 'frontend' };
  if (typeof payload.componentStack === 'string' && payload.componentStack.length > 0) {
    context.componentStack = payload.componentStack;
  }
  if (typeof payload.source === 'string' && payload.source.length > 0) {
    context.source = payload.source;
  }

  reportBackendError(error, context);
}
