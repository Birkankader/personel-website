import { spawn, type ChildProcessByStdio } from 'node:child_process';
import { existsSync } from 'node:fs';
import { win32 } from 'node:path';
import type { Readable, Writable } from 'node:stream';
import { CONNECTION_ENV_KEYS, type ConnectionEnv, type ConnectionEnvKey } from '../../shared/connection-settings';
import { jobHelperPath } from '../win-job';

// Two programs answer the same request the same way: the native helper
// (`ai-bridge-job.exe --user-env`, backend/native/win-job/src/user_env.rs) when it
// is shipped, and this PowerShell script as its fallback. Every chat launch waits
// for the read at backend start, and the helper takes ~20 ms where a PowerShell
// cold start takes a second or more.
//
// Only fixed arguments go in argv. Values travel as base64 UTF-8 JSON over stdin,
// never through cmd.exe, PowerShell interpolation, logs or a temp file.
const SCRIPT = `
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
try {
  $request = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String([Console]::In.ReadToEnd())) | ConvertFrom-Json
  $keys = @('ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL', 'ANTHROPIC_MODEL')
  if ($null -ne $request.key) {
    if ($keys -cnotcontains $request.key) { throw 'Invalid key' }
    [Environment]::SetEnvironmentVariable($request.key, [string]$request.value, 'User')
  }
  $values = @{}; $machine = @{}
  foreach ($key in $keys) {
    $values[$key] = [Environment]::GetEnvironmentVariable($key, 'User')
    $machine[$key] = [Environment]::GetEnvironmentVariable($key, 'Machine')
  }
  @{ values = $values; machine = $machine } | ConvertTo-Json -Compress
} catch { [Console]::Error.Write('Windows user environment operation failed.'); exit 1 }
`;

interface Snapshot {
  values: Record<ConnectionEnvKey, string | null>;
  machine: Record<ConnectionEnvKey, string | null>;
}

type Request = { key?: ConnectionEnvKey; value?: string };

const FAILED = 'Windows user environment operation failed.';

/** The program never did its work: it did not start, or died before it could
 * answer. Both programs end a failed operation with exit 1 instead. */
class ProgramUnavailable extends Error {}

/** Set when the helper could not run once; this backend then keeps to PowerShell. */
let helperUnavailable = false;

function run(request: Request): Promise<Snapshot> {
  const powershell = () => runProgram(
    win32.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe'),
    ['-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(SCRIPT, 'utf16le').toString('base64')],
    request,
  );
  const helper = jobHelperPath();
  if (helperUnavailable || !existsSync(helper)) return powershell();
  // Application control or an antivirus can refuse the unsigned exe; the same
  // request then goes to PowerShell, which a write repeats harmlessly.
  return runProgram(helper, ['--user-env'], request).catch((error: unknown) => {
    if (!(error instanceof ProgramUnavailable)) throw error;
    helperUnavailable = true;
    console.error('[node-backend]', 'User environment helper could not run — using PowerShell');
    return powershell();
  });
}

function runProgram(executable: string, args: string[], request: Request): Promise<Snapshot> {
  let child: ChildProcessByStdio<Writable, Readable, Readable>;
  try {
    child = spawn(executable, args, {
      shell: false, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'],
    });
  } catch {
    // Node throws, instead of emitting 'error', for some refusals: an image
    // Windows cannot load, or one a policy blocks.
    return Promise.reject(new ProgramUnavailable(FAILED));
  }
  return new Promise((resolve, reject) => {
    let output = '';
    let settled = false;
    let started = false;
    const fail = (error = new Error(FAILED)) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      child.kill();
      reject(error);
    };
    const timer = setTimeout(fail, 15_000);
    child.on('spawn', () => { started = true; });
    child.on('error', () => fail(started ? undefined : new ProgramUnavailable(FAILED)));
    // A broken pipe means the program has ended or is ending: its exit code decides.
    child.stdin.on('error', () => {});
    child.stderr.resume(); // Never expose diagnostics that might contain a value.
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', chunk => {
      output += chunk;
      if (output.length > 512_000) fail();
    });
    child.on('close', code => {
      if (settled) return;
      if (code !== 0) return fail(code === 1 ? undefined : new ProgramUnavailable(FAILED));
      try {
        const parsed = JSON.parse(output.replace(/^\uFEFF/, '').trim()) as Snapshot;
        for (const group of [parsed.values, parsed.machine]) {
          for (const key of CONNECTION_ENV_KEYS) {
            if (!group || (group[key] !== null && typeof group[key] !== 'string')) throw new Error();
          }
        }
        settled = true;
        clearTimeout(timer);
        resolve(parsed);
      } catch { fail(); }
    });
    child.stdin.end(Buffer.from(JSON.stringify(request), 'utf8').toString('base64'));
  });
}

let queue: Promise<unknown> = Promise.resolve();
const managedKeys = new Set<ConnectionEnvKey>();
function transact(request: Request): Promise<ConnectionEnv> {
  const next = queue.then(async () => {
    const snapshot = await run(request);
    if (request.key) managedKeys.add(request.key);
    for (const key of CONNECTION_ENV_KEYS) {
      if (snapshot.values[key] !== null) managedKeys.add(key);
      if (!managedKeys.has(key)) continue; // Preserve intentionally inherited process-only values.
      const value = snapshot.values[key] ?? snapshot.machine[key];
      if (value === null) delete process.env[key];
      else process.env[key] = value;
    }
    return Object.fromEntries(CONNECTION_ENV_KEYS.map(key => [key, snapshot.values[key] ?? ''])) as ConnectionEnv;
  });
  queue = next.catch(() => {});
  return next;
}

export async function getWindowsUserEnv() {
  if (process.platform !== 'win32') return { supported: false as const };
  return { supported: true as const, values: await transact({}) };
}

export async function saveWindowsUserEnv(key: unknown, value: unknown): Promise<void> {
  if (process.platform !== 'win32') throw new Error('Windows is required.');
  if (!CONNECTION_ENV_KEYS.includes(key as ConnectionEnvKey) || typeof value !== 'string' || value.length > 32760 || /[\0\r\n]/.test(value)) {
    throw new Error('Invalid environment variable.');
  }
  await transact({ key: key as ConnectionEnvKey, value });
}

/** Refresh once at backend startup/settings reload; saving also updates this
 * backend immediately. Running CLI processes keep their launch environment. */
export async function refreshWindowsUserEnv(): Promise<void> {
  if (process.platform !== 'win32') return;
  try { await transact({}); }
  catch { console.error('[node-backend]', 'Could not refresh Windows user environment.'); }
}
