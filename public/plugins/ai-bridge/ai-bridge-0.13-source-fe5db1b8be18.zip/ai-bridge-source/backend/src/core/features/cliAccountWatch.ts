import { watch, type FSWatcher } from 'fs';
import { readFile } from 'fs/promises';
import { basename, dirname } from 'path';

/**
 * Notice when the account the Claude CLI is signed in with changes, so the
 * catalogue loaded under the previous one (models, commands) is read again.
 *
 * A login, logout or account switch — `claude auth login` or `/login` in a
 * terminal, or `ai-bridge account` — rewrites the `oauthAccount` entry of the
 * CLI's global config file (`.claude.json`), the entry the account manager
 * already reads (`live-credentials.ts`). The CLI rewrites that file far more
 * often than that, so only a change of the account it names counts.
 *
 * This replaced running `claude auth status` from every open page at startup and
 * on every window focus, which nothing showed and which served only this check.
 * Best effort: a change this misses leaves the catalogue to its next load (the
 * 30-second cache in loadCliConfig, or /reload).
 *
 * The backend watches the file itself, as it does the CLI's settings files: the
 * file belongs to the CLI on this machine, not to a project the IDE tracks.
 */

const DEBOUNCE_MS = 500;

interface AccountWatch {
  watcher: FSWatcher;
  timer: NodeJS.Timeout | null;
  /** The account last read; undefined until a read succeeds. */
  account: string | null | undefined;
}

const watches = new Map<string, AccountWatch>();
const listeners = new Set<() => void>();

/**
 * Which account the config file names: null when none is signed in, undefined
 * when the file could not be read (caught mid-write), so nothing is concluded.
 */
async function readSignedInAccount(configFile: string): Promise<string | null | undefined> {
  let text: string;
  try {
    text = await readFile(configFile, 'utf8');
  } catch (err) {
    return (err as NodeJS.ErrnoException).code === 'ENOENT' ? null : undefined;
  }
  let root: unknown;
  try {
    root = JSON.parse(text);
  } catch {
    return undefined;
  }
  const account = (root as { oauthAccount?: unknown } | null)?.oauthAccount;
  if (!account || typeof account !== 'object' || Array.isArray(account)) return null;
  // The fields that name the account and its organisation. The profile details
  // stored next to them are refreshed in place and do not make it another account.
  const { accountUuid, emailAddress, organizationUuid } = account as Record<string, unknown>;
  const named = [accountUuid, emailAddress, organizationUuid];
  return named.some((value) => typeof value === 'string') ? JSON.stringify(named) : JSON.stringify(account);
}

/** Same file name, folding case where the file system does. */
function sameName(candidate: string, name: string): boolean {
  return process.platform === 'win32' || process.platform === 'darwin'
    ? candidate.toLowerCase() === name.toLowerCase()
    : candidate === name;
}

/**
 * Watch the CLI global config file [configFile] for a change of the signed-in
 * account. Once per file: every catalogue load names the file for its config
 * directory, and a project may use its own (`CLAUDE_CONFIG_DIR`).
 */
export function watchCliAccount(configFile: string): void {
  if (watches.has(configFile)) return;
  const name = basename(configFile);

  let entry: AccountWatch;
  const check = async (): Promise<void> => {
    const account = await readSignedInAccount(configFile);
    if (account === undefined || watches.get(configFile) !== entry) return;
    const previous = entry.account;
    entry.account = account;
    if (previous === undefined || previous === account) return;
    console.error('[node-backend]', `The Claude CLI account changed (${configFile})`);
    for (const listener of listeners) {
      try {
        listener();
      } catch (err) {
        console.error('[node-backend]', 'A CLI account listener threw:', err);
      }
    }
  };

  try {
    // The directory, not the file: the CLI may replace the file by renaming a
    // new one over it, and a watch on the file would stay on the replaced one.
    const watcher = watch(dirname(configFile), { persistent: false }, (_event, filename) => {
      // Some platforms report no name; then any event might be this file.
      if (filename && !sameName(String(filename), name)) return;
      if (entry.timer) clearTimeout(entry.timer);
      entry.timer = setTimeout(() => {
        entry.timer = null;
        void check();
      }, DEBOUNCE_MS);
    });
    watcher.on('error', (err) => {
      console.error('[node-backend]', `Stopped watching ${configFile} for account changes:`, err);
    });
    entry = { watcher, timer: null, account: undefined };
  } catch (err) {
    console.error('[node-backend]', `Could not watch ${configFile} for account changes:`, err);
    return;
  }
  watches.set(configFile, entry);
  void readSignedInAccount(configFile).then((account) => {
    if (entry.account === undefined) entry.account = account;
  });
}

/** Call [listener] whenever a watched file names another account. Returns a function that stops it. */
export function onCliAccountChanged(listener: () => void): () => void {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

/** Stop every watch (shutdown, tests). Listeners stay registered. */
export function stopCliAccountWatches(): void {
  for (const entry of watches.values()) {
    if (entry.timer) clearTimeout(entry.timer);
    entry.watcher.close();
  }
  watches.clear();
}
