import { describe, it, expect, vi, beforeEach } from 'vitest';

vi.mock('../../features/settings', () => ({
  readMergedSettings: vi.fn(),
  readSettingsFile: vi.fn(),
  readProjectSettings: vi.fn(),
  getSettingsFileProblem: vi.fn(),
  refreshSettingsFileProblem: vi.fn(),
}));
vi.mock('../../features/settings-watcher', () => ({
  getSettingsWatcher: vi.fn(() => undefined),
}));
vi.mock('../../../config/environment', () => ({
  clientInfo: 'IntelliJ IDEA 2024.1.4 (IC-241.18034.62)',
}));

import { getSettingsHandler, parseIdeProductName } from '../getSettings';
import { readMergedSettings, readProjectSettings, getSettingsFileProblem, refreshSettingsFileProblem } from '../../features/settings';
import { MessageType, ClientEnv } from '../../../shared';
import type { ConnectionManager } from '../../../ws/connection-manager';
import type { Bridge } from '../../../bridge/bridge-interface';
import type { IPCMessage } from '../../types';

function createMockConnections() {
  return {
    sendTo: vi.fn(),
  } as unknown as ConnectionManager;
}

function createBridges(jetbrainsConnected: boolean | undefined): Record<ClientEnv, Bridge> {
  const jetbrains = jetbrainsConnected === undefined
    ? ({} as Bridge)
    : ({ isConnected: () => jetbrainsConnected } as unknown as Bridge);
  return {
    [ClientEnv.BROWSER]: {} as Bridge,
    [ClientEnv.JETBRAINS]: jetbrains,
  };
}

describe('getSettingsHandler', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(readMergedSettings).mockResolvedValue({ settings: {}, overrides: [] });
  });

  it('acks with ideAttached=true and ideProduct parsed from the client info when the JetBrains bridge is connected', async () => {
    const connections = createMockConnections();
    const bridges = createBridges(true);
    const message: IPCMessage = {
      type: MessageType.GET_SETTINGS,
      payload: {},
      timestamp: 0,
      requestId: 'req-1',
    };

    await getSettingsHandler('conn-1', message, connections, {} as Bridge, bridges);

    expect(connections.sendTo).toHaveBeenCalledWith(
      'conn-1',
      MessageType.ACK,
      expect.objectContaining({
        requestId: 'req-1',
        ideAttached: true,
        ideProduct: 'IntelliJ IDEA',
      }),
    );
  });

  it('acks with ideAttached=false when the JetBrains bridge is not connected', async () => {
    const connections = createMockConnections();
    const bridges = createBridges(false);
    const message: IPCMessage = {
      type: MessageType.GET_SETTINGS,
      payload: {},
      timestamp: 0,
      requestId: 'req-2',
    };

    await getSettingsHandler('conn-1', message, connections, {} as Bridge, bridges);

    expect(connections.sendTo).toHaveBeenCalledWith(
      'conn-1',
      MessageType.ACK,
      expect.objectContaining({ ideAttached: false }),
    );
  });

  it('acks with ideAttached=false when the bridge lacks isConnected (browser mode)', async () => {
    const connections = createMockConnections();
    const bridges = createBridges(undefined);
    const message: IPCMessage = {
      type: MessageType.GET_SETTINGS,
      payload: {},
      timestamp: 0,
      requestId: 'req-3',
    };

    await getSettingsHandler('conn-1', message, connections, {} as Bridge, bridges);

    expect(connections.sendTo).toHaveBeenCalledWith(
      'conn-1',
      MessageType.ACK,
      expect.objectContaining({ ideAttached: false }),
    );
  });
});

describe('getSettingsHandler settings file status', () => {
  const problem = {
    filePath: '/home/u/.ai-bridge/settings.js',
    reason: 'Unexpected end of JSON input',
  };

  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(readMergedSettings).mockResolvedValue({ settings: {}, overrides: [] });
    vi.mocked(refreshSettingsFileProblem).mockResolvedValue(null);
  });

  it('sends the problem after the ACK when the global file is unreadable', async () => {
    vi.mocked(getSettingsFileProblem).mockReturnValue(problem);
    const connections = createMockConnections();
    const message: IPCMessage = { type: MessageType.GET_SETTINGS, payload: {}, timestamp: 0, requestId: 'req-4' };

    await getSettingsHandler('conn-1', message, connections, {} as Bridge, createBridges(false));

    expect(connections.sendTo).toHaveBeenCalledWith('conn-1', MessageType.SETTINGS_FILE_STATUS, {
      unreadable: true,
      filePath: problem.filePath,
      reason: problem.reason,
    });
    // The webview's subscription must be in place before the notice, so the ACK
    // goes first and the tab only sees a warning it can act on.
    const calls = vi.mocked(connections.sendTo).mock.calls;
    const ackIndex = calls.findIndex(([, type]) => type === MessageType.ACK);
    const statusIndex = calls.findIndex(([, type]) => type === MessageType.SETTINGS_FILE_STATUS);
    expect(ackIndex).toBeLessThan(statusIndex);
  });

  it('withdraws the notice with unreadable: false when the file reads fine', async () => {
    vi.mocked(getSettingsFileProblem).mockReturnValue(null);
    const connections = createMockConnections();
    const message: IPCMessage = { type: MessageType.GET_SETTINGS, payload: {}, timestamp: 0, requestId: 'req-5' };

    await getSettingsHandler('conn-1', message, connections, {} as Bridge, createBridges(false));

    expect(connections.sendTo).toHaveBeenCalledWith('conn-1', MessageType.SETTINGS_FILE_STATUS, { unreadable: false });
  });

  it('refreshes the global file state for a project-scope read, which never touches it', async () => {
    vi.mocked(readProjectSettings).mockResolvedValue({});
    const connections = createMockConnections();
    const message: IPCMessage = {
      type: MessageType.GET_SETTINGS,
      payload: { scope: 'project', workingDir: '/project' },
      timestamp: 0,
      requestId: 'req-6',
    };

    await getSettingsHandler('conn-1', message, connections, {} as Bridge, createBridges(false));

    expect(refreshSettingsFileProblem).toHaveBeenCalledTimes(1);
  });
});

describe('parseIdeProductName', () => {
  it('extracts the product name from a version-and-build suffix', () => {
    expect(parseIdeProductName('WebStorm 2024.1.4 (WS-241.18034.62)')).toBe('WebStorm');
    expect(parseIdeProductName('IntelliJ IDEA 2024.1 (IC-241.14494.240)')).toBe('IntelliJ IDEA');
  });

  it('returns an empty string for empty input', () => {
    expect(parseIdeProductName('')).toBe('');
  });
});
