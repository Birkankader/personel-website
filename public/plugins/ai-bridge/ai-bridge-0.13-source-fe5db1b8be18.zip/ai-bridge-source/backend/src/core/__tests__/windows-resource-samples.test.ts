import {afterEach, beforeEach, describe, expect, it, vi} from 'vitest';
import {existsSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {parseWindowsResourceSamples, readWindowsResourceSamples} from '../windows-resource-samples';

const transport = vi.hoisted(() => ({exec: vi.fn()}));
vi.mock('node:child_process', async importOriginal => {
  const actual = await importOriginal<typeof import('node:child_process')>();
  const {promisify} = await import('node:util');
  const execFile = Object.assign(vi.fn(), {[promisify.custom]: transport.exec});
  return {...actual, execFile};
});
vi.mock('node:fs', async importOriginal => ({
  ...await importOriginal<typeof import('node:fs')>(), existsSync: vi.fn(() => false),
}));
beforeEach(() => {transport.exec.mockReset(); vi.mocked(existsSync).mockReturnValue(false);});
afterEach(() => {vi.restoreAllMocks(); vi.unstubAllEnvs();});

describe('Windows resource snapshots', () => {
  const row = {pid: 10, ppid: 1, rssBytes: 123456, cpuSeconds: 1.2345678, identity: '134066493210123456'};
  it('preserves byte units, sub-second CPU and exact process identity', () => {
    expect(parseWindowsResourceSamples('\uFEFF' + JSON.stringify([row]))).toEqual([row]);
  });
  it('retains unreadable process links without inventing zero usage', () => {
    expect(parseWindowsResourceSamples(JSON.stringify([{...row, rssBytes: null, cpuSeconds: null, identity: null}]))).toEqual([
      {pid: 10, ppid: 1, rssBytes: null, cpuSeconds: null},
    ]);
  });
  it.each([
    {...row, rssBytes: -1}, {...row, rssBytes: 0.5}, {...row, cpuSeconds: '1'}, {...row, pid: 1.5},
    {...row, ppid: 0x1_0000_0000}, {...row, identity: 134066493210123456},
  ])('rejects malformed counters (%j)', value => {
    expect(() => parseWindowsResourceSamples(JSON.stringify([value]))).toThrow('Invalid Windows');
  });
  it('accepts an empty process snapshot but rejects a non-array', () => {
    expect(parseWindowsResourceSamples('[]')).toEqual([]);
    expect(() => parseWindowsResourceSamples('{}')).toThrow('Invalid Windows');
  });
  it('does no work without active CLI roots', async () => {
    expect(await readWindowsResourceSamples([], 'nonexistent-helper')).toEqual([]);
  });
  it('reports a missing helper explicitly without falling back to a persistent process', async () => {
    await expect(readWindowsResourceSamples([10], join(tmpdir(), 'ai-bridge-absent-helper', 'absent.exe')))
      .rejects.toThrow('requires the bundled native helper');
  });
  it('rejects invalid root IDs before starting any process', async () => {
    await expect(readWindowsResourceSamples([0], 'unused')).rejects.toThrow('Invalid process roots');
    await expect(readWindowsResourceSamples([NaN], 'unused')).rejects.toThrow('Invalid process roots');
    expect(transport.exec).not.toHaveBeenCalled();
  });
  it('runs one hidden bounded helper for selected roots and preserves its counters', async () => {
    vi.mocked(existsSync).mockReturnValue(true);
    vi.stubEnv('AI_BRIDGE_JOB_CMDLINE', 'echo never-run-a-cli-for-a-resource-read');
    transport.exec.mockResolvedValue({stdout: JSON.stringify([row]), stderr: ''});
    expect(await readWindowsResourceSamples([10, 10], 'helper.exe')).toEqual([row]);
    expect(transport.exec.mock.calls.length).toBe(1);
    const [file, args, options] = transport.exec.mock.calls[0];
    expect(file).toBe('helper.exe');
    expect(args).toEqual(['--resources', '10']);
    // Never include the inherited environment in assertion output.
    expect({windowsHide: options.windowsHide, timeout: options.timeout, maxBuffer: options.maxBuffer, encoding: options.encoding}).toEqual({
      windowsHide: true, timeout: 1500, maxBuffer: 1024 * 1024, encoding: 'utf8',
    });
    expect(Object.keys(options.env).some(name => name.toUpperCase() === 'AI_BRIDGE_JOB_CMDLINE')).toBe(false);
  });
  it('reports failed or outdated helpers without starting a PowerShell fallback', async () => {
    vi.mocked(existsSync).mockReturnValue(true);
    transport.exec.mockRejectedValue(new Error('helper blocked'));
    await expect(readWindowsResourceSamples([10], 'helper.exe')).rejects.toThrow('measurement failed');
    expect(transport.exec).toHaveBeenCalledTimes(1);
  });
});
