import {execFile} from 'node:child_process';
import {existsSync} from 'node:fs';
import {promisify} from 'node:util';
import {jobHelperPath} from './win-job';
import type {ProcessSample} from './features/runtime-resources';

const exec = promisify(execFile);
const nonnegative = (value: unknown): value is number => typeof value === 'number' && Number.isFinite(value) && value >= 0;
const pid = (value: unknown): value is number => nonnegative(value) && Number.isInteger(value) && value <= 0xffff_ffff;

export function parseWindowsResourceSamples(output: string): ProcessSample[] {
  const rows: unknown = JSON.parse(output.replace(/^\uFEFF/, '').trim());
  if (!Array.isArray(rows)) throw new Error('Invalid Windows process resource snapshot.');
  return rows.map(row => {
    if (!row || typeof row !== 'object') throw new Error('Invalid Windows process resource snapshot.');
    const sample = row as Record<string, unknown>;
    if (!pid(sample.pid) || !pid(sample.ppid) ||
      !(sample.rssBytes === null || (nonnegative(sample.rssBytes) && Number.isSafeInteger(sample.rssBytes))) ||
      !(sample.cpuSeconds === null || nonnegative(sample.cpuSeconds)) ||
      !(sample.identity === null || (typeof sample.identity === 'string' && /^\d{1,20}$/.test(sample.identity)))) {
      throw new Error('Invalid Windows process resource snapshot.');
    }
    return {pid: sample.pid, ppid: sample.ppid, rssBytes: sample.rssBytes, cpuSeconds: sample.cpuSeconds,
      ...(typeof sample.identity === 'string' ? {identity: sample.identity} : {})};
  });
}

/** The resource panel owns polling; this reader starts no timers or persistent helper. */
export async function readWindowsResourceSamples(roots: number[], helper = jobHelperPath()): Promise<ProcessSample[]> {
  if (!roots.length) return [];
  if (roots.length > 128 || roots.some(root => !pid(root) || root === 0)) throw new Error('Invalid process roots.');
  if (!existsSync(helper)) throw new Error('Windows CLI resource measurement requires the bundled native helper.');
  // Older helpers treat an unknown switch as a chat session ID. Never let a
  // read-only scan inherit a launch payload, even if one exists in the host env.
  const env = Object.fromEntries(Object.entries(process.env).filter(([name]) => name.toUpperCase() !== 'AI_BRIDGE_JOB_CMDLINE'));
  try {
    const {stdout} = await exec(helper, ['--resources', ...new Set(roots.map(String))], {
      windowsHide: true, timeout: 1500, maxBuffer: 1024 * 1024, encoding: 'utf8', env,
    });
    return parseWindowsResourceSamples(stdout);
  } catch {
    // Keep missing/blocked/old helpers visibly unavailable. Starting PowerShell
    // on every panel refresh would make measurement itself expensive.
    throw new Error('Windows CLI resource measurement failed. Check the bundled native helper.');
  }
}
