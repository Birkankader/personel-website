import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { MessageType } from '../../shared';
import {
  reconnectMcpServer,
  setMcpServerEnabled,
  addMcpServer,
  removeMcpServer,
  logoutMcpServer,
} from '../features/mcp-manager';
import { cancelMcpLogin, startMcpLogin, submitMcpLoginCallbackUrl } from '../features/mcp-login';
import { searchMcpRegistry } from '../features/mcp-registry';

// ─── Helpers ──────────────────────────────────────────────────────────────────

function ack(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  payload: Record<string, unknown>,
): Promise<void> {
  return connections.sendTo(connectionId, MessageType.ACK, {
    requestId: message.requestId,
    ...payload,
  });
}

function getStringPayload(message: IPCMessage, key: string): string | null {
  const val = (message.payload as Record<string, unknown>)?.[key];
  return typeof val === 'string' && val.trim() ? val.trim() : null;
}

function errorMessage(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}

/** The first of `values` that is a string with something other than whitespace in it, trimmed. */
function firstNonEmpty(...values: unknown[]): string | undefined {
  for (const value of values) {
    if (typeof value === 'string' && value.trim() !== '') return value.trim();
  }
  return undefined;
}

// ─── RECONNECT_MCP_SERVER ─────────────────────────────────────────────────────

/**
 * Re-fetch a server via `claude mcp get <name>`. The CLI health-checks the
 * connection when invoked, so re-running it serves as a CLI-first reconnect probe.
 */
export async function reconnectMcpServerHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const name = getStringPayload(message, 'name');
  if (!name) {
    return ack(connectionId, message, connections, { status: 'error', error: 'Missing name' });
  }
  try {
    const server = await reconnectMcpServer(name, getStringPayload(message, 'workingDir') ?? undefined);
    await ack(connectionId, message, connections, { status: 'ok', server });
  } catch (err) {
    await ack(connectionId, message, connections, {
      status: 'error',
      error: err instanceof Error ? err.message : String(err),
    });
  }
}

// ─── AUTHENTICATE_MCP_SERVER ──────────────────────────────────────────────────

/**
 * Sign in to an MCP server by running the official `claude mcp login --no-browser
 * <name>` in a pseudo-terminal (see features/mcp-login.ts).
 * Payload: { name: string, workingDir?: string }
 *
 * ACKs at once with McpAuthenticateResponse: `started`, or `terminal-required` with the
 * command to run by hand when no PTY is available here. A sign-in takes minutes, so its
 * progress is not this ACK: it arrives as MCP_SERVER_AUTHENTICATION_STATUS pushes to
 * this connection.
 */
export async function authenticateMcpServerHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const name = getStringPayload(message, 'name');
  if (!name) {
    return ack(connectionId, message, connections, { status: 'error', error: 'Missing name' });
  }
  try {
    const answer = await startMcpLogin({
      connectionId,
      name,
      workingDir: getStringPayload(message, 'workingDir') ?? undefined,
      onUpdate: (update) => {
        // Progress is best effort: the tab may be gone by the time the CLI says something.
        void Promise.resolve(
          connections.sendTo(connectionId, MessageType.MCP_SERVER_AUTHENTICATION_STATUS, update as unknown as Record<string, unknown>),
        ).catch(() => undefined);
      },
    });
    await ack(connectionId, message, connections, answer);
  } catch (err) {
    await ack(connectionId, message, connections, { status: 'error', error: errorMessage(err) });
  }
}

// ─── CANCEL_MCP_SERVER_AUTHENTICATION ─────────────────────────────────────────

/**
 * Cancel this connection's running `claude mcp login` for a server.
 * Payload: { name: string }. ACK: { status: 'ok', cancelled: boolean }.
 */
export async function cancelMcpServerAuthenticationHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const name = getStringPayload(message, 'name');
  if (!name) {
    return ack(connectionId, message, connections, { status: 'error', error: 'Missing name' });
  }
  await ack(connectionId, message, connections, { status: 'ok', cancelled: cancelMcpLogin(connectionId, name) });
}

// ─── CLEAR_MCP_SERVER_AUTH ────────────────────────────────────────────────────

/**
 * Sign out of an MCP server with the official `claude mcp logout <name>`, which
 * clears its saved OAuth credentials exactly as it does for a terminal user.
 * Payload: { name: string, workingDir?: string }
 *
 * ACK: { status: 'ok', name, output } with the CLI's own message, or
 * { status: 'error', error } with what the CLI said (stderr, then stdout).
 */
export async function clearMcpServerAuthHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const name = getStringPayload(message, 'name');
  if (!name) {
    return ack(connectionId, message, connections, { status: 'error', error: 'Missing name' });
  }
  try {
    const output = await logoutMcpServer(name, getStringPayload(message, 'workingDir') ?? undefined);
    await ack(connectionId, message, connections, { status: 'ok', name, output });
  } catch (err) {
    const failed = err as { stderr?: unknown; stdout?: unknown };
    await ack(connectionId, message, connections, {
      status: 'error',
      error: firstNonEmpty(failed?.stderr, failed?.stdout) ?? errorMessage(err),
    });
  }
}

// ─── SET_MCP_SERVER_ENABLED ───────────────────────────────────────────────────

/**
 * Enable or disable a named MCP server by editing disabledMcpServers in ~/.claude.json.
 * No CLI command exists for this — CLI users also edit the file directly.
 */
export async function setMcpServerEnabledHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const name = getStringPayload(message, 'name');
  const enabled = (message.payload as Record<string, unknown>)?.enabled;
  if (!name) {
    return ack(connectionId, message, connections, { status: 'error', error: 'Missing name' });
  }
  if (typeof enabled !== 'boolean') {
    return ack(connectionId, message, connections, {
      status: 'error',
      error: 'Missing or invalid enabled (must be boolean)',
    });
  }
  try {
    await setMcpServerEnabled(name, enabled);
    await ack(connectionId, message, connections, { status: 'ok', name, enabled });
  } catch (err) {
    await ack(connectionId, message, connections, {
      status: 'error',
      error: err instanceof Error ? err.message : String(err),
    });
  }
}

// ─── SUBMIT_MCP_OAUTH_CALLBACK_URL ───────────────────────────────────────────

/**
 * Paste the redirect URL into the running `claude mcp login` for a server, for when
 * the browser could not reach the CLI's own loopback listener (remote backend).
 * Payload: { name: string, callbackUrl: string }
 *
 * `callbackUrl` is read as sent and validated by the login module, which is the one
 * place that decides what may be typed into the terminal. ACK: { status: 'ok' } or
 * { status: 'error', error }. What the CLI makes of the URL follows as
 * MCP_SERVER_AUTHENTICATION_STATUS.
 */
export async function submitMcpOauthCallbackUrlHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const name = getStringPayload(message, 'name');
  const callbackUrl = (message.payload as Record<string, unknown> | undefined)?.callbackUrl;
  if (!name) {
    return ack(connectionId, message, connections, { status: 'error', error: 'Missing name' });
  }
  if (typeof callbackUrl !== 'string' || callbackUrl === '') {
    return ack(connectionId, message, connections, { status: 'error', error: 'Missing callbackUrl' });
  }
  await ack(connectionId, message, connections, submitMcpLoginCallbackUrl(connectionId, name, callbackUrl));
}

// ─── ADD_MCP_SERVER (Phase 3) ─────────────────────────────────────────────────

/**
 * Add a new MCP server via `claude mcp add-json`.
 * Payload: { name: string, config: object, scope: 'user' | 'project' | 'local' }
 */
export async function addMcpServerHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const payload = message.payload as Record<string, unknown>;
  const name = typeof payload?.name === 'string' ? payload.name.trim() : '';
  const config = payload?.config as Record<string, unknown> | undefined;
  const scope = typeof payload?.scope === 'string' ? payload.scope : 'user';

  if (!name) {
    return ack(connectionId, message, connections, { status: 'error', error: 'Missing name' });
  }
  if (!config || typeof config !== 'object') {
    return ack(connectionId, message, connections, {
      status: 'error',
      error: 'Missing or invalid config',
    });
  }
  try {
    await addMcpServer(name, config, scope, getStringPayload(message, 'workingDir') ?? undefined);
    await ack(connectionId, message, connections, { status: 'ok', name });
  } catch (err) {
    await ack(connectionId, message, connections, {
      status: 'error',
      error: err instanceof Error ? err.message : String(err),
    });
  }
}

// ─── SEARCH_MCP_REGISTRY ──────────────────────────────────────────────────────

/**
 * Search the official MCP registry for installable servers.
 * Payload: { query: string, cursor?: string }
 *
 * CLI-equivalence note: `claude mcp` has no `search` subcommand, so this is a
 * GUI-only capability backed by the registry's PUBLIC REST API (not the Claude
 * SDK). Installation still goes through `claude mcp add-json` (ADD_MCP_SERVER).
 */
export async function searchMcpRegistryHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const payload = message.payload as Record<string, unknown>;
  const query = typeof payload?.query === 'string' ? payload.query : '';
  const cursor = typeof payload?.cursor === 'string' ? payload.cursor : undefined;
  try {
    const result = await searchMcpRegistry(query, cursor);
    await ack(connectionId, message, connections, { status: 'ok', ...result });
  } catch (err) {
    await ack(connectionId, message, connections, {
      status: 'error',
      error: err instanceof Error ? err.message : String(err),
    });
  }
}

// ─── REMOVE_MCP_SERVER (Phase 3) ──────────────────────────────────────────────

/**
 * Remove a named MCP server via `claude mcp remove`.
 * Payload: { name: string, scope: 'user' | 'project' | 'local' | 'claudeai' }
 */
export async function removeMcpServerHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const name = getStringPayload(message, 'name');
  const scope =
    typeof (message.payload as Record<string, unknown>)?.scope === 'string'
      ? ((message.payload as Record<string, unknown>).scope as string)
      : 'user';

  if (!name) {
    return ack(connectionId, message, connections, { status: 'error', error: 'Missing name' });
  }
  try {
    await removeMcpServer(name, scope, getStringPayload(message, 'workingDir') ?? undefined);
    await ack(connectionId, message, connections, { status: 'ok', name });
  } catch (err) {
    await ack(connectionId, message, connections, {
      status: 'error',
      error: err instanceof Error ? err.message : String(err),
    });
  }
}
