import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { markSessionAsSpawned } from '../claude-process';
import { MessageType } from '../../shared';
import { loadAndSendSession } from './loadAndSendSession';

export async function loadSessionHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const workingDir = message.payload?.workingDir as string | undefined;
  const sessionId = message.payload?.sessionId as string;

  if (!workingDir) {
    await connections.sendTo(connectionId, MessageType.ERROR, {
      requestId: message.requestId,
      error: 'workingDir is required',
    });
    return;
  }

  if (sessionId) {
    // Loading an existing session → mark it so the next spawn uses --resume
    markSessionAsSpawned(sessionId);
    connections.subscribe(connectionId, sessionId, workingDir);
    
    const beforeUuid = message.payload?.beforeUuid as string | undefined;
    const limit = message.payload?.limit as number | undefined;
    const isOlderPage = message.type === MessageType.LOAD_OLDER_MESSAGES;

    try {
      await loadAndSendSession(connectionId, connections, workingDir, sessionId, {
        beforeUuid,
        limit,
        isOlderPage,
      });
    } catch (err) {
      // The transcript could not be read: tell the caller instead of ACKing an
      // empty history it would take for a real one.
      console.error('[node-backend]', 'Failed to load session:', err);
      await connections.sendTo(connectionId, MessageType.ERROR, {
        requestId: message.requestId,
        error: err instanceof Error ? err.message : String(err),
      });
      return;
    }
  }
  await connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId });
}
