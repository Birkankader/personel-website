import {
  execFile as cpExecFile,
  type ExecFileOptions,
  type ExecFileOptionsWithBufferEncoding,
} from 'child_process';
import { decodeConsoleOutput } from './console-encoding';

/**
 * Windows-only: run an external launcher with an argv ARRAY, so no shell ever
 * tokenizes an individual argument.
 *
 * ## Why this exists (shell-tokenization avoidance — the project's established pattern)
 *
 * On win32 the CLIs we drive (`claude`, `npm`, `brew`, ...) are launchers
 * (`.cmd`, `.exe`, ...). execFile cannot run a `.cmd` without a shell (ENOENT,
 * and since CVE-2024-27980 Node refuses with EINVAL), so the naive fix is
 * `shell: true`. But `shell: true` hands the whole command line to cmd.exe as a
 * STRING, which splits on spaces and acts on `& | < > ^ ( )`. A launcher path
 * like `C:\Program Files\nodejs\npm.cmd` or a variable argument then gets torn
 * apart, or worse, run (the v0.22.x defect).
 *
 * ## The three routes ([planWindowsLaunch])
 *
 * - `.exe` / `.com`: executed DIRECTLY with `shell: false`. Node applies the
 *   standard CommandLineToArgvW quoting and no cmd.exe is involved, so nothing
 *   can be interpreted and `%` is an ordinary character.
 * - `.cmd` / `.bat`: cmd.exe is spawned as the file, with the line
 *   `cmd /d /v:off /s /c "<launcher> <args>"` built by [buildCmdCommandLine] and
 *   passed verbatim (Node must not re-quote it). A batch launcher is parsed
 *   TWICE: once by `cmd /c`, then again when its `%*` is expanded. So every
 *   argument is CommandLineToArgvW-quoted (the launcher's own program parses it
 *   that way) and each cmd metacharacter is caret-escaped twice, once per parse.
 *   Measured on a real npm shim: the previous form (one argv element per
 *   argument, Node quoting, `windowsVerbatimArguments: false`) executed an
 *   injected command for an `mcp add-json` payload containing `&`, and broke
 *   whenever the launcher path held a space.
 * - A bare name or any other extension (`npm`, `.ps1`) keeps the historic
 *   `cmd /d /s /c <name> <args...>` argv shape: which file PATHEXT resolves to
 *   decides the escaping level (an `.exe` must see one level, a batch file two),
 *   so it cannot be chosen here. Its callers (npm, brew, the harness installer)
 *   pass fixed arguments, and this route refuses a `"` or an unquoted `& | < > ^`
 *   instead of trusting that (see [assertNoUnquotedCmdOperator]). Resolve the
 *   launcher to a full path first to get one of the safe routes and call
 *   [assertResolvedWindowsLauncher] on it, as Claude.execViaCmd and the MCP
 *   sign-in do. Guessing that an extension-less name is a batch file is not a
 *   safe shortcut: against a native `.exe` install the batch escaping delivers
 *   extra carets (`a b` arrives as `a^ b`).
 *
 * ## What is refused instead of escaped
 *
 * - `%`, on both cmd routes: cmd.exe expands `%VAR%` even when quoted or
 *   caret-escaped, which would silently corrupt the argument. Per the
 *   original-data-preservation rule we fail loudly (see
 *   [assertNoCmdPercentExpansion]) rather than run a mangled command.
 * - A line break, on both cmd routes: it ends a `cmd /c` command line, so every
 *   argument after it would be dropped without an error (see
 *   [assertNoCmdLineBreak]).
 * - A `"` or an unquoted `& | < > ^`, on the legacy route only (see
 *   [assertNoUnquotedCmdOperator]): cmd.exe would run it as a command.
 *
 * macOS/Linux never reach this function; callers branch on `process.platform`.
 */
export async function execViaCmdArgv(
  command: string,
  args: string[],
  options?: ExecFileOptions,
  executor?: (command: string, args: string[], options: ExecFileOptions) => Promise<{ stdout: string; stderr: string }>,
): Promise<{ err: Error | null; stdout: string; stderr: string }> {
  // `async` so the synchronous guards in the plan surface as a rejected promise
  // (callers await it), never an uncaught throw during promise construction.
  const plan = planWindowsLaunch(command, args);
  // encoding:'buffer' is pinned AFTER ...options on purpose. cmd.exe writes non-ASCII on
  // stdout in the system's legacy OEM codepage (CP949/CP936/CP932), never UTF-8, so Node's
  // default utf8 decoding would turn a Korean or Chinese install path into U+FFFD before we
  // ever see it — losing the bytes decodeConsoleOutput needs to recover the text.
  const execOptions: ExecFileOptionsWithBufferEncoding = {
    // Match Claude.exec's historic 10s default; callers (CLI update, which
    // downloads + links) pass their own longer timeout to override it.
    timeout: 10000,
    ...options,
    encoding: 'buffer',
    // shell:false — Node spawns the planned file directly, not nested in another shell.
    shell: false,
    // Verbatim only for the pre-quoted cmd line; every other route lets Node quote.
    windowsVerbatimArguments: plan.windowsVerbatimArguments,
  };
  if (executor) {
    try { return { err: null, ...await executor(plan.file, plan.args, execOptions) }; }
    catch (error) {
      const err = error instanceof Error ? error : new Error(String(error));
      const captured = err as Error & { stdout?: string; stderr?: string };
      return { err, stdout: captured.stdout ?? '', stderr: captured.stderr ?? '' };
    }
  }
  return new Promise((resolve) => {
    cpExecFile(plan.file, plan.args, execOptions, (err, stdout, stderr) => {
      resolve({
        err: err ?? null,
        stdout: decodeConsoleOutput(stdout ?? ''),
        stderr: decodeConsoleOutput(stderr ?? ''),
      });
    });
  });
}

/** What to execute, and how Node must pass its arguments. */
export interface WindowsLaunch {
  file: string;
  args: string[];
  windowsVerbatimArguments: boolean;
}

/**
 * Decide how to start `command` on Windows without a shell interpreting its
 * arguments. See [execViaCmdArgv] for what each route does and why.
 *
 * Throws (synchronously) when an argument cannot be passed to cmd.exe intact.
 */
export function planWindowsLaunch(
  command: string,
  args: string[],
): WindowsLaunch {
  if (/\.(exe|com)$/i.test(command)) {
    return { file: command, args, windowsVerbatimArguments: false };
  }
  const comspec = process.env.ComSpec || 'cmd.exe';
  if (/\.(cmd|bat)$/i.test(command)) {
    return {
      file: comspec,
      // `/d` skips AutoRun, `/v:off` keeps `!` literal even if the registry turns
      // delayed expansion on, `/s` strips exactly the outer pair of quotes of the
      // line, `/c` runs then exits.
      args: ['/d', '/v:off', '/s', '/c', buildCmdCommandLine(command, args)],
      windowsVerbatimArguments: true,
    };
  }
  assertNoCmdPercentExpansion([command, ...args]);
  assertNoCmdLineBreak([command, ...args]);
  assertNoUnquotedCmdOperator([command, ...args]);
  return { file: comspec, args: ['/d', '/s', '/c', command, ...args], windowsVerbatimArguments: false };
}

/**
 * The launcher extensions [planWindowsLaunch] can start through a route that
 * never lets cmd.exe tokenize an argument (a pre-quoted batch line, or the
 * `.exe`/`.com` directly).
 */
const RESOLVED_LAUNCHER = /\.(cmd|bat|exe|com)$/i;

/**
 * Fail closed unless `launcher` is a path [planWindowsLaunch] can start safely.
 *
 * An unresolved launcher — a bare `claude` after `where` failed, or a configured
 * `cliPath` without an extension — would take the legacy `cmd /d /s /c <launcher>
 * ...args` shape, where cmd.exe splits the arguments and runs `& | < > ^`. It must
 * not be guessed at either: treating an extension-less name as a batch file
 * (`planWindowsLaunch` called with a `.cmd`-shaped line) delivers an extra caret
 * level to a native `.exe` install, so a server name such as `a b` or `a&b` reaches
 * the CLI corrupted.
 *
 * Callers that pass values from user or project config (MCP server names, JSON
 * payloads) resolve the launcher first and then refuse here when that failed —
 * both `Claude.execViaCmd` and the MCP sign-in do.
 */
export function assertResolvedWindowsLauncher(launcher: string): void {
  if (RESOLVED_LAUNCHER.test(launcher)) return;
  throw new Error(
    'Could not resolve the claude launcher (where claude failed); set the Claude CLI path in settings and retry.',
  );
}

/**
 * Quote one argument for CommandLineToArgvW, the parser nearly every Windows
 * program (Node included) uses to split its command line.
 *
 * An argument with no space, tab or `"` needs nothing. Otherwise it is wrapped in
 * double quotes; a run of backslashes in front of a `"` is doubled and the `"`
 * is escaped, and a run at the very end is doubled so it cannot escape the
 * closing quote. An empty argument becomes `""` so it still counts as one.
 */
export function quoteWindowsArg(arg: string): string {
  if (arg !== '' && !/[ \t"]/.test(arg)) return arg;
  let out = '"';
  let backslashes = 0;
  for (const ch of arg) {
    if (ch === '\\') {
      backslashes++;
    } else if (ch === '"') {
      out += '\\'.repeat(backslashes * 2 + 1) + '"';
      backslashes = 0;
    } else {
      out += '\\'.repeat(backslashes) + ch;
      backslashes = 0;
    }
  }
  return out + '\\'.repeat(backslashes * 2) + '"';
}

// The characters that make cmd.exe do something other than pass the text on: the
// operators `& | < > ^ ( )`, quote mode (`"`), expansion (`% !`), the delimiters
// that split a command (space `,` `;`) and the wildcards. A caret in front of
// one makes it literal. Same set cross-spawn escapes for batch launchers.
const CMD_META = /([()\][%!^"`<>&|;, *?])/g;
const CMD_META_TEST = /[()\][%!^"`<>&|;, *?]/;

function caretEscape(text: string): string {
  return text.replace(CMD_META, '^$1');
}

/**
 * The line to run as `cmd /d /v:off /s /c <line>` for a `.cmd`/`.bat` launcher,
 * outer quotes included (`/s` strips exactly that pair).
 *
 * The launcher is escaped once (cmd.exe resolves it itself). Each argument is
 * CommandLineToArgvW-quoted first, because the program behind the batch file
 * splits its command line that way, and, when it holds a cmd metacharacter,
 * caret-escaped TWICE: once for this `cmd /c` parse, once for the batch file's
 * own re-parse of `%*`. After both, the program receives the argument exactly.
 *
 * Throws on `%` and on a line break (see [assertNoCmdPercentExpansion] and
 * [assertNoCmdLineBreak]).
 */
export function buildCmdCommandLine(command: string, args: string[]): string {
  assertNoCmdPercentExpansion([command, ...args]);
  assertNoCmdLineBreak([command, ...args]);
  const parts = [caretEscape(command)];
  for (const arg of args) {
    const quoted = quoteWindowsArg(arg);
    parts.push(CMD_META_TEST.test(quoted) ? caretEscape(caretEscape(quoted)) : quoted);
  }
  return `"${parts.join(' ')}"`;
}

/**
 * Reject argv that cmd.exe would mangle via `%`-expansion. cmd.exe expands
 * `%VAR%` even inside double quotes, and a caret does not stop it, so a value
 * like `%API_KEY%` would reach the launcher altered (or emptied). We fail loudly
 * rather than run a corrupted command. The error names the position and the
 * cause but never echoes the full value — an argument may carry a secret.
 */
export function assertNoCmdPercentExpansion(args: string[]): void {
  const idx = args.findIndex((a) => a.includes('%'));
  if (idx === -1) return;
  throw new Error(
    `Cannot run this command on Windows: argument #${idx + 1} contains a '%' character, ` +
    `which Windows cmd.exe expands as an environment variable (even inside quotes) and would ` +
    `corrupt the value. Remove the '%' from that value and try again.`,
  );
}

/**
 * For the legacy `cmd /c <name> ...args` shape only: reject a command or argument
 * that cmd.exe would act on. Node quotes an argument only when it holds a space,
 * tab or `"`, so a bare `pkg@1&calc` reaches cmd.exe as an operator, and a `"`
 * (which Node escapes with a backslash cmd.exe does not understand) ends the
 * quoting early. An argument that does hold whitespace and no `"` is wrapped by
 * Node and cmd.exe treats `& | < > ^` inside the quotes as text, so it is allowed
 * (`--prefix C:\Users\A & B\dir`). The error names the position, never the value.
 */
export function assertNoUnquotedCmdOperator(args: string[]): void {
  const idx = args.findIndex((a) => a.includes('"') || (!/[ \t]/.test(a) && /[&|<>^]/.test(a)));
  if (idx === -1) return;
  throw new Error(
    `Cannot run this command on Windows: argument #${idx + 1} contains a character (& | < > ^ or a double quote) ` +
    `that cmd.exe would run as a command instead of passing it on. Remove it from that value and try again.`,
  );
}

/**
 * Reject argv holding a CR or LF. cmd.exe ends a `/c` command line at the first
 * line break, so the rest of that argument and every later one would silently
 * vanish (`mcp remove "a<LF>b" -s project` would run as `mcp remove a`). Like the
 * `%` guard it names the position only, never the value.
 */
export function assertNoCmdLineBreak(args: string[]): void {
  const idx = args.findIndex((a) => /[\r\n]/.test(a));
  if (idx === -1) return;
  throw new Error(
    `Cannot run this command on Windows: argument #${idx + 1} contains a line break, ` +
    `which ends a cmd.exe command line and would silently drop the rest of the command. ` +
    `Remove the line break from that value and try again.`,
  );
}
