import {afterEach, describe, expect, it, vi} from 'vitest';
import {spawn, type ChildProcess} from 'node:child_process';
import {existsSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import type {ConnectionManager} from '../../ws/connection-manager';
import {RuntimeResourceSampler} from '../features/runtime-resources';

const builtHelper = fileURLToPath(new URL('../../../dist/ai-bridge-job.exe', import.meta.url));
vi.mock('../win-job', () => ({jobHelperPath: () => fileURLToPath(new URL('../../../dist/ai-bridge-job.exe', import.meta.url))}));
vi.mock('../features/runtime-tasks', () => ({runtimeTasks: () => ({ready: Promise.resolve(), limiter: {snapshot: () => ({limit: 2, tasks: []})}})}));

describe.skipIf(process.platform !== 'win32' || !existsSync(builtHelper))('built Windows resource helper through the default sampler', () => {
  let child: ChildProcess | undefined;
  afterEach(async () => {
    if (child && child.exitCode === null && child.signalCode === null) {
      const closed = new Promise<void>(resolve => child!.once('exit', () => resolve()));
      child.kill();
      await closed;
    }
    vi.restoreAllMocks();
  });
  it('measures the packaged sidecar and returns real working set bytes', async () => {
    child = spawn(process.execPath, ['-e', 'const memory=Buffer.alloc(16*1024*1024,1); console.log("ready"); setInterval(()=>memory[0],1000);'],
      {stdio: ['ignore', 'pipe', 'ignore'], windowsHide: true});
    await new Promise<void>((resolve, reject) => {
      child!.once('error', reject);
      child!.stdout!.once('data', () => resolve());
    });
    const connections = {getConnectionStats: () => ({total: 1}), getRuntimeSessions: () => [{pid: child!.pid!, sessionId: 'owned-test', workingDir: '/fixture'}]} as unknown as ConnectionManager;
    const sample = await new RuntimeResourceSampler().sample(connections);
    expect(sample.measurementError).toBeUndefined();
    expect(sample.cli[0].rssBytes).toBeGreaterThan(16 * 1024 * 1024);
    expect(sample.cli[0].processCount).toBeGreaterThanOrEqual(1);
    expect(sample.cli[0].cpuPercent).toBeNull(); // One sample cannot establish a CPU rate.
  });
});
