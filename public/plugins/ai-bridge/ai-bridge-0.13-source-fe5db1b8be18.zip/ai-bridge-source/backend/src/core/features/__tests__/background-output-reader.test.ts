import { mkdtemp, appendFile, writeFile, rename, rm } from 'fs/promises';
import { realpathSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { BackgroundOutputReader } from '../background-output-reader';

describe('incremental background output', () => {
  let directory: string;
  let file: string;
  beforeEach(async () => {
    directory = realpathSync(await mkdtemp(join(tmpdir(), 'output-reader-')));
    file = join(directory, 'task.output');
    vi.stubEnv('CLAUDE_CODE_TMPDIR', directory);
  });
  afterEach(async () => { vi.unstubAllEnvs(); await rm(directory, { recursive: true, force: true }); });

  it('reads only append ranges and preserves split UTF-8 characters', async () => {
    const reader = new BackgroundOutputReader();
    await writeFile(file, 'first\n');
    expect(await reader.read(file)).toMatchObject({ kind: 'snapshot', text: 'first\n', endOffset: 6 });
    const bytes = Buffer.from('çığ 🧭');
    const outputs = [];
    for (const byte of bytes) {
      await appendFile(file, Buffer.from([byte]));
      outputs.push(await reader.read(file));
    }
    expect(outputs.map(output => output?.text).join('')).toBe('çığ 🧭');
    expect(outputs.every(output => output?.kind === 'append')).toBe(true);
    expect(await reader.read(file)).toBeUndefined();
  });

  it('emits reset after truncation/regrowth and replacement even at the same size', async () => {
    const reader = new BackgroundOutputReader();
    await writeFile(file, 'original'); await reader.read(file);
    await writeFile(file, 'replacement grew');
    expect(await reader.read(file)).toMatchObject({ kind: 'reset', text: 'replacement grew' });
    await rename(file, `${file}.old`);
    await writeFile(file, 'replacement next');
    expect(await reader.read(file)).toMatchObject({ kind: 'reset', text: 'replacement next' });
  });

  it('keeps initial snapshots bounded but delivers all appended bytes in bounded chunks', async () => {
    const reader = new BackgroundOutputReader();
    await writeFile(file, 'x'.repeat(900_000));
    const first = await reader.read(file);
    expect(first?.text.length).toBe(600_000);
    expect(first?.truncated).toBe(true);
    await appendFile(file, 'y'.repeat(150_000));
    let text = '';
    do {
      const update = await reader.read(file);
      expect(update?.text.length).toBeLessThanOrEqual(64 * 1024);
      text += update?.text;
    } while (reader.more);
    expect(text).toBe('y'.repeat(150_000));
  });
});
