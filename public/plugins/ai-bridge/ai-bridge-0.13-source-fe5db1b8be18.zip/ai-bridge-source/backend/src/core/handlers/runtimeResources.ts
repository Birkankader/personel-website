import type { ConnectionManager } from '../../ws/connection-manager';
import type { IPCMessage } from '../types';
import { MessageType } from '../../shared';
import { sampleRuntimeResources } from '../features/runtime-resources';
import { runtimeTasks, setTaskConcurrency } from '../features/runtime-tasks';
import { sendInterruptToProcess } from '../claude-process';
import { Claude } from '../claude';

export async function runtimeResourcesHandler(connectionId: string, message: IPCMessage, connections: ConnectionManager): Promise<void> {
  try {
    const manager = runtimeTasks(connections);
    await manager.ready;
    if (message.type === MessageType.GET_RUNTIME_RESOURCES) {
      const snapshot = await sampleRuntimeResources(connections);
      await connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId, ...snapshot });
      return;
    }
    if (message.type === MessageType.GET_RUNTIME_TASKS) {
      const sessionId = message.payload?.sessionId;
      await connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId, ...manager.limiter.snapshot(),
        ...(typeof sessionId === 'string' ? { queuedMessages: manager.limiter.queuedMessages(sessionId) } : {}),
      });
      return;
    }
    if (message.type === MessageType.SET_TASK_CONCURRENCY) {
      await setTaskConcurrency(connections, message.payload?.limit as number);
    } else if (message.type === MessageType.REORDER_QUEUED_TASKS || message.type === MessageType.MERGE_QUEUED_TASKS) {
      const { sessionId, taskIds } = message.payload ?? {};
      if (typeof sessionId !== 'string' || !Array.isArray(taskIds) || !taskIds.every(id => typeof id === 'string')) {
        throw new Error('sessionId and taskIds are required');
      }
      if (message.type === MessageType.REORDER_QUEUED_TASKS) manager.limiter.reorderQueued(sessionId, taskIds);
      else manager.limiter.mergeQueued(sessionId, taskIds);
    } else if (message.type === MessageType.STEER_QUEUED_TASK) {
      const taskId = message.payload?.taskId;
      if (typeof taskId !== 'string') throw new Error('taskId is required');
      await manager.limiter.steerQueued(taskId);
    } else {
      const taskId = message.payload?.taskId;
      if (typeof taskId !== 'string') throw new Error('taskId is required');
      const task = manager.limiter.get(taskId);
      if (task) {
        if (task.state === 'queued') {
          if (!manager.limiter.cancelQueued(taskId)) throw new Error('This message is already being delivered.');
        }
        else if (message.type === MessageType.STOP_RUNTIME_TASK) {
          manager.limiter.markStopping(taskId);
          connections.getSession(task.sessionId)?.cancelRecovery?.();
          const proc = connections.getSession(task.sessionId)?.process;
          if (proc && !sendInterruptToProcess(connections, task.sessionId)) Claude.killTree(proc);
        } else throw new Error('The task has already started. Use Stop to interrupt it.');
      }
    }
    await connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId, ...manager.limiter.snapshot() });
  } catch (error) {
    await connections.sendTo(connectionId, MessageType.ERROR, { requestId: message.requestId, error: error instanceof Error ? error.message : String(error) });
  }
}
