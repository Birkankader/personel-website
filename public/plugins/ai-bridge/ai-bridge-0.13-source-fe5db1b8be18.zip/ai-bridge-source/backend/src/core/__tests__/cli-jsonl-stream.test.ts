import { PassThrough } from 'node:stream';
import { describe, expect, it, vi } from 'vitest';
import { CliJsonlStream } from '../cli-jsonl-stream';

const tick = () => new Promise<void>(resolve => setImmediate(resolve));

describe('CLI pipe backpressure', () => {
  it('waits within one chunk and drains the unterminated final event before close', async () => {
    const source = new PassThrough();
    let release!: () => void;
    const gate = new Promise<void>(resolve => { release = resolve; });
    const received: string[] = [];
    const lines = Array.from({ length: 200 }, (_, id) => JSON.stringify({ type: 'assistant', id, text: 'Türkçe 🧭' }));
    const onLine = vi.fn((line: string) => {
      received.push(line);
      if (received.length === 1) return gate;
    });
    const onError = vi.fn();
    const stream = new CliJsonlStream(source, onLine, onError);
    source.write(Buffer.from(lines.join('\n')));
    expect(onLine).toHaveBeenCalledTimes(1);
    expect(source.isPaused()).toBe(true);
    let closed = false;
    const finish = Promise.resolve(stream.finish()).then(() => { closed = true; });
    await tick();
    expect(closed).toBe(false);
    expect(onLine).toHaveBeenCalledTimes(1);
    release();
    await finish;
    expect(received).toEqual(lines);
    expect(onError).not.toHaveBeenCalled();
    source.destroy();
  });

  it('leaves later chunks in the Readable until the current send is accepted', async () => {
    const source = new PassThrough({ highWaterMark: 32 });
    let release!: () => void;
    const gate = new Promise<void>(resolve => { release = resolve; });
    const received: string[] = [];
    const stream = new CliJsonlStream(source, line => {
      received.push(line);
      if (line === 'first') return gate;
    }, vi.fn());
    source.write(Buffer.from('first\n'));
    source.write(Buffer.from('second\nthird\n'));
    expect(received).toEqual(['first']);
    expect(source.readableLength).toBeGreaterThan(0);
    release();
    await tick();
    expect(received).toEqual(['first', 'second', 'third']);
    await stream.finish();
    source.destroy();
  });

  it('retains UTF-8 boundaries and resumes after a reported consumer failure', async () => {
    const source = new PassThrough();
    const received: string[] = [];
    const error = new Error('transport closed');
    const onError = vi.fn();
    const stream = new CliJsonlStream(source, line => {
      received.push(line);
      if (line === 'first') return Promise.reject(error);
    }, onError);
    const bytes = Buffer.from('first\nÜç 🧭\n');
    source.write(bytes.subarray(0, bytes.length - 3));
    source.write(bytes.subarray(bytes.length - 3));
    await tick();
    await stream.finish();
    expect(received).toEqual(['first', 'Üç 🧭']);
    expect(onError).toHaveBeenCalledExactlyOnceWith(error);
    source.destroy();
  });
});
