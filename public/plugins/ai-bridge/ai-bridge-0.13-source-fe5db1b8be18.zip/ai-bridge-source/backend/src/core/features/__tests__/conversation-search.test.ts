import { beforeEach, afterEach, describe, expect, it, vi } from 'vitest';
import { mkdtemp, mkdir, writeFile, rm, symlink, opendir, stat, utimes, rename } from 'fs/promises';
import { createReadStream } from 'fs';
import { join } from 'path';
import { tmpdir } from 'os';
import { ConversationSearchIndex } from '../conversation-search';

vi.mock('fs/promises', async (original) => {
  const actual = await original<typeof import('fs/promises')>();
  return { ...actual, opendir: vi.fn(actual.opendir) };
});
vi.mock('fs', async (original) => {
  const actual = await original<typeof import('fs')>();
  return { ...actual, createReadStream: vi.fn(actual.createReadStream) };
});

let directory: string;
let project: string;
const request = { owner: 'window-a', query: 'needle', workingDir: '/work' };
const message = (uuid: string, text = 'needle') => ({ type: 'user', uuid, cwd: '/work', message: { content: text } });

beforeEach(async () => {
  vi.clearAllMocks();
  directory = await mkdtemp(join(tmpdir(), 'swttch-search-'));
  project = join(directory, 'projects', '-work');
  await mkdir(project, { recursive: true });
  vi.stubEnv('CLAUDE_CONFIG_DIR', directory);
});
afterEach(async () => { vi.unstubAllEnvs(); await rm(directory, { recursive: true, force: true }); });

async function transcript(entries: unknown[], name = 'session-a') {
  await writeFile(join(project, `${name}.jsonl`), entries.map((e) => JSON.stringify(e)).join('\n') + '\n');
}

describe('conversation search', () => {
  it('pages matching text without duplicates and preserves exact session/message identities', async () => {
    await transcript([message('m1'), message('m2'), message('m3')]);
    const index = new ConversationSearchIndex();
    const found = [];
    let cursor: string | undefined;
    do {
      const page = await index.search({ ...request, limit: 1, cursor });
      expect(page.results.length).toBeLessThanOrEqual(1);
      found.push(...page.results);
      cursor = page.nextCursor ?? undefined;
    } while (cursor);
    expect(found.map((r) => r.messageUuid)).toEqual(['m1', 'm2', 'm3']);
    expect(found[0]).toMatchObject({ sessionId: 'session-a', workingDir: '/work', sourceMessageUuid: 'm1' });
  });

  it('searches actual commands and outputs and navigates outputs to the owning tool card', async () => {
    await transcript([
      { type: 'assistant', uuid: 'assistant-1', cwd: '/work', message: { content: [{ type: 'tool_use', id: 'tool1', name: 'Bash', input: { command: 'printf NEEDLE' } }] } },
      { type: 'user', uuid: 'result-1', cwd: '/work', message: { content: [{ type: 'tool_result', tool_use_id: 'tool1', content: 'finished needle output' }] } },
    ]);
    const page = await new ConversationSearchIndex().search(request);
    expect(page.results).toHaveLength(2);
    expect(page.results[1]).toMatchObject({ messageUuid: 'assistant-1', sourceMessageUuid: 'result-1' });
    expect(page.results[1].snippet).toContain('finished needle output');
  });

  it('does not index embedded image data as conversation text', async () => {
    await transcript([{ type: 'user', uuid: 'img', cwd: '/work', message: { content: [{ type: 'image', source: { type: 'base64', data: 'needle' } }] } }]);
    expect((await new ConversationSearchIndex().search(request)).results).toEqual([]);
  });

  it('selects the matching tool when one output entry carries multiple results', async () => {
    await transcript([
      { type: 'assistant', uuid: 'assistant-a', cwd: '/work', message: { content: [{ type: 'tool_use', id: 'tool-a', name: 'Bash', input: { command: 'first' } }] } },
      { type: 'assistant', uuid: 'assistant-b', cwd: '/work', message: { content: [{ type: 'tool_use', id: 'tool-b', name: 'Bash', input: { command: 'second' } }] } },
      { type: 'user', uuid: 'outputs', cwd: '/work', message: { content: [{ type: 'tool_result', tool_use_id: 'tool-a', content: 'needle from first' }, { type: 'tool_result', tool_use_id: 'tool-b', content: 'other result' }] } },
    ]);
    const index = new ConversationSearchIndex();
    expect((await index.search(request)).results[0].messageUuid).toBe('assistant-a');
    expect((await index.search({ ...request, query: 'other result' })).results[0].messageUuid).toBe('assistant-b');
  });

  it('bounds each work slice even if no text matches and continues on demand', async () => {
    await transcript(Array.from({ length: 2500 }, (_, i) => message(`m${i}`, 'other text')));
    const page = await new ConversationSearchIndex().search(request);
    expect(page.results).toEqual([]);
    expect(page.nextCursor).not.toBeNull();
  });

  it('clamps caller limits and rejects cursors belonging to another window', async () => {
    await transcript(Array.from({ length: 100 }, (_, i) => message(`m${i}`)));
    const index = new ConversationSearchIndex();
    const page = await index.search({ ...request, limit: 10_000 });
    expect(page.results.length).toBeLessThanOrEqual(50);
    await expect(index.search({ ...request, owner: 'another-window', cursor: page.nextCursor! })).rejects.toThrow('expired');
  });

  it('invalidates changed files instead of returning stale cached text', async () => {
    await transcript([message('m1', 'old needle')]);
    const index = new ConversationSearchIndex();
    expect((await index.search(request)).results[0].snippet).toContain('old needle');
    await transcript([message('m2', 'newer needle content')]);
    expect((await index.search(request)).results[0].messageUuid).toBe('m2');
  });

  it.each(['rewrite', 'replace'])('invalidates same-size cached transcripts after %s even when mtime is preserved', async (operation) => {
    const path = join(project, 'session-a.jsonl');
    await transcript([message('m1', 'old needle')]);
    // Set a precisely representable timestamp so mtime remains identical.
    await utimes(path, 1_700_000_000, 1_700_000_000);
    const before = await stat(path);
    const index = new ConversationSearchIndex();
    expect((await index.search(request)).results[0].sourceMessageUuid).toBe('m1');
    const target = operation === 'rewrite' ? path : join(project, 'replacement.tmp');
    await writeFile(target, JSON.stringify(message('m2', 'new needle')) + '\n');
    await utimes(target, before.atime, before.mtime);
    if (operation === 'replace') await rename(target, path);
    expect((await stat(path)).size).toBe(before.size);
    expect((await stat(path)).mtimeMs).toBe(before.mtimeMs);
    expect((await index.search(request)).results[0].sourceMessageUuid).toBe('m2');
  });

  it('bounds the count of cached empty transcripts independently of text bytes', async () => {
    const index = new ConversationSearchIndex();
    // One file per query ensures evicted paths cannot be immediately reinserted
    // by the next query, while exercising actual zero-row cache admission.
    for (let i = 0; i < 514; i++) {
      const path = join(project, `empty-${i}.jsonl`);
      await writeFile(path, '');
      await index.search(request);
      await rm(path);
    }
    // The first path must have been evicted even though all rows cost 0 bytes.
    // Recreate it with identical metadata impossible to retain across unlink;
    // inspect the bounded cache count directly, not an unrelated file reread.
    expect((index as unknown as { cache: Map<string, unknown> }).cache.size).toBeLessThanOrEqual(512);
  });

  it('includes navigation metadata when deciding whether a transcript fits the small-file cache', async () => {
    await transcript([{ type: 'user', uuid: 'many-blocks', cwd: '/work', message: { content: Array.from({ length: 20_000 }, () => ({ type: 'text', text: 'x' })) } }]);
    const index = new ConversationSearchIndex();
    let page = await index.search(request);
    while (page.nextCursor) page = await index.search({ ...request, cursor: page.nextCursor });
    expect((index as unknown as { cache: Map<string, unknown> }).cache.size).toBe(0);
  });

  it('ignores symlink transcripts and refuses cancellation immediately', async () => {
    const outside = join(directory, 'outside.jsonl');
    await writeFile(outside, JSON.stringify(message('secret')) + '\n');
    try {
      await symlink(outside, join(project, 'escape.jsonl'));
    } catch (error) {
      if (process.platform !== 'win32' || (error as NodeJS.ErrnoException).code !== 'EPERM') throw error;
      // Creating Windows file symlinks needs Developer Mode/admin rights.
      // Still exercise discovery's real Dirent exclusion without changing the host.
      vi.mocked(opendir).mockResolvedValueOnce({
        read: vi.fn().mockResolvedValueOnce({ name: 'escape.jsonl', isFile: () => false, isDirectory: () => false, isSymbolicLink: () => true }).mockResolvedValue(null),
        close: vi.fn().mockResolvedValue(undefined),
      } as unknown as Awaited<ReturnType<typeof opendir>>);
    }
    expect((await new ConversationSearchIndex().search(request)).results).toEqual([]);
    const controller = new AbortController(); controller.abort();
    await expect(new ConversationSearchIndex().search({ ...request, signal: controller.signal })).rejects.toThrow('cancelled');
  });

  it('keeps client paths inside the configured Claude projects directory', async () => {
    await transcript([message('m1')]);
    expect((await new ConversationSearchIndex().search({ ...request, workingDir: '../../etc' })).results).toEqual([]);
    await expect(new ConversationSearchIndex().search({ ...request, cursor: '../../etc/passwd' })).rejects.toThrow('expired');
  });

  it('resumes partial UTF-8 JSON lines across byte slices without losing a match or the following row', async () => {
    const query = 'ışık needle';
    // Put a multibyte character over the exact first work-slice boundary.
    const prefix = JSON.stringify(message('large', '')).replace(/""}}$/, '"');
    const padding = 'x'.repeat(512 * 1024 - Buffer.byteLength(prefix) - 1);
    const large = prefix + padding + query + 'z'.repeat(600 * 1024) + '"}}';
    await writeFile(join(project, 'large-session.jsonl'), large + '\n' + JSON.stringify(message('after', query)));
    const index = new ConversationSearchIndex();
    const first = await index.search({ ...request, query });
    expect(first.results).toEqual([]);
    expect(first.nextCursor).not.toBeNull();
    const found = [];
    let cursor = first.nextCursor;
    let slices = 0;
    while (cursor) {
      expect(++slices).toBeLessThan(12);
      const page = await index.search({ ...request, query, cursor });
      found.push(...page.results); cursor = page.nextCursor;
    }
    expect(found.map((row) => row.messageUuid)).toEqual(['large', 'after']);
    expect(found[0].snippet).toContain(query);
  });

  it('yields before reading a newline-free oversized line and skips it once before the next match', async () => {
    await writeFile(join(project, 'oversized.jsonl'), 'x'.repeat(9 * 1024 * 1024) + '\n' + JSON.stringify(message('after')));
    const index = new ConversationSearchIndex();
    let page = await index.search(request);
    expect(page.skippedEntries).toBe(0);
    expect(page.nextCursor).not.toBeNull();
    const found = [];
    let slices = 0;
    while (page.nextCursor) {
      expect(++slices).toBeLessThan(30);
      page = await index.search({ ...request, cursor: page.nextCursor });
      found.push(...page.results);
    }
    expect(slices).toBeGreaterThan(10);
    expect(page.skippedEntries).toBe(1);
    expect(found.map((row) => row.messageUuid)).toEqual(['after']);
  });

  it('discovers many projects incrementally and visits each transcript once', async () => {
    await Promise.all(Array.from({ length: 150 }, async (_, index) => {
      const path = join(directory, 'projects', `project-${index}`);
      await mkdir(path);
      await writeFile(join(path, `session-${index}.jsonl`), JSON.stringify(message(`m${index}`)));
    }));
    const index = new ConversationSearchIndex();
    const initial = await index.search({ ...request, allProjects: true, query: 'absent' });
    expect(initial.nextCursor).not.toBeNull();
    expect(initial.totalFiles).toBeLessThan(150);
    // The next query starts from scratch and releases the previous directory cursors.
    let page = await index.search({ ...request, allProjects: true, limit: 50 });
    const found = [...page.results];
    while (page.nextCursor) {
      page = await index.search({ ...request, allProjects: true, limit: 50, cursor: page.nextCursor });
      found.push(...page.results);
    }
    expect(found).toHaveLength(150);
    expect(new Set(found.map((row) => row.messageUuid)).size).toBe(150);
  });

  it('closes directory handles and discards partial line storage when cancelled between slices', async () => {
    await writeFile(join(project, 'large.jsonl'), 'x'.repeat(2 * 1024 * 1024));
    const index = new ConversationSearchIndex();
    const page = await index.search(request);
    expect(page.nextCursor).not.toBeNull();
    const handles = await Promise.all(vi.mocked(opendir).mock.results.map((result) => result.value));
    index.cancel(request.owner);
    await new Promise((resolve) => setImmediate(resolve));
    for (const handle of handles) await expect(handle.read()).rejects.toThrow('closed');
    await expect(index.search({ ...request, cursor: page.nextCursor! })).rejects.toThrow('expired');
  });

  it('cancels paused pages by current request identity without cancelling a newer page', async () => {
    await writeFile(join(project, 'large.jsonl'), 'x'.repeat(2 * 1024 * 1024));
    const index = new ConversationSearchIndex();
    const first = await index.search({ ...request, cancellationId: 'first-page' });
    const second = await index.search({ ...request, cancellationId: 'second-page', cursor: first.nextCursor! });
    index.cancel(request.owner, 'first-page');
    const third = await index.search({ ...request, cancellationId: 'third-page', cursor: second.nextCursor! });
    expect(third.nextCursor).not.toBeNull();
    index.cancel(request.owner, 'third-page');
    await expect(index.search({ ...request, cursor: third.nextCursor! })).rejects.toThrow('expired');
  });

  it('bounds retained tool ownership metadata and reports a truncated scope before proceeding to the next transcript', async () => {
    await transcript([{ type: 'assistant', uuid: 'tool-owner', cwd: '/work', message: { content: [{ type: 'tool_use', id: 'x'.repeat(3 * 1024 * 1024), name: 'Bash', input: { command: 'needle' } }] } }], 'oversized-tool');
    await transcript([message('safe-after')], 'normal');
    const index = new ConversationSearchIndex();
    let page = await index.search(request);
    const found = [...page.results];
    let slices = 0;
    while (page.nextCursor) {
      expect(++slices).toBeLessThan(20);
      page = await index.search({ ...request, cursor: page.nextCursor });
      found.push(...page.results);
    }
    expect(page.scopeTruncated).toBe(true);
    expect(page.skippedEntries).toBe(1);
    expect(found.map((row) => row.sourceMessageUuid)).toEqual(['safe-after']);
  });

  it('aborts an in-flight line read and closes both transcript and discovery handles', async () => {
    await writeFile(join(project, 'large.jsonl'), 'x'.repeat(2 * 1024 * 1024));
    const controller = new AbortController();
    const actual = await vi.importActual<typeof import('fs')>('fs');
    vi.mocked(createReadStream).mockImplementationOnce((...args) => {
      const stream = actual.createReadStream(...args);
      stream.once('data', () => controller.abort());
      return stream;
    });
    await expect(new ConversationSearchIndex().search({ ...request, signal: controller.signal })).rejects.toThrow('cancelled');
    const stream = vi.mocked(createReadStream).mock.results[0].value;
    expect(stream.destroyed).toBe(true);
    const handles = await Promise.all(vi.mocked(opendir).mock.results.map((result) => result.value));
    for (const handle of handles) await expect(handle.read()).rejects.toThrow('closed');
  });

  it('maps text-array workflow notifications to their visible owning assistant', async () => {
    await transcript([
      { type: 'assistant', uuid: 'assistant', cwd: '/work', message: { content: [{ type: 'tool_use', id: 'workflow', name: 'Task', input: { prompt: 'work' } }] } },
      { type: 'user', uuid: 'hidden-notification', cwd: '/work', message: { content: [
        { type: 'text', text: '<task-notification><tool-use-id>workflow</tool-use-id>' },
        { type: 'text', text: '<summary>needle result</summary></task-notification>' },
      ] } },
    ]);
    const result = (await new ConversationSearchIndex().search(request)).results[0];
    expect(result).toMatchObject({ sourceMessageUuid: 'hidden-notification', messageUuid: 'assistant' });
  });

  it('resolves WSL UNC current-project directories through the shared session path helper', async () => {
    const original = Object.getOwnPropertyDescriptor(process, 'platform')!;
    Object.defineProperty(process, 'platform', { value: 'linux' });
    try {
      const wslProject = join(directory, 'projects', '-home-user-work');
      await mkdir(wslProject);
      await writeFile(join(wslProject, 'session-wsl.jsonl'), JSON.stringify({ ...message('wsl'), cwd: '/home/user/work' }));
      const page = await new ConversationSearchIndex().search({ ...request, workingDir: '//wsl.localhost/Ubuntu/home/user/work' });
      expect(page.results).toMatchObject([{ sessionId: 'session-wsl', messageUuid: 'wsl', workingDir: '/home/user/work' }]);
    } finally { Object.defineProperty(process, 'platform', original); }
  });
});
