import { beforeEach, describe, expect, it, vi } from 'vitest';

vi.mock('../loadAndSendSession', () => ({
  loadAndSendSession: vi.fn(),
}));
vi.mock('../../claude-process', () => ({
  markSessionAsSpawned: vi.fn(),
}));
vi.mock('../../claude', () => ({
  Claude: { killTree: vi.fn() },
}));

import { loadSessionHandler } from '../loadSession';
import { reclaimSessionHandler } from '../reclaimSession';
import { loadAndSendSession } from '../loadAndSendSession';
import { Claude } from '../../claude';
import type { ConnectionManager } from '../../../ws/connection-manager';
import type { Bridge } from '../../../bridge/bridge-interface';
import type { IPCMessage } from '../../types';
import { MessageType } from '../../../shared';

const mockLoadAndSend = vi.mocked(loadAndSendSession);

interface SentMessage {
  type: string;
  payload: Record<string, unknown>;
}

function makeConnections(session?: { process: unknown }): { conn: ConnectionManager; sent: SentMessage[] } {
  const sent: SentMessage[] = [];
  const conn = {
    subscribe: vi.fn(),
    getSession: vi.fn(() => session),
    setProcess: vi.fn(),
    sendTo: vi.fn(async (_id: string, type: string, payload: Record<string, unknown>) => {
      sent.push({ type, payload });
    }),
  } as unknown as ConnectionManager;
  return { conn, sent };
}

const bridge = {} as Bridge;

function request(type: MessageType, payload: Record<string, unknown>): IPCMessage {
  return { type, requestId: 'r1', payload, timestamp: 0 };
}

describe('session load failures reach the caller', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.spyOn(console, 'error').mockImplementation(() => undefined);
  });

  describe('loadSessionHandler', () => {
    it('replies with exactly one ERROR carrying the requestId, and no ACK, when the transcript cannot be read', async () => {
      mockLoadAndSend.mockRejectedValueOnce(new Error('boom'));
      const { conn, sent } = makeConnections();

      await loadSessionHandler(
        'c1',
        request(MessageType.LOAD_SESSION, { sessionId: 's1', workingDir: '/work' }),
        conn,
        bridge,
      );

      expect(sent).toEqual([{ type: MessageType.ERROR, payload: { requestId: 'r1', error: 'boom' } }]);
    });

    it('also covers the older-page request', async () => {
      mockLoadAndSend.mockRejectedValueOnce(new Error('boom'));
      const { conn, sent } = makeConnections();

      await loadSessionHandler(
        'c1',
        request(MessageType.LOAD_OLDER_MESSAGES, { sessionId: 's1', workingDir: '/work', beforeUuid: 'u1' }),
        conn,
        bridge,
      );

      expect(sent).toEqual([{ type: MessageType.ERROR, payload: { requestId: 'r1', error: 'boom' } }]);
    });

    it('stringifies a non-Error rejection', async () => {
      mockLoadAndSend.mockRejectedValueOnce('plain failure');
      const { conn, sent } = makeConnections();

      await loadSessionHandler(
        'c1',
        request(MessageType.LOAD_SESSION, { sessionId: 's1', workingDir: '/work' }),
        conn,
        bridge,
      );

      expect(sent).toEqual([{ type: MessageType.ERROR, payload: { requestId: 'r1', error: 'plain failure' } }]);
    });

    it('still ACKs after a successful load', async () => {
      mockLoadAndSend.mockResolvedValueOnce(undefined);
      const { conn, sent } = makeConnections();

      await loadSessionHandler(
        'c1',
        request(MessageType.LOAD_SESSION, { sessionId: 's1', workingDir: '/work' }),
        conn,
        bridge,
      );

      expect(sent).toEqual([{ type: MessageType.ACK, payload: { requestId: 'r1' } }]);
    });
  });

  describe('reclaimSessionHandler', () => {
    it('replies with exactly one ERROR carrying the requestId, and no ACK, when the transcript cannot be read', async () => {
      mockLoadAndSend.mockRejectedValueOnce(new Error('boom'));
      const { conn, sent } = makeConnections();

      await reclaimSessionHandler(
        'c1',
        request(MessageType.RECLAIM_SESSION, { sessionId: 's1', workingDir: '/work' }),
        conn,
        bridge,
      );

      expect(sent).toEqual([{ type: MessageType.ERROR, payload: { requestId: 'r1', error: 'boom' } }]);
    });

    it('still kills the internal process before the load fails', async () => {
      mockLoadAndSend.mockRejectedValueOnce(new Error('boom'));
      const proc = { pid: 1 };
      const { conn } = makeConnections({ process: proc });
      vi.useFakeTimers();
      try {
        const done = reclaimSessionHandler(
          'c1',
          request(MessageType.RECLAIM_SESSION, { sessionId: 's1', workingDir: '/work' }),
          conn,
          bridge,
        );
        await vi.advanceTimersByTimeAsync(600);
        await done;
      } finally {
        vi.useRealTimers();
      }

      expect(Claude.killTree).toHaveBeenCalledWith(proc);
    });

    it('still ACKs after a successful reclaim', async () => {
      mockLoadAndSend.mockResolvedValueOnce(undefined);
      const { conn, sent } = makeConnections();

      await reclaimSessionHandler(
        'c1',
        request(MessageType.RECLAIM_SESSION, { sessionId: 's1', workingDir: '/work' }),
        conn,
        bridge,
      );

      expect(sent).toEqual([{ type: MessageType.ACK, payload: { requestId: 'r1' } }]);
    });
  });
});
