import { MAX_MODEL_LIST_ENTRIES, modelListMatches, validModelList } from './model-list';

/**
 * The textOnlyModels setting: models that do not read images.
 *
 * A model without an image encoder cannot use an image block, and the server in
 * front of it usually fails the whole request. The image then stays in the
 * conversation, so every later turn fails the same way and the chat looks dead.
 * For these models a message's images go as a text description instead
 * (image-summary.ts), and the computer-use screenshot tool answers in text.
 *
 * Entries are matched as model-list.ts describes.
 */
export const MAX_TEXT_ONLY_MODELS = MAX_MODEL_LIST_ENTRIES;

export function validTextOnlyModels(value: unknown): value is string[] {
  return validModelList(value);
}

/** Whether any of a model's names matches an entry of the textOnlyModels setting. */
export function isTextOnlyModel(entries: unknown, modelNames: readonly string[]): boolean {
  return modelListMatches(entries, modelNames);
}
