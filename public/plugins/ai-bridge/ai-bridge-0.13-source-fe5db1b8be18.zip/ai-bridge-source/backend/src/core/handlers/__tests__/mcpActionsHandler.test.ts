/**
 * The MCP sign-in / sign-out handlers: what each ACK looks like and how a login
 * run's progress reaches the webview. The CLI side (PTY, `claude mcp logout`) is
 * mocked; its own tests live next to it.
 */
import { describe, it, expect, vi, beforeEach } from 'vitest';

vi.mock('../../features/mcp-login', () => ({
  startMcpLogin: vi.fn(),
  submitMcpLoginCallbackUrl: vi.fn(),
  cancelMcpLogin: vi.fn(),
}));
vi.mock('../../features/mcp-manager', () => ({
  reconnectMcpServer: vi.fn(),
  setMcpServerEnabled: vi.fn(),
  addMcpServer: vi.fn(),
  removeMcpServer: vi.fn(),
  logoutMcpServer: vi.fn(),
}));
vi.mock('../../features/mcp-registry', () => ({ searchMcpRegistry: vi.fn() }));

import {
  authenticateMcpServerHandler,
  cancelMcpServerAuthenticationHandler,
  clearMcpServerAuthHandler,
  submitMcpOauthCallbackUrlHandler,
} from '../mcpActionsHandler';
import { startMcpLogin, submitMcpLoginCallbackUrl, cancelMcpLogin } from '../../features/mcp-login';
import { logoutMcpServer } from '../../features/mcp-manager';
import type { ConnectionManager } from '../../../ws/connection-manager';
import type { Bridge } from '../../../bridge/bridge-interface';
import type { IPCMessage } from '../../types';
import { MessageType, McpAuthenticationState } from '../../../shared';

const start = vi.mocked(startMcpLogin);
const submit = vi.mocked(submitMcpLoginCallbackUrl);
const cancel = vi.mocked(cancelMcpLogin);
const logout = vi.mocked(logoutMcpServer);
const bridge = {} as Bridge;

function connectionsMock() {
  return { sendTo: vi.fn(async () => undefined) } as unknown as ConnectionManager & { sendTo: ReturnType<typeof vi.fn> };
}

function message(type: MessageType, payload: Record<string, unknown>): IPCMessage {
  return { type, requestId: 'req-1', payload, timestamp: 0 };
}

const ackOf = (connections: { sendTo: ReturnType<typeof vi.fn> }) => {
  const calls = connections.sendTo.mock.calls.filter((c) => c[1] === MessageType.ACK);
  expect(calls).toHaveLength(1);
  return calls[0][2] as Record<string, unknown>;
};

beforeEach(() => {
  vi.clearAllMocks();
});

describe('authenticateMcpServerHandler', () => {
  it('answers a missing name without starting anything', async () => {
    const connections = connectionsMock();

    await authenticateMcpServerHandler('conn-1', message(MessageType.AUTHENTICATE_MCP_SERVER, {}), connections, bridge);

    expect(start).not.toHaveBeenCalled();
    expect(ackOf(connections)).toEqual({ requestId: 'req-1', status: 'error', error: 'Missing name' });
  });

  it('starts the login for this connection and workingDir and ACKs the module answer as is', async () => {
    const connections = connectionsMock();
    start.mockResolvedValue({ status: 'started' });

    await authenticateMcpServerHandler(
      'conn-1',
      message(MessageType.AUTHENTICATE_MCP_SERVER, { name: 'aib spaced', workingDir: 'C:\\proj' }),
      connections,
      bridge,
    );

    expect(start).toHaveBeenCalledWith({
      connectionId: 'conn-1',
      name: 'aib spaced',
      workingDir: 'C:\\proj',
      onUpdate: expect.any(Function),
    });
    expect(ackOf(connections)).toEqual({ requestId: 'req-1', status: 'started' });
  });

  it('passes workingDir as undefined when the payload has none', async () => {
    start.mockResolvedValue({ status: 'started' });

    await authenticateMcpServerHandler('conn-1', message(MessageType.AUTHENTICATE_MCP_SERVER, { name: 'a' }), connectionsMock(), bridge);

    expect(start.mock.calls[0][0].workingDir).toBeUndefined();
  });

  it('ACKs the terminal fallback with the command to run', async () => {
    const connections = connectionsMock();
    start.mockResolvedValue({ status: 'terminal-required', command: 'claude mcp login "aib-fixture"', reason: 'PTY disabled' });

    await authenticateMcpServerHandler('conn-1', message(MessageType.AUTHENTICATE_MCP_SERVER, { name: 'aib-fixture' }), connections, bridge);

    expect(ackOf(connections)).toEqual({
      requestId: 'req-1',
      status: 'terminal-required',
      command: 'claude mcp login "aib-fixture"',
      reason: 'PTY disabled',
    });
  });

  it('ACKs an error the module reports', async () => {
    const connections = connectionsMock();
    start.mockResolvedValue({ status: 'error', error: "Cannot run this command on Windows: argument #4 contains a '%' character" });

    await authenticateMcpServerHandler('conn-1', message(MessageType.AUTHENTICATE_MCP_SERVER, { name: 'a%b' }), connections, bridge);

    expect(ackOf(connections)).toMatchObject({ status: 'error', error: expect.stringContaining('%') });
  });

  it('ACKs an error instead of rejecting when the module throws', async () => {
    const connections = connectionsMock();
    start.mockRejectedValue(new Error('boom'));

    await authenticateMcpServerHandler('conn-1', message(MessageType.AUTHENTICATE_MCP_SERVER, { name: 'a' }), connections, bridge);

    expect(ackOf(connections)).toEqual({ requestId: 'req-1', status: 'error', error: 'boom' });
  });

  it('pushes every progress update to the same connection as MCP_SERVER_AUTHENTICATION_STATUS', async () => {
    const connections = connectionsMock();
    start.mockResolvedValue({ status: 'started' });
    await authenticateMcpServerHandler('conn-1', message(MessageType.AUTHENTICATE_MCP_SERVER, { name: 'a' }), connections, bridge);
    const onUpdate = start.mock.calls[0][0].onUpdate;
    const update = { name: 'a', state: McpAuthenticationState.AWAITING_CALLBACK, url: 'http://127.0.0.1:19900/authorize?x=1' };

    onUpdate(update);

    expect(connections.sendTo).toHaveBeenCalledWith('conn-1', MessageType.MCP_SERVER_AUTHENTICATION_STATUS, update);
  });
});

describe('clearMcpServerAuthHandler', () => {
  it('answers a missing name', async () => {
    const connections = connectionsMock();

    await clearMcpServerAuthHandler('conn-1', message(MessageType.CLEAR_MCP_SERVER_AUTH, { name: '  ' }), connections, bridge);

    expect(logout).not.toHaveBeenCalled();
    expect(ackOf(connections)).toEqual({ requestId: 'req-1', status: 'error', error: 'Missing name' });
  });

  it('runs `claude mcp logout` for the name in the workingDir and ACKs the CLI output', async () => {
    const connections = connectionsMock();
    logout.mockResolvedValue('Removed authentication for "aib spaced".');

    await clearMcpServerAuthHandler(
      'conn-1',
      message(MessageType.CLEAR_MCP_SERVER_AUTH, { name: 'aib spaced', workingDir: '/work/proj' }),
      connections,
      bridge,
    );

    expect(logout).toHaveBeenCalledWith('aib spaced', '/work/proj');
    expect(ackOf(connections)).toEqual({
      requestId: 'req-1',
      status: 'ok',
      name: 'aib spaced',
      output: 'Removed authentication for "aib spaced".',
    });
  });

  it('ACKs the CLI stderr in preference to stdout and the generic message', async () => {
    const connections = connectionsMock();
    logout.mockRejectedValue(Object.assign(new Error('Command failed: claude mcp logout x'), {
      stdout: 'stdout text',
      stderr: '  No stored authentication for "x".\n',
    }));

    await clearMcpServerAuthHandler('conn-1', message(MessageType.CLEAR_MCP_SERVER_AUTH, { name: 'x' }), connections, bridge);

    expect(ackOf(connections)).toEqual({ requestId: 'req-1', status: 'error', error: 'No stored authentication for "x".' });
  });

  it('falls back to stdout, then to the error message', async () => {
    const a = connectionsMock();
    logout.mockRejectedValueOnce(Object.assign(new Error('Command failed'), { stdout: 'only stdout\n', stderr: '' }));
    await clearMcpServerAuthHandler('conn-1', message(MessageType.CLEAR_MCP_SERVER_AUTH, { name: 'x' }), a, bridge);
    expect(ackOf(a)).toMatchObject({ status: 'error', error: 'only stdout' });

    const b = connectionsMock();
    logout.mockRejectedValueOnce(new Error('spawn claude ENOENT'));
    await clearMcpServerAuthHandler('conn-1', message(MessageType.CLEAR_MCP_SERVER_AUTH, { name: 'x' }), b, bridge);
    expect(ackOf(b)).toMatchObject({ status: 'error', error: 'spawn claude ENOENT' });
  });

  it('copes with a rejection that is not an Error', async () => {
    const connections = connectionsMock();
    logout.mockRejectedValue('nope');

    await clearMcpServerAuthHandler('conn-1', message(MessageType.CLEAR_MCP_SERVER_AUTH, { name: 'x' }), connections, bridge);

    expect(ackOf(connections)).toEqual({ requestId: 'req-1', status: 'error', error: 'nope' });
  });
});

describe('submitMcpOauthCallbackUrlHandler', () => {
  it('requires a name and a callbackUrl', async () => {
    const noName = connectionsMock();
    await submitMcpOauthCallbackUrlHandler('conn-1', message(MessageType.SUBMIT_MCP_OAUTH_CALLBACK_URL, { callbackUrl: 'http://x/' }), noName, bridge);
    expect(ackOf(noName)).toEqual({ requestId: 'req-1', status: 'error', error: 'Missing name' });

    const noUrl = connectionsMock();
    await submitMcpOauthCallbackUrlHandler('conn-1', message(MessageType.SUBMIT_MCP_OAUTH_CALLBACK_URL, { name: 'a' }), noUrl, bridge);
    expect(ackOf(noUrl)).toEqual({ requestId: 'req-1', status: 'error', error: 'Missing callbackUrl' });

    const empty = connectionsMock();
    await submitMcpOauthCallbackUrlHandler('conn-1', message(MessageType.SUBMIT_MCP_OAUTH_CALLBACK_URL, { name: 'a', callbackUrl: '' }), empty, bridge);
    expect(ackOf(empty)).toEqual({ requestId: 'req-1', status: 'error', error: 'Missing callbackUrl' });

    expect(submit).not.toHaveBeenCalled();
  });

  it('hands the raw pasted text to the module and ACKs its verdict', async () => {
    const ok = connectionsMock();
    submit.mockReturnValueOnce({ status: 'ok' });
    await submitMcpOauthCallbackUrlHandler(
      'conn-1',
      message(MessageType.SUBMIT_MCP_OAUTH_CALLBACK_URL, { name: 'aib spaced', callbackUrl: '  http://localhost:1/callback?code=1\n' }),
      ok,
      bridge,
    );
    expect(submit).toHaveBeenCalledWith('conn-1', 'aib spaced', '  http://localhost:1/callback?code=1\n');
    expect(ackOf(ok)).toEqual({ requestId: 'req-1', status: 'ok' });

    const refused = connectionsMock();
    submit.mockReturnValueOnce({ status: 'error', error: 'The sign-in is not waiting for a redirect URL.' });
    await submitMcpOauthCallbackUrlHandler(
      'conn-1',
      message(MessageType.SUBMIT_MCP_OAUTH_CALLBACK_URL, { name: 'a', callbackUrl: 'http://x/' }),
      refused,
      bridge,
    );
    expect(ackOf(refused)).toEqual({ requestId: 'req-1', status: 'error', error: 'The sign-in is not waiting for a redirect URL.' });
  });
});

describe('cancelMcpServerAuthenticationHandler', () => {
  it('answers a missing name', async () => {
    const connections = connectionsMock();

    await cancelMcpServerAuthenticationHandler('conn-1', message(MessageType.CANCEL_MCP_SERVER_AUTHENTICATION, {}), connections, bridge);

    expect(cancel).not.toHaveBeenCalled();
    expect(ackOf(connections)).toEqual({ requestId: 'req-1', status: 'error', error: 'Missing name' });
  });

  it('cancels this connection\'s run and says whether there was one', async () => {
    const running = connectionsMock();
    cancel.mockReturnValueOnce(true);
    await cancelMcpServerAuthenticationHandler('conn-1', message(MessageType.CANCEL_MCP_SERVER_AUTHENTICATION, { name: 'aib spaced' }), running, bridge);
    expect(cancel).toHaveBeenCalledWith('conn-1', 'aib spaced');
    expect(ackOf(running)).toEqual({ requestId: 'req-1', status: 'ok', cancelled: true });

    const idle = connectionsMock();
    cancel.mockReturnValueOnce(false);
    await cancelMcpServerAuthenticationHandler('conn-1', message(MessageType.CANCEL_MCP_SERVER_AUTHENTICATION, { name: 'aib spaced' }), idle, bridge);
    expect(ackOf(idle)).toEqual({ requestId: 'req-1', status: 'ok', cancelled: false });
  });
});
