import { afterEach, describe, expect, it, vi } from 'vitest';
import { spawn, type ChildProcess } from 'child_process';
import { existsSync } from 'fs';
import { join } from 'path';
import { tmpdir } from 'os';
import { fileURLToPath } from 'url';

// The built helper's process scan against PowerShell's, compared on processes
// this test starts and keeps alive. The rest of the machine's process table is
// not compared: a process that starts or exits between two scans, or a PID that
// changes hands, is not something either scan got wrong, and a parallel test
// run starts dozens of them a second. Other processes' command lines can hold
// secrets, so a failure reports PIDs only, never a command line.
const builtHelper = fileURLToPath(new URL('../../../dist/ai-bridge-job.exe', import.meta.url));

const { helper } = vi.hoisted(() => ({ helper: { path: '' } }));
vi.mock('../win-job', () => ({ jobHelperPath: () => helper.path }));
vi.mock('child_process', async (importOriginal) => {
  const actual = await importOriginal<typeof import('child_process')>();
  // The scan's 5 s budget suits a backend at rest. Under a parallel test run
  // PowerShell can take longer to start; this test is about what each scan
  // reads, not how fast, so it gives both scans a minute.
  const execFile = ((file: string, args: string[], options: object, callback: unknown) =>
    actual.execFile(file, args, { ...options, timeout: 60_000 }, callback as Parameters<typeof actual.execFile>[3])) as unknown as typeof actual.execFile;
  return { ...actual, execFile };
});

/** Command-line text a scan has to carry through unchanged: spaces, quotes, non-ASCII, length. */
const MARKER_ARGS = [
  ['plain-marker'],
  ['with spaces', 'a "quoted" word', 'back\\slash\\'],
  ['çğış öü 日本語 ✓'],
  ['x'.repeat(600)],
];

const children: ChildProcess[] = [];

/** Start a process that idles until killed, and resolve once it runs. */
function startMarker(args: string[]): Promise<ChildProcess> {
  const child = spawn(process.execPath, ['-e', "process.stdout.write('ready'); setInterval(() => {}, 1000)", '--', ...args], {
    stdio: ['ignore', 'pipe', 'ignore'],
    windowsHide: true,
  });
  children.push(child);
  return new Promise((resolve, reject) => {
    child.once('error', reject);
    child.stdout!.once('data', () => resolve(child));
  });
}

async function scanThrough(path: string) {
  helper.path = path;
  vi.resetModules();
  const errors = vi.spyOn(console, 'error').mockImplementation(() => {});
  const { readWindowsProcessSnapshot } = await import('../windows-processes');
  const snapshot = await readWindowsProcessSnapshot();
  // The helper scan falls back to PowerShell on failure and says so here. A
  // fallback would compare PowerShell with itself and prove nothing.
  const fellBack = errors.mock.calls.some(call => call.join(' ').includes('Process scan helper failed'));
  errors.mockRestore();
  return { snapshot, fellBack };
}

describe.skipIf(process.platform !== 'win32' || !existsSync(builtHelper))('process scan through the built helper', () => {
  afterEach(() => {
    for (const child of children.splice(0)) child.kill();
    vi.restoreAllMocks();
  });

  it('reads the same command lines as the PowerShell scan', async () => {
    const markers = await Promise.all(MARKER_ARGS.map(startMarker));
    const native = await scanThrough(builtHelper);
    const powershell = await scanThrough(join(tmpdir(), 'ccg-not-shipped', 'ai-bridge-job.exe'));
    const after = await scanThrough(builtHelper);

    expect(native.snapshot).not.toBeNull();
    expect(native.fellBack, 'the helper scan fell back to PowerShell').toBe(false);
    expect(powershell.snapshot).not.toBeNull();
    expect(after.snapshot).not.toBeNull();
    expect(after.fellBack, 'the helper scan fell back to PowerShell').toBe(false);

    // Every process here lives through all three scans, so its PID cannot change hands.
    const pids = [process.pid, ...markers.map(child => child.pid!)];
    const differing = pids.filter(pid => {
      const text = native.snapshot!.get(pid);
      return typeof text !== 'string' || text !== powershell.snapshot!.get(pid) || text !== after.snapshot!.get(pid);
    });
    expect(differing, 'PIDs whose command line the scans did not read the same').toEqual([]);

    // And the text is the one each process was started with.
    MARKER_ARGS.forEach((args, index) => {
      const text = native.snapshot!.get(markers[index].pid!)!;
      for (const arg of args) expect(text.includes(arg.replace(/"/g, '\\"')) || text.includes(arg), `marker ${index}`).toBe(true);
    });
    expect(native.snapshot!.get(process.pid)!.includes('vitest'), 'the scan reads this test process').toBe(true);
  }, 120_000);
});
