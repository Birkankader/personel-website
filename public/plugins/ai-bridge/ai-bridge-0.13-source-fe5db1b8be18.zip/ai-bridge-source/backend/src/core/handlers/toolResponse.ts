import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { sendToolResultToProcess, sendControlResponseToProcess } from '../claude-process';
import { MessageType, buildUserDeclinedContent } from '../../shared';
import type { PermissionUpdate } from '../../shared';
import { takePreview, peekPreview } from '../features/diffPreview';
import { holdApprovalIfBaseMoved } from '../features/reviewBase';

/** WebView -> Backend TOOL_RESPONSE payload */
interface ToolResponsePayload {
  toolUseId: string;
  sessionId?: string;
  approved: boolean;
  controlRequestId?: string;
  updatedInput?: Record<string, unknown>;
  reason?: string;
  result?: string;
  /**
   * Permission rules to install alongside this approval — how "yes, and stop
   * asking this session" is said to the CLI (#393). Passed through untouched:
   * the shape is the CLI's, and the webview builds it from the shared helper.
   */
  updatedPermissions?: PermissionUpdate[];
}

export async function toolResponseHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  bridge: Bridge,
): Promise<void> {
  const payload = message.payload as ToolResponsePayload | undefined;
  const sessionId = payload?.sessionId ?? connections.getClient(connectionId)?.subscribedSessionId;
  const toolUseId = payload?.toolUseId ?? '';
  const approved = payload?.approved ?? true;
  const controlRequestId = payload?.controlRequestId;
  const fail = (error: string) => connections.sendTo(connectionId, MessageType.ACK, {
    requestId: message.requestId, status: 'error', error,
  });
  if (!sessionId || sessionId !== connections.getClient(connectionId)?.subscribedSessionId) {
    await fail('The conversation changed. Return to the conversation that requested permission.');
    return;
  }
  if (controlRequestId) {
    const pending = connections.getSession(sessionId)?.pendingControlRequests.get(controlRequestId);
    const request = pending?.request as Record<string, unknown> | undefined;
    if (!request || (toolUseId && request.tool_use_id !== toolUseId)) {
      await fail('This permission request is no longer pending in this conversation.');
      return;
    }
  }

  /*
   * The gate, on this path too (#359).
   *
   * This is the button the reporter actually pressed — the chat prompt's Yes,
   * not the review diff's Confirm — so a check that lived only in the other
   * handler left the reported case wide open. Approving here writes the tool
   * call as proposed, and the proposal was built from the file as it was when
   * the request arrived.
   *
   * Peeked, not taken, so a held approval stays answerable: the preview is
   * consumed below only once an answer is really going out.
   */
  const preview = toolUseId ? peekPreview(toolUseId) : undefined;
  if (approved && preview) {
    const held = await holdApprovalIfBaseMoved({
      connections,
      sessionId,
      toolUseId,
      preview,
      bridge,
      // No selection travels on this path — the chat's Yes means the whole
      // change — so every disk change is treated as touching it.
    });
    if (held) {
      // Nothing sent to the CLI: the request stays open, and the surface has
      // been told to offer a refresh. ACK so the webview stops waiting on us.
      await connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId, status: 'held' });
      return;
    }
  }

  if (controlRequestId) {
    // control_response protocol (can_use_tool permission, ExitPlanMode, AskUserQuestion).
    // A denial here is the user's DECISION, not a tool/server failure. This is the
    // LIVE path for every permission prompt: the CLI turns our `deny` message into
    // the resulting tool_result content (is_error:true). We stamp that message with
    // the shared USER_DECLINED_PREFIX marker so the webview can render it as a
    // neutral "Declined" note instead of a red error — and, since the marker lives
    // in the persisted content, the distinction survives a reload.
    const response = {
      subtype: 'success' as const,
      request_id: controlRequestId,
      response: approved
        ? {
            behavior: 'allow',
            updatedInput: payload?.updatedInput ?? {},
            // Only when there is something to install: an empty array is a
            // different statement from saying nothing, and the CLI has no
            // reason to read one.
            ...(payload?.updatedPermissions?.length
              ? { updatedPermissions: payload.updatedPermissions }
              : {}),
          }
        : { behavior: 'deny', message: buildUserDeclinedContent(payload?.reason) },
    };
    if (!sendControlResponseToProcess(connections, sessionId, response)) {
      await fail('Could not deliver the permission response. Please retry.');
      return;
    }
    console.error('[node-backend]', `CONTROL_RESPONSE sent for request ${controlRequestId} (approved: ${approved})`);
  } else {
    // Legacy tool_result path (kept for completeness; permission prompts use the
    // control_response branch above). Same marker rule so a denial reads as a
    // neutral decision rather than a red error, and survives reload.
    const resultContent = approved
      ? (payload?.result || 'Tool execution approved')
      : buildUserDeclinedContent(payload?.reason);

    const toolResult = {
      type: 'tool_result' as const,
      tool_use_id: toolUseId,
      content: resultContent,
      is_error: !approved,
    };
    if (!sendToolResultToProcess(connections, sessionId, toolResult)) {
      await fail('Could not deliver the permission response. Please retry.');
      return;
    }
    console.error('[node-backend]', `TOOL_RESPONSE sent for tool ${toolUseId} (approved: ${approved})`);
  }

  // The IDE's diff owns hunk selection now, so a plain approval from the chat
  // means the whole change. Still consume any stored preview: the request is
  // answered either way, and a leftover entry would outlive its question.
  if (toolUseId) takePreview(toolUseId);

  // The user has answered, so whatever previewed this edit has served its
  // purpose — close it either way. Both surfaces are told, because which one was
  // opened depends on a setting read when the request arrived, and it may have
  // changed since; unknown ids are a no-op on the IDE side, so telling both is
  // cheaper than remembering. Fire-and-forget: the CLI is waiting on the
  // response below, not on a closing tab.
  if (toolUseId) {
    bridge.closeDiff({ toolUseId }).catch((err) => {
      console.error('[node-backend]', 'Failed to close IDE diff after decision:', err);
    });
    bridge.closeDiffTab({ toolUseId }).catch((err) => {
      console.error('[node-backend]', 'Failed to close diff tab after decision:', err);
    });
  }

  await connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId, status: 'resolved' });
}
