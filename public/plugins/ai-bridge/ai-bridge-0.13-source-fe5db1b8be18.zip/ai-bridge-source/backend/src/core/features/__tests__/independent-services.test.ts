import { afterEach, describe, expect, it, vi } from 'vitest';
import * as telemetry from '../telemetry';

afterEach(() => { vi.unstubAllGlobals(); vi.unstubAllEnvs(); vi.restoreAllMocks(); });

describe('no upstream service transport', () => {
  it('has no analytics calls left to revive', () => {
    expect(Object.keys(telemetry).sort()).toEqual(['getRawClientInfo', 'reportBackendError', 'setBrowserClient']);
  });

  it('reports errors only locally, even with the old endpoint/API-key environment variables set', () => {
    const network = vi.fn(); vi.stubGlobal('fetch', network);
    vi.spyOn(console, 'error').mockImplementation(() => {});
    vi.stubEnv('CCG_WWW_API_BASE', 'https://upstream.invalid/api');
    vi.stubEnv('_CCG_RYBBIT_API_KEY', 'old-secret');
    vi.stubEnv('AI_BRIDGE_ANNOUNCE_URL', 'https://upstream.invalid/announcements');
    telemetry.reportBackendError(new Error('local failure'));
    expect(network).not.toHaveBeenCalled();
  });
});
