import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

// environment.ts reads process.env once at import time, so each case re-imports it
// with a controlled environment (module cache reset in beforeEach).
async function loadModules() {
  const environment = await import('../../../config/environment');
  const telemetry = await import('../telemetry');
  return { environment, telemetry };
}

describe('clientInfo (producer: AI_BRIDGE_CLIENT_INFO, consumer: getRawClientInfo)', () => {
  beforeEach(() => {
    vi.resetModules();
  });

  afterEach(() => {
    vi.unstubAllEnvs();
    vi.restoreAllMocks();
  });

  it('exports the launcher-injected client info as `clientInfo`', async () => {
    vi.stubEnv('AI_BRIDGE_CLIENT_INFO', 'WebStorm 2024.1 (WS-241.14494.240)');
    const { environment } = await loadModules();
    expect(environment.clientInfo).toBe('WebStorm 2024.1 (WS-241.14494.240)');
  });

  it('defaults to an empty string when the launcher injected nothing', async () => {
    vi.stubEnv('AI_BRIDGE_CLIENT_INFO', undefined);
    const { environment } = await loadModules();
    expect(environment.clientInfo).toBe('');
  });

  it('getRawClientInfo returns the injected value in JetBrains mode', async () => {
    vi.stubEnv('JETBRAINS_MODE', 'true');
    vi.stubEnv('AI_BRIDGE_CLIENT_INFO', 'IntelliJ IDEA 2024.1.4 (IC-241.18034.62)');
    const { telemetry } = await loadModules();
    telemetry.setBrowserClient('ignored browser client');
    expect(telemetry.getRawClientInfo()).toBe('IntelliJ IDEA 2024.1.4 (IC-241.18034.62)');
  });

  it('getRawClientInfo returns the browser-reported client outside JetBrains mode', async () => {
    vi.stubEnv('JETBRAINS_MODE', 'false');
    vi.stubEnv('AI_BRIDGE_CLIENT_INFO', 'IntelliJ IDEA 2024.1.4 (IC-241.18034.62)');
    const { telemetry } = await loadModules();
    telemetry.setBrowserClient('Chrome 130');
    expect(telemetry.getRawClientInfo()).toBe('Chrome 130');
  });
});

describe('reportBackendError', () => {
  afterEach(() => {
    vi.restoreAllMocks();
  });

  it('logs under the canonical [node-backend] source tag', async () => {
    const spy = vi.spyOn(console, 'error').mockImplementation(() => {});
    const { reportBackendError } = await import('../telemetry');

    reportBackendError(new Error('something broke'), { area: 'test' });

    expect(spy).toHaveBeenCalledWith('[node-backend]', 'something broke', { area: 'test' });
  });
});
