import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { isKnownInputMode, sendSetPermissionModeToProcess } from '../claude-process';
import { MessageType } from '../../shared';

/**
 * Carry a permission mode the user picked to the CLI that is running right now.
 *
 * Answered with `ok` whether or not the CLI took it. A session with no live CLI
 * is the ordinary case (the user changes the mode between turns), and the mode
 * still reaches the next spawn as `--permission-mode` — so reporting an error
 * here would call the normal path a failure. `applied` says which of the two
 * happened, for callers that care.
 *
 * A mode this backend does not know (`yolo`, a prototype key such as `toString`)
 * is an `error`, not an `ok` with `applied: false`: nothing would ever apply it,
 * neither now nor at the next spawn, and the caller should hear that.
 */
export async function setPermissionModeHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const client = connections.getClient(connectionId);
  const inputMode = message.payload?.inputMode as string | undefined;

  if (!inputMode) {
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'error',
      error: 'No inputMode given',
    });
    return;
  }

  // Judged before the session: a bad value is wrong whichever tab sent it.
  if (!isKnownInputMode(inputMode)) {
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'error',
      error: `Unknown inputMode "${inputMode}"`,
    });
    return;
  }

  if (!client?.subscribedSessionId) {
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'error',
      error: 'No active session',
    });
    return;
  }

  const sessionId = client.subscribedSessionId;
  const applied = sendSetPermissionModeToProcess(connections, sessionId, inputMode);

  await connections.sendTo(connectionId, MessageType.ACK, {
    requestId: message.requestId,
    status: 'ok',
    applied,
  });
}
