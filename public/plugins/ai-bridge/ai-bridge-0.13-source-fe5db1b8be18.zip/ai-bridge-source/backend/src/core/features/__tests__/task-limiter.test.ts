import { describe, expect, it, vi } from 'vitest';
import { TaskLimiter } from '../task-limiter';

const flush = async () => { for (let i = 0; i < 5; i++) await Promise.resolve(); };

describe('TaskLimiter', () => {
  it('keeps every pending user message, active startup, internal FIFO tasks and other sessions', async () => {
    const updates = vi.fn();
    const limiter = new TaskLimiter(1, updates);
    const started: string[] = [];
    const work = (name: string) => () => { started.push(name); return true; };
    const active = limiter.enqueueUser('a', '/project', work('active'), vi.fn(), 'msg-a');
    const old = limiter.enqueueUser('a', '/project', work('old'), vi.fn(), 'msg-old');
    const internal = limiter.enqueue('a', '/project', work('internal'), vi.fn());
    const other = limiter.enqueueUser('b', '/other', work('other'), vi.fn(), 'msg-b');
    const latest = limiter.enqueueUser('a', '/project', work('latest'), vi.fn(), 'msg-latest');
    expect(limiter.get(active.id)?.state).toBe('starting');
    expect(limiter.get(old.id)?.state).toBe('queued');
    expect(limiter.get(internal.id)).toBeDefined();
    expect(limiter.get(other.id)).toBeDefined();
    expect(limiter.get(latest.id)?.state).toBe('queued');
    expect(updates.mock.calls.some(([snapshot]) => snapshot.changedTask?.state === 'cancelled')).toBe(false);
    await flush();
    expect(started).toEqual(['active']);
    limiter.release('a'); await flush();
    limiter.release('a'); await flush();
    limiter.release('a'); await flush();
    limiter.release('b'); await flush();
    expect(started).toEqual(['active', 'old', 'internal', 'other', 'latest']);
  });

  it('rejects new work at capacity without losing existing queued messages', async () => {
    const limiter = new TaskLimiter(1);
    limiter.enqueueUser('a', '/project', () => true, vi.fn(), 'active');
    const old = limiter.enqueueUser('a', '/project', () => true, vi.fn(), 'old');
    for (let i = 0; i < 126; i++) limiter.enqueue(`other-${i}`, '/project', () => true, vi.fn());
    const work = vi.fn(() => true);
    expect(() => limiter.enqueueUser('a', '/project', work, vi.fn(), 'latest')).toThrow('queue is full');
    expect(limiter.snapshot().tasks).toHaveLength(128);
    expect(limiter.cancelQueued(old.id)).toBe(true);
    await flush();
    expect(work).not.toHaveBeenCalled();
    expect(limiter.snapshot().tasks[0].state).toBe('running');
  });

  it('reserves slots before async startup and starts queued tasks in order on real completion', async () => {
    const limiter = new TaskLimiter(2);
    const started: string[] = [];
    for (const id of ['a', 'b', 'c', 'd']) limiter.enqueue(id, '/project', () => { started.push(id); return true; }, vi.fn());
    await flush();
    expect(started).toEqual(['a', 'b']);
    expect(limiter.snapshot().tasks.map((task) => task.state)).toEqual(['running', 'running', 'queued', 'queued']);
    limiter.release('a');
    await flush();
    expect(started).toEqual(['a', 'b', 'c']);
    limiter.release('b');
    await flush();
    expect(started).toEqual(['a', 'b', 'c', 'd']);
  });

  it('does not write a second message to a session while its turn is running', async () => {
    const limiter = new TaskLimiter(2);
    const first = vi.fn(() => true), second = vi.fn(() => true), other = vi.fn(() => true);
    limiter.enqueue('a', '/project', first, vi.fn());
    limiter.enqueue('a', '/project', second, vi.fn());
    limiter.enqueue('b', '/other', other, vi.fn());
    await flush();
    expect(first).toHaveBeenCalledOnce(); expect(second).not.toHaveBeenCalled(); expect(other).toHaveBeenCalledOnce();
    limiter.release('a'); await flush(); expect(second).toHaveBeenCalledOnce();
  });

  it('cancels queued work without ever invoking it', async () => {
    const updates = vi.fn();
    const limiter = new TaskLimiter(1, updates);
    limiter.enqueue('a', '/project', () => true, vi.fn());
    const work = vi.fn(() => true);
    const queued = limiter.enqueue('b', '/other', work, vi.fn());
    expect(limiter.cancelQueued(queued.id)).toBe(true);
    limiter.release('a'); await flush();
    expect(work).not.toHaveBeenCalled();
    expect(updates.mock.calls.some(([update]) => update.changedTask?.state === 'cancelled')).toBe(true);
  });

  it('releases a slot on startup failure and reports the actual error', async () => {
    const limiter = new TaskLimiter(1);
    const onError = vi.fn();
    limiter.enqueue('a', '/project', async () => { throw new Error('spawn failed'); }, onError);
    const next = vi.fn(() => true);
    limiter.enqueue('b', '/other', next, vi.fn());
    await flush(); await flush();
    expect(onError).toHaveBeenCalledWith(expect.objectContaining({ message: 'spawn failed' }));
    expect(next).toHaveBeenCalledOnce();
    expect(limiter.snapshot().tasks).toHaveLength(1);
  });

  it('cancels async startup before stdin is written and then releases its slot', async () => {
    const limiter = new TaskLimiter(1);
    let finish!: () => void;
    const startup = new Promise<void>((resolve) => { finish = resolve; });
    const write = vi.fn();
    limiter.enqueue('a', '/project', async (cancelled) => { await startup; if (cancelled()) return false; write(); return true; }, vi.fn());
    await flush(); limiter.cancelSession('a'); finish(); await flush();
    expect(write).not.toHaveBeenCalled(); expect(limiter.snapshot().tasks).toEqual([]);
  });

  it('ends a user send stopped before it claimed its turn, without waiting for its startup', async () => {
    const limiter = new TaskLimiter(1);
    let finish!: () => void;
    const startup = new Promise<void>((resolve) => { finish = resolve; });
    const write = vi.fn();
    limiter.enqueueUser('a', '/project', async (cancelled) => { await startup; if (cancelled()) return false; write(); return true; }, vi.fn(), 'msg-a');
    const next = vi.fn(() => true);
    limiter.enqueue('b', '/other', next, vi.fn());
    await flush(); limiter.cancelSession('a'); await flush();
    expect(limiter.snapshot().tasks.map(task => task.sessionId)).toEqual(['b']);
    expect(next).toHaveBeenCalledOnce();
    finish(); await flush();
    expect(write).not.toHaveBeenCalled();
  });

  it('keeps a user send that claimed its turn until the CLI confirms completion', async () => {
    const limiter = new TaskLimiter(1);
    let written!: () => void;
    const writing = new Promise<void>((resolve) => { written = resolve; });
    limiter.enqueueUser('a', '/project', async (cancelled) => { if (cancelled()) return false; await writing; return true; }, vi.fn(), 'msg-a');
    await flush(); limiter.cancelSession('a'); await flush();
    expect(limiter.snapshot().tasks[0].state).toBe('stopping');
    written(); await flush();
    expect(limiter.snapshot().tasks[0].state).toBe('stopping');
    limiter.release('a'); await flush();
    expect(limiter.snapshot().tasks).toEqual([]);
  });

  it('keeps stopping work in its slot until the CLI confirms completion', async () => {
    const limiter = new TaskLimiter(1);
    limiter.enqueue('a', '/project', () => true, vi.fn());
    const next = vi.fn(() => true);
    limiter.enqueue('b', '/other', next, vi.fn());
    await flush(); limiter.cancelSession('a'); await flush();
    expect(next).not.toHaveBeenCalled();
    expect(limiter.snapshot().tasks[0].state).toBe('stopping');
    limiter.release('a'); await flush(); expect(next).toHaveBeenCalledOnce();
  });

  it('applies increases immediately and decreases after existing turns finish', async () => {
    const limiter = new TaskLimiter(1);
    const started: string[] = [];
    for (const id of ['a', 'b', 'c', 'd']) limiter.enqueue(id, '/project', () => { started.push(id); return true; }, vi.fn());
    await flush(); limiter.setLimit(3); await flush(); expect(started).toEqual(['a', 'b', 'c']);
    limiter.setLimit(1); limiter.release('a'); limiter.release('b'); await flush(); expect(started).toHaveLength(3);
    limiter.release('c'); await flush(); expect(started).toEqual(['a', 'b', 'c', 'd']);
  });

  it.each([0, 17, 1.5, NaN])('rejects invalid limit %s', (limit) => {
    expect(() => new TaskLimiter(limit)).toThrow('between 1 and 16');
  });

  it('never starts queued work when running processes exit during backend shutdown', async () => {
    const limiter = new TaskLimiter(1);
    limiter.enqueue('a', '/project', () => true, vi.fn());
    const next = vi.fn(() => true);
    limiter.enqueue('b', '/other', next, vi.fn());
    await flush(); limiter.shutdown(); limiter.release('a'); await flush();
    expect(next).not.toHaveBeenCalled();
    expect(limiter.snapshot().tasks).toEqual([]);
    expect(() => limiter.enqueue('c', '/other', next, vi.fn())).toThrow('shutting down');
  });
});
