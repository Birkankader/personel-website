import { describe, expect, it, vi } from 'vitest';
import { estimateHistoryBytes, SessionHistoryCache } from '../sessionHistoryCache';

function deferred<T>() {
  let resolve!: (value: T) => void;
  let reject!: (error: Error) => void;
  const promise = new Promise<T>((yes, no) => { resolve = yes; reject = no; });
  return { promise, resolve, reject };
}
const result = <T>(value: T, cacheable = true) => ({ value, cacheable });

describe('SessionHistoryCache', () => {
  it('evicts by byte budget using the access order, not only the session count', async () => {
    const value = [{ text: 'small history' }];
    const bytes = estimateHistoryBytes(value, Infinity);
    const cache = new SessionHistoryCache(bytes * 2, 4);
    const read = vi.fn(async () => result(value));
    await cache.getOrLoad('a', 'v1', read);
    await cache.getOrLoad('b', 'v1', read);
    await cache.getOrLoad('a', 'v1', read);
    await cache.getOrLoad('c', 'v1', read);
    expect(cache.estimatedBytes).toBe(bytes * 2);
    await cache.getOrLoad('a', 'v1', read);
    expect(read).toHaveBeenCalledTimes(3);
    await cache.getOrLoad('b', 'v1', read);
    expect(read).toHaveBeenCalledTimes(4);
    expect(cache.estimatedBytes).toBeLessThanOrEqual(bytes * 2);
  });

  it('keeps the session count cap as well as the byte cap', async () => {
    const cache = new SessionHistoryCache(10_000, 2);
    const read = vi.fn(async () => result([]));
    for (const key of ['a', 'b', 'c', 'a']) await cache.getOrLoad(key, 'v1', read);
    expect(read).toHaveBeenCalledTimes(4);
  });

  it('returns oversized histories intact without evicting a small cached session', async () => {
    const cache = new SessionHistoryCache<unknown[]>(1024);
    const small = vi.fn(async () => result([{ unknownField: { intact: true } }]));
    const largeValue = [{ text: 'x'.repeat(1024), original: { nested: [1, 2, 3] } }];
    const large = vi.fn(async () => result(largeValue));
    await cache.getOrLoad('small', 'v1', small);
    const bytes = cache.estimatedBytes;
    expect(await cache.getOrLoad('large', 'v1', large)).toBe(largeValue);
    await cache.getOrLoad('large', 'v1', large);
    await cache.getOrLoad('small', 'v1', small);
    expect(large).toHaveBeenCalledTimes(2);
    expect(small).toHaveBeenCalledTimes(1);
    expect(cache.estimatedBytes).toBe(bytes);
  });

  it('shares one pending read and allows retry after rejection', async () => {
    const cache = new SessionHistoryCache<string[]>();
    const gate = deferred<ReturnType<typeof result<string[]>>>();
    const read = vi.fn(() => gate.promise);
    const first = cache.getOrLoad('a', 'v1', read);
    const second = cache.getOrLoad('a', 'v1', read);
    expect(second).toBe(first);
    const settled = Promise.allSettled([first, second]);
    gate.reject(new Error('temporary read failure'));
    expect((await settled).map(item => item.status)).toEqual(['rejected', 'rejected']);
    expect(read).toHaveBeenCalledTimes(1);
    expect(await cache.getOrLoad('a', 'v1', async () => result(['retry']))).toEqual(['retry']);
  });

  it('does not let an older completion overwrite a newer snapshot', async () => {
    const cache = new SessionHistoryCache<string[]>();
    const old = deferred<ReturnType<typeof result<string[]>>>();
    const oldRequest = cache.getOrLoad('a', 'v1', () => old.promise);
    const current = ['current'];
    await cache.getOrLoad('a', 'v2', async () => result(current));
    old.resolve(result(['old']));
    expect(await oldRequest).toEqual(['old']);
    const unexpectedRead = vi.fn(async () => result([]));
    expect(await cache.getOrLoad('a', 'v2', unexpectedRead)).toBe(current);
    expect(unexpectedRead).not.toHaveBeenCalled();
  });

  it('an old failure cannot remove a newer pending read', async () => {
    const cache = new SessionHistoryCache<string[]>();
    const old = deferred<ReturnType<typeof result<string[]>>>();
    const current = deferred<ReturnType<typeof result<string[]>>>();
    const oldRequest = cache.getOrLoad('a', 'v1', () => old.promise);
    const failed = expect(oldRequest).rejects.toThrow('old failure');
    const newRequest = cache.getOrLoad('a', 'v2', () => current.promise);
    old.reject(new Error('old failure'));
    await failed;
    expect(cache.getOrLoad('a', 'v2', async () => result(['wrong']))).toBe(newRequest);
    current.resolve(result(['new']));
    expect(await newRequest).toEqual(['new']);
  });

  it('does not retain a snapshot changed during its read or explicitly invalidated', async () => {
    const cache = new SessionHistoryCache<string[]>();
    const read = vi.fn(async () => result(['changing'], false));
    await cache.getOrLoad('a', 'v1', read);
    await cache.getOrLoad('a', 'v1', read);
    expect(read).toHaveBeenCalledTimes(2);
    const gate = deferred<ReturnType<typeof result<string[]>>>();
    const request = cache.getOrLoad('a', 'v1', () => gate.promise);
    cache.invalidate('a');
    gate.resolve(result(['deleted']));
    await request;
    expect(cache.estimatedBytes).toBe(0);
  });

  it('releases the old weight when a snapshot is replaced', async () => {
    const cache = new SessionHistoryCache<string[]>();
    await cache.getOrLoad('a', 'v1', async () => result(['long'.repeat(100)]));
    const value = ['short'];
    await cache.getOrLoad('a', 'v2', async () => result(value));
    expect(cache.estimatedBytes).toBe(estimateHistoryBytes(value, Infinity));
    cache.invalidate('a');
    expect(cache.estimatedBytes).toBe(0);
  });
});

describe('estimateHistoryBytes', () => {
  it('counts nested data and UTF-16 strings without dropping fields or copying payloads', () => {
    const value = [{ unfamiliar: { content: '😀'.repeat(20), extra: [true, 123, null] } }];
    const original = JSON.stringify(value);
    expect(estimateHistoryBytes(value, Infinity)).toBeGreaterThan(80);
    expect(estimateHistoryBytes(value, 80)).toBe(81);
    expect(JSON.stringify(value)).toBe(original);
  });

  it('counts shared object references once and terminates on cycles', () => {
    const item: Record<string, unknown> = { text: 'shared' };
    const shared = estimateHistoryBytes([item, item], Infinity);
    expect(estimateHistoryBytes([item, { ...item }], Infinity)).toBeGreaterThan(shared);
    item.self = item;
    expect(Number.isFinite(estimateHistoryBytes(item, Infinity))).toBe(true);
  });
});
