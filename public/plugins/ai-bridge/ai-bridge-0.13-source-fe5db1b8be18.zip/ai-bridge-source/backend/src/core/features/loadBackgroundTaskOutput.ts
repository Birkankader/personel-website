import { open, realpath } from 'fs/promises';
import { join, resolve, sep } from 'path';
import { getTmpBase } from '../handlers/findBackgroundTaskOutputPath';
import { getClaudeConfigDir } from './claudeConfigDir';

// Cap how much of a long-running Bash task's log we return in one shot —
// mirrors loadWorkflowAgentTranscript's MAX_ENTRIES safety valve. Counted in
// characters here since the file is plain text, not JSONL.
const MAX_CHARS = 200_000;
// UTF-8 needs at most three bytes per UTF-16 code unit. The extra character
// proves truncation, and three more bytes cover a partial leading code point.
// Keep disk reads bounded as well as the response, even for multi-GB logs.
const MAX_BYTES = (MAX_CHARS + 1) * 3 + 3;

export interface BackgroundTaskOutput {
  text: string;
  truncated: boolean;
}

/**
 * Read a background task's raw output file: a plain Bash task's stdout/stderr
 * log, written directly under the tmp root (issue #347) — or a backgrounded
 * Agent/Task's own JSONL transcript (issue #383), whose advertised path under
 * the tmp root is actually a *symlink* to the real transcript file the CLI
 * already writes under the Claude config dir's `projects/.../subagents/`
 * (confirmed by `ls -la` on a live one: `tasks/<id>.output -> ~/.claude/
 * projects/<proj>/<session>/subagents/agent-<id>.jsonl`). Either way
 * task_type 'local_bash'/'local_agent' has no agents array to render a
 * transcript picker for, so the detail modal shows this file directly.
 * `outputFile` is server-issued (WorkflowTask.outputFile) but round-tripped
 * through the client, so it is revalidated here rather than trusted — against
 * BOTH roots, since a real path can legitimately resolve under either.
 */
export async function resolveBackgroundTaskOutput(outputFile: string): Promise<string | null> {
  if (!outputFile) return null;

  let tmpRoot: string;
  try {
    tmpRoot = await realpath(getTmpBase());
  } catch {
    return null;
  }

  let projectsRoot: string | null;
  try {
    projectsRoot = await realpath(join(getClaudeConfigDir(), 'projects'));
  } catch {
    projectsRoot = null;
  }

  const resolved = resolve(outputFile);
  let real: string;
  try {
    real = await realpath(resolved);
  } catch {
    // Not written yet (task just started) — not an error, nothing to show.
    return null;
  }

  const underTmpRoot = real === tmpRoot || real.startsWith(tmpRoot + sep);
  const underProjectsRoot = !!projectsRoot && (real === projectsRoot || real.startsWith(projectsRoot + sep));
  return underTmpRoot || underProjectsRoot ? real : null;
}

export async function loadBackgroundTaskOutput(payload: { outputFile: string }): Promise<BackgroundTaskOutput> {
  const real = await resolveBackgroundTaskOutput(payload.outputFile);
  if (!real) return { text: '', truncated: false };

  try {
    const handle = await open(real, 'r');
    try {
      const { size } = await handle.stat();
      const length = Math.min(size, MAX_BYTES);
      const start = size - length;
      const buffer = Buffer.allocUnsafe(length);
      let bytesRead = 0;
      while (bytesRead < length) {
        const read = await handle.read(buffer, bytesRead, length - bytesRead, start + bytesRead);
        if (read.bytesRead === 0) break; // The task may truncate its log while we read.
        bytesRead += read.bytesRead;
      }

      const text = buffer.toString('utf-8', 0, bytesRead);
      const truncated = start > 0 || text.length > MAX_CHARS;
      return { text: text.slice(-MAX_CHARS), truncated };
    } finally {
      await handle.close();
    }
  } catch {
    return { text: '', truncated: false };
  }
}
