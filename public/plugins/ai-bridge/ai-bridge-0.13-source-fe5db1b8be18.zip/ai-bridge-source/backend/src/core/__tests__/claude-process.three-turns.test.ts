import { EventEmitter } from 'events';
import { Writable } from 'stream';
import type { ChildProcess } from 'child_process';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { Bridge } from '../../bridge/bridge-interface';
import { ConnectionManager } from '../../ws/connection-manager';
import { MessageType } from '../../shared';
import { TaskLimiter } from '../features/task-limiter';
import { sendMessageHandler } from '../handlers/sendMessage';
import { Claude } from '../claude';
import { sendAfterTurn } from '../features/afterTurn';

const holder = vi.hoisted(() => ({ manager: null as unknown }));
vi.mock('../features/runtime-tasks', () => ({ runtimeTasks: () => holder.manager }));
vi.mock('../claude', () => ({ Claude: { command: 'claude', applyConfigDir: vi.fn(async () => {}), spawnAuthed: vi.fn(), killTree: vi.fn() } }));
vi.mock('../features/settings', () => ({ readMergedSettings: vi.fn(async () => ({ settings: {} })) }));
vi.mock('../features/claude-settings', () => ({ readMergedClaudeSettings: vi.fn(async () => ({ settings: {} })) }));
vi.mock('../features/scheduled-messages', () => ({ restoreSchedulesForSession: vi.fn(async () => {}) }));
vi.mock('../features/lastRecordedSend', () => ({ readLastRecordedSend: vi.fn(async () => null) }));
vi.mock('../cli-registry', () => ({ findLiveCliForSession: vi.fn(() => null), registerCliProcess: vi.fn(), unregisterCliProcess: vi.fn() }));
vi.mock('../features/workflow-tracker', () => ({ WorkflowProgressTracker: { create: () => ({ handleEvent: vi.fn(), stopSession: vi.fn(), hasRunning: () => false }) } }));
vi.mock('../features/telemetry', () => ({ reportBackendError: vi.fn() }));

type PendingWrite = { content: string; complete: (error?: Error | null) => void };
function fakeProcess(pid: number) {
  const writes: PendingWrite[] = [];
  const stdin = new Writable({ highWaterMark: 1, write(chunk, _encoding, callback) {
    writes.push({ content: JSON.parse(String(chunk)).message.content, complete: callback });
  } });
  // Capture a failed fixture pipe without letting EventEmitter fail the test
  // runner before we can assert the backend's task/error handling.
  stdin.on('error', () => {});
  return Object.assign(new EventEmitter(), {
    pid, exitCode: null as number | null, signalCode: null,
    stdout: new EventEmitter(), stderr: new EventEmitter(), stdin, writes,
  });
}
type FakeProcess = ReturnType<typeof fakeProcess>;
const bridge = {} as Bridge;
let connections: ConnectionManager;
let limiter: TaskLimiter;
let launches: FakeProcess[];
let session: string;
let sequence = 0;

beforeEach(() => {
  vi.clearAllMocks();
  launches = [];
  limiter = new TaskLimiter(1);
  holder.manager = { limiter, ready: Promise.resolve() };
  connections = new ConnectionManager(true);
  vi.spyOn(connections, 'broadcastToSession');
  session = `three-turns-${++sequence}`;
  connections.getOrCreateSession(session, '/fixture');
  vi.mocked(Claude.spawnAuthed).mockImplementation(async () => {
    const proc = fakeProcess(45000 + launches.length);
    launches.push(proc);
    setImmediate(() => proc.emit('spawn'));
    return proc as unknown as ChildProcess;
  });
  vi.mocked(Claude.killTree).mockImplementation(child => {
    const proc = child as unknown as FakeProcess;
    proc.exitCode = 0; proc.emit('close', 0);
  });
});
afterEach(() => {
  vi.useRealTimers();
  limiter.shutdown();
  for (const proc of launches) {
    proc.stdin.destroy();
    proc.exitCode = 0; proc.emit('close', 0);
  }
});

function send(content: string) {
  return sendMessageHandler('client', {
    type: MessageType.SEND_MESSAGE, requestId: content, timestamp: 0,
    payload: { sessionId: session, workingDir: '/fixture', content },
  }, connections, bridge);
}
function result(proc: FakeProcess) {
  proc.stdout.emit('data', Buffer.from(JSON.stringify({ type: 'result', session_id: session, is_error: false }) + '\n'));
}
async function written(index: number, processIndex = 0) {
  await vi.waitFor(() => expect(launches[processIndex]?.writes).toHaveLength(index + 1));
  return launches[processIndex].writes[index];
}
async function finish(index: number, processIndex = 0) {
  (await written(index, processIndex)).complete();
  await vi.waitFor(() => expect(limiter.snapshot().tasks[0]?.state).toBe('running'));
  result(launches[processIndex]);
}

describe('three prompt delivery and process lifecycle', () => {
  it('preserves the full CLI event when UTF-8 characters cross stdout chunks', async () => {
    await send('Türkçe mesaj');
    (await written(0)).complete();
    const event = {
      type: 'assistant', session_id: session, unknown_future_field: { label: 'çığ 🧭' },
      message: { content: [{ type: 'text', text: 'Üçüncü yanıt: Köprü 🧭' }] },
    };
    const bytes = Buffer.from(JSON.stringify(event) + '\n');
    for (const byte of bytes) launches[0].stdout.emit('data', Buffer.from([byte]));
    await vi.waitFor(() => expect(connections.broadcastToSession).toHaveBeenCalledWith(session, MessageType.CLI_EVENT, event));
  });

  it('flushes a fragmented final CLI event without a trailing newline before close', async () => {
    await send('son mesaj');
    (await written(0)).complete();
    const event = { type: 'result', session_id: session, is_error: false, result: 'Bitti 🧭' };
    const bytes = Buffer.from(JSON.stringify(event));
    for (let i = 0; i < bytes.length; i += 2) launches[0].stdout.emit('data', bytes.subarray(i, i + 2));
    launches[0].exitCode = 0;
    launches[0].emit('close', 0);
    await vi.waitFor(() => expect(connections.broadcastToSession).toHaveBeenCalledWith(session, MessageType.CLI_EVENT, event));
    await vi.waitFor(() => expect(limiter.snapshot().tasks).toEqual([]));
  });

  it('delivers three sequential prompts once each without appending earlier prompt text', async () => {
    for (const [index, content] of ['bir', 'iki', 'üç'].entries()) {
      await send(content);
      await finish(index);
    }
    expect(launches).toHaveLength(1);
    expect(launches[0].writes.map(write => write.content)).toEqual(['bir', 'iki', 'üç']);
    await vi.waitFor(() => expect(limiter.snapshot().tasks).toEqual([]));
  });

  it('finishes the active prompt and writes every queued prompt in order, without interrupting or restarting', async () => {
    await send('bir'); await send('iki'); await send('üç');
    await written(0);
    expect(launches[0].writes).toHaveLength(1);
    expect(limiter.snapshot().tasks).toHaveLength(3);
    for (let index = 0; index < 3; index++) await finish(index);
    expect(launches[0].writes.map(write => write.content)).toEqual(['bir', 'iki', 'üç']);
    expect(Claude.killTree).not.toHaveBeenCalled();
    expect(launches).toHaveLength(1);
    await vi.waitFor(() => expect(limiter.snapshot().tasks).toEqual([]));
  });

  it('waits for pipe acceptance and reports a third-write failure instead of leaving the task running', async () => {
    await send('bir'); await finish(0);
    await send('iki'); await finish(1);
    await send('üç');
    const third = await written(2);
    expect(limiter.snapshot().tasks[0]?.state).toBe('starting');
    third.complete(Object.assign(new Error('controlled EPIPE'), { code: 'EPIPE' }));
    await vi.waitFor(() => expect(limiter.snapshot().tasks).toEqual([]));
    expect(connections.broadcastToSession).toHaveBeenCalledWith(session, MessageType.SERVICE_ERROR,
      expect.objectContaining({ error: expect.stringContaining('controlled EPIPE') }));
  });

  it('accepts the third prompt after backpressure clears without replaying its write', async () => {
    await send('bir'); await finish(0);
    await send('iki'); await finish(1);
    const write = vi.spyOn(launches[0].stdin, 'write');
    await send('üç');
    await written(2);
    expect(write).toHaveReturnedWith(false);
    expect(limiter.snapshot().tasks[0]?.state).toBe('starting');
    await finish(2);
    expect(write).toHaveBeenCalledTimes(1);
    await vi.waitFor(() => expect(limiter.snapshot().tasks).toEqual([]));
  });

  it('fails a third prompt with a stalled pipe after a bounded wait and prevents late buffered delivery', async () => {
    await send('bir'); await finish(0);
    await send('iki'); await finish(1);
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout'] });
    await send('üç');
    await written(2);
    expect(limiter.snapshot().tasks[0]?.state).toBe('starting');
    await vi.advanceTimersByTimeAsync(30_000);
    await vi.waitFor(() => expect(limiter.snapshot().tasks).toEqual([]));
    expect(launches[0].stdin.destroyed).toBe(true);
    expect(launches[0].writes.map(write => write.content)).toEqual(['bir', 'iki', 'üç']);
    expect(connections.broadcastToSession).toHaveBeenCalledWith(session, MessageType.SERVICE_ERROR,
      expect.objectContaining({ error: expect.stringContaining('within 30 seconds') }));
  });

  it('respawns for prompt three after exit and ignores the old process delayed close', async () => {
    await send('bir'); await finish(0);
    await send('iki'); await finish(1);
    const old = launches[0];
    old.exitCode = 0;
    old.emit('exit', 0);
    await send('üç');
    await vi.waitFor(() => expect(old.listenerCount('close')).toBeGreaterThan(1));
    expect(old.writes).toHaveLength(2);
    old.emit('close', 0);
    await vi.waitFor(() => expect(launches).toHaveLength(2));
    const third = await written(0, 1);
    third.complete();
    await vi.waitFor(() => expect(limiter.snapshot().tasks[0]?.state).toBe('running'));
    old.emit('close', 0);
    expect(connections.getSession(session)?.process).toBe(launches[1]);
    expect(limiter.snapshot().tasks[0]?.state).toBe('running');
    expect(launches.flatMap(proc => proc.writes.map(write => write.content))).toEqual(['bir', 'iki', 'üç']);
    result(launches[1]);
    await vi.waitFor(() => expect(limiter.snapshot().tasks).toEqual([]));
  });

  it('echoes a held prompt before a fast result and does not restart streaming after its late write callback', async () => {
    await send('bir');
    (await written(0)).complete();
    await vi.waitFor(() => expect(limiter.snapshot().tasks[0]?.state).toBe('running'));
    sendAfterTurn(session, 'held notice');
    result(launches[0]);
    const held = await written(1);
    const startsBeforeResult = vi.mocked(connections.broadcastToSession).mock.calls
      .filter(([, type]) => type === MessageType.STREAM_START).length;
    result(launches[0]);
    await vi.waitFor(() => expect(limiter.snapshot().tasks).toEqual([]));
    held.complete();
    await vi.waitFor(() => expect(connections.broadcastToSession).toHaveBeenCalledWith(session,
      MessageType.USER_MESSAGE_BROADCAST, { content: 'held notice', sessionId: session }));
    const calls = vi.mocked(connections.broadcastToSession).mock.calls;
    const echoIndex = calls.findIndex(([, type, payload]) => type === MessageType.USER_MESSAGE_BROADCAST
      && (payload as { content?: string })?.content === 'held notice');
    const resultIndices = calls.flatMap(([, type, payload], index) => type === MessageType.CLI_EVENT
      && (payload as { type?: string })?.type === 'result' ? [index] : []);
    expect(echoIndex).toBeLessThan(resultIndices.at(-1)!);
    expect(calls.filter(([, type]) => type === MessageType.STREAM_START)).toHaveLength(startsBeforeResult);
    expect(connections.getSession(session)?.streaming).toBe(false);
    expect(launches[0].writes.map(write => write.content)).toEqual(['bir', 'held notice']);
  });
});
