import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const { execFile, existsSync, HELPER } = vi.hoisted(() => ({
  execFile: vi.fn(), existsSync: vi.fn(), HELPER: 'C:\\Users\\me\\ccg\\ai-bridge-job.exe',
}));
vi.mock('child_process', () => ({ execFile }));
vi.mock('fs', async (importOriginal) => ({ ...await importOriginal<typeof import('fs')>(), existsSync }));
vi.mock('../win-job', () => ({ jobHelperPath: () => HELPER }));

const rows = [{ ProcessId: 4, CommandLine: null }, { ProcessId: 9, CommandLine: 'claude --resume s-1' }];
/** What the helper answers; PowerShell always answers with `rows`. */
let helperAnswer: { error?: Error; stdout?: string };

beforeEach(() => {
  vi.resetModules();
  existsSync.mockReset().mockReturnValue(true);
  helperAnswer = { stdout: JSON.stringify(rows) };
  execFile.mockReset().mockImplementation((file: string, _args, _options, callback) => {
    const answer = file === HELPER ? helperAnswer : { stdout: JSON.stringify(rows) };
    queueMicrotask(() => callback(answer.error ?? null, answer.stdout ?? '', ''));
    return {};
  });
});
afterEach(() => { vi.restoreAllMocks(); });

const programs = () => execFile.mock.calls.map(([file]) => (file === HELPER ? 'helper' : file));
const expected = new Map([[4, null], [9, 'claude --resume s-1']]);

describe('readWindowsProcessSnapshot program choice', () => {
  it('scans through the shipped helper with nothing but --processes in argv', async () => {
    const { readWindowsProcessSnapshot } = await import('../windows-processes');
    expect(await readWindowsProcessSnapshot()).toEqual(expected);
    expect(execFile.mock.calls[0].slice(0, 2)).toEqual([HELPER, ['--processes']]);
    expect(programs()).toEqual(['helper']);
  });

  it('scans with PowerShell when the helper is not shipped', async () => {
    existsSync.mockReturnValue(false);
    const { readWindowsProcessSnapshot } = await import('../windows-processes');
    expect(await readWindowsProcessSnapshot()).toEqual(expected);
    expect(programs()).toEqual(['powershell.exe']);
  });

  it.each([
    ['cannot run', { error: Object.assign(new Error('spawn UNKNOWN'), { code: 'UNKNOWN' }) }],
    ['answers garbage', { stdout: '[{"ProcessId":"oops"}]' }],
  ])('scans with PowerShell for good once the helper %s', async (_name, answer) => {
    helperAnswer = answer;
    const error = vi.spyOn(console, 'error').mockImplementation(() => {});
    const { readWindowsProcessSnapshot } = await import('../windows-processes');
    expect(await readWindowsProcessSnapshot()).toEqual(expected);
    expect(await readWindowsProcessSnapshot()).toEqual(expected);
    expect(programs()).toEqual(['helper', 'powershell.exe', 'powershell.exe']);
    expect(error).toHaveBeenCalledTimes(1);
  });

  it('reports no snapshot when neither program can scan', async () => {
    helperAnswer = { error: new Error('boom') };
    execFile.mockImplementation((_file, _args, _options, callback) => {
      queueMicrotask(() => callback(new Error('boom'), '', ''));
      return {};
    });
    vi.spyOn(console, 'error').mockImplementation(() => {});
    const { readWindowsProcessSnapshot } = await import('../windows-processes');
    expect(await readWindowsProcessSnapshot()).toBeNull();
  });
});
