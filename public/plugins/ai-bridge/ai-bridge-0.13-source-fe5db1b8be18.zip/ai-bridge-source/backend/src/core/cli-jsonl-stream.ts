import type { Readable } from 'node:stream';
import { CliJsonlReader } from './cli-jsonl-reader';

/** Keep backpressure at the pipe: at most the current stdout chunk is parsed
 * while its recipient is full. Do not create an outstanding send per line. */
export class CliJsonlStream {
  private readonly reader = new CliJsonlReader();
  private pending?: Promise<void>;
  private ended = false;

  constructor(
    private readonly stream: Readable | null,
    private readonly onLine: (line: string) => void | Promise<void>,
    private readonly onError: (error: unknown) => void,
  ) {
    stream?.on('data', (chunk: Buffer) => {
      stream.pause?.();
      const consume = () => this.consume(this.reader.write(chunk));
      // A real Readable stops emitting data after pause(). Chaining also
      // preserves order for custom stream adapters delivering a final chunk.
      this.track(this.pending ? this.pending.then(consume) : consume());
    });
  }

  /** Process death must not overtake a blocked send or the final partial line. */
  finish(): void | Promise<void> {
    this.ended = true;
    const finish = () => this.consume(this.reader.end());
    return this.pending ? this.pending.then(finish) : finish();
  }

  private consume(lines: string[], offset = 0): void | Promise<void> {
    for (let index = offset; index < lines.length; index += 1) {
      let work: void | Promise<void> = undefined;
      try { work = this.onLine(lines[index]); } catch (error) { this.onError(error); }
      // Release each complete line once it has been handed to its consumer.
      lines[index] = '';
      if (work) {
        return work.catch(this.onError).then(() => this.consume(lines, index + 1));
      }
    }
  }

  private track(work: void | Promise<void>): void {
    if (!work) {
      if (!this.ended) this.stream?.resume?.();
      return;
    }
    const pending = work.catch(this.onError).then(() => {
      if (this.pending !== pending) return;
      this.pending = undefined;
      if (!this.ended) this.stream?.resume?.();
    });
    this.pending = pending;
  }
}
