import { createReadStream, type Dir } from 'fs';
import { opendir, realpath, stat } from 'fs/promises';
import { createHash, randomUUID } from 'crypto';
import { join, relative, sep } from 'path';
import { setImmediate as yieldToLoop } from 'timers/promises';
import type { ConversationSearchPage, ConversationSearchResult } from '../../shared/conversation-tools';
import { getClaudeConfigDir } from './claudeConfigDir';
import { getProjectSessionsPath } from './getProjectSessionsPath';

const MAX_FILES = 20_000;
const MAX_LINE_BYTES = 8 * 1024 * 1024;
const MAX_FILE_CACHE_BYTES = 1024 * 1024;
const MAX_CACHE_BYTES = 8 * 1024 * 1024;
const MAX_CACHE_FILES = 512;
const MAX_TOOL_REFERENCE_BYTES = 4 * 1024 * 1024;
const MAX_RECORDS_PER_PAGE = 2_000;
const MAX_BYTES_PER_PAGE = 512 * 1024;
const MAX_DISCOVERY_ENTRIES_PER_PAGE = 256;
const PAGE_BUDGET_MS = 120;
const CURSOR_TTL_MS = 5 * 60_000;
const ID = /^[a-zA-Z0-9_-]{1,160}$/;

type IndexedEntry = Omit<ConversationSearchResult, 'snippet'> & { text: string; end: number; navigationRanges: { end: number; uuid: string }[] };
interface FileCache { signature: string; rows: IndexedEntry[]; bytes: number }
interface Discovery {
  allProjects: boolean;
  rootDir?: Dir;
  projectDir?: Dir;
  projectPath?: string;
  initialProject?: string;
  done: boolean;
}
interface ScanState {
  owner: string;
  fingerprint: string;
  query: string;
  files: string[];
  root: string;
  workingDir: string;
  fileIndex: number;
  offset: number;
  cacheIndex: number;
  fileSignature?: string;
  title: string;
  cwd: string;
  tools: Map<string, string>;
  toolReferenceBytes: number;
  cancellationId?: string;
  candidate: IndexedEntry[];
  candidateBytes: number;
  skippedEntries: number;
  scopeTruncated: boolean;
  touchedAt: number;
  busy: boolean;
  discovery: Discovery;
  controller: AbortController;
  expiry?: ReturnType<typeof setTimeout>;
  cleanup?: Promise<void>;
  lineParts: Buffer[];
  lineLength: number;
  lineOversized: boolean;
}

export interface ConversationSearchRequest {
  owner: string;
  query: string;
  workingDir: string;
  allProjects?: boolean;
  cursor?: string;
  limit?: number;
  signal?: AbortSignal;
  cancellationId?: string;
}

class ToolReferenceLimitError extends Error {}

function assertActive(signal?: AbortSignal): void {
  if (signal?.aborted) throw new Error('Search cancelled');
}

function inside(root: string, path: string): boolean {
  const rel = relative(root, path);
  return rel !== '' && rel !== '..' && !rel.startsWith(`..${sep}`) && !rel.startsWith(sep);
}

/** Read in chunks, retaining at most one bounded JSON line. Never reads binary attachments. */
async function* lines(path: string, state: ScanState, size: number, byteBudget: number) {
  const start = state.offset;
  const end = Math.min(size, start + byteBudget);
  if (start >= end) return;
  const stream = createReadStream(path, { start, end: end - 1, highWaterMark: 64 * 1024, signal: state.controller.signal });
  let consumed = start;
  let checkpoint = start;
  try {
    for await (const chunk of stream) {
      assertActive(state.controller.signal);
      const buffer = chunk as Buffer;
      let from = 0;
      while (from < buffer.length) {
        const newline = buffer.indexOf(10, from);
        const to = newline < 0 ? buffer.length : newline + 1;
        const part = buffer.subarray(from, to);
        consumed += part.length;
        state.offset = consumed;
        state.lineLength += part.length;
        if (state.lineLength > MAX_LINE_BYTES) { state.lineParts = []; state.lineOversized = true; }
        else if (!state.lineOversized) state.lineParts.push(part);
        if (newline >= 0) {
          const text = state.lineOversized ? null : Buffer.concat(state.lineParts).toString('utf8');
          state.lineParts = []; state.lineLength = 0; state.lineOversized = false;
          const bytes = consumed - checkpoint; checkpoint = consumed;
          yield { text, end: consumed, bytes };
        }
        from = to;
      }
      // Progress checkpoints also cover a giant line without any newline. The
      // next request resumes its bytes and UTF-8 sequence, not a truncated JSON.
      if (consumed > checkpoint && consumed < size) {
        const bytes = consumed - checkpoint; checkpoint = consumed;
        yield { text: undefined, end: consumed, bytes };
      }
    }
    if (consumed === size && state.lineLength > 0) {
      const text = state.lineOversized ? null : Buffer.concat(state.lineParts).toString('utf8');
      state.lineParts = []; state.lineLength = 0; state.lineOversized = false;
      yield { text, end: consumed, bytes: consumed - checkpoint };
    }
  } finally {
    stream.destroy();
  }
}

/** Includes visible text, thoughts, command/tool inputs and tool outputs; excludes image data. */
function contentText(value: unknown, depth = 0): string {
  if (depth > 12 || value == null) return '';
  if (typeof value === 'string') return value;
  if (Array.isArray(value)) return value.map((v) => contentText(v, depth + 1)).filter(Boolean).join('\n');
  if (typeof value !== 'object') return String(value);
  const record = value as Record<string, unknown>;
  if (record.type === 'image' || record.type === 'document') return '';
  return Object.entries(record)
    .filter(([key]) => !['source', 'data', 'id', 'tool_use_id', 'type', 'signature'].includes(key))
    .map(([, child]) => contentText(child, depth + 1)).filter(Boolean).join('\n');
}

function indexEntry(raw: string, end: number, state: ScanState, sessionId: string): IndexedEntry | null {
  const entry = JSON.parse(raw) as Record<string, unknown>;
  if (typeof entry.cwd === 'string') state.cwd = entry.cwd;
  if (typeof entry.customTitle === 'string') state.title = entry.customTitle;
  if (entry.isSidechain === true || !ID.test(String(entry.uuid ?? ''))) return null;
  if (entry.type !== 'user' && entry.type !== 'assistant') return null;
  const message = entry.message as Record<string, unknown> | undefined;
  if (!message) return null;
  const uuid = entry.uuid as string;
  let targetUuid = typeof entry.sourceToolUseID === 'string' ? state.tools.get(entry.sourceToolUseID) ?? uuid : uuid;
  const navigationRanges: { end: number; uuid: string }[] = [];
  let text = '';
  if (Array.isArray(message.content)) {
    for (const block of message.content) {
      if (!block || typeof block !== 'object') continue;
      if (block.type === 'tool_use' && typeof block.id === 'string') {
        const previous = state.tools.get(block.id);
        const bytes = previous === undefined ? (block.id.length + uuid.length) * 2 + 64 : (uuid.length - previous.length) * 2;
        if (state.toolReferenceBytes + bytes > MAX_TOOL_REFERENCE_BYTES) throw new ToolReferenceLimitError();
        state.toolReferenceBytes += bytes;
        state.tools.set(block.id, uuid);
      }
      let blockTarget = targetUuid;
      if (block.type === 'tool_result' && typeof block.tool_use_id === 'string') {
        blockTarget = state.tools.get(block.tool_use_id) ?? uuid;
      }
      const blockText = contentText(block);
      if (!blockText) continue;
      text += `${text ? '\n' : ''}${blockText}`;
      navigationRanges.push({ end: text.length, uuid: blockTarget });
    }
  } else text = contentText(message.content);
  const workflowTool = /<tool-use-id>\s*([^<]+)\s*<\/tool-use-id>/.exec(text)?.[1]?.trim();
  if (workflowTool) {
    targetUuid = state.tools.get(workflowTool) ?? targetUuid;
    // A workflow notification is folded into its tool card by the WebView.
    // Text blocks initially point at the hidden notification UUID; update those
    // ranges too, while retaining distinct owners of ordinary tool_result blocks.
    for (const range of navigationRanges) if (range.uuid === uuid) range.uuid = targetUuid;
  }
  if (!text.trim()) return null;
  if (!state.title && entry.type === 'user') state.title = text.slice(0, 100).replace(/\s+/g, ' ');
  return {
    workingDir: state.cwd || state.workingDir, sessionId, messageUuid: targetUuid,
    sourceMessageUuid: uuid, role: String(entry.type), title: state.title || sessionId,
    timestamp: typeof entry.timestamp === 'string' ? entry.timestamp : undefined,
    text, end, navigationRanges,
  };
}

function resultFor(row: IndexedEntry, query: string): ConversationSearchResult | null {
  const at = row.text.toLocaleLowerCase().indexOf(query);
  if (at < 0 || !row.workingDir) return null;
  const start = Math.max(0, at - 75);
  const finish = Math.min(row.text.length, at + query.length + 150);
  const { text, end: _end, navigationRanges, ...result } = row;
  const messageUuid = navigationRanges.find((range) => at < range.end)?.uuid ?? result.messageUuid;
  return { ...result, messageUuid, snippet: `${start ? '…' : ''}${text.slice(start, finish)}${finish < text.length ? '…' : ''}` };
}

function entryBytes(row: IndexedEntry): number {
  const strings = row.text.length + row.workingDir.length + row.sessionId.length
    + row.messageUuid.length + row.sourceMessageUuid.length + row.title.length + (row.timestamp?.length ?? 0);
  return 512 + strings * 2 + row.navigationRanges.reduce((bytes, range) => bytes + 64 + range.uuid.length * 2, 0);
}

/** On-demand index. No watchers, startup work or polling; unchanged small files are cached. */
export class ConversationSearchIndex {
  private readonly cursors = new Map<string, ScanState>();
  private readonly cache = new Map<string, FileCache>();
  private cacheBytes = 0;

  cancel(owner: string, cancellationId?: string): void {
    for (const [id, state] of this.cursors) {
      if (state.owner === owner && (cancellationId === undefined || state.cancellationId === cancellationId)) this.forget(id, state);
    }
  }

  private forget(id: string, state: ScanState): void {
    this.cursors.delete(id);
    if (state.expiry) clearTimeout(state.expiry);
    state.controller.abort();
    state.lineParts = [];
    state.cleanup = Promise.all([state.cleanup, this.closeDiscovery(state.discovery)]).then(() => {});
  }

  private async closeDiscovery(discovery: Discovery): Promise<void> {
    const handles = [discovery.projectDir, discovery.rootDir];
    discovery.projectDir = undefined; discovery.rootDir = undefined;
    await Promise.all(handles.map((handle) => handle?.close().catch(() => {})));
  }

  /** Discover only as far as the next transcript; open directory cursors resume
   * on the next page and are closed on completion, cancellation or expiry. */
  private async discover(state: ScanState, budget: () => boolean, visited: () => void): Promise<void> {
    const discovery = state.discovery;
    while (!discovery.done && state.fileIndex >= state.files.length && !budget()) {
      assertActive(state.controller.signal);
      if (discovery.projectDir) {
        const file = await discovery.projectDir.read();
        visited();
        assertActive(state.controller.signal);
        if (!file) {
          await discovery.projectDir.close(); discovery.projectDir = undefined;
          continue;
        }
        if (file.isFile() && file.name.endsWith('.jsonl') && ID.test(file.name.slice(0, -6))) {
          if (state.files.length >= MAX_FILES) {
            state.scopeTruncated = true; discovery.done = true;
            await this.closeDiscovery(discovery);
          } else state.files.push(join(discovery.projectPath!, file.name));
        }
        continue;
      }
      let projectPath: string | undefined;
      if (discovery.allProjects) {
        if (!discovery.rootDir) discovery.rootDir = await opendir(state.root);
        assertActive(state.controller.signal);
        const directory = await discovery.rootDir.read();
        visited();
        assertActive(state.controller.signal);
        if (!directory) {
          discovery.done = true; await this.closeDiscovery(discovery); break;
        }
        if (!directory.isDirectory() || directory.name.startsWith('.')) continue;
        projectPath = join(state.root, directory.name);
      } else {
        projectPath = discovery.initialProject;
        discovery.initialProject = undefined;
        if (!projectPath) { discovery.done = true; break; }
      }
      try {
        if (!inside(state.root, await realpath(projectPath))) continue;
        assertActive(state.controller.signal);
        discovery.projectDir = await opendir(projectPath);
        discovery.projectPath = projectPath;
        assertActive(state.controller.signal);
      } catch { assertActive(state.controller.signal); /* absent/inaccessible project */ }
    }
  }

  private remember(path: string, file: FileCache): void {
    const old = this.cache.get(path);
    if (old) this.cacheBytes -= old.bytes;
    this.cache.delete(path);
    while ((this.cacheBytes + file.bytes > MAX_CACHE_BYTES || this.cache.size >= MAX_CACHE_FILES) && this.cache.size) {
      const first = this.cache.keys().next().value!;
      this.cacheBytes -= this.cache.get(first)!.bytes;
      this.cache.delete(first);
    }
    this.cache.set(path, file);
    this.cacheBytes += file.bytes;
  }

  async search(request: ConversationSearchRequest): Promise<ConversationSearchPage> {
    const deadline = Date.now() + PAGE_BUDGET_MS;
    const query = request.query.trim().toLocaleLowerCase();
    if (query.length < 2 || query.length > 300) throw new Error('Search needs 2–300 characters');
    if (typeof request.workingDir !== 'string' || request.workingDir.length > 4096) throw new Error('Invalid working directory');
    assertActive(request.signal);
    const rootPath = join(getClaudeConfigDir(), 'projects');
    let root: string;
    try { root = await realpath(rootPath); }
    catch { return { results: [], nextCursor: null, scannedFiles: 0, totalFiles: 0, skippedEntries: 0, scopeTruncated: false }; }
    const fingerprint = createHash('sha256').update(JSON.stringify([root, query, request.workingDir, !!request.allProjects])).digest('hex');
    for (const [id, state] of this.cursors) if (Date.now() - state.touchedAt > CURSOR_TTL_MS) this.forget(id, state);
    let cursor = request.cursor;
    let state = cursor ? this.cursors.get(cursor) : undefined;
    if (cursor && (!state || state.owner !== request.owner || state.fingerprint !== fingerprint)) throw new Error('Search expired; start again');
    if (!state) {
      this.cancel(request.owner);
      while (this.cursors.size >= 8) {
        const [id, expired] = this.cursors.entries().next().value!;
        this.forget(id, expired);
      }
      cursor = randomUUID();
      state = { owner: request.owner, fingerprint, query, files: [], root, workingDir: request.allProjects ? '' : request.workingDir,
        fileIndex: 0, offset: 0, cacheIndex: 0, title: '', cwd: '', tools: new Map(), toolReferenceBytes: 0, candidate: [], candidateBytes: 0,
        skippedEntries: 0, scopeTruncated: false, touchedAt: Date.now(), busy: false,
        discovery: { allProjects: !!request.allProjects, done: false,
          initialProject: request.allProjects ? undefined : await getProjectSessionsPath(request.workingDir) },
        controller: new AbortController(), lineParts: [], lineLength: 0, lineOversized: false };
      this.cursors.set(cursor, state);
    }
    if (state.busy) throw new Error('A search page is already loading');
    state.cancellationId = request.cancellationId;
    state.busy = true;
    if (state.expiry) clearTimeout(state.expiry);
    const onAbort = () => this.forget(cursor!, state!);
    request.signal?.addEventListener('abort', onAbort, { once: true });
    const results: ConversationSearchResult[] = [];
    const limit = Math.max(1, Math.min(50, Number.isFinite(request.limit) ? Math.floor(request.limit!) : 30));
    let processed = 0;
    let readBytes = 0;
    let discovered = 0;
    const budget = () => results.length >= limit || processed >= MAX_RECORDS_PER_PAGE
      || readBytes >= MAX_BYTES_PER_PAGE || discovered >= MAX_DISCOVERY_ENTRIES_PER_PAGE || Date.now() >= deadline;
    try {
      scan: while (!budget()) {
        assertActive(request.signal);
        assertActive(state.controller.signal);
        if (state.fileIndex >= state.files.length) {
          await this.discover(state, budget, () => { discovered++; });
          if (state.fileIndex >= state.files.length || budget()) break;
        }
        const path = state.files[state.fileIndex];
        let signature: string;
        let size: number;
        try {
          if (!inside(root, await realpath(path))) throw new Error('Transcript outside Claude projects');
          const info = await stat(path);
          size = info.size; signature = `${info.dev}:${info.ino}:${info.size}:${info.mtimeMs}:${info.ctimeMs}`;
        } catch { state.skippedEntries++; this.nextFile(state); continue; }
        if (state.fileSignature && state.fileSignature !== signature) {
          throw new Error('Conversation changed during search; start again');
        }
        state.fileSignature = signature;
        const cached = this.cache.get(path);
        if (cached?.signature === signature) {
          for (; state.cacheIndex < cached.rows.length; state.cacheIndex++) {
            const row = cached.rows[state.cacheIndex];
            if (row.end <= state.offset) continue;
            assertActive(state.controller.signal);
            state.offset = row.end;
            processed++;
            const result = resultFor(row, query);
            if (result) results.push(result);
            if (processed % 64 === 0) await yieldToLoop();
            if (budget()) { state.cacheIndex++; break scan; }
          }
          this.nextFile(state);
        } else {
          const sessionId = path.slice(path.lastIndexOf(sep) + 1, -6);
          for await (const line of lines(path, state, size, MAX_BYTES_PER_PAGE - readBytes)) {
            readBytes += line.bytes;
            if (line.text === undefined) {
              if (budget()) break scan;
              continue;
            }
            processed++;
            let row: IndexedEntry | null = null;
            if (line.text === null) state.skippedEntries++;
            else if (line.text.trim()) {
              try { row = indexEntry(line.text, line.end, state, sessionId); }
              catch (error) {
                state.skippedEntries++;
                if (error instanceof ToolReferenceLimitError) {
                  // Keep navigation ownership exact within a bounded memory
                  // budget. Report the skipped remainder instead of silently
                  // pointing tool results at an evicted, hidden message UUID.
                  state.scopeTruncated = true;
                  this.nextFile(state);
                  continue scan;
                }
              }
            }
            if (row) {
              state.candidateBytes += entryBytes(row);
              if (state.candidateBytes <= MAX_FILE_CACHE_BYTES) state.candidate.push(row);
              else state.candidate = [];
              const result = resultFor(row, query);
              if (result) results.push(result);
            }
            if (processed % 64 === 0) await yieldToLoop();
            if (budget()) break scan;
          }
          if (state.offset < size) break;
          if (state.candidateBytes <= MAX_FILE_CACHE_BYTES) this.remember(path, { signature, rows: state.candidate, bytes: state.candidateBytes });
          this.nextFile(state);
        }
        if (budget()) break;
      }
      assertActive(request.signal);
      assertActive(state.controller.signal);
      state.touchedAt = Date.now();
      const nextCursor = state.fileIndex < state.files.length || !state.discovery.done ? cursor! : null;
      if (!nextCursor) this.forget(cursor!, state);
      else {
        state.expiry = setTimeout(() => this.forget(cursor!, state!), CURSOR_TTL_MS);
        state.expiry.unref();
      }
      return { results, nextCursor, scannedFiles: state.fileIndex, totalFiles: state.files.length,
        skippedEntries: state.skippedEntries, scopeTruncated: state.scopeTruncated };
    } catch (error) {
      const cancelled = state.controller.signal.aborted || request.signal?.aborted;
      this.forget(cursor!, state);
      if (cancelled) throw new Error('Search cancelled', { cause: error });
      throw error;
    } finally {
      state.busy = false;
      request.signal?.removeEventListener('abort', onAbort);
      if (state.controller.signal.aborted) {
        await state.cleanup;
        await this.closeDiscovery(state.discovery);
      }
    }
  }

  private nextFile(state: ScanState): void {
    state.fileIndex++; state.offset = 0; state.cacheIndex = 0; state.title = ''; state.cwd = '';
    state.fileSignature = undefined;
    state.lineParts = []; state.lineLength = 0; state.lineOversized = false;
    state.tools.clear(); state.toolReferenceBytes = 0; state.candidate = []; state.candidateBytes = 0;
  }
}

export const conversationSearch = new ConversationSearchIndex();
