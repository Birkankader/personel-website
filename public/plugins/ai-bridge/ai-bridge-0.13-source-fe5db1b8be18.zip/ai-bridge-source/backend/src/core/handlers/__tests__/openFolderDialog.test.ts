import { describe, it, expect, vi, beforeEach } from 'vitest';
import { openFolderDialogHandler } from '../openFolderDialog';
import { ConnectionManager } from '../../../ws/connection-manager';
import { ClientEnv, MessageType } from '../../../shared';
import type { Bridge } from '../../../bridge/bridge-interface';
import type { IPCMessage } from '../../types';

function createMockWs() {
  return { readyState: 1, bufferedAmount: 0, send: vi.fn((_data, callback) => callback?.()), on: vi.fn(), close: vi.fn() } as never;
}

function openFolderDialogMessage(): IPCMessage {
  return { type: MessageType.OPEN_FOLDER_DIALOG, payload: {}, requestId: 'req-1', timestamp: 0 };
}

/**
 * The folder dialog used to be spawned by the backend itself (osascript, zenity,
 * PowerShell). The bridge is the only path from the backend to the environment, so
 * it now asks `bridge.pickFiles` and answers on the ACK. Nothing here opens a real
 * dialog: the bridge is a fake.
 */
describe('openFolderDialogHandler', () => {
  let connections: ConnectionManager;

  beforeEach(() => {
    connections = new ConnectionManager();
  });

  it('asks the bridge for a single folder and acks the picked path', async () => {
    const bridge = { pickFiles: vi.fn().mockResolvedValue({ paths: ['/picked'] }) } as unknown as Bridge;
    const connId = connections.addConnection(createMockWs(), ClientEnv.JETBRAINS);
    const sendTo = vi.spyOn(connections, 'sendTo');

    await openFolderDialogHandler(connId, openFolderDialogMessage(), connections, bridge);

    expect(bridge.pickFiles).toHaveBeenCalledWith({ mode: 'folders', multiple: false });
    expect(sendTo).toHaveBeenCalledTimes(1);
    expect(sendTo).toHaveBeenCalledWith(connId, MessageType.ACK, { requestId: 'req-1', path: '/picked' });
  });

  it('returns the path exactly as the bridge spelled it', async () => {
    const bridge = { pickFiles: vi.fn().mockResolvedValue({ paths: ['C:\\work\\new\\'] }) } as unknown as Bridge;
    const connId = connections.addConnection(createMockWs(), ClientEnv.BROWSER);
    const sendTo = vi.spyOn(connections, 'sendTo');

    await openFolderDialogHandler(connId, openFolderDialogMessage(), connections, bridge);

    expect(sendTo).toHaveBeenCalledWith(connId, MessageType.ACK, { requestId: 'req-1', path: 'C:\\work\\new\\' });
  });

  /** A cancelled dialog is an answer, not a failure: the caller still has to be released. */
  it('acks null when the dialog is cancelled', async () => {
    const bridge = { pickFiles: vi.fn().mockResolvedValue({ paths: [] }) } as unknown as Bridge;
    const connId = connections.addConnection(createMockWs(), ClientEnv.JETBRAINS);
    const sendTo = vi.spyOn(connections, 'sendTo');

    await openFolderDialogHandler(connId, openFolderDialogMessage(), connections, bridge);

    expect(sendTo).toHaveBeenCalledWith(connId, MessageType.ACK, { requestId: 'req-1', path: null });
  });

  it('answers with an ERROR carrying the requestId when the bridge throws, and no ACK', async () => {
    const bridge = {
      pickFiles: vi.fn().mockRejectedValue(new Error('No RPC client connected')),
    } as unknown as Bridge;
    const connId = connections.addConnection(createMockWs(), ClientEnv.JETBRAINS);
    const sendTo = vi.spyOn(connections, 'sendTo');

    await openFolderDialogHandler(connId, openFolderDialogMessage(), connections, bridge);

    expect(sendTo).toHaveBeenCalledTimes(1);
    expect(sendTo).toHaveBeenCalledWith(connId, MessageType.ERROR, {
      requestId: 'req-1',
      error: 'No RPC client connected',
    });
    expect(sendTo).not.toHaveBeenCalledWith(connId, MessageType.ACK, expect.anything());
  });

  it('stringifies a non-Error rejection', async () => {
    const bridge = { pickFiles: vi.fn().mockRejectedValue('boom') } as unknown as Bridge;
    const connId = connections.addConnection(createMockWs(), ClientEnv.JETBRAINS);
    const sendTo = vi.spyOn(connections, 'sendTo');

    await openFolderDialogHandler(connId, openFolderDialogMessage(), connections, bridge);

    expect(sendTo).toHaveBeenCalledWith(connId, MessageType.ERROR, { requestId: 'req-1', error: 'boom' });
  });
});
