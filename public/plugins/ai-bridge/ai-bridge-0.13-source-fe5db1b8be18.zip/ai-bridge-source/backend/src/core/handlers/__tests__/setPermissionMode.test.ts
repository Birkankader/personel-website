import { describe, it, expect, vi, beforeEach } from 'vitest';

// The real isKnownInputMode decides what is valid; only the write to the CLI is replaced.
vi.mock('../../claude-process', async (importOriginal) => {
  const actual = await importOriginal<typeof import('../../claude-process')>();
  return { ...actual, sendSetPermissionModeToProcess: vi.fn(() => true) };
});

import { setPermissionModeHandler } from '../setPermissionMode';
import * as claudeProcess from '../../claude-process';
import type { ConnectionManager } from '../../../ws/connection-manager';
import type { Bridge } from '../../../bridge/bridge-interface';
import type { IPCMessage } from '../../types';
import { MessageType } from '../../../shared';

const bridge = {} as Bridge;

function connectionsWith(subscribedSessionId: string | undefined) {
  return {
    getClient: vi.fn(() => ({ subscribedSessionId })),
    sendTo: vi.fn(),
  } as unknown as ConnectionManager & { sendTo: ReturnType<typeof vi.fn> };
}

function message(payload: Record<string, unknown>): IPCMessage {
  return { type: MessageType.SET_PERMISSION_MODE, requestId: 'req-1', payload, timestamp: 0 };
}

const send = vi.mocked(claudeProcess.sendSetPermissionModeToProcess);

beforeEach(() => {
  send.mockClear();
  send.mockReturnValue(true);
});

describe('setPermissionModeHandler', () => {
  it('rejects an unknown mode with an error ACK and never writes to the CLI', async () => {
    const connections = connectionsWith('session-1');

    await setPermissionModeHandler('conn-1', message({ inputMode: 'yolo' }), connections, bridge);

    expect(send).not.toHaveBeenCalled();
    expect(connections.sendTo).toHaveBeenCalledWith('conn-1', MessageType.ACK, {
      requestId: 'req-1',
      status: 'error',
      error: 'Unknown inputMode "yolo"',
    });
  });

  it.each(['toString', '__proto__', 'constructor', 'hasOwnProperty', 'valueOf'])(
    'rejects the prototype key "%s" as an unknown mode',
    async (inputMode) => {
      const connections = connectionsWith('session-1');

      await setPermissionModeHandler('conn-1', message({ inputMode }), connections, bridge);

      expect(send).not.toHaveBeenCalled();
      expect(connections.sendTo).toHaveBeenCalledWith('conn-1', MessageType.ACK, expect.objectContaining({
        requestId: 'req-1', status: 'error',
      }));
    },
  );

  it('rejects a mode that is not a string', async () => {
    const connections = connectionsWith('session-1');

    await setPermissionModeHandler('conn-1', message({ inputMode: 5 }), connections, bridge);

    expect(send).not.toHaveBeenCalled();
    expect(connections.sendTo).toHaveBeenCalledWith('conn-1', MessageType.ACK, expect.objectContaining({ status: 'error' }));
  });

  it('judges the mode before the session, so a bad value is named even with no session', async () => {
    const connections = connectionsWith(undefined);

    await setPermissionModeHandler('conn-1', message({ inputMode: 'yolo' }), connections, bridge);

    expect(connections.sendTo).toHaveBeenCalledWith('conn-1', MessageType.ACK, expect.objectContaining({
      status: 'error', error: 'Unknown inputMode "yolo"',
    }));
  });

  it.each(['plan', 'bypass', 'ask_before_edit', 'auto_edit', 'auto'])(
    'accepts the known mode "%s" and reports whether the CLI took it',
    async (inputMode) => {
      const connections = connectionsWith('session-1');

      await setPermissionModeHandler('conn-1', message({ inputMode }), connections, bridge);

      expect(send).toHaveBeenCalledWith(connections, 'session-1', inputMode);
      expect(connections.sendTo).toHaveBeenCalledWith('conn-1', MessageType.ACK, {
        requestId: 'req-1', status: 'ok', applied: true,
      });
    },
  );

  it('answers ok with applied:false when there is no live CLI to take the mode', async () => {
    send.mockReturnValue(false);
    const connections = connectionsWith('session-1');

    await setPermissionModeHandler('conn-1', message({ inputMode: 'plan' }), connections, bridge);

    expect(connections.sendTo).toHaveBeenCalledWith('conn-1', MessageType.ACK, {
      requestId: 'req-1', status: 'ok', applied: false,
    });
  });

  it('keeps the existing error when no inputMode is given', async () => {
    const connections = connectionsWith('session-1');

    await setPermissionModeHandler('conn-1', message({}), connections, bridge);

    expect(send).not.toHaveBeenCalled();
    expect(connections.sendTo).toHaveBeenCalledWith('conn-1', MessageType.ACK, {
      requestId: 'req-1', status: 'error', error: 'No inputMode given',
    });
  });

  it('keeps the existing error when the connection has no active session', async () => {
    const connections = connectionsWith(undefined);

    await setPermissionModeHandler('conn-1', message({ inputMode: 'plan' }), connections, bridge);

    expect(send).not.toHaveBeenCalled();
    expect(connections.sendTo).toHaveBeenCalledWith('conn-1', MessageType.ACK, {
      requestId: 'req-1', status: 'error', error: 'No active session',
    });
  });
});

describe('isKnownInputMode', () => {
  it('knows exactly the modes the webview offers', () => {
    for (const mode of ['plan', 'bypass', 'ask_before_edit', 'auto_edit', 'auto']) {
      expect(claudeProcess.isKnownInputMode(mode)).toBe(true);
    }
  });

  it('refuses everything else, including inherited object keys and non-strings', () => {
    for (const mode of ['', 'yolo', 'PLAN', 'default', 'acceptEdits', 'toString', '__proto__', 'constructor']) {
      expect(claudeProcess.isKnownInputMode(mode)).toBe(false);
    }
    for (const mode of [undefined, null, 0, {}, ['plan']]) {
      expect(claudeProcess.isKnownInputMode(mode)).toBe(false);
    }
  });
});

describe('buildClaudeArgs and unknown modes', () => {
  it('omits --permission-mode for an unknown or prototype mode instead of passing a bogus flag', () => {
    for (const mode of ['yolo', 'toString', '__proto__']) {
      expect(claudeProcess.buildClaudeArgs('--session-id', 'abc', mode)).not.toContain('--permission-mode');
    }
    expect(claudeProcess.buildClaudeArgs('--session-id', 'abc', 'plan')).toEqual(
      expect.arrayContaining(['--permission-mode', 'plan']),
    );
  });
});
