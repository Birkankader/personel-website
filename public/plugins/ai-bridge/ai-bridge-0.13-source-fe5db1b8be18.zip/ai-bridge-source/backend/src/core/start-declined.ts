/**
 * The CLI was not started for a send, and ensureClaudeProcess has already told
 * the session why: another live backend is writing the session, or a WSL
 * project was opened from Windows. A user send or an automatic recovery send
 * fails on it without an echo of a send that never happened, a generic error
 * over that reason, or a backend error report.
 */
export class StartDeclined extends Error {
  constructor() { super('Claude was not started for this session.'); }
}
