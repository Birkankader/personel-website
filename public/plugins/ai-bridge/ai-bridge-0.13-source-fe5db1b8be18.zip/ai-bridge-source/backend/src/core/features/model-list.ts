/**
 * A setting that lists model ids: textOnlyModels, chatCompletionsImageModels.
 *
 * Each entry is a model id, matched without regard to case, where `*` stands for
 * any run of characters: "glm-5.3-flash", "glm-*", or "*" for every model. An
 * entry also matches the id after a provider prefix, so "glm-5.3-flash" covers
 * "office/glm-5.3-flash" the way an ACP harness names it.
 */
export const MAX_MODEL_LIST_ENTRIES = 50;

export function validModelList(value: unknown): value is string[] {
  return Array.isArray(value) && value.length <= MAX_MODEL_LIST_ENTRIES &&
    value.every(entry => typeof entry === 'string' && entry.trim().length > 0 && entry.length <= 200);
}

function entryPattern(entry: string): RegExp {
  const parts = entry.trim().toLowerCase().split('*').map(part => part.replace(/[.+?^${}()|[\]\\]/g, '\\$&'));
  return new RegExp(`^${parts.join('.*')}$`);
}

/** Whether any of a model's names matches an entry of the list. */
export function modelListMatches(entries: unknown, modelNames: readonly string[]): boolean {
  if (!validModelList(entries) || entries.length === 0) return false;
  const patterns = entries.map(entryPattern);
  const names = modelNames.flatMap((name) => {
    const lower = name.toLowerCase();
    const tail = lower.slice(lower.lastIndexOf('/') + 1);
    return tail === lower ? [lower] : [lower, tail];
  });
  return names.some(name => patterns.some(pattern => pattern.test(name)));
}
