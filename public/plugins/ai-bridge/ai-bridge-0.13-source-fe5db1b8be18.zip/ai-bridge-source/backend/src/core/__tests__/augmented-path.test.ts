import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { mkdtempSync, rmSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';

// The nvm probe never spawns a real bash here: on Windows a bare `bash` is
// usually System32\bash.exe, which starts WSL.
vi.mock('child_process', async (importOriginal) => ({
  ...(await importOriginal<typeof import('child_process')>()),
  execFileSync: vi.fn(() => ''),
}));

import { execFileSync } from 'child_process';
import { augmentedEnv, augmentedPath, buildAugmentedPath } from '../augmented-path';

describe('augmented-path', () => {
  it('buildAugmentedPath returns a PATH string', () => {
    expect(typeof buildAugmentedPath()).toBe('string');
  });

  it('augmentedPath is cached (stable across calls)', () => {
    expect(augmentedPath()).toBe(augmentedPath());
  });

  it('augmentedEnv sets PATH to the augmented path', () => {
    expect(augmentedEnv().PATH).toBe(augmentedPath());
  });

  it('augmentedEnv preserves other process env vars', () => {
    process.env.__AUG_TEST__ = 'xyz';
    try {
      expect(augmentedEnv().__AUG_TEST__).toBe('xyz');
    } finally {
      delete process.env.__AUG_TEST__;
    }
  });

  it('augmentedEnv applies extra vars alongside PATH', () => {
    const env = augmentedEnv({ FOO: 'bar' });
    expect(env.FOO).toBe('bar');
    expect(env.PATH).toBe(augmentedPath());
  });

  it('augmentedEnv lets extra override PATH when explicitly provided', () => {
    expect(augmentedEnv({ PATH: '/custom/bin' }).PATH).toBe('/custom/bin');
  });
});

describe('buildAugmentedPath nvm probe', () => {
  let nvmDir: string;
  let originalNvmDir: string | undefined;
  let originalPlatform: PropertyDescriptor | undefined;

  beforeEach(() => {
    vi.mocked(execFileSync).mockClear();
    nvmDir = mkdtempSync(join(tmpdir(), 'aug-nvm-'));
    writeFileSync(join(nvmDir, 'nvm.sh'), '');
    originalNvmDir = process.env.NVM_DIR;
    process.env.NVM_DIR = nvmDir;
    originalPlatform = Object.getOwnPropertyDescriptor(process, 'platform');
  });

  afterEach(() => {
    if (originalPlatform) Object.defineProperty(process, 'platform', originalPlatform);
    if (originalNvmDir === undefined) delete process.env.NVM_DIR;
    else process.env.NVM_DIR = originalNvmDir;
    rmSync(nvmDir, { recursive: true, force: true });
  });

  it('runs bash to ask nvm for the current node when nvm.sh exists', () => {
    Object.defineProperty(process, 'platform', { value: 'linux' });

    buildAugmentedPath();

    expect(execFileSync).toHaveBeenCalledWith('bash', expect.any(Array), expect.any(Object));
  });

  it('never runs bash on Windows, even when nvm.sh exists', () => {
    Object.defineProperty(process, 'platform', { value: 'win32' });

    buildAugmentedPath();

    expect(execFileSync).not.toHaveBeenCalled();
  });
});
