import { randomBytes } from 'node:crypto';

/**
 * Anthropic Messages <-> OpenAI Chat Completions, for the
 * chatCompletionsImageModels setting (chat-completions-image-proxy.ts).
 *
 * Some OpenAI-compatible servers also answer /v1/messages, but fail every
 * request there that carries an image, while their /v1/chat/completions reads
 * the same image. Such a request is translated to Chat Completions, and the
 * answer back into a Messages answer or event stream, so the CLI gets what it
 * would have got from /v1/messages.
 *
 * Kept: system prompt, text, images (base64 and url), tool definitions, tool
 * calls and their results (a result's images follow it in a user message, since
 * a tool message carries text only), tool_choice, max_tokens, temperature,
 * top_p and stop sequences.
 * Dropped: thinking blocks of earlier turns, the thinking parameter (the
 * server's own default applies), the server's reasoning text, cache_control,
 * metadata and server tools. Reasoning is not turned into thinking blocks: they
 * would carry no signature, and a later request without an image takes them to
 * /v1/messages as they are.
 */

type Json = Record<string, unknown>;

const record = (value: unknown): Json =>
  value !== null && typeof value === 'object' && !Array.isArray(value) ? value as Json : {};
const list = (value: unknown): unknown[] => Array.isArray(value) ? value : [];
const text = (value: unknown): string => typeof value === 'string' ? value : '';
const count = (value: unknown): number => typeof value === 'number' && Number.isFinite(value) ? value : 0;
const randomId = () => randomBytes(12).toString('hex');

/** Whether a Messages request carries an image anywhere, tool results included. */
export function hasImage(body: Json): boolean {
  const visit = (blocks: unknown): boolean => list(blocks).some((block) => {
    const entry = record(block);
    return entry.type === 'image' || (entry.type === 'tool_result' && visit(entry.content));
  });
  return list(body.messages).some(message => visit(record(message).content));
}

type Part = { type: 'text'; text: string } | { type: 'image_url'; image_url: { url: string } };

function imagePart(block: Json): Part | null {
  const source = record(block.source);
  if (source.type === 'base64' && text(source.data)) {
    return { type: 'image_url', image_url: { url: `data:${text(source.media_type) || 'image/png'};base64,${text(source.data)}` } };
  }
  if (source.type === 'url' && text(source.url)) return { type: 'image_url', image_url: { url: text(source.url) } };
  return null;
}

function contentPart(block: Json): Part | null {
  switch (block.type) {
    case 'text': return text(block.text) ? { type: 'text', text: text(block.text) } : null;
    case 'image': return imagePart(block);
    case 'document': {
      const source = record(block.source);
      if (source.type === 'text' && text(source.data)) return { type: 'text', text: text(source.data) };
      const title = text(block.title);
      return { type: 'text', text: `[A document${title ? ` (${title})` : ''} was attached here, in a form this endpoint cannot read.]` };
    }
    default: return null;
  }
}

function userMessages(content: unknown): Json[] {
  if (typeof content === 'string') return [{ role: 'user', content }];
  const results: Json[] = [];
  const resultImages: Part[] = [];
  const parts: Part[] = [];
  for (const block of list(content).map(record)) {
    if (block.type !== 'tool_result') {
      const part = contentPart(block);
      if (part) parts.push(part);
      continue;
    }
    const inner = typeof block.content === 'string' ? [{ type: 'text', text: block.content }] : list(block.content).map(record);
    const images = inner.filter(entry => entry.type === 'image').map(imagePart).filter((part): part is Part => part !== null);
    const output = inner.filter(entry => entry.type === 'text').map(entry => text(entry.text)).join('\n');
    results.push({ role: 'tool', tool_call_id: text(block.tool_use_id), content: output || (images.length ? '(an image, attached below)' : '') });
    resultImages.push(...images);
  }
  if (resultImages.length) parts.unshift({ type: 'text', text: 'Images from the tool results above:' }, ...resultImages);
  if (parts.length) results.push({ role: 'user', content: parts });
  else if (!results.length) results.push({ role: 'user', content: '' });
  return results;
}

function assistantMessage(content: unknown): Json {
  if (typeof content === 'string') return { role: 'assistant', content };
  const blocks = list(content).map(record);
  const reply = blocks.filter(block => block.type === 'text').map(block => text(block.text)).join('\n');
  const calls = blocks.filter(block => block.type === 'tool_use').map(block => ({
    id: text(block.id), type: 'function', function: { name: text(block.name), arguments: JSON.stringify(block.input ?? {}) },
  }));
  return calls.length ? { role: 'assistant', content: reply || null, tool_calls: calls } : { role: 'assistant', content: reply };
}

function systemPrompt(system: unknown): string {
  if (typeof system === 'string') return system;
  return list(system).map(record).filter(block => block.type === 'text').map(block => text(block.text)).join('\n\n');
}

function toolChoice(choice: unknown): unknown {
  const entry = record(choice);
  switch (entry.type) {
    case 'auto': return 'auto';
    case 'any': return 'required';
    case 'none': return 'none';
    case 'tool': return { type: 'function', function: { name: text(entry.name) } };
    default: return undefined;
  }
}

/** The Chat Completions request for a Messages request. */
export function toChatCompletionsRequest(body: Json): Json {
  const messages: Json[] = [];
  const system = systemPrompt(body.system);
  if (system) messages.push({ role: 'system', content: system });
  for (const message of list(body.messages).map(record)) {
    if (message.role === 'assistant') messages.push(assistantMessage(message.content));
    else messages.push(...userMessages(message.content));
  }
  const request: Json = { model: body.model, messages };
  if (typeof body.max_tokens === 'number') request.max_tokens = body.max_tokens;
  if (typeof body.temperature === 'number') request.temperature = body.temperature;
  if (typeof body.top_p === 'number') request.top_p = body.top_p;
  const stop = list(body.stop_sequences).filter((entry): entry is string => typeof entry === 'string');
  if (stop.length) request.stop = stop;
  // Server tools (web search and the like) have a type and no input_schema.
  const tools = list(body.tools).map(record).filter(tool => tool.input_schema && (tool.type === undefined || tool.type === 'custom'));
  if (tools.length) {
    request.tools = tools.map(tool => ({
      type: 'function',
      function: { name: text(tool.name), ...(text(tool.description) ? { description: text(tool.description) } : {}), parameters: tool.input_schema },
    }));
    const choice = toolChoice(body.tool_choice);
    if (choice) request.tool_choice = choice;
    if (record(body.tool_choice).disable_parallel_tool_use === true) request.parallel_tool_calls = false;
  }
  if (body.stream === true) {
    request.stream = true;
    request.stream_options = { include_usage: true };
  }
  return request;
}

/** Tool call arguments as the JSON text of an object; anything else becomes {}. */
function argumentsJson(value: unknown): string {
  if (value !== null && typeof value === 'object' && !Array.isArray(value)) return JSON.stringify(value);
  try {
    const parsed: unknown = JSON.parse(text(value).trim() || '{}');
    return parsed !== null && typeof parsed === 'object' && !Array.isArray(parsed) ? JSON.stringify(parsed) : '{}';
  } catch { return '{}'; }
}

function stopReason(finishReason: string, calledTools: boolean): string {
  if (calledTools || finishReason === 'tool_calls' || finishReason === 'function_call') return 'tool_use';
  if (finishReason === 'length') return 'max_tokens';
  return 'end_turn';
}

const messageId = (id: unknown) => text(id).startsWith('msg_') ? text(id) : `msg_${text(id) || randomId()}`;

/** The Messages answer for a Chat Completions answer. */
export function toMessagesResponse(completion: Json, model: string): Json {
  const choice = record(list(completion.choices)[0]);
  const message = record(choice.message);
  const content: Json[] = [];
  if (text(message.content)) content.push({ type: 'text', text: text(message.content) });
  const calls = list(message.tool_calls).map(record);
  for (const call of calls) {
    const fn = record(call.function);
    content.push({ type: 'tool_use', id: text(call.id) || `toolu_${randomId()}`, name: text(fn.name), input: JSON.parse(argumentsJson(fn.arguments)) });
  }
  const usage = record(completion.usage);
  return {
    id: messageId(completion.id), type: 'message', role: 'assistant', model: text(completion.model) || model, content,
    stop_reason: stopReason(text(choice.finish_reason), calls.length > 0), stop_sequence: null,
    usage: { input_tokens: count(usage.prompt_tokens), output_tokens: count(usage.completion_tokens) },
  };
}

const sse = (type: string, data: Json) => `event: ${type}\ndata: ${JSON.stringify({ type, ...data })}\n\n`;

/**
 * Turns a Chat Completions event stream into a Messages event stream, as SSE
 * text. Text is passed on as it arrives. Tool calls are collected and sent
 * whole at the end: their pieces can interleave, which Messages blocks cannot.
 */
export class MessagesEventStream {
  private started = false;
  private index = 0;
  private textOpen = false;
  private readonly calls = new Map<number, { id: string; name: string; arguments: string | Json }>();
  private finishReason = '';
  private usage = { input_tokens: 0, output_tokens: 0 };

  constructor(private readonly model: string) {}

  private start(chunk: Json): string {
    if (this.started) return '';
    this.started = true;
    return sse('message_start', {
      message: {
        id: messageId(chunk.id), type: 'message', role: 'assistant', model: text(chunk.model) || this.model,
        content: [], stop_reason: null, stop_sequence: null, usage: { ...this.usage },
      },
    });
  }

  private closeText(): string {
    if (!this.textOpen) return '';
    this.textOpen = false;
    return sse('content_block_stop', { index: this.index++ });
  }

  /** The events for one line of the Chat Completions stream. */
  line(line: string): string {
    if (!line.startsWith('data:')) return '';
    const data = line.slice(5).trim();
    if (!data || data === '[DONE]') return '';
    try { return this.push(record(JSON.parse(data))); } catch { return ''; }
  }

  /** The events for one Chat Completions chunk. */
  push(chunk: Json): string {
    let out = this.start(chunk);
    const error = record(chunk.error);
    if (text(error.message)) return out + sse('error', { error: { type: 'api_error', message: text(error.message) } });
    const usage = record(chunk.usage);
    if (usage.prompt_tokens !== undefined) this.usage.input_tokens = count(usage.prompt_tokens);
    if (usage.completion_tokens !== undefined) this.usage.output_tokens = count(usage.completion_tokens);
    const choice = record(list(chunk.choices)[0]);
    const delta = record(choice.delta);
    if (text(delta.content)) {
      if (!this.textOpen) {
        out += sse('content_block_start', { index: this.index, content_block: { type: 'text', text: '' } });
        this.textOpen = true;
      }
      out += sse('content_block_delta', { index: this.index, delta: { type: 'text_delta', text: text(delta.content) } });
    }
    for (const call of list(delta.tool_calls).map(record)) {
      const key = typeof call.index === 'number' ? call.index : this.calls.size;
      const entry = this.calls.get(key) ?? { id: '', name: '', arguments: '' };
      const fn = record(call.function);
      entry.id ||= text(call.id);
      entry.name ||= text(fn.name);
      if (typeof fn.arguments === 'string' && typeof entry.arguments === 'string') entry.arguments += fn.arguments;
      else if (fn.arguments !== null && typeof fn.arguments === 'object') entry.arguments = fn.arguments as Json;
      this.calls.set(key, entry);
    }
    if (text(choice.finish_reason)) this.finishReason = text(choice.finish_reason);
    return out;
  }

  /** The closing events, after the last chunk. */
  end(): string {
    let out = this.start({}) + this.closeText();
    for (const call of this.calls.values()) {
      out += sse('content_block_start', { index: this.index, content_block: { type: 'tool_use', id: call.id || `toolu_${randomId()}`, name: call.name, input: {} } });
      out += sse('content_block_delta', { index: this.index, delta: { type: 'input_json_delta', partial_json: argumentsJson(call.arguments) } });
      out += sse('content_block_stop', { index: this.index++ });
    }
    out += sse('message_delta', { delta: { stop_reason: stopReason(this.finishReason, this.calls.size > 0), stop_sequence: null }, usage: { ...this.usage } });
    return out + sse('message_stop', {});
  }
}

const ERROR_TYPES: Record<number, string> = {
  400: 'invalid_request_error', 401: 'authentication_error', 403: 'permission_error', 404: 'not_found_error',
  413: 'request_too_large', 429: 'rate_limit_error', 529: 'overloaded_error',
};

/** A Messages error body for a failed Chat Completions request, keeping the server's message. */
export function toMessagesError(status: number, body: string): Json {
  let message = body.trim().slice(0, 4000);
  try {
    const json = record(JSON.parse(body));
    const error = json.error;
    message = text(record(error).message) || text(error) || text(json.message) || message;
  } catch { /* not JSON: keep the text */ }
  return { type: 'error', error: { type: ERROR_TYPES[status] ?? (status >= 500 ? 'api_error' : 'invalid_request_error'), message: message || `HTTP ${status}` } };
}
