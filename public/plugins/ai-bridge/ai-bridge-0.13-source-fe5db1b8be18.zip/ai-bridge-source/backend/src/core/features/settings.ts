import { readFile, mkdir } from 'fs/promises';
import { existsSync } from 'fs';
import { join } from 'path';
import { homedir } from 'os';
import { atomicWriteFile, updateJsonFile } from './atomic-json';
import { adoptLegacyProjectSettings } from './legacy-data';
import { validTaskTemplates } from '../../shared/task-template';
import { isReasoningEffort } from './reasoning-effort';
import { MAX_TEXT_ONLY_MODELS, validTextOnlyModels } from './text-only-models';
import { MAX_MODEL_LIST_ENTRIES, validModelList } from './model-list';
import {
  DiffSurface,
  BrowserDiffPresentation,
  DIFF_SURFACES,
  BROWSER_DIFF_PRESENTATIONS,
  isAcpHarness,
  isHarnessId,
} from '../../shared';

// ─── Settings helpers ────────────────────────────────────────────────────────

const SETTINGS_FILE = join(homedir(), '.ai-bridge', 'settings.js');

// ─── Scope policy: project-local by default ──────────────────────────────────
//
// Every setting MUST be overridable per project. A setting that can be set
// locally is the better decision, so treat project scope as the default and do
// not ask whether a new key "should" support it — it should.
//
// Global-only is the rare exception, allowed solely when project scope is
// genuinely impossible. Two real cases so far, both structural rather than a
// matter of taste:
//   - CLAUDE_CONFIG_DIR (#123): it decides WHERE the settings file lives, so
//     resolving it from that file would be circular.
//   - nodePath: it decides which node LAUNCHES this backend, so the backend
//     cannot be the one to resolve it (ProjectSettingsReader is the narrow
//     read-only escape hatch the IDE uses instead).
//
// One further exception exists on product grounds rather than structural ones:
//   - dockLayout: the header dock is a toolbar the user navigates by muscle
//     memory, so the icons must not move when they switch projects. Nothing
//     prevents resolving it per project — the editor simply always writes to
//     global scope. A value placed in a project file by hand still wins, exactly
//     as it does for the two keys above.
//
// Note what is NOT a reason: "the Settings UI greys it out on the Project tab"
// is a symptom, not a justification. #239 removed exactly that greying for five
// keys after finding nothing about them required global scope. When a key looks
// global-only, state the structural reason it cannot be resolved per project;
// if no such reason exists, make it project-scoped.
//
// If a new key does look like an exception, the agent decides and proposes it
// with that reasoning — it is not a question to hand back to the user.

const DEFAULT_SETTINGS: Record<string, unknown> = {
  cliPath: null,
  nodePath: null,
  theme: 'system',
  fontSize: 13,
  uiDensity: 'compact',
  zoomLevel: 1,
  lineHeight: 1.6,
  autoScrollThreshold: 80,
  softWrap: false,
  messageNavigator: true,
  userMessageColor: null,
  messageNavigatorColor: null,
  terminalApp: null,
  openFilesWith: null,
  openFilesWithCustom: null,
  hostMode: 'editor-tab',
  openSettingsAs: 'overlay',
  chatPagination: true,
  includeNestedSessions: false,
  uiDirection: 'ltr',
  // GUI-only keys migrated out of the native ~/.claude/settings.json (not part of
  // Claude Code's official settings schema). See settings-migration.ts.
  uiLanguage: null,
  useCtrlEnterToSend: false,
  focusInputOnEditorContext: true,
  autoResumeOnLimit: true,
  // Marker for the one-time reset of the pre-0.31 `autoResumeOnLimit: false`
  // default; see settings-migration.ts.
  autoResumeDefaultReset: false,
  lowResourceMode: true,
  reasoningEffort: 'auto',
  // Agent runtime for new chats. Existing chats keep the one they started on.
  harness: 'claude',
  // Where each ACP harness lives when it is not on PATH (null = find it).
  harnessPaths: {},
  // Experimental local computer-use MCP server (screenshots, mouse, keyboard).
  computerUse: false,
  // Experimental web page and shader tools in a headless Chrome or Edge.
  webTools: false,
  // Models that do not read images; their images go as a text description.
  textOnlyModels: [],
  // Models whose gateway reads images only on /v1/chat/completions.
  chatCompletionsImageModels: ['GLM-5.3-Flash', 'GLM-5.3-Flash-Low'],
  taskTemplates: [],
  contextWarningTokens: 32000,
  attachEditorContext: true,
  autoOpenDiffOnPermission: true,
  diffSurface: DiffSurface.IDE,
  browserDiffPresentation: BrowserDiffPresentation.NEW_TAB,
  // Whether switching the model (dropdown or the rotate shortcut) also writes the
  // native `model` default, matching the CLI's single global default. GUI-only:
  // the CLI has no per-session override to gate. See issue #354.
  syncModelToDefault: true,
  // Header dock arrangement: `order` is the row order in the ⋮ menu (and, once
  // filtered to `visible`, the dock's icon order too); `visible` names which of
  // those items are pulled out into the dock. Both empty means "not configured
  // yet", which the webview normalizes into "declaration order, none visible" —
  // so a fresh install shows only the overflow (⋮) button.
  dockLayout: { order: [], visible: [] },
  // Only CLAUDE_CONFIG_DIR lives here: it decides where the native settings file
  // is, so it cannot be stored inside that file. Every other variable belongs to
  // the native `env` key. See settings-migration.ts.
  env: {},
  // ── Legacy keys kept ONLY so the migration can clear them ───────────────────
  // They moved to the native file (language, respectGitignore, ultracode).
  // Removing them from this map would make validateSetting reject the write that
  // empties them, stranding the old value here forever. Drop them once the
  // migration retires.
  language: null,
  respectGitignoreForContext: false,
  ultracode: null,
  // Unlike the two above, this one did not go native — it was replaced by our own
  // `diffSurface`, which names the surface instead of asking a yes/no about the
  // IDE. null is the default so a value here always means "not migrated yet".
  showDiffInIde: null,
};

const COMMENT_MAP: Record<string, string> = {
  cliPath: 'Claude CLI executable path (null = auto-detect)',
  nodePath: 'Node.js executable path (null = auto-detect; restart required after changing)',
  theme: 'Theme: "system" | "light" | "dark" | "modern-technical" (in JetBrains mode "system" also follows the IDE theme colors)',
  fontSize: 'Font size (8~32)',
  uiDensity: 'Interface density: compact or comfortable (larger control targets)',
  zoomLevel: 'UI zoom (0.5~3). Adjust with Ctrl/Cmd +/- and Ctrl/Cmd + wheel. Unlike font size, it also scales icons and spacing',
  lineHeight: 'Chat message line spacing (line-height multiplier, 0.5~10)',
  autoScrollThreshold: 'Auto-scroll threshold (px). The view follows the stream only while within this distance of the end of the messages',
  softWrap: 'Wrap long lines to the code block width (diffs, tool input/output, etc.). false = horizontal scroll',
  messageNavigator: 'Show one dot per sent message at the start edge of the chat; clicking a dot scrolls to that message.',
  userMessageColor: 'Color of your own messages as "#RRGGBB". null follows the theme accent.',
  messageNavigatorColor: 'Color of the message navigator dots as "#RRGGBB". null uses userMessageColor.',
  terminalApp: 'Terminal program (null = OS default terminal)',
  openFilesWith: 'Program to open files with (null = OS default, "$custom" = use openFilesWithCustom)',
  openFilesWithCustom: 'Custom program to open files: { path, arguments } (%TARGET_PATH% in arguments is replaced with the file path)',
  hostMode: 'Where the chat opens: "editor-tab" | "tool-window"',
  openSettingsAs: 'How the settings screen opens: "overlay" | "new-tab"',
  chatPagination: 'Load chat history page by page (older messages are added on scroll). false = load everything at once',
  includeNestedSessions: 'Include sessions from subdirectories of the working directory in the session list. false = only the current directory',
  uiDirection: 'UI mirroring (layout direction): "ltr" | "rtl"',
  uiLanguage: 'GUI display language (e.g. "turkish"). null = English. Independent of the Claude response language (language)',
  useCtrlEnterToSend: 'true = send with Ctrl/Cmd+Enter and Enter inserts a newline. false = send with Enter',
  focusInputOnEditorContext: 'true = after Alt+K inserts a file path, focus moves to the chat input',
  autoResumeOnLimit: 'Resume automatically when the usage limit resets. On by default. Seeds the default action of the limit banner',
  autoResumeDefaultReset: 'Internal: true once a stored pre-0.31 autoResumeOnLimit=false has been reset to true. Do not edit.',
  reasoningEffort: 'Claude reasoning effort on the next message: auto, low, medium, high, xhigh or max. Auto follows provider settings.',
  harness: 'Agent runtime for new chats: claude (Claude Code CLI), opencode (OpenCode, run as "opencode acp") or deepseek (DeepSeek Harness, run as "dsh --profile acp"). Existing chats keep the runtime they started on.',
  harnessPaths: 'Where to run each harness from, e.g. { deepseek: "C:/src/deepseek-harness" }: an executable, an npm install folder, or a deepseek-harness source checkout (run like "pnpm dsh"). Unset = the copy AI Bridge installed, then PATH.',
  computerUse: 'Experimental. true lets the agent take screenshots and control the mouse and keyboard through a local MCP server. Off by default.',
  webTools: 'Experimental. true gives the agent web page and shader tools (open_page, page_layout, page_click, render_shader...) through a local MCP server. They run in a headless Chrome or Edge on this computer, drawing on the CPU. Off by default.',
  textOnlyModels: 'Models that do not read images, e.g. ["glm-5.3-flash"]. * matches anything ("glm-*", or "*" for every model). Images sent to these models, and computer-use screenshots, go as a text description (OCR text, layout, colors) instead of the image.',
  chatCompletionsImageModels: 'Models whose gateway (ANTHROPIC_BASE_URL) reads images only on its OpenAI-compatible /v1/chat/completions, e.g. ["GLM-5.3-Flash"]. * matches anything. A request to these models that carries an image goes there, translated both ways by a local proxy; every other request goes to /v1/messages unchanged.',
  lowResourceMode: 'Pause hidden chat rendering and offscreen message updates; running tasks continue.',
  taskTemplates: 'Saved project task templates: prompt, model, effort and explicit file references (maximum 50).',
  contextWarningTokens: 'Approximate context warning threshold in tokens (1000–1000000).',
  attachEditorContext: 'Whether the editor context chip starts active in a new session. false = the chip shows but starts inactive (clicks during a session are not saved)',
  autoOpenDiffOnPermission: 'Whether to open the diff automatically when asking permission for a file edit. false = only the approval panel shows, and the diff opens when the file name in the prompt is clicked (the changes are kept either way, so they can be viewed later)',
  diffSurface: 'Where to draw the changes when asking permission for a file edit: "ide" (the IDE diff viewer) | "built-in" (our diff page). Always "built-in" when running without an IDE',
  browserDiffPresentation: 'How our diff page opens in the browser: "new-tab" (a new browser tab) | "overlay" (a modal over the current session). In the IDE it opens as an editor tab, regardless of this value',
  ultracode: '[Legacy] Moved to the native settings.json (an official key the CLI reads). Kept only so migration can clear it',
  syncModelToDefault: 'Changing the model (dropdown or cycle shortcut) also updates the CLI default model (the native model setting), not just the current session. true matches how the CLI behaves',
  dockLayout: 'Top bar right dock layout: { order, visible }. order is the order of every item in the More menu, visible is the set of item ids shown in the dock. Both empty = not set (all hidden)',
  env: 'CLAUDE_CONFIG_DIR only. Other environment variables go in env of the native settings.json',
  showDiffInIde: '[Legacy] Replaced by diffSurface. Kept only so migration can move the value and clear it',
  language: '[Legacy] Moved to the native settings.json. Kept only so migration can clear it',
  respectGitignoreForContext: '[Legacy] Moved to the native respectGitignore. Kept only so migration can clear it',
};

/**
 * The text of settings.js: every known key in declaration order, then any key
 * this build does not know, as it was found. A key a removed feature left behind
 * (or a newer build wrote) is the user's data; rewriting the file for an
 * unrelated save must not drop it.
 */
function generateSettingsContent(settings: Record<string, unknown>): string {
  const lines: string[] = ['export default {'];
  const line = (key: string, value: unknown) => {
    const name = /^[A-Za-z_$][A-Za-z0-9_$]*$/.test(key) ? key : JSON.stringify(key);
    lines.push(`  ${name}: ${value === null ? 'null' : JSON.stringify(value)},`);
  };
  for (const key of Object.keys(DEFAULT_SETTINGS)) {
    const comment = COMMENT_MAP[key];
    if (comment) {
      lines.push(`  // ${comment}`);
    }
    line(key, key in settings ? settings[key] : DEFAULT_SETTINGS[key]);
  }
  const unknown = Object.keys(settings).filter(key => !(key in DEFAULT_SETTINGS));
  if (unknown.length > 0) {
    lines.push('  // Not used by this version of AI Bridge; kept as they were');
    for (const key of unknown) line(key, settings[key]);
  }
  lines.push('};');
  return lines.join('\n') + '\n';
}

/**
 * Strip `//` line comments and block comments from the settings JS source, but
 * NEVER when the marker sits inside a string literal. A value such as
 * "//wsl.localhost/..." (a WSL UNC path a user may enter for cliPath/nodePath)
 * must survive intact — otherwise JSON.parse throws and the whole settings
 * object silently falls back to defaults, dropping the user's saved hostMode
 * down to "editor-tab" (regression #7).
 */
function stripJsComments(src: string): string {
  let out = '';
  let inString = false;
  let quote = '';
  for (let i = 0; i < src.length; i++) {
    const ch = src[i];
    if (inString) {
      out += ch;
      if (ch === '\\') {
        // preserve the escaped character verbatim
        i++;
        if (i < src.length) out += src[i];
        continue;
      }
      if (ch === quote) inString = false;
      continue;
    }
    if (ch === '"' || ch === "'") {
      inString = true;
      quote = ch;
      out += ch;
      continue;
    }
    const next = src[i + 1];
    if (ch === '/' && next === '/') {
      // line comment → drop to end of line, keep the newline
      while (i < src.length && src[i] !== '\n') i++;
      if (i < src.length) out += '\n';
      continue;
    }
    if (ch === '/' && next === '*') {
      // block comment → drop through the closing marker
      i += 2;
      while (i < src.length && !(src[i] === '*' && src[i + 1] === '/')) i++;
      i++; // skip '*'; the loop's i++ skips '/'
      continue;
    }
    out += ch;
  }
  return out;
}

/**
 * Parse the text of settings.js (a `export default { ... }` JS object literal)
 * into a plain object. Throws when the text is not a readable settings object.
 */
function parseSettingsSource(raw: string): Record<string, unknown> {
  // Strip comments in a string-literal-aware way so a value like
  // "//wsl.localhost/..." (WSL UNC path) is never mistaken for a comment (#7).
  let stripped = stripJsComments(raw);

  // Remove `export default` prefix and trailing semicolon
  stripped = stripped.replace(/^\s*export\s+default\s*/, '').replace(/;\s*$/, '').trim();

  // Add quotes to unquoted keys: word chars followed by colon
  stripped = stripped.replace(/([{,]\s*)([A-Za-z_$][A-Za-z0-9_$]*)\s*:/g, '$1"$2":');

  // Remove trailing commas before closing braces/brackets
  stripped = stripped.replace(/,\s*([\]}])/g, '$1');

  return JSON.parse(stripped) as Record<string, unknown>;
}

/**
 * Outcome of reading settings.js without any fallback. `missing` and
 * `unreadable` are kept apart on purpose: a file that is not there may be
 * created, a file that is there but cannot be read or parsed must be left alone
 * — writing over it would destroy whatever the user had in it.
 */
type SettingsFileRead =
  | { status: 'ok'; settings: Record<string, unknown> }
  | { status: 'missing' }
  | { status: 'unreadable'; error: string };

/**
 * The global settings file as the backend last found it: `null` while it reads
 * fine, otherwise the path and a short reason. Kept at module scope so a problem
 * noticed on any read (startup migration, CLI resolution) can be reported to a
 * tab that only attaches later; every read refreshes it, so fixing the file
 * clears the notice without a restart.
 *
 * The reason is always an error message, never the file's content — it may hold
 * env values.
 */
export interface SettingsFileProblem {
  filePath: string;
  reason: string;
}

let settingsFileProblem: SettingsFileProblem | null = null;

/** The current problem with the global settings file, or null when it reads fine. */
export function getSettingsFileProblem(): SettingsFileProblem | null {
  return settingsFileProblem;
}

/**
 * Re-read the global settings file only to refresh {@link getSettingsFileProblem},
 * for a request that did not read it itself (project scope). No side effects: a
 * missing file stays missing rather than being created here.
 */
export async function refreshSettingsFileProblem(): Promise<SettingsFileProblem | null> {
  const read = await readSettingsFileStrict();
  settingsFileProblem = read.status === 'unreadable'
    ? { filePath: SETTINGS_FILE, reason: read.error }
    : null;
  return settingsFileProblem;
}

/** Test seam: clear the module-level problem between cases. */
export function resetSettingsFileProblemForTest(): void {
  settingsFileProblem = null;
}

async function readSettingsFileStrict(): Promise<SettingsFileRead> {
  if (!existsSync(SETTINGS_FILE)) return { status: 'missing' };
  let raw: string;
  try {
    raw = await readFile(SETTINGS_FILE, 'utf-8');
  } catch (err) {
    // Deleted between the existence check and the read: still just missing.
    if ((err as NodeJS.ErrnoException | undefined)?.code === 'ENOENT') return { status: 'missing' };
    return { status: 'unreadable', error: err instanceof Error ? err.message : String(err) };
  }
  try {
    return { status: 'ok', settings: parseSettingsSource(raw) };
  } catch (err) {
    // The message only — never the file content, which may hold env values.
    return { status: 'unreadable', error: err instanceof Error ? err.message : String(err) };
  }
}

export async function readSettingsFile(): Promise<Record<string, unknown>> {
  try {
    const read = await readSettingsFileStrict();
    if (read.status === 'missing') {
      // Create with defaults
      settingsFileProblem = null;
      await mkdir(join(homedir(), '.ai-bridge'), { recursive: true });
      await atomicWriteFile(SETTINGS_FILE, generateSettingsContent(DEFAULT_SETTINGS));
      return { ...DEFAULT_SETTINGS };
    }
    if (read.status === 'unreadable') {
      // Lenient for readers (the UI still needs settings), but never write here:
      // the file exists and is not ours to replace.
      settingsFileProblem = { filePath: SETTINGS_FILE, reason: read.error };
      console.error('[node-backend]', 'Failed to read settings file, using defaults:', read.error);
      return { ...DEFAULT_SETTINGS };
    }

    // Merge with defaults so missing keys get default values
    settingsFileProblem = null;
    return { ...DEFAULT_SETTINGS, ...read.settings };
  } catch (err) {
    console.error('[node-backend]', 'Failed to read settings file, using defaults:', err);
    return { ...DEFAULT_SETTINGS };
  }
}

export interface SaveResult {
  status: 'ok' | 'error';
  error?: string;
}

function validateSetting(key: string, value: unknown): string | null {
  if (!(key in DEFAULT_SETTINGS)) {
    return `Unknown settings key: ${key}`;
  }
  switch (key) {
    case 'uiDensity':
      if (value !== 'compact' && value !== 'comfortable') return 'uiDensity must be compact or comfortable';
      break;
    case 'theme':
      if (!['system', 'light', 'dark', 'modern-technical'].includes(value as string)) {
        return 'theme must be one of "system", "light", "dark", "modern-technical"';
      }
      break;
    case 'fontSize': {
      const n = Number(value);
      if (!Number.isInteger(n) || n < 8 || n > 32) {
        return 'fontSize must be an integer between 8 and 32';
      }
      break;
    }
    case 'zoomLevel': {
      const n = Number(value);
      if (!Number.isFinite(n) || n < 0.5 || n > 3) {
        return 'zoomLevel must be a number between 0.5 and 3';
      }
      break;
    }
    case 'lineHeight': {
      const n = Number(value);
      if (!Number.isFinite(n) || n < 0.5 || n > 10) {
        return 'lineHeight must be a number between 0.5 and 10';
      }
      break;
    }
    case 'autoScrollThreshold': {
      const n = Number(value);
      if (!Number.isInteger(n) || n < 1) {
        return 'autoScrollThreshold must be a positive integer';
      }
      break;
    }
    case 'cliPath':
      if (value !== null && typeof value !== 'string') {
        return 'cliPath must be a string or null';
      }
      break;
    case 'nodePath':
      if (value !== null && typeof value !== 'string') {
        return 'nodePath must be a string or null';
      }
      break;
    case 'terminalApp':
      if (value !== null && typeof value !== 'string') {
        return 'terminalApp must be a string or null';
      }
      break;
    case 'openFilesWith':
      if (value !== null && typeof value !== 'string') {
        return 'openFilesWith must be a string or null';
      }
      break;
    case 'openFilesWithCustom': {
      if (value !== null) {
        if (typeof value !== 'object' || Array.isArray(value)) {
          return 'openFilesWithCustom must be an object or null';
        }
        const custom = value as Record<string, unknown>;
        if (typeof custom.path !== 'string' || typeof custom.arguments !== 'string') {
          return 'openFilesWithCustom must have string "path" and "arguments"';
        }
      }
      break;
    }
    case 'hostMode':
      if (!['editor-tab', 'tool-window'].includes(value as string)) {
        return 'hostMode must be one of "editor-tab", "tool-window"';
      }
      break;
    case 'openSettingsAs':
      if (!['overlay', 'new-tab'].includes(value as string)) {
        return 'openSettingsAs must be one of "overlay", "new-tab"';
      }
      break;
    case 'diffSurface':
      if (!DIFF_SURFACES.includes(value as string)) {
        return `diffSurface must be one of ${DIFF_SURFACES.map((s) => `"${s}"`).join(', ')}`;
      }
      break;
    case 'browserDiffPresentation':
      if (!BROWSER_DIFF_PRESENTATIONS.includes(value as string)) {
        return `browserDiffPresentation must be one of ${BROWSER_DIFF_PRESENTATIONS.map((p) => `"${p}"`).join(', ')}`;
      }
      break;
    case 'autoOpenDiffOnPermission':
    case 'chatPagination':
    case 'includeNestedSessions':
    case 'softWrap':
    case 'messageNavigator':
      if (typeof value !== 'boolean') {
        return `${key} must be a boolean`;
      }
      break;
    case 'userMessageColor':
    case 'messageNavigatorColor':
      if (value !== null && (typeof value !== 'string' || !/^#[0-9a-fA-F]{6}$/.test(value))) {
        return `${key} must be a "#RRGGBB" color or null`;
      }
      break;
    case 'uiDirection':
      if (!['ltr', 'rtl'].includes(value as string)) {
        return 'uiDirection must be one of "ltr", "rtl"';
      }
      break;
    case 'uiLanguage':
      if (value !== null && typeof value !== 'string') {
        return 'uiLanguage must be a string or null';
      }
      break;
    // Legacy: kept so the migration can clear it (null) after moving the value
    // to the native file.
    case 'language':
      if (value !== null && typeof value !== 'string') {
        return 'language must be a string or null';
      }
      break;
    case 'reasoningEffort':
      if (value !== null && !isReasoningEffort(value)) return 'reasoningEffort must be auto, low, medium, high, xhigh or max';
      break;
    case 'harness':
      if (value !== null && !isHarnessId(value)) return 'harness must be claude, opencode or deepseek';
      break;
    case 'harnessPaths': {
      if (typeof value !== 'object' || value === null || Array.isArray(value)) return 'harnessPaths must be an object';
      for (const [id, path] of Object.entries(value as Record<string, unknown>)) {
        if (!isAcpHarness(id)) return `harnessPaths: unknown harness ${id} (opencode or deepseek)`;
        if (path !== null && typeof path !== 'string') return `harnessPaths.${id} must be a string or null`;
      }
      break;
    }
    case 'textOnlyModels':
      if (!validTextOnlyModels(value)) return `textOnlyModels must be a list of at most ${MAX_TEXT_ONLY_MODELS} model ids`;
      break;
    case 'chatCompletionsImageModels':
      if (!validModelList(value)) return `chatCompletionsImageModels must be a list of at most ${MAX_MODEL_LIST_ENTRIES} model ids`;
      break;
    case 'taskTemplates':
      if (!validTaskTemplates(value)) return 'Invalid task templates (maximum 50 templates)';
      break;
    case 'contextWarningTokens':
      if (typeof value !== 'number' || !Number.isInteger(value) || value < 1000 || value > 1000000) return 'Context warning must be between 1000 and 1000000 tokens';
      break;
    case 'lowResourceMode':
    case 'computerUse':
    case 'webTools':
    case 'useCtrlEnterToSend':
    case 'focusInputOnEditorContext':
    case 'autoResumeOnLimit':
    case 'autoResumeDefaultReset':
    case 'attachEditorContext':
    case 'syncModelToDefault':
      if (typeof value !== 'boolean') {
        return `${key} must be a boolean`;
      }
      break;
    // Legacy: null clears it once the value has moved to `diffSurface`. Rejecting
    // null would leave the old key in the file forever, and the migration would
    // retry the same failing write on every startup.
    case 'showDiffInIde':
      if (value !== null && typeof value !== 'boolean') {
        return 'showDiffInIde must be a boolean or null';
      }
      break;
    // null = off/cleared, mirroring how the effort slider clears the top step.
    case 'ultracode':
      if (value !== null && typeof value !== 'boolean') {
        return 'ultracode must be a boolean or null';
      }
      break;
    // Legacy: null clears it once the value has moved to native respectGitignore.
    case 'respectGitignoreForContext':
      if (value !== null && typeof value !== 'boolean') {
        return 'respectGitignoreForContext must be a boolean or null';
      }
      break;
    // Shape-only validation, on purpose. The item ids live in the webview's dock
    // registry; mirroring the list here would mean editing two files to add one
    // icon, and the webview already drops ids it no longer knows (and any id in
    // `visible` that `order` does not also contain) when it normalizes the
    // layout. So an unrecognized or inconsistent id is stored but harmless.
    case 'dockLayout': {
      if (value === null || typeof value !== 'object' || Array.isArray(value)) {
        return 'dockLayout must be an object with "order" and "visible" arrays';
      }
      const layout = value as Record<string, unknown>;
      if (!Array.isArray(layout.order) || !Array.isArray(layout.visible)) {
        return 'dockLayout.order and dockLayout.visible must both be arrays';
      }
      if (layout.order.some((entry) => typeof entry !== 'string') || layout.visible.some((entry) => typeof entry !== 'string')) {
        return 'dockLayout entries must be strings';
      }
      // A duplicate would leave two rows claiming the same position in `order`
      // and make the drag reorder ambiguous about which copy moved.
      if (new Set(layout.order as string[]).size !== layout.order.length) {
        return 'dockLayout.order entries must be unique';
      }
      break;
    }
    case 'env': {
      if (value === null || typeof value !== 'object' || Array.isArray(value)) {
        return 'env must be an object of string values';
      }
      for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
        if (typeof v !== 'string') {
          return `env.${k} must be a string`;
        }
      }
      break;
    }
  }
  return null;
}

/** Coerce an unknown settings value into a string-keyed env record (or {}). */
function asEnvRecord(value: unknown): Record<string, string> {
  if (value && typeof value === 'object' && !Array.isArray(value)) {
    return value as Record<string, string>;
  }
  return {};
}

/**
 * Read project-level app settings.
 * Project settings use JSON format: {projectPath}/.ai-bridge/settings.json
 */
export async function readProjectSettings(projectPath: string): Promise<Record<string, unknown>> {
  const filePath = join(projectPath, '.ai-bridge', 'settings.json');
  await adoptLegacyProjectSettings(projectPath);
  try {
    if (!existsSync(filePath)) return {};
    const raw = await readFile(filePath, 'utf-8');
    return JSON.parse(raw) as Record<string, unknown>;
  } catch (err) {
    console.error('[node-backend]', 'Failed to read project settings:', err);
    return {};
  }
}

/**
 * Read merged settings: DEFAULT → global → project
 */
export async function readMergedSettings(projectPath?: string): Promise<{ settings: Record<string, unknown>; overrides: string[] }> {
  const globalSettings = await readSettingsFile();
  if (!projectPath) {
    return { settings: globalSettings, overrides: [] };
  }
  const projectSettings = await readProjectSettings(projectPath);
  const overrides = Object.keys(projectSettings);
  const merged: Record<string, unknown> = { ...globalSettings, ...projectSettings };
  // env is the one nested key we merge by sub-key (Claude's own order: global env,
  // then project env overriding individual keys) rather than replacing wholesale —
  // otherwise a project that sets one var would wipe the user's global vars.
  merged.env = { ...asEnvRecord(globalSettings.env), ...asEnvRecord(projectSettings.env) };
  return { settings: merged, overrides };
}

/**
 * Resolve the effective CLAUDE_CONFIG_DIR override declared in the plugin settings
 * `env` map (project takes priority over global). Returns null when unset, so callers
 * can fall back to process.env / the default ~/.claude.
 */
export async function resolveClaudeConfigDirOverride(projectPath?: string): Promise<string | null> {
  const { settings } = await readMergedSettings(projectPath);
  const value = asEnvRecord(settings.env).CLAUDE_CONFIG_DIR;
  return typeof value === 'string' && value.trim() !== '' ? value : null;
}

/**
 * Set or remove a single variable inside the `env` map at the given scope, preserving
 * the other variables. Passing value === null removes the variable.
 */
export async function saveEnvVarToScope(
  name: string,
  value: string | null,
  scope: 'global' | 'project',
  projectPath?: string,
): Promise<SaveResult> {
  if (scope === 'project' && !projectPath) {
    return { status: 'error', error: 'projectPath required for project scope' };
  }

  const source = scope === 'project'
    ? await readProjectSettings(projectPath as string)
    : await readSettingsFile();
  const currentEnv = { ...asEnvRecord(source.env) };

  if (value === null) {
    delete currentEnv[name];
  } else {
    currentEnv[name] = value;
  }

  return saveSettingToScope('env', currentEnv, scope, projectPath);
}

/**
 * Save a setting to the specified scope.
 * For project scope, saves to {projectPath}/.ai-bridge/settings.json
 *
 * At project scope, `value === null` removes the key rather than storing a null —
 * the same convention {@link saveEnvVarToScope} uses for env vars. That is what
 * "reset to the global value" means here: a stored null would keep the key in the
 * file, so it would still count as a project override and still win the merge,
 * and the global value would never come back (issue #344).
 */
export async function saveSettingToScope(
  key: string,
  value: unknown,
  scope: 'global' | 'project',
  projectPath?: string,
): Promise<SaveResult> {
  if (scope === 'project') {
    if (!projectPath) return { status: 'error', error: 'projectPath required for project scope' };
    // A removal still has to name a real key, but the value-shape checks do not
    // apply to it — validateSetting('theme', null) would reject, which would make
    // resetting a key to the global value fail for every typed setting.
    if (!(key in DEFAULT_SETTINGS)) return { status: 'error', error: `Unknown settings key: ${key}` };
    if (value !== null) {
      const validationError = validateSetting(key, value);
      if (validationError) return { status: 'error', error: validationError };
    }

    try {
      const filePath = join(projectPath, '.ai-bridge', 'settings.json');
      await adoptLegacyProjectSettings(projectPath);
      await mkdir(join(projectPath, '.ai-bridge'), { recursive: true });
      // "start fresh" on a parse failure used to be the behaviour here, and that
      // is exactly what wipes a file: the one key being saved becomes the whole
      // file (issue #386). updateJsonFile aborts on a file it cannot read.
      const result = await updateJsonFile(filePath, (current) => {
        if (value === null) {
          delete current[key];
        } else {
          current[key] = value;
        }
        return current;
      });
      return result.status === 'ok' ? { status: 'ok' } : { status: 'error', error: result.error };
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      return { status: 'error', error: msg };
    }
  }
  // global scope: use existing saveSettingToFile
  return saveSettingToFile(key, value);
}

/**
 * Serializes global settings writes. Concurrent updateSetting calls used to
 * interleave their read-modify-write of settings.js — a shorter new write left
 * a tail of the previous content, corrupting the file. Chaining guarantees one
 * read-modify-write completes before the next begins.
 */
let settingsWriteChain: Promise<unknown> = Promise.resolve();

export function saveSettingToFile(key: string, value: unknown): Promise<SaveResult> {
  const run = settingsWriteChain.then(() => doSaveSettingToFile(key, value));
  // Keep the chain alive even if a write fails.
  settingsWriteChain = run.then(
    () => undefined,
    () => undefined,
  );
  return run;
}

async function doSaveSettingToFile(key: string, value: unknown): Promise<SaveResult> {
  const validationError = validateSetting(key, value);
  if (validationError) {
    return { status: 'error', error: validationError };
  }

  try {
    // A save rewrites the whole file, so it must start from what is really in
    // it. A file that exists but cannot be read or parsed is left untouched —
    // falling back to defaults here would replace the user's content with them.
    const read = await readSettingsFileStrict();
    if (read.status === 'unreadable') {
      console.error('[node-backend]', 'Refusing to overwrite unreadable settings file:', read.error);
      return {
        status: 'error',
        error: `Settings file ${SETTINGS_FILE} could not be read (${read.error}); it was left unchanged. Fix or remove it, then try again.`,
      };
    }
    const current: Record<string, unknown> = read.status === 'ok'
      ? { ...DEFAULT_SETTINGS, ...read.settings }
      : { ...DEFAULT_SETTINGS };
    current[key] = value;
    await mkdir(join(homedir(), '.ai-bridge'), { recursive: true });
    await atomicWriteFile(SETTINGS_FILE, generateSettingsContent(current));
    return { status: 'ok' };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.error('[node-backend]', 'Failed to save setting:', err);
    return { status: 'error', error: msg };
  }
}
