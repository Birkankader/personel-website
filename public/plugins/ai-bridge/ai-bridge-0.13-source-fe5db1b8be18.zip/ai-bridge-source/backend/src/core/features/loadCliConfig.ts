import { StringDecoder } from 'string_decoder';
import { performance } from 'perf_hooks';
import { Claude } from '../claude';
import { harnessLaunch } from '../harness-launch';
import { harnessCommandEnv } from './harness-locator';
import { isAcpHarness, type HarnessId } from '../../shared';
import { watchCliAccount } from './cliAccountWatch';
import { globalConfigFilePath } from './live-credentials';

export interface SlashCommandInfo {
  name: string;
  description: string;
  argumentHint: string;
}

export interface ControlResponse<T> {
  type: 'control_response';
  response: {
    subtype: 'success';
    request_id: string;
    response: T;
  };
}

export interface CliInitResponse {
  commands: SlashCommandInfo[];
  agents: AgentInfo[];
  output_style: string;
  available_output_styles: string[];
  models: ModelInfo[];
  account: AccountInfo;
  pid: number;
}

export interface AgentInfo {
  name: string;
  description: string;
  model?: string;
}

export interface ModelInfo {
  value: string;
  displayName: string;
  description: string;
  supportsEffort?: boolean;
  supportedEffortLevels?: string[];
  supportsAdaptiveThinking?: boolean;
  supportsFastMode?: boolean;
  supportsAutoMode?: boolean;
}

export interface AccountInfo {
  email: string;
  subscriptionType: string;
}

export type CliConfigControlResponse = ControlResponse<CliInitResponse>;

/**
 * Parse CLI stdout to find the control_response event and return it as-is.
 * Returns null if no control_response is found.
 */
export function parseCliConfigResponse(stdout: string): CliConfigControlResponse | null {
  const lines = stdout.split('\n');

  let cliConfigResponse: CliConfigControlResponse | null = null;

  lines.forEach((line) => {
    const trimmed = line.trim();
    if (!trimmed) return;

    let event: Record<string, unknown>;
    try {
      event = JSON.parse(trimmed);
    } catch {
      return;
    }

    if (event.type === 'control_response') {
      cliConfigResponse = event as unknown as CliConfigControlResponse;
    }
  })

  return cliConfigResponse;
}

// Cache + dedup per workingDir and active CLI/config directory. The backend is shared across all IDE
// projects (NodeBackendService is @Service(Service.Level.APP)), so a single
// global cache would leak commands/skills from the first project to every
// other project.
const cacheByWorkingDir = new Map<string, { config: CliConfigControlResponse; expiresAt: number }>();
const pendingByWorkingDir = new Map<string, Promise<CliConfigControlResponse | null>>();
const cacheLifetimeMs = 30_000;

export interface LoadCliConfigOptions {
  /** Skip the cache and respawn the CLI (used by UI-triggered refresh). */
  refresh?: boolean;
  /** The runtime whose catalogue (models, commands) to load; Claude when omitted. */
  harness?: HarnessId;
}

/**
 * Spawn a config-only CLI process to load CLI config for a given workingDir.
 * Sends an `initialize` control_request to get control_response.
 * Results are cached per workingDir; pass `{ refresh: true }` to bypass.
 */
export async function loadCliConfig(
  workingDir: string,
  options: LoadCliConfigOptions = {},
): Promise<CliConfigControlResponse | null> {
  // No await before the dedup check below: simultaneous requests must find each other.
  const harness: HarnessId = isAcpHarness(options.harness) ? options.harness : 'claude';
  const cacheKey = JSON.stringify([workingDir, Claude.command, process.env.CLAUDE_CONFIG_DIR ?? '', Claude.env?.PATH ?? '', harness]);
  // The catalogue depends on who is signed in, so a change of account forgets it
  // (see forgetCliConfig). The file is the one for the config dir applied now.
  watchCliAccount(globalConfigFilePath());
  // A refresh bypasses a completed snapshot, not a probe already in flight.
  // Separate IDE tabs have separate React Query clients and can refresh together.
  const pending = pendingByWorkingDir.get(cacheKey);
  if (pending) {
    console.error('[loadCliConfig]', 'dedup — waiting for pending request for', workingDir);
    return pending;
  }
  if (options.refresh) cacheByWorkingDir.delete(cacheKey);
  const cached = cacheByWorkingDir.get(cacheKey);
  if (cached && cached.expiresAt > performance.now()) {
    console.error('[loadCliConfig]', 'returning cached config for', workingDir);
    return cached.config;
  }
  cacheByWorkingDir.delete(cacheKey);
  const promise = loadCliConfigInternal(workingDir, harness);
  pendingByWorkingDir.set(cacheKey, promise);
  try {
    const config = await promise;
    if (config && pendingByWorkingDir.get(cacheKey) === promise) {
      cacheByWorkingDir.set(cacheKey, { config, expiresAt: performance.now() + cacheLifetimeMs });
    }
    return config;
  } finally {
    if (pendingByWorkingDir.get(cacheKey) === promise) pendingByWorkingDir.delete(cacheKey);
  }
}

/**
 * Forget every loaded catalogue, for when the CLI's account changed. A probe
 * still running was started under the old account: its callers get its answer,
 * but it is not cached, and the next request starts a probe of its own.
 */
export function forgetCliConfig(): void {
  cacheByWorkingDir.clear();
  pendingByWorkingDir.clear();
}

/** Test-only: clear the workingDir cache between test cases. */
export function _resetCliConfigCache(): void {
  forgetCliConfig();
}

async function loadCliConfigInternal(workingDir: string, harness: HarnessId = 'claude'): Promise<CliConfigControlResponse | null> {
  const startedAt = performance.now();
  const args = [
    '-p',
    '--no-session-persistence',
    '--output-format', 'stream-json',
    '--input-format', 'stream-json',
    '--verbose',
    '--permission-mode', 'default',
  ];

  // spawnAuthed: the config probe runs as the same authenticated identity as chat
  // (inherited OAuth tokens stripped identically); env-provided API keys are kept. Awaited
  // before wiring handlers — the 'spawn' event fires only after this sync block registers it.
  const env = { TERM: 'dumb', CI: 'true', CLAUDECODE: undefined };
  // A harness answers the same `initialize` through the ACP bridge, in the same shape.
  const launch = isAcpHarness(harness) ? harnessLaunch(harness, args) : null;
  const proc = launch
    ? await Claude.spawnAuthedWith(launch.command, launch.args, workingDir, {
      cwd: workingDir,
      stdio: ['pipe', 'pipe', 'pipe'],
      env: { ...env, ...launch.env, ...await harnessCommandEnv(harness, workingDir) },
    })
    : await Claude.spawnAuthed(args, workingDir, {
      cwd: workingDir,
      stdio: ['pipe', 'pipe', 'pipe'],
      env,
    });

  return new Promise((resolve) => {
    let resolved = false;
    let timeoutHandle: ReturnType<typeof setTimeout> | undefined;
    // Decode split UTF-8 characters once; retain only the current JSONL line.
    // Re-parsing accumulated stdout on every chunk repeats preceding hook output.
    const decoder = new StringDecoder('utf8');
    let fragments: string[] = [];
    let lineLength = 0;
    let stdoutLength = 0;
    const maxLineLength = 8 * 1024 * 1024;
    const maxOutputLength = 16 * 1024 * 1024;
    const safeResolve = (value: CliConfigControlResponse | null): void => {
      if (resolved) return;
      resolved = true;
      // Clear the safety timeout so it cannot fire a stale killTreeNonBlocking after the
      // probe process has already closed and its pid may have been reused.
      if (timeoutHandle) clearTimeout(timeoutHandle);
      fragments = [];
      console.error('[loadCliConfig]', 'probe finished', {
        outcome: value ? 'ready' : 'unavailable',
        elapsedMs: Math.round(performance.now() - startedAt),
        stdoutBytes: stdoutLength,
        platform: process.platform,
      });
      resolve(value);
    };
    const finish = (value: CliConfigControlResponse | null): void => {
      safeResolve(value);
      Claude.killTreeNonBlocking(proc);
    };
    const consume = (text: string, final = false): void => {
      let start = 0;
      while (!resolved) {
        const end = text.indexOf('\n', start);
        const fragment = text.slice(start, end === -1 ? undefined : end);
        lineLength += fragment.length;
        if (lineLength > maxLineLength) {
          console.error('[loadCliConfig]', 'oversized response line — stopping probe');
          finish(null);
          return;
        }
        if (fragment) fragments.push(fragment);
        if (end === -1 && !final) return;

        const config = parseCliConfigResponse(fragments.join(''));
        fragments = [];
        lineLength = 0;
        if (config) {
          finish(config);
          return;
        }
        if (end === -1) return;
        start = end + 1;
      }
    };

    proc.stdout?.on('data', (data: Buffer) => {
      if (resolved) return;
      stdoutLength += data.length;
      if (stdoutLength > maxOutputLength) {
        console.error('[loadCliConfig]', 'excessive probe output — stopping probe');
        finish(null);
        return;
      }
      consume(decoder.write(data));
    });

    // Send initialize control_request to trigger system/init + control_response
    proc.on('spawn', () => {
      if (resolved) return;
      const initReq = JSON.stringify({
        type: 'control_request',
        request_id: 'config_init',
        request: { subtype: 'initialize' },
      }) + '\n';
      proc.stdin?.write(initReq);
    });
    proc.stdin?.on('error', (err) => {
      console.error('[loadCliConfig]', 'stdin error:', err.message);
      if (!resolved) finish(null);
    });

    proc.stderr?.on('data', (data: Buffer) => {
      if (!resolved) console.error('[loadCliConfig]', 'stderr:', data.toString().substring(0, 300));
    });

    proc.on('error', (err) => {
      console.error('[loadCliConfig]', 'spawn error:', err);
      safeResolve(null);
    });

    proc.on('close', (code) => {
      if (resolved) return;
      console.error('[loadCliConfig]', 'process closed with code:', code, 'stdout length:', stdoutLength);
      consume(decoder.end(), true);
      safeResolve(null);
    });

    // A shell wrapper can fail to emit close after termination (notably on
    // Windows). Settle here so one stuck probe cannot keep every tab waiting.
    timeoutHandle = setTimeout(() => {
      console.error('[loadCliConfig]', 'timeout — stopping probe');
      finish(null);
    }, 15000);
  });
}
