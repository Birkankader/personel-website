import { afterAll, afterEach, describe, expect, it, vi } from 'vitest';
import { spawnSync, type ChildProcess } from 'child_process';
import { existsSync, readFileSync, rmSync, writeFileSync } from 'fs';
import { join } from 'path';
import { fileURLToPath } from 'url';

// The native helper as the build ships it: `be-build` compiles native/win-job and
// copies the exe into backend/dist. win-job.ts looks for it beside its own module,
// which in a source run is src/core, so point that one lookup at the build.
const builtHelper = fileURLToPath(new URL('../../../dist/ai-bridge-job.exe', import.meta.url));

vi.mock('url', async (importOriginal) => {
  const actual = await importOriginal<typeof import('url')>();
  return {
    ...actual,
    fileURLToPath: (url: URL | string) => String(url).endsWith('/ai-bridge-job.exe')
      ? actual.fileURLToPath(new URL('../../../dist/ai-bridge-job.exe', import.meta.url))
      : actual.fileURLToPath(url),
  };
});

// The CLI registry lives under homedir()/.ai-bridge: keep this file's records out
// of the real one.
const { home } = vi.hoisted(() => ({ home: { path: '' } }));
vi.mock('os', async (importOriginal) => {
  const actual = await importOriginal<typeof import('os')>();
  home.path = actual.tmpdir() + `\\ccg-helper-e2e-home-${process.pid}`;
  return { ...actual, homedir: () => home.path };
});

import { resetJobHelperProbe, spawnWin32JobCli } from '../win-job';
import { readWindowsProcessSnapshot, terminateWindowsTree, windowsSessionProcessIds } from '../windows-processes';
import { findLiveCliForSession, killRegisteredCli, registerCliProcess } from '../cli-registry';

interface Exited { code: number | null; stdout: string; stderr: string }

function collect(proc: ChildProcess): Promise<Exited> {
  return new Promise((resolve, reject) => {
    let stdout = '';
    let stderr = '';
    proc.stdout?.on('data', (data: Buffer) => { stdout += data.toString(); });
    proc.stderr?.on('data', (data: Buffer) => { stderr += data.toString(); });
    proc.on('error', reject);
    proc.on('close', (code) => resolve({ code, stdout, stderr }));
  });
}

function firstLine(proc: ChildProcess): Promise<string> {
  return new Promise((resolve, reject) => {
    let buffered = '';
    proc.stdout?.on('data', (data: Buffer) => {
      buffered += data.toString();
      const end = buffered.indexOf('\n');
      if (end >= 0) resolve(buffered.slice(0, end).trim());
    });
    proc.on('error', reject);
    proc.on('close', () => reject(new Error(`helper exited before the stand-in printed: "${buffered}"`)));
  });
}

const alive = (pid: number) => {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
};

// Skipped where there is nothing to run: off Windows, or before `be-build` has built
// the helper (a machine without a Rust toolchain never does, and keeps the wrapper).
describe.skipIf(process.platform !== 'win32' || !existsSync(builtHelper))('ai-bridge-job.exe through spawnWin32JobCli', () => {
  const sessionId = `ccg-helper-e2e-${process.pid}`;
  const helpers: ChildProcess[] = [];
  const standIns: number[] = [];

  afterEach(() => {
    for (const proc of helpers.splice(0)) {
      if (proc.exitCode === null && proc.signalCode === null && proc.pid) {
        spawnSync('taskkill', ['/F', '/T', '/PID', String(proc.pid)], { stdio: 'ignore' });
      }
    }
    for (const pid of standIns.splice(0)) {
      if (alive(pid)) spawnSync('taskkill', ['/F', '/PID', String(pid)], { stdio: 'ignore' });
    }
    resetJobHelperProbe();
  });

  // Spied over the whole file: a failed helper scan is logged once, and every scan
  // after it is PowerShell's without a word.
  const logged = vi.spyOn(console, 'error');
  afterAll(() => {
    logged.mockRestore();
    rmSync(home.path, { recursive: true, force: true });
  });

  function launch(command: string, args: string[]): ChildProcess {
    const proc = spawnWin32JobCli(command, args, sessionId, { env: process.env, windowsHide: true });
    helpers.push(proc);
    return proc;
  }

  it('runs the CLI through the helper, passing its exit code and adding nothing to stdout', async () => {
    const proc = launch('exit', ['5']);
    expect(proc.spawnfile).toBe(builtHelper);
    expect(await collect(proc)).toEqual({ code: 5, stdout: '', stderr: '' });
  }, 60_000);

  it('is found by the orphan sweep, and taking it down takes the CLI tree with it', async () => {
    const proc = launch('powershell', [
      '-NoProfile', '-NonInteractive', '-Command', '"[Console]::Out.WriteLine($PID); Start-Sleep 120"',
    ]);
    const standIn = Number(await firstLine(proc));
    standIns.push(standIn);
    expect(alive(standIn)).toBe(true);

    const snapshot = await readWindowsProcessSnapshot();
    expect(snapshot).not.toBeNull();
    expect(windowsSessionProcessIds(snapshot!, sessionId)).toContain(proc.pid);

    expect(await terminateWindowsTree(proc.pid!)).toBe(true);
    const deadline = Date.now() + 10_000;
    while (alive(standIn) && Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    expect(alive(standIn)).toBe(false);
  }, 60_000);

  it('is found as an orphan before a chat starts on its session, and killed with its tree', async () => {
    const proc = launch('powershell', [
      '-NoProfile', '-NonInteractive', '-Command', '"[Console]::Out.WriteLine($PID); Start-Sleep 120"',
    ]);
    const standIn = Number(await firstLine(proc));
    standIns.push(standIn);
    // Recorded as a crashed backend leaves it: by a backend that is gone.
    registerCliProcess(proc, sessionId, process.cwd());
    const record = join(home.path, '.ai-bridge', 'cli-registry', `${proc.pid}.json`);
    const owner = { pid: spawnSync(process.execPath, ['-e', '']).pid, argv1: 'backend.mjs' };
    writeFileSync(record, JSON.stringify({ ...JSON.parse(readFileSync(record, 'utf8')), owner }));

    const conflict = await findLiveCliForSession(sessionId);
    expect(conflict).toMatchObject({ entry: { pid: proc.pid }, ownerAlive: false });
    await killRegisteredCli(conflict!.entry);

    expect(existsSync(record)).toBe(false);
    const deadline = Date.now() + 10_000;
    while (alive(standIn) && Date.now() < deadline) {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    expect(alive(standIn)).toBe(false);
    // Every scan in this file was the helper's: none fell back to PowerShell.
    expect(logged.mock.calls.flat().join('\n')).not.toContain('Process scan helper failed');
  }, 60_000);
});
