import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { installHarness } from '../features/harness-locator';
import { isAcpHarness, MessageType } from '../../shared';

/**
 * Install a harness after the user clicked Install on the Connection page. ACK
 * at once (npm can take minutes, past the request timeout) and report the
 * outcome as a HARNESS_INSTALL_STATUS broadcast.
 */
export async function installHarnessHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const harness = ((message.payload as Record<string, unknown>) ?? {}).harness;
  if (!isAcpHarness(harness)) {
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'error',
      error: `Unknown harness: ${String(harness)}`,
    });
    return;
  }
  await connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId, status: 'ok' });

  try {
    await installHarness(harness);
    await connections.broadcastToAll(MessageType.HARNESS_INSTALL_STATUS, { harness, status: 'installed' });
  } catch (err) {
    const error = err instanceof Error ? err.message : String(err);
    console.error('[node-backend]', `Installing ${harness} failed:`, error);
    await connections.broadcastToAll(MessageType.HARNESS_INSTALL_STATUS, { harness, status: 'failed', error });
  }
}
