import { beforeEach, describe, expect, it, vi } from 'vitest';
import { open } from 'fs/promises';
import { resolve } from 'path';

vi.mock('fs/promises', () => ({
  open: vi.fn(),
  realpath: vi.fn(async (file: string) => resolve(file)),
}));
vi.mock('../../handlers/findBackgroundTaskOutputPath', () => ({ getTmpBase: () => '/tasks' }));
vi.mock('../claudeConfigDir', () => ({ getClaudeConfigDir: () => '/config' }));

import { loadBackgroundTaskOutput } from '../loadBackgroundTaskOutput';

describe('background output read budget', () => {
  beforeEach(() => vi.clearAllMocks());

  function setup(size: number, shortReads = false) {
    let totalBytesRead = 0;
    const handle = {
      stat: vi.fn(async () => ({ size })),
      close: vi.fn(async () => {}),
      read: vi.fn(async (buffer: Buffer, offset: number, length: number, position: number) => {
        const bytesRead = Math.min(length, shortReads ? 16_384 : length);
        buffer.fill('x', offset, offset + bytesRead);
        if (position + bytesRead === size) buffer.write('TAIL', offset + bytesRead - 4);
        totalBytesRead += bytesRead;
        return { bytesRead, buffer };
      }),
    };
    vi.mocked(open).mockResolvedValue(handle as unknown as Awaited<ReturnType<typeof open>>);
    return { handle, bytesRead: () => totalBytesRead };
  }

  it.each([8 * 1024 * 1024, 1024 * 1024 * 1024])('reads less than 601 KB from a %i-byte log', async (size) => {
    const fixture = setup(size);
    const output = await loadBackgroundTaskOutput({ outputFile: '/tasks/build.output' });

    expect(output).toEqual({ text: 'x'.repeat(199_996) + 'TAIL', truncated: true });
    expect(fixture.bytesRead()).toBeLessThan(601_000);
    expect(fixture.handle.close).toHaveBeenCalledOnce();
  });

  it('completes partial reads without including uninitialized buffer bytes', async () => {
    const fixture = setup(8 * 1024 * 1024, true);
    const output = await loadBackgroundTaskOutput({ outputFile: '/tasks/build.output' });

    expect(output.text).toBe('x'.repeat(199_996) + 'TAIL');
    expect(fixture.bytesRead()).toBeLessThan(601_000);
    expect(fixture.handle.read.mock.calls.length).toBeGreaterThan(1);
    expect(fixture.handle.close).toHaveBeenCalledOnce();
  });

  it('closes the descriptor when reading fails', async () => {
    const fixture = setup(8 * 1024 * 1024);
    fixture.handle.read.mockRejectedValueOnce(new Error('read failed'));

    expect(await loadBackgroundTaskOutput({ outputFile: '/tasks/build.output' }))
      .toEqual({ text: '', truncated: false });
    expect(fixture.handle.close).toHaveBeenCalledOnce();
  });
});
