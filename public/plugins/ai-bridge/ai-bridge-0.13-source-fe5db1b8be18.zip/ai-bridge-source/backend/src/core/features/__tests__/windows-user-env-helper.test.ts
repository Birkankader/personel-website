import { afterAll, afterEach, beforeAll, describe, expect, it, vi } from 'vitest';
import { existsSync, mkdtempSync, rmSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';

// The real programs against the real registry, read-only: these tests compare what
// the native helper and the PowerShell script read for the user running them, so a
// failure says only that they differ, never what either one read.
const builtHelper = fileURLToPath(new URL('../../../../dist/ai-bridge-job.exe', import.meta.url));

const { helper, spawned } = vi.hoisted(() => ({ helper: { path: '' }, spawned: [] as string[] }));
vi.mock('node:child_process', async (importOriginal) => {
  const actual = await importOriginal<typeof import('node:child_process')>();
  const spawn = ((...args: Parameters<typeof actual.spawn>) => {
    spawned.push(String(args[0]));
    return actual.spawn(...args);
  }) as typeof actual.spawn;
  return { ...actual, spawn };
});
vi.mock('../../win-job', () => ({ jobHelperPath: () => helper.path }));

const keys = ['ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL', 'ANTHROPIC_MODEL'] as const;
const inherited = Object.fromEntries(keys.map(key => [key, process.env[key]]));
let scratch = '';

/** What a backend learns from one read: the values it reports and the env it keeps. */
async function readThrough(path: string) {
  helper.path = path;
  spawned.length = 0;
  vi.resetModules();
  const { getWindowsUserEnv } = await import('../windows-user-env');
  const reported = await getWindowsUserEnv();
  const kept = Object.fromEntries(keys.map(key => [key, process.env[key] ?? null]));
  return JSON.stringify({ reported, kept });
}

describe.skipIf(process.platform !== 'win32' || !existsSync(builtHelper))('Windows User Env through the built helper', () => {
  beforeAll(() => { scratch = mkdtempSync(join(tmpdir(), 'ccg-user-env-')); });
  afterAll(() => { rmSync(scratch, { recursive: true, force: true }); });
  afterEach(() => {
    vi.restoreAllMocks();
    for (const key of keys) { if (inherited[key] === undefined) delete process.env[key]; else process.env[key] = inherited[key]; }
  });

  it('reads what the PowerShell script reads', async () => {
    const native = await readThrough(builtHelper);
    expect(spawned).toEqual([builtHelper]);
    const powershell = await readThrough(join(scratch, 'not-shipped.exe'));
    expect(spawned).toHaveLength(1);
    expect(spawned[0]).toMatch(/powershell\.exe$/i);
    expect(native === powershell, 'the helper and PowerShell read different values').toBe(true);
  }, 30_000);

  it('falls back to PowerShell when a shipped helper cannot start', async () => {
    const error = vi.spyOn(console, 'error').mockImplementation(() => {});
    const broken = join(scratch, 'ai-bridge-job.exe');
    writeFileSync(broken, 'not a Windows executable');
    const fallback = await readThrough(broken);
    expect(spawned).toHaveLength(2);
    expect(spawned[0]).toBe(broken);
    expect(spawned[1]).toMatch(/powershell\.exe$/i);
    expect(error).toHaveBeenCalledWith('[node-backend]', 'User environment helper could not run — using PowerShell');
    expect(fallback === await readThrough(builtHelper), 'the fallback read different values').toBe(true);
  }, 30_000);
});
