import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { loadCliConfig } from '../features/loadCliConfig';
import { readMergedSettings } from '../features/settings';
import { isAcpHarness, MessageType, type HarnessId } from '../../shared';
import { Claude } from '../claude';

export async function getCliConfigHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  try {
    const payload = (message.payload as Record<string, unknown>) ?? {};
    const workingDir = payload.workingDir as string | undefined;
    const refresh = payload.refresh === true;
    const cwd = workingDir || process.cwd();
    await Claude.applyConfigDir(cwd);

    console.error('[node-backend]', `Loading CLI config for cwd: ${cwd}${refresh ? ' (refresh)' : ''}`);
    const controlResponse = await loadCliConfig(cwd, { refresh, harness: await configuredHarness(cwd) });

    if (controlResponse) {
      console.error('[node-backend]', 'CLI config loaded');
    } else {
      console.error('[node-backend]', 'CLI config: null (CLI may not be available)');
    }

    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'ok',
      controlResponse,
    });
  } catch (err) {
    console.error('[node-backend]', 'Failed to load CLI config:', err);
    await connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'error',
      error: err instanceof Error ? err.message : String(err),
    });
  }
}

/**
 * Start the catalogue probe for [workingDir] before the page asks for it, so the
 * CLI's `initialize` runs while the IDE is still bringing the browser up. The
 * page's first GET_CLI_CONFIG then joins this probe, or finds its result cached,
 * instead of starting the CLI only after the page has drawn. It makes the same
 * lookup as the handler, which is what puts both on the same cache entry.
 * Best effort: a failure is logged and the page's own request probes again.
 */
export async function warmCliConfig(workingDir: string): Promise<void> {
  try {
    await Claude.applyConfigDir(workingDir);
    console.error('[node-backend]', `Warming CLI config for cwd: ${workingDir}`);
    await loadCliConfig(workingDir, { harness: await configuredHarness(workingDir) });
  } catch (err) {
    console.error('[node-backend]', 'CLI config warm-up failed:', err);
  }
}

/**
 * The project whose catalogue this backend can warm at startup: the root the
 * JetBrains plugin started it for, which is the working directory its page asks
 * with. None for a WSL backend, whose root is the Linux path while the page asks
 * with the Windows one, and none outside JetBrains, where no page is coming yet.
 */
export function cliConfigWarmupDir(env: NodeJS.ProcessEnv, jetBrainsMode: boolean): string | undefined {
  if (!jetBrainsMode || env.WSL_DISTRO_NAME) return undefined;
  return env.AI_BRIDGE_RUNTIME_SCOPE || undefined;
}

/**
 * The runtime new chats start on, whose catalogue (models, commands) the picker
 * shows. Unreadable settings mean the default, Claude.
 */
async function configuredHarness(workingDir: string): Promise<HarnessId> {
  try {
    const { settings } = await readMergedSettings(workingDir);
    return isAcpHarness(settings.harness) ? settings.harness : 'claude';
  } catch {
    return 'claude';
  }
}
