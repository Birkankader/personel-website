import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { MessageType } from '../../../shared';
import { SettingsFileWatcher } from '../settings-watcher';
import { readMergedSettings } from '../settings';
import { join } from 'path';

const calls = vi.hoisted(() => ({
  watchers: [] as { dir: string; callback: (event: string, filename: string) => void; close: ReturnType<typeof vi.fn> }[],
}));
vi.mock('fs', () => ({
  existsSync: () => true,
  watch: vi.fn((dir: string, callback: (event: string, filename: string) => void) => {
    const close = vi.fn(); calls.watchers.push({ dir, callback, close }); return { close };
  }),
}));
vi.mock('os', () => ({ homedir: () => '/test-home' }));
vi.mock('../settings', () => ({
  readMergedSettings: vi.fn(async (project?: string) => ({
    settings: { reasoningEffort: project ? 'high' : 'low' }, overrides: project ? ['reasoningEffort'] : [],
  })),
}));
vi.mock('../claude-settings', () => ({ readMergedClaudeSettings: vi.fn(async () => ({ settings: {}, overrides: [] })) }));

describe('settings watcher scope and lifetime', () => {
  let watcher: SettingsFileWatcher;
  const notify = vi.fn((_event: string, _data: unknown): void | Promise<void> => {});
  beforeEach(() => {
    vi.useFakeTimers(); calls.watchers.length = 0; notify.mockReset();
    vi.mocked(readMergedSettings).mockClear();
    vi.stubEnv('CLAUDE_CONFIG_DIR', '/provider');
    watcher = new SettingsFileWatcher(notify);
  });
  afterEach(() => { watcher.stopAll(); vi.useRealTimers(); vi.unstubAllEnvs(); });

  it('tags project merged snapshots while global updates remain unscoped for each client to refetch', async () => {
    watcher.startGlobalWatchers();
    watcher.registerProject('/project-a');
    calls.watchers.find((w) => w.dir === join('/project-a', '.ai-bridge'))!.callback('change', 'settings.json');
    await vi.advanceTimersByTimeAsync(300);
    expect(notify).toHaveBeenLastCalledWith(MessageType.SETTINGS_CHANGED, {
      workingDir: '/project-a', settings: { reasoningEffort: 'high' }, overrides: ['reasoningEffort'],
    });
    calls.watchers.find((w) => w.dir === join('/test-home', '.ai-bridge'))!.callback('change', 'settings.js');
    await vi.advanceTimersByTimeAsync(300);
    expect(notify).toHaveBeenLastCalledWith(MessageType.SETTINGS_CHANGED, {
      settings: { reasoningEffort: 'low' }, overrides: [],
    });
  });

  it('keeps a shared project watcher until its last reference closes and cancels pending notifications', async () => {
    watcher.registerProject('/project-a'); watcher.registerProject('/project-a');
    expect(calls.watchers).toHaveLength(3);
    watcher.unregisterProject('/project-a');
    expect(calls.watchers.every((w) => w.close.mock.calls.length === 0)).toBe(true);
    calls.watchers[2].callback('change', 'settings.json');
    watcher.unregisterProject('/project-a');
    await vi.advanceTimersByTimeAsync(300);
    expect(calls.watchers.every((w) => w.close.mock.calls.length === 1)).toBe(true);
    expect(notify).not.toHaveBeenCalled();
    expect(vi.getTimerCount()).toBe(0);
  });

  it('waits for delivery and coalesces file changes before reading another snapshot', async () => {
    let delivered!: () => void;
    notify.mockImplementationOnce(() => new Promise<void>(resolve => { delivered = resolve; }));
    watcher.registerProject('/project-a');
    const changed = calls.watchers.find(w => w.dir === join('/project-a', '.ai-bridge'))!.callback;
    changed('change', 'settings.json');
    await vi.advanceTimersByTimeAsync(300);
    for (let i = 0; i < 20; i++) {
      changed('change', 'settings.json');
      await vi.advanceTimersByTimeAsync(300);
    }
    expect(readMergedSettings).toHaveBeenCalledOnce();
    expect(notify).toHaveBeenCalledOnce();
    expect(vi.getTimerCount()).toBe(0);
    delivered();
    await vi.advanceTimersByTimeAsync(0);
    expect(readMergedSettings).toHaveBeenCalledTimes(2);
    expect(notify).toHaveBeenCalledTimes(2);
  });

  it('cancels a pending reread when a pressured watcher is unregistered', async () => {
    let delivered!: () => void;
    notify.mockImplementationOnce(() => new Promise<void>(resolve => { delivered = resolve; }));
    watcher.registerProject('/project-a');
    const changed = calls.watchers.find(w => w.dir === join('/project-a', '.ai-bridge'))!.callback;
    changed('change', 'settings.json');
    await vi.advanceTimersByTimeAsync(300);
    changed('change', 'settings.json');
    watcher.unregisterProject('/project-a');
    delivered();
    await vi.advanceTimersByTimeAsync(0);
    expect(readMergedSettings).toHaveBeenCalledOnce();
    expect(notify).toHaveBeenCalledOnce();
    expect(vi.getTimerCount()).toBe(0);
  });

  it('does not publish a read from a removed subscription into its replacement', async () => {
    let read!: (value: Awaited<ReturnType<typeof readMergedSettings>>) => void;
    vi.mocked(readMergedSettings).mockImplementationOnce(() => new Promise(resolve => { read = resolve; }));
    watcher.registerProject('/project-a');
    const changed = calls.watchers.find(w => w.dir === join('/project-a', '.ai-bridge'))!.callback;
    changed('change', 'settings.json');
    await vi.advanceTimersByTimeAsync(300);
    watcher.unregisterProject('/project-a');
    watcher.registerProject('/project-a');
    read({ settings: {}, overrides: [] } as Awaited<ReturnType<typeof readMergedSettings>>);
    changed('change', 'settings.json');
    await vi.advanceTimersByTimeAsync(300);
    expect(notify).not.toHaveBeenCalled();
    expect(readMergedSettings).toHaveBeenCalledOnce();
  });
});
