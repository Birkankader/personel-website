import { clientInfo, isJetBrainsMode } from '../../config/environment';

export interface TelemetryProperties { [key: string]: string | number | boolean }
let browserClient = '';
/** Kept only for local About information, never transmitted. */
export function setBrowserClient(client: string): void { browserClient = client; }
export function getRawClientInfo(): string { return isJetBrainsMode ? clientInfo : browserClient; }
/** Preserve local diagnostics without a remote error-reporting transport. */
export function reportBackendError(error: Error, context: TelemetryProperties = {}): void {
  console.error('[node-backend]', error.message, context);
}
