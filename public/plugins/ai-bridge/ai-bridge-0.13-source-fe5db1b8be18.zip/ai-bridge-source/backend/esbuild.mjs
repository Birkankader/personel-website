import { build } from 'esbuild';
import { spawnSync } from 'child_process';
import {
  chmodSync, copyFileSync, existsSync, mkdirSync, readFileSync, readdirSync,
  realpathSync, renameSync, rmSync, statSync,
} from 'fs';
import { createRequire } from 'module';
import { dirname, join } from 'path';

const pkg = JSON.parse(readFileSync('package.json', 'utf-8'));

// ─── Build-time env injection ───────────────────────────────────────────────
// Build-time injection is opt-in via a leading underscore: only root-.env keys
// named `_FOO` are baked into the bundle. scripts/build.sh (and the gradle
// buildNodeBackend task) collect those `_`-prefixed key names into
// BUILD_INJECT_KEYS, so esbuild replaces `process.env._FOO` with the literal
// value. Plain keys stay runtime-only; nothing unrelated (PATH etc.) is swept in.
const injectKeys = (process.env.BUILD_INJECT_KEYS ?? '')
  .split(/\s+/)
  .filter(Boolean);

const injectedDefine = Object.fromEntries(
  injectKeys.map((key) => [
    `process.env.${key}`,
    JSON.stringify(process.env[key] ?? ''),
  ]),
);

// Shared esbuild options. Both the WebSocket server and the standalone account
// CLI are bundled with the SAME platform/format/banner so the account helper —
// which imports the same account-manager code (keychain via child_process under
// ESM needs the createRequire shim) — runs identically to the backend.
const common = {
  bundle: true,
  platform: 'node',
  target: 'node18',
  format: 'esm',
  sourcemap: true,
  minify: false,
  // node-pty is a native addon plus worker files (the Windows ConPTY console
  // connection forks a worker script), none of which can live inside a bundle. It
  // is loaded lazily by core/features/mcp-login.ts and shipped beside the bundle
  // by copyNodePtyRuntime() below.
  external: ['@lydell/node-pty'],
  define: {
    '__PLUGIN_VERSION__': JSON.stringify(pkg.version),
    // The esbuild bundle (backend.mjs) is by definition the shipped, production
    // artifact — dev runs `src/server.ts` through tsx (`pnpm dev`) and never the
    // bundle. Bake NODE_ENV=production so isDev()/isProd() are reliable at
    // runtime even though the launchers (Kotlin spawn, ai-bridge foreground.sh) clear
    // or omit NODE_ENV. This is what lets the per-launch auth token default to a
    // RANDOM secret in production (never the shared dev token) when
    // AI_BRIDGE_AUTH_TOKEN is somehow unset — see backend/src/config/environment.ts.
    'process.env.NODE_ENV': JSON.stringify('production'),
    // Keys defined in the root .env, injected at build time — never committed
    // as source constants.
    ...injectedDefine,
  },
  banner: {
    // Prepended verbatim to the top of every bundle, so these run before any
    // bundled module body (including the MCP SDK → eventsource-parser code below).
    js: [
      // Aliased, like the stream globals below: a bundled module that imports
      // `createRequire` under its own name (backend/src/core/extend-kit.ts does,
      // to resolve from a root other than this file) would otherwise collide with
      // this declaration and kill the bundle with "Identifier 'createRequire' has
      // already been declared" before it prints its PORT line.
      `import { createRequire as __aiBridgeCreateRequire } from 'node:module';`,
      `const require = __aiBridgeCreateRequire(import.meta.url);`,
      // Web Streams globals (TransformStream/Readable/Writable) are only guaranteed
      // on the global scope in newer Node runtimes; older or non-standard nodes that
      // the plugin may end up launching expose them only on `node:stream/web`. The
      // bundled MCP SDK pulls in eventsource-parser, whose `class extends
      // TransformStream` is evaluated at module load — a missing global there kills
      // the backend before it can even print its PORT line (#159). Pull them from
      // the module and fill any gap so the bundle loads on any Node >= 16.5.
      `import { TransformStream as __aiBridgeTransformStream, ReadableStream as __aiBridgeReadableStream, WritableStream as __aiBridgeWritableStream } from 'node:stream/web';`,
      `globalThis.TransformStream ??= __aiBridgeTransformStream;`,
      `globalThis.ReadableStream ??= __aiBridgeReadableStream;`,
      `globalThis.WritableStream ??= __aiBridgeWritableStream;`,
    ].join('\n'),
  },
};

// Main backend (WebSocket server). Name stays `backend.mjs` — cli/lib/runtime.sh
// keys the runtime cache off it.
await build({ ...common, entryPoints: ['src/server.ts'], outfile: 'dist/backend.mjs' });

// Terminal account-switch helper, shipped beside backend.mjs in the standalone
// runtime and invoked by `ai-bridge account …`.
await build({ ...common, entryPoints: ['src/cli/account.ts'], outfile: 'dist/account-cli.mjs' });

// Helper processes started beside the chat: the ACP bridge that runs OpenCode /
// DeepSeek Harness in the CLI's place, and the computer-use MCP server. The
// backend resolves it next to backend.mjs (core/harness-launch.ts), so every
// distributable carries it beside the bundle like the win32 assets below.
await build({ ...common, entryPoints: ['src/agent-tools/main.ts'], outfile: 'dist/agent-tools.mjs' });

// Ship the win32 Job Object wrapper next to the bundle. It's a runtime asset (not
// JS to bundle): win-job.ts resolves it via `new URL('./win-job-wrapper.ps1',
// import.meta.url)`, i.e. beside backend.mjs. Both distributables (plugin
// syncResources, standalone tgz) copy it from dist/ alongside backend.mjs.
copyFileSync('src/core/win-job-wrapper.ps1', 'dist/win-job-wrapper.ps1');

// Same deal for the BASH_ENV script the CLI's bash sources on every non-interactive
// start (win-job.ts `utf8BashEnv`). It is what keeps CJK console output from reaching
// the chat as U+FFFD, and utf8BashEnv stays SILENT when the file is absent — so a
// distributable that forgets to carry it degrades invisibly. Keep all three copy
// sites (here, gradle syncResources, standalone tgz) in step.
copyFileSync('src/core/win-bash-env.sh', 'dist/win-bash-env.sh');

// The native win32 helper (native/win-job, Rust): the Job Object wrapper win-job.ts
// prefers to win-job-wrapper.ps1, and the user environment reader and process scan
// that windows-user-env.ts and windows-processes.ts prefer to their PowerShell
// scripts, whenever it sits beside the bundle. It ships
// through the same three copy sites. Building it takes a Rust toolchain that can
// target Windows; a machine without one still builds the backend, and that build
// keeps to PowerShell. An earlier build's helper is removed first, so dist/ never
// carries one that does not match the source. Cargo runs in the crate, where it
// finds the crate's .cargo/config.toml (the static CRT).
const jobHelper = 'dist/ai-bridge-job.exe';
try {
  rmSync(jobHelper, { force: true });
} catch {
  // A chat of a backend running from dist/ (runIde) holds the exe, and Windows
  // lets a running image be renamed but never deleted or overwritten.
  renameSync(jobHelper, `${jobHelper}.${Date.now()}.old`);
}
for (const stale of readdirSync('dist').filter((name) => /^ai-bridge-job\.exe\.\d+\.old$/.test(name))) {
  try { rmSync(`dist/${stale}`); } catch { /* still running: the next build gets it */ }
}
const jobHelperTarget = process.env.AI_BRIDGE_WIN_JOB_TARGET
  ?? (process.platform === 'win32' ? 'x86_64-pc-windows-msvc' : 'x86_64-pc-windows-gnu');
const cargo = spawnSync('cargo', ['build', '--release', '--locked', '--target', jobHelperTarget], {
  cwd: 'native/win-job', stdio: 'inherit',
});
if (cargo.status === 0) {
  copyFileSync(`native/win-job/target/${jobHelperTarget}/release/ai-bridge-job.exe`, jobHelper);
} else {
  const reason = cargo.error ? `cargo not found (${cargo.error.message})` : `cargo exited with ${cargo.status}`;
  console.warn(`[esbuild] WARNING: win32 job helper not built for ${jobHelperTarget}: ${reason}.`);
  console.warn('[esbuild] Windows chats in this build use win-job-wrapper.ps1 instead.');
}

// ─── node-pty runtime (dist/node_modules/@lydell) ───────────────────────────
// `@lydell/node-pty` stays external (see `common`), so backend.mjs resolves it from
// a node_modules folder beside itself. Every distributable carries that folder: the
// plugin (gradle syncWebviewResources → PluginResourceExtractor) and the standalone
// tgz. Keep all three copy sites in step.
//
// The package picks its prebuild at runtime from a sibling package named
// `@lydell/node-pty-<platform>-<arch>`, and a release is built on one machine for
// every platform, so all six platform packages are copied (pnpm installs them all
// through `supportedArchitectures` in pnpm-workspace.yaml). Without `*.pdb` debug
// symbols that is a few MB instead of ~24.
const NODE_PTY_PLATFORMS = [
  'darwin-arm64', 'darwin-x64', 'linux-arm64', 'linux-x64', 'win32-arm64', 'win32-x64',
];

// A running backend started from dist/ keeps conpty.node loaded, and Windows refuses
// to overwrite or delete a loaded image.
function inUseGuard(path, action) {
  try {
    return action();
  } catch (error) {
    if (error && (error.code === 'EBUSY' || error.code === 'EPERM')) {
      throw new Error(`${path} is in use (a running backend has node-pty loaded); stop it and rebuild`, { cause: error });
    }
    throw error;
  }
}

// Make `dst` an exact copy of `src`: *.pdb files are left out, a file is rewritten
// only when missing or different (so an unchanged, loaded conpty.node is never
// touched), and anything in `dst` that `src` lacks is removed. pnpm trees are full
// of links, so entries are followed (statSync) and always copied as real files.
function syncTree(src, dst, totals) {
  mkdirSync(dst, { recursive: true });
  const wanted = new Set();
  for (const name of readdirSync(src)) {
    if (name.endsWith('.pdb')) continue;
    wanted.add(name);
    const from = join(src, name);
    const to = join(dst, name);
    const info = statSync(from);
    if (info.isDirectory()) {
      if (existsSync(to) && !statSync(to).isDirectory()) inUseGuard(to, () => rmSync(to, { force: true }));
      syncTree(from, to, totals);
      continue;
    }
    if (existsSync(to) && statSync(to).isDirectory()) inUseGuard(to, () => rmSync(to, { recursive: true, force: true }));
    const unchanged = existsSync(to)
      && statSync(to).size === info.size
      && Buffer.compare(readFileSync(from), readFileSync(to)) === 0;
    if (!unchanged) inUseGuard(to, () => copyFileSync(from, to));
    // Windows has no execute bit (and chmod there only flips the read-only flag);
    // the other copy sites set it again where it matters.
    if (process.platform !== 'win32') {
      chmodSync(to, name === 'spawn-helper' ? 0o755 : info.mode & 0o777);
    }
    totals.files += 1;
    totals.bytes += info.size;
  }
  pruneExcept(dst, wanted);
}

// Remove every entry of `dir` whose name is not in `keep`.
function pruneExcept(dir, keep) {
  for (const name of readdirSync(dir)) {
    if (!keep.has(name)) inUseGuard(join(dir, name), () => rmSync(join(dir, name), { recursive: true, force: true }));
  }
}

function copyNodePtyRuntime() {
  // The package's `exports` map blocks `@lydell/node-pty/package.json`, so resolve the
  // entry file and take its folder. pnpm exposes it through links, hence realpath:
  // the platform packages sit next to the real folder in the virtual store.
  const main = realpathSync(dirname(createRequire(import.meta.url).resolve('@lydell/node-pty')));
  const scope = dirname(main);
  const out = 'dist/node_modules/@lydell';
  const totals = { files: 0, bytes: 0 };

  syncTree(main, `${out}/node-pty`, totals);
  for (const platform of NODE_PTY_PLATFORMS) {
    const src = join(scope, `node-pty-${platform}`);
    if (!existsSync(src)) {
      throw new Error(`@lydell/node-pty-${platform} is not installed — backend/pnpm-workspace.yaml supportedArchitectures must cover it (run be-install)`);
    }
    syncTree(realpathSync(src), `${out}/node-pty-${platform}`, totals);
  }
  // Nothing else belongs in dist/node_modules (an earlier build may have left more).
  pruneExcept('dist/node_modules', new Set(['@lydell']));
  pruneExcept(out, new Set(['node-pty', ...NODE_PTY_PLATFORMS.map((platform) => `node-pty-${platform}`)]));
  console.log(`[esbuild] node-pty runtime: ${totals.files} files, ${(totals.bytes / 1024 / 1024).toFixed(1)} MB in dist/node_modules/@lydell`);
}

copyNodePtyRuntime();

console.log('Backend bundled successfully');
