// ESLint for the backend: `bash ./scripts/build.sh be-lint` runs tsc, then this.
// typescript-eslint's recommended rules without type information, so a run
// stays fast and needs no tsconfig project setup.
import js from '@eslint/js';
import { defineConfig, globalIgnores } from 'eslint/config';
import globals from 'globals';
import tseslint from 'typescript-eslint';

export default defineConfig(
  // Build output and paths .gitignore keeps out of the repo, so a local run
  // lints what CI lints. native/ is the Rust helper.
  globalIgnores(['dist/', 'coverage/', 'native/', 'bin/', 'lib/']),
  js.configs.recommended,
  tseslint.configs.recommended,
  {
    linterOptions: { reportUnusedDisableDirectives: 'error' },
    languageOptions: { globals: globals.node },
    rules: {
      // Same rule as tsc's noUnusedLocals/noUnusedParameters: a leading
      // underscore marks a name that is unused on purpose.
      '@typescript-eslint/no-unused-vars': ['error', {
        args: 'all',
        argsIgnorePattern: '^_',
        caughtErrors: 'all',
        caughtErrorsIgnorePattern: '^_',
        destructuredArrayIgnorePattern: '^_',
        varsIgnorePattern: '^_',
        ignoreRestSiblings: true,
      }],
      // A `let` that a closure reads before its one assignment cannot be const.
      'prefer-const': ['error', { ignoreReadBeforeAssign: true }],
    },
  },
);
