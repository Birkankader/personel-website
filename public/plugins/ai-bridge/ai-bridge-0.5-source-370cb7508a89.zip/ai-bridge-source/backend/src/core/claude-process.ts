import type { ChildProcess } from 'child_process';
import type { ConnectionManager } from '../ws/connection-manager';
import type { Bridge } from '../bridge/bridge-interface';
import { Claude } from './claude';
import { diagnoseAuthError } from './features/auth-diagnosis';
import { watchReviewBase } from './features/reviewBaseWatch';
import { EditedFileTracker } from './features/editedFileTracker';
import { WorkflowProgressTracker } from './features/workflow-tracker';
import { isWslUncPath } from './wsl-path';
import { reportBackendError } from './features/telemetry';
import { restoreSchedulesForSession } from './features/scheduled-messages';
import { takeMessagesForFinishedTurn, clearMessagesForSession } from './features/afterTurn';
import { rememberPreview, resolveDiffPreview } from './features/diffPreview';
import { readMergedSettings } from './features/settings';
import { readMergedClaudeSettings } from './features/claude-settings';
import { reasoningLaunch } from './features/reasoning-effort';
import { readLastRecordedSend } from './features/lastRecordedSend';
import { findLiveCliForSession, killRegisteredCli, registerCliProcess, unregisterCliProcess } from './cli-registry';
import { settleControlResponse } from './control-response-waiter';
import { ErrorCode, MessageType } from '../shared';
import { runtimeTasks } from './features/runtime-tasks';
import { CliDiagnostics } from './cli-diagnostics';
import { CliJsonlReader } from './cli-jsonl-reader';
import { ContextBudget } from './features/context-budget';
import { ApiRecovery, type RecoveryPrompt } from './features/api-recovery';
import { commitAttribution, spawnWithCliLaunchSettings } from './features/cli-launch-settings';
import { resolveSessionHarness } from './features/harness-sessions';
import { harnessLaunch } from './harness-launch';
import { computerUseBridgeEnv, computerUseMcpArgs } from './features/computer-use-launch';
import { harnessCommandEnv } from './features/harness-locator';
import { isAcpHarness, type HarnessId } from '../shared';

const sessionRecovery = new WeakMap<object, { recovery: ApiRecovery; taskId?: string; requestedModel?: string }>();
const processContextEnv = new WeakMap<ChildProcess, string>();

function getSessionRecovery(connections: ConnectionManager, sessionId: string) {
  const session = connections.getSession(sessionId);
  return session ? sessionRecovery.get(session) : undefined;
}

/** A stop during backoff must release the retained queue slot immediately. */
export function cancelApiRecovery(connections: ConnectionManager, sessionId: string): void {
  const state = getSessionRecovery(connections, sessionId);
  if (!state) return;
  const waiting = state.recovery.waiting;
  state.recovery.cancel();
  if (waiting && state.taskId) {
    connections.setStreaming(sessionId, false);
    runtimeTasks(connections).limiter.release(sessionId, 'cancelled', state.taskId);
    connections.broadcastToSession(sessionId, MessageType.STREAM_END);
  }
}

// Tracks files Claude edits so the IDE can be told to reload them once the
// edit completes on disk. Shared across sessions — tool_use ids are unique.
const editedFileTracker = new EditedFileTracker();

// Tracks background dynamic workflows and streams live progress to the webview.
// Lazily created on the first stream event because it needs the (single,
// process-lifetime) ConnectionManager to broadcast from its polling timers.
let workflowTracker: WorkflowProgressTracker | null = null;
function getWorkflowTracker(connections: ConnectionManager): WorkflowProgressTracker {
  if (!workflowTracker) workflowTracker = WorkflowProgressTracker.create(connections);
  return workflowTracker;
}

/**
 * Settle a session's still-running background workflows as `stopped` and push a
 * final update to the webview.
 *
 * NOT called on interrupt any more (issue #330). An `interrupt` ends the turn
 * but leaves background tasks running — measured: the CLI answers the interrupt
 * and emits `result`, while the task sends no `task_notification` and keeps
 * going. Settling here painted live tasks as stopped, and a single Escape wiped
 * the Background tasks panel. A task still shown as "running" after Escape is
 * running.
 *
 * Has no caller at the moment. Process death is already handled by
 * `workflowTracker.stopSession` in the CLI `close` handler, which covers the
 * case this was written for; what is left here is settling workflows while the
 * process lives on, and nothing needs that today.
 */
export function stopWorkflowsForSession(sessionId: string): void {
  workflowTracker?.stopRunning(sessionId);
}

/**
 * Whether a workflow is still actually running in this process. Lets transcript
 * reconstruction (on session load) keep a genuinely-running workflow as
 * `running` while settling interrupted ones to `stopped` instead of resurrecting
 * them as `running`.
 */
export function isWorkflowRunning(sessionId: string, toolUseId: string): boolean {
  return workflowTracker?.isRunning(sessionId, toolUseId) ?? false;
}

// InputMode -> CLI --permission-mode flag mapping
const INPUT_MODE_TO_CLI_FLAG: Record<string, string> = {
  plan: 'plan',
  bypass: 'bypassPermissions',
  ask_before_edit: 'default',
  auto_edit: 'acceptEdits',
  auto: 'auto',
};

// Reverse of the above: the CLI reports its permission mode using its own flag
// names, and we store modes in the webview's vocabulary. Derived from the forward
// map so the two can never drift apart. Exported: both the live stream (system
// events) and the on-disk JSONL (user entries) carry the mode as this same flag
// vocabulary in a `permissionMode` field, so the translation is shared while each
// caller decides which entry's field to read (see readReportedMode and
// findLastReportedModeInPage in loadSessionMessages.ts).
export const CLI_FLAG_TO_INPUT_MODE: Record<string, string> = Object.fromEntries(
  Object.entries(INPUT_MODE_TO_CLI_FLAG).map(([inputMode, flag]) => [flag, inputMode]),
);

/**
 * The permission mode a CLI stream event reports, translated into our InputMode
 * vocabulary — or null if this event does not report one.
 *
 * The CLI announces its mode on `system/init` (at spawn) and again on
 * `system/status` when it changes the mode itself, which is how an approved
 * ExitPlanMode plan leaving plan mode becomes observable without inspecting the
 * tool call. Exported for tests.
 */
export function readReportedMode(event: Record<string, unknown>): string | null {
  if (event.type !== 'system') return null;
  const flag = event.permissionMode;
  if (typeof flag !== 'string') return null;
  return CLI_FLAG_TO_INPUT_MODE[flag] ?? null;
}

/**
 * Build the argv for spawning the Claude CLI in interactive print mode.
 * Extracted as a pure function so the flag composition (session flag,
 * permission mode, pinned model) is unit-testable without spawning a process.
 */
export function buildClaudeArgs(
  sessionFlag: string,
  targetSessionId: string,
  inputMode: string | undefined,
  model?: string,
): string[] {
  const args: string[] = [
    '-p',
    '--output-format',
    'stream-json',
    '--input-format',
    'stream-json',
    '--verbose',
    '--include-partial-messages',
    '--replay-user-messages',
    '--permission-prompt-tool',
    'stdio',
  ];

  args.push(sessionFlag, targetSessionId);

  // No requested mode means nothing has established one for this session yet, so
  // the CLI is left to read its own `permissions.defaultMode`. Passing a flag here
  // would override that setting rather than defer to it — `--permission-mode
  // default` names the ask-before-edits mode, it does not mean "follow settings".
  const cliFlag = inputMode ? INPUT_MODE_TO_CLI_FLAG[inputMode] : undefined;
  if (cliFlag) {
    args.push('--permission-mode', cliFlag);
  }

  // Pin the user-selected model so the spawn honors it even when the previous
  // process has exited — set_model only reaches a live process, so without this
  // a model picked while idle would be lost and the CLI would fall back to its
  // default. 'default' is that very fallback, so passing it is redundant; omit
  // it to avoid handing the CLI a no-op alias.
  if (model && model !== 'default') {
    args.push('--model', model);
  }

  return args;
}

/**
 * The env that decides whether the CLI snapshots a file before editing it, which
 * is what a code rewind restores from (issue #356).
 *
 * The CLI gates this on the mode it is running in. Its interactive REPL reads the
 * `fileCheckpointingEnabled` setting, which defaults to true, so someone typing
 * `claude` in a terminal can rewind without configuring anything. A headless
 * caller like us reaches a different branch, where the same feature is off unless
 * CLAUDE_CODE_ENABLE_SDK_FILE_CHECKPOINTING says otherwise. Measured: without the
 * variable no backup file is written and no `file-history-snapshot` entry appears
 * in the transcript, and `--rewind-files` then exits with "File rewinding is not
 * enabled."
 *
 * So spawning without it is us taking away something the CLI gives a terminal
 * user, and passing it restores the parity rather than adding a feature of ours.
 * The official Agent SDK injects the same variable at the same point.
 *
 * The user's answer is the official setting, not one of ours, so that turning
 * checkpointing off in a terminal turns it off here too. Absent means Claude's
 * default, which is on.
 *
 * CLAUDE_CODE_DISABLE_FILE_CHECKPOINTING is deliberately not handled here: the
 * CLI honours it on this branch as well, so a user who exports it gets the same
 * answer from the CLI itself.
 */
export function buildCheckpointingEnv(
  settings: Record<string, unknown>,
): { CLAUDE_CODE_ENABLE_SDK_FILE_CHECKPOINTING?: string } {
  if (settings.fileCheckpointingEnabled === false) return {};
  return { CLAUDE_CODE_ENABLE_SDK_FILE_CHECKPOINTING: 'true' };
}

// Tracks whether a result event arrived (decides error propagation on an abnormal exit)
const sessionsWithResult = new Set<string>();

/**
 * Main-chain tool calls the CLI has started and not yet answered, per session.
 * The CLI hands a steering message to the model when the next step begins: as
 * a tool returns. While a tool runs that is soon and the tool must not be
 * killed; while none runs the model is thinking or writing, and the message
 * would wait for that whole response. Send now then interrupts the response.
 */
const openToolUses = new Map<string, Set<string>>();

/** Follows tool_use / tool_result pairs on the main chain; a turn's result closes them all. */
export function trackToolUses(sessionId: string, event: Record<string, unknown>): void {
  if (event.parent_tool_use_id || event.parentToolUseID) return;
  if (event.type === 'result') {
    openToolUses.delete(sessionId);
    return;
  }
  if (event.isReplay === true || (event.type !== 'assistant' && event.type !== 'user')) return;
  const content = (event.message as { content?: unknown } | undefined)?.content;
  if (!Array.isArray(content)) return;
  for (const block of content as Array<Record<string, unknown>>) {
    if (event.type === 'assistant' && block?.type === 'tool_use' && typeof block.id === 'string') {
      let open = openToolUses.get(sessionId);
      if (!open) openToolUses.set(sessionId, open = new Set());
      open.add(block.id);
    } else if (event.type === 'user' && block?.type === 'tool_result' && typeof block.tool_use_id === 'string') {
      openToolUses.get(sessionId)?.delete(block.tool_use_id);
    }
  }
}

export function hasOpenToolUse(sessionId: string): boolean {
  return !!openToolUses.get(sessionId)?.size;
}

// Sessions whose CLI we are killing on purpose so the next message respawns it.
// The exit is ours, not a failure, so the close handler must not surface it as an
// error or as STREAM_END. Used for spawn-time setting changes and account changes.
const sessionsRestarting = new Set<string>();
// Process identity avoids transferring an old launch preference to a successor.
const processReasoning = new WeakMap<ChildProcess, string>();
// The runtime each live process runs (absent = the Claude CLI). A session whose
// runtime no longer matches — the harness setting changed before its first
// message — needs a new process, whatever else stayed the same.
const processHarness = new WeakMap<ChildProcess, HarnessId>();
// Launch-time extras that are ours rather than Claude's (the computer-use MCP
// server), fingerprinted like reasoning so a change applies on the next message.
const processExtras = new WeakMap<ChildProcess, string>();

// How long to wait for a CLI to exit on SIGTERM during a deliberate restart before
// escalating to SIGKILL. The user is waiting on their message, so this stays short.
const SESSION_RESTART_KILL_TIMEOUT_MS = 3000;

// Sessions spawned at least once (decides whether a restart uses --resume)
// --session-id: new sessions only (an existing JSONL fails with "already in use")
// --resume: continues an existing session (needs its JSONL)
const spawnedSessions = new Set<string>();

/**
 * Marks a session as spawned from outside (the next spawn uses --resume).
 * Used by reclaimSession and similar.
 */
export function markSessionAsSpawned(sessionId: string): void {
  spawnedSessions.add(sessionId);
}

/**
 * Whether a live CLI running under `liveMode` can serve a message requesting
 * `requestedMode`, or has to be restarted first.
 *
 * `--permission-mode` is a spawn-time flag and no official CLI command changes it
 * in place, so honoring a mid-chat mode change means respawning (#172). Extracted
 * as a pure function so this decision is unit-testable without spawning anything.
 *
 * Every message carries the mode the UI is currently showing, so this compares it
 * against what the CLI is actually running under. `liveMode` tracks the CLI, not
 * merely the flag we spawned it with: the CLI reports its own mode on `system/init`
 * and again on `system/status` whenever it changes it itself (approving an
 * ExitPlanMode plan leaves plan mode with no respawn), and the stream handler keeps
 * the record in step. Comparing against a spawn-time-only record would read that
 * self-initiated exit as "no change" and reuse a CLI that is no longer in plan.
 *
 * A null `liveMode` means we have a process but never recorded a mode for it (e.g. a
 * session reclaimed after a backend restart). Restarting is the safe reading: reusing
 * would gamble on an unknown mode and risk edits running under looser permissions
 * than the user chose.
 */
export function needsRestartForMode(
  liveMode: string | null,
  requestedMode: string | undefined,
): boolean {
  // No requested mode is not a mode to compare against — it means the sender has
  // no mode to ask for, so whatever the live CLI is already running under stands.
  // Restarting here would tear down a working process to spawn an identical one.
  if (!requestedMode) return false;
  return liveMode !== requestedMode;
}

/**
 * Terminate a session's live CLI so the next message respawns it with current
 * spawn-time settings and credentials, and wait until it is really gone.
 *
 * Waiting matters: the respawn uses `--resume` on the same session, and two CLIs
 * writing one JSONL branches the history. The CLI's own 'close' handler does the
 * teardown (process reference, registry entry), so this only has to kill and wait
 * for that to run. The timeout is a liveness guard — a CLI ignoring SIGTERM gets
 * SIGKILL rather than hanging the user's message forever.
 */
export async function restartClaudeSessionProcess(
  connections: ConnectionManager,
  sessionId: string,
  proc: ChildProcess,
): Promise<void> {
  sessionsRestarting.add(sessionId);

  let didExit = proc.exitCode !== null || proc.signalCode !== null;
  const exited = new Promise<void>((resolve) => {
    if (didExit) {
      resolve();
      return;
    }
    proc.once('close', () => { didExit = true; resolve(); });
  });

  Claude.killTree(proc);

  let escalation: NodeJS.Timeout | undefined;
  const escalated = new Promise<void>((resolve) => {
    escalation = setTimeout(() => {
      console.error(
        '[node-backend]',
        `CLI for session ${sessionId} did not exit on SIGTERM; escalating to SIGKILL`,
      );
      Claude.killTree(proc, 'SIGKILL');
      resolve();
    }, SESSION_RESTART_KILL_TIMEOUT_MS);
  });

  await Promise.race([exited, escalated]);
  if (escalation) clearTimeout(escalation);
  // After a SIGKILL escalation the close handler may still be pending; give it the
  // same bounded wait so the respawn never races the teardown it depends on.
  let finalTimeout: NodeJS.Timeout | undefined;
  await Promise.race([exited, new Promise<void>((resolve) => {
    finalTimeout = setTimeout(resolve, SESSION_RESTART_KILL_TIMEOUT_MS);
  })]);
  if (finalTimeout) clearTimeout(finalTimeout);

  sessionsRestarting.delete(sessionId);
  if (!didExit) throw new Error('Claude did not stop; refusing to start a second process for this session.');

  // The close handler normally clears this. Do not reuse a dead reference.
  connections.setProcess(sessionId, null);
  // The turn-in-flight flag is normally cleared by the CLI `result` event, with
  // STREAM_END as the process-death safety net — and this restart deliberately
  // suppresses that STREAM_END. A previous turn that died without a `result`
  // would leave the flag stuck on forever, so clear it here explicitly. The
  // replacement process sets it again when the pending message reaches stdin.
  connections.setStreaming(sessionId, false);
}

/**
 * Spawns a claude -p process for the session if it has none.
 * Does nothing when a live process already exists, except that a
 * requested permission mode different from the live process's mode
 * restarts it in that mode (--permission-mode is a spawn-time flag).
 */
const pendingProcessStarts = new WeakMap<ConnectionManager, Map<string, Promise<void>>>();
const closedProcesses = new WeakSet<ChildProcess>();

/** Process-start preferences that do not affect the CLI itself. */
export interface EnsureProcessOptions {
  /**
   * Started ahead of a send (see {@link prewarmClaudeProcess}): failures are
   * logged, never shown, because the user has not asked for anything yet. The
   * send that follows retries the start and reports what goes wrong then.
   */
  quiet?: boolean;
}

/**
 * Prewarmed CLIs that have not received a message yet, with the timer that
 * closes them if none arrives. Their exit is not a failure the user caused, so
 * it is not reported; and a session that never received a message has no
 * transcript, so it must not be resumed (see {@link spawnedSessions}).
 */
const idlePrewarmed = new WeakMap<ChildProcess, ReturnType<typeof setTimeout>>();

/** How long a prewarmed CLI may wait for its first message before it is closed. */
export const PREWARM_IDLE_TIMEOUT_MS = 10 * 60_000;

function waitForProcessClose(proc: ChildProcess): Promise<void> {
  if (closedProcesses.has(proc)) return Promise.resolve();
  return new Promise((resolve, reject) => {
    const onClose = () => { clearTimeout(timer); resolve(); };
    const timer = setTimeout(() => {
      proc.off('close', onClose);
      reject(new Error('The previous Claude process has exited but its output is still closing. Please retry after it closes.'));
    }, 5000);
    proc.once('close', onClose);
  });
}

export async function ensureClaudeProcess(
  connections: ConnectionManager,
  connectionId: string,
  workingDir: string,
  targetSessionId: string,
  inputMode: string | undefined,
  bridge: Bridge,
  model?: string,
  applyReasoningChange = false,
  options: EnsureProcessOptions = {},
): Promise<void> {
  let pendingForManager = pendingProcessStarts.get(connections);
  if (!pendingForManager) {
    pendingForManager = new Map();
    pendingProcessStarts.set(connections, pendingForManager);
  }
  const pending = pendingForManager.get(targetSessionId);
  if (pending) {
    await pending;
    // Recheck the caller's preferences against the now-ready process. Merely
    // sharing the promise would silently discard a different mode or effort.
    return ensureClaudeProcess(connections, connectionId, workingDir, targetSessionId,
      inputMode, bridge, model, applyReasoningChange, options);
  }
  const start = ensureClaudeProcessInternal(connections, connectionId, workingDir,
    targetSessionId, inputMode, bridge, model, applyReasoningChange, options);
  pendingForManager.set(targetSessionId, start);
  try {
    await start;
  } finally {
    if (pendingForManager.get(targetSessionId) === start) pendingForManager.delete(targetSessionId);
  }
}

async function ensureClaudeProcessInternal(
  connections: ConnectionManager,
  connectionId: string,
  workingDir: string,
  targetSessionId: string,
  inputMode: string | undefined,
  bridge: Bridge,
  model?: string,
  applyReasoningChange = false,
  options: EnsureProcessOptions = {},
): Promise<void> {
  // Standalone mode on Windows can't reach a WSL project's tooling: cmd.exe rejects
  // the UNC cwd and the CLI would use PowerShell instead of bash. Guide the user to
  // launch the GUI from inside their WSL shell. (JetBrains mode runs the backend
  // inside the distro, so platform is 'linux' there and this never trips.) Issue #57.
  if (process.platform === 'win32' && isWslUncPath(workingDir)) {
    const msg =
      'This project is inside WSL. On Windows, start the GUI from your WSL shell ' +
      '(run `ccg` in a WSL terminal) so Claude runs with bash and a Linux working ' +
      'directory instead of failing on the Windows UNC path.';
    console.error('[node-backend]', msg);
    if (options.quiet) return;
    connections.broadcastToSession(targetSessionId, MessageType.SERVICE_ERROR, {
      type: MessageType.WSL_HOST_MISMATCH,
      reason: msg,
      error: msg,
    });
    connections.broadcastToSession(targetSessionId, MessageType.STREAM_END);
    return;
  }

  // Resolve against this project's provider directory before reading either
  // preference. Saving never restarts a process; only actual message admission
  // opts into applying a changed launch preference to an existing session.
  await Claude.applyConfigDir(workingDir);
  const { settings: appSettings } = await readMergedSettings(workingDir);
  const { settings: claudeSettings } = await readMergedClaudeSettings(workingDir);
  const reasoning = reasoningLaunch(appSettings.reasoningEffort, claudeSettings, process.env);
  const harness = await resolveSessionHarness(workingDir, targetSessionId, appSettings.harness);
  const computerUse = appSettings.computerUse === true;
  const extrasFingerprint = JSON.stringify([computerUse]);

  const recoverySession = connections.getOrCreateSession(targetSessionId, workingDir);
  let recoveryState = sessionRecovery.get(recoverySession);
  const configuredBudget = new ContextBudget(claudeSettings, process.env, model);
  if (!recoveryState) {
    const budget = configuredBudget;
    await budget.load(targetSessionId, workingDir);
    const state = { recovery: null as unknown as ApiRecovery, taskId: undefined as string | undefined, requestedModel: model };
    const valid = () => !connections.isShuttingDown() && connections.getSession(targetSessionId) === recoverySession &&
      !!state.taskId && !!runtimeTasks(connections).limiter.get(state.taskId) &&
      runtimeTasks(connections).limiter.get(state.taskId)?.state !== 'stopping';
    state.recovery = new ApiRecovery(budget, {
      valid,
      status: (status) => connections.broadcastToSession(targetSessionId, MessageType.API_RECOVERY_STATUS, { ...status }),
      failed: (error, kind) => {
        connections.broadcastToSession(targetSessionId, MessageType.SERVICE_ERROR,
          kind ? { error, errorCode: ErrorCode.API_RECOVERY_STOPPED, kind } : { error });
        connections.setStreaming(targetSessionId, false);
        if (state.taskId) runtimeTasks(connections).limiter.release(targetSessionId, 'failed', state.taskId);
      },
      send: async (prompt) => {
        if (!valid()) return;
        const sendingTaskId = state.taskId;
        await ensureClaudeProcess(connections, connectionId, workingDir, targetSessionId,
          connections.getInputMode(targetSessionId) ?? inputMode, bridge, undefined, true);
        if (!valid() || state.taskId !== sendingTaskId) {
          if (sendingTaskId) runtimeTasks(connections).limiter.release(targetSessionId, 'cancelled', sendingTaskId);
          return;
        }
        if (prompt.echo !== false) {
          connections.broadcastToSession(targetSessionId, MessageType.USER_MESSAGE_BROADCAST, {
            sessionId: targetSessionId, content: prompt.content,
          });
        }
        if (!(await sendMessageToProcess(connections, targetSessionId, prompt.content, prompt.attachments, true))) {
          throw new Error('Claude could not accept the automatic recovery message.');
        }
        if (valid() && state.taskId === sendingTaskId) connections.broadcastToSession(targetSessionId, MessageType.STREAM_START);
      },
    });
    recoveryState = state;
    sessionRecovery.set(recoverySession, state);
    recoverySession.cancelRecovery = () => cancelApiRecovery(connections, targetSessionId);
  } else if (configuredBudget.configurationKey !== recoveryState.recovery.budget.configurationKey) {
    // A gateway/config-dir change must never reuse another provider's limits.
    await configuredBudget.load(targetSessionId, workingDir);
    recoveryState.recovery.budget = configuredBudget;
  }
  if (model !== undefined && model !== recoveryState.requestedModel) {
    recoveryState.recovery.budget.setModel(model === 'default' ? configuredBudget.model : model);
    recoveryState.requestedModel = model;
  }
  const contextEnv = recoveryState.recovery.budget.launchEnv();
  const contextFingerprint = JSON.stringify(contextEnv);

  let existingSession = connections.getSession(targetSessionId);
  const previous = existingSession?.process;
  if (previous && (previous.exitCode != null || previous.signalCode != null)) {
    // exit can precede close while Windows descendants still hold output pipes.
    // Never send into that dead stdin, or mix its final output with a new CLI.
    await waitForProcessClose(previous);
    existingSession = connections.getSession(targetSessionId);
  } else if (previous && (!previous.stdin?.writable || previous.stdin.destroyed || previous.stdin.writableEnded)) {
    await restartClaudeSessionProcess(connections, targetSessionId, previous);
    existingSession = connections.getSession(targetSessionId);
  }
  if (existingSession?.process) {
    // `--permission-mode` is a spawn-time flag: a live CLI keeps whatever mode it
    // started with, and no official CLI command changes it in place. So when the user
    // picks a different mode mid-chat, honoring it means restarting the process under
    // the new flag — otherwise the choice is silently dropped and the CLI's next
    // `system/init` pushes the old mode back onto the webview, which looks like the
    // mode flipping itself off (#172). Same mode → reuse as before.
    const liveMode = connections.getInputMode(targetSessionId);
    const reasoningChanged = applyReasoningChange &&
      processReasoning.get(existingSession.process) !== reasoning.fingerprint;
    const contextChanged = applyReasoningChange && processContextEnv.get(existingSession.process) !== contextFingerprint;
    const harnessChanged = (processHarness.get(existingSession.process) ?? 'claude') !== harness;
    const extrasChanged = applyReasoningChange && (processExtras.get(existingSession.process) ?? '[false]') !== extrasFingerprint;
    if (!needsRestartForMode(liveMode, inputMode) && !reasoningChanged && !contextChanged && !harnessChanged && !extrasChanged) {
      console.error(
        '[node-backend]',
        `Reusing existing process for session ${targetSessionId} (PID: ${existingSession.process.pid})`,
      );
      return;
    }

    console.error(
      '[node-backend]',
      `Launch preferences changed for session ${targetSessionId} ` +
        `(permission mode ${liveMode} -> ${inputMode}, reasoning changed: ${reasoningChanged}, ` +
        `runtime changed: ${harnessChanged}); ` +
        `restarting CLI (PID: ${existingSession.process.pid})`,
    );
    await restartClaudeSessionProcess(connections, targetSessionId, existingSession.process);
  }

  // Liveness guard before spawning: a live, identity-checked CLI may
  // already be writing this session's JSONL — an orphan left by a hard-killed
  // backend, or a session legitimately open under another live backend. Spawning
  // a second CLI would mean two writers on one JSONL (branched history,
  // false task verdicts, interleaved GUI) — so kill the orphan / refuse the takeover.
  const conflict = findLiveCliForSession(targetSessionId);
  if (conflict) {
    if (conflict.ownerAlive) {
      const reason =
        `Session ${targetSessionId} is already active under another backend ` +
        `(CLI PID ${conflict.entry.pid}, backend PID ${conflict.entry.owner.pid}). ` +
        'Refusing to start a second writer on the same session.';
      console.error('[node-backend]', reason);
      if (options.quiet) return;
      connections.broadcastToSession(targetSessionId, MessageType.SERVICE_ERROR, {
        type: MessageType.SPAWN_ERROR,
        reason,
        error: reason,
      });
      connections.broadcastToSession(targetSessionId, MessageType.STREAM_END);
      return;
    }
    console.error(
      '[node-backend]',
      `Killing orphaned CLI ${conflict.entry.pid} before respawning session ${targetSessionId}`,
    );
    await killRegisteredCli(conflict.entry);
    // The orphan proves this session already ran — resume it instead of passing
    // --session-id, which would fail with "already in use".
    spawnedSessions.add(targetSessionId);
  }

  if (connections.isShuttingDown()) throw new Error('The backend is shutting down.');

  const useResume = spawnedSessions.has(targetSessionId);
  const sessionFlag = useResume ? '--resume' : '--session-id';


  console.error('[node-backend]', `Starting Claude CLI process (-p interactive)...`);
  console.error('[node-backend]', `Working directory: ${workingDir}`);
  console.error('[node-backend]', `Session: ${targetSessionId} (${sessionFlag})`);

  const resolvedModel = model ?? (recoveryState.recovery.budget.model === 'default' ? undefined : recoveryState.recovery.budget.model);
  // spawnAuthed strips inherited OAuth tokens (e.g. from Claude Desktop spawning the IDE) so
  // the CLI falls through to its refreshable keychain auth. Centralized in Claude so chat and
  // `auth status` strip identically; user-pinned / ANTHROPIC_API_KEY env is preserved there.
  const proc = await spawnWithCliLaunchSettings({ env: contextEnv, ...commitAttribution(claudeSettings) }, async (launchSettings) => {
    const args = [...buildClaudeArgs(sessionFlag, targetSessionId, inputMode, resolvedModel),
      ...launchSettings.args, ...reasoning.args];
    if (isAcpHarness(harness)) {
      // A third-party harness runs behind the ACP bridge, which takes the CLI's
      // own flags and speaks its stream-json, so everything below stays as is.
      const launch = harnessLaunch(harness, args);
      console.error('[node-backend]', `Command (${harness}): ${launch.command} ${launch.args.join(' ')}`);
      return Claude.spawnAuthedWith(launch.command, launch.args, workingDir, {
        cwd: workingDir,
        stdio: ['pipe', 'pipe', 'pipe'],
        detached: process.platform !== 'win32',
        env: {
          ...launchSettings.env,
          ...launch.env,
          // The harness program found for this project (setting, AI Bridge's copy, PATH).
          ...await harnessCommandEnv(harness, workingDir),
          ...(computerUse ? computerUseBridgeEnv() : {}),
        },
      }, targetSessionId);
    }
    if (computerUse) args.push(...await computerUseMcpArgs());
    console.error('[node-backend]', `Command: ${Claude.command} ${args.join(' ')}`);
    return Claude.spawnAuthed(args, workingDir, {
      cwd: workingDir,
      stdio: ['pipe', 'pipe', 'pipe'],
      // POSIX: detach the CLI into its own process group so every kill path can take
      // down the WHOLE tree at once (Claude.killTree signals -pid: the CLI plus its
      // subagent shells and background tasks). Trade-off: a detached CLI no longer
      // shares the terminal's process group, so it stops receiving the terminal's
      // SIGHUP alongside the backend — server.ts compensates with its own SIGHUP
      // handler (graceful shutdownAll). Keep those two in sync.
      detached: process.platform !== 'win32',
      env: {
        TERM: 'dumb',
        CI: 'true',
        CLAUDECODE: undefined,
        ...buildCheckpointingEnv(claudeSettings),
        ...reasoning.env,
        ...contextEnv,
        ...launchSettings.env,
      },
      // win32: route this long-lived chat CLI through a Job Object wrapper so its
      // whole tree (incl. MSYS/git-bash workers that escape taskkill /F /T) dies with
      // the backend. POSIX uses the detached process-group above instead.
    }, targetSessionId);
  });

  connections.trackSessionProcess(proc);
  const diagnostics = new CliDiagnostics();

  // Wait for the spawn to finish (so sendMessageToProcess can safely write to stdin)
  await new Promise<void>((resolve, reject) => {
    proc.on('spawn', () => {
      console.error('[node-backend]', `Claude CLI spawned with PID: ${proc.pid}`);
      resolve();
    });
    proc.on('error', (err) => {
      console.error('[node-backend]', 'Failed to start Claude CLI:', err);
      // No trackError here: this rejects the awaited spawn promise, so it propagates
      // up through ensureClaudeProcess → sendMessageHandler → the ws-server handler
      // boundary, which reports it once via reportBackendError. Reporting here too
      // would double-count.
      if (!options.quiet) {
        connections.broadcastToSession(targetSessionId, MessageType.SERVICE_ERROR, {
          type: MessageType.SPAWN_ERROR,
          reason: err.message,
          error: err.message,
        });
        connections.broadcastToSession(targetSessionId, MessageType.STREAM_END);
      }

      const session = connections.getSession(targetSessionId);
      if (session?.process === proc) {
        connections.setProcess(targetSessionId, null);
      }
      reject(err);
    });
  });

  if (connections.isShuttingDown()) throw new Error('The backend is shutting down.');

  // No `spawnedSessions.add` here: the CLI writes a new session's transcript only
  // when its first message arrives, so `--resume` works only after one was
  // written (sendMessageToProcess). Measured: a `--session-id` CLI closed without
  // a message leaves no file, and `--resume` on that id exits with "No
  // conversation found". A respawn before the first message claims the id again.
  if (options.quiet) {
    const reaper = setTimeout(() => {
      if (idlePrewarmed.has(proc) && connections.getSession(targetSessionId)?.process === proc) {
        console.error('[node-backend]', `Closing prewarmed CLI for ${targetSessionId}: no message arrived`);
        Claude.killTree(proc);
      }
    }, PREWARM_IDLE_TIMEOUT_MS);
    reaper.unref?.();
    idlePrewarmed.set(proc, reaper);
  }

  // Store the process on the SessionRecord
  connections.setProcess(targetSessionId, proc);
  processReasoning.set(proc, reasoning.fingerprint);
  processHarness.set(proc, harness);
  processExtras.set(proc, extrasFingerprint);
  processContextEnv.set(proc, contextFingerprint);
  // Remember the mode this process actually runs under, so a later mode change is
  // detected and honored by restarting instead of being silently dropped (#172).
  // Must follow setProcess — clearing the process also clears the recorded mode.
  // Spawning without a requested mode leaves this null: the CLI picked the mode
  // from its own settings, and it reports that choice on `system/init`, which is
  // what fills the record in.
  connections.setInputMode(targetSessionId, inputMode ?? null);
  const stdoutReader = new CliJsonlReader();

  // The session's process is now alive — this is where we re-arm any scheduled
  // messages ("send later" reservations) that outlived a backend restart. Timers
  // live in memory only, so a restart drops them; restoring here (the single
  // convergence point where a session's process spawns) rebuilds them so a due
  // reservation can deliver to this fresh process. Idempotent (already-armed
  // timers are skipped) and fire-and-forget so it never blocks the stream start.
  void restoreSchedulesForSession(targetSessionId, connections);

  // Record the live CLI in the on-disk registry: lets a FUTURE backend detect this
  // process as an orphan (startup sweep) or as a conflicting writer (resume guard)
  // if we die hard before the 'close' handler unregisters it.
  registerCliProcess(proc, targetSessionId, workingDir);

  // Tell every subscriber the stream started
  connections.broadcastToSession(targetSessionId, MessageType.STREAM_START);

  proc.stdout?.on('data', (data: Buffer) => {
    // claude CLI stdout streaming runs outside the handleMessage flow, so the ws-server
    // handler boundary can't catch a throw here. Route any unexpected failure to the
    // single backend error reporting point so this async path converges with the rest.
    try {
      for (const line of stdoutReader.write(data)) {
        if (!line.trim()) continue;

        try {
          const event = JSON.parse(line) as Record<string, unknown>;
          handleStreamEvent(targetSessionId, event, connections, bridge, workingDir, proc.pid);
        } catch {
          // Non-JSON line is expected noise (not an error) in stream-json mode — only log.
          const preview = diagnostics.preview(line);
          if (preview) console.error('[node-backend]', `Non-JSON CLI output: ${preview}`);
        }
      }
    } catch (err) {
      reportBackendError(err instanceof Error ? err : new Error(String(err)), {
        layer: 'claude_stream',
        phase: 'stdout',
      });
    }
  });

  proc.stderr?.on('data', (data: Buffer) => {
    const text = data.toString();
    const preview = diagnostics.stderrChunk(text);
    if (preview) console.error('[node-backend]', `Claude CLI stderr: ${preview}`);
  });
  // A Writable emits error separately even when its write callback received it.
  // The pending send reports failure; this listener prevents an uncaught EPIPE.
  proc.stdin?.on('error', (error) => {
    const preview = diagnostics.preview(error.message);
    if (preview) console.error('[node-backend]', `Claude CLI stdin error: ${preview}`);
  });

  proc.on('close', (code) => {
    closedProcesses.add(proc);
    const idleReaper = idlePrewarmed.get(proc);
    if (idleReaper !== undefined) {
      clearTimeout(idleReaper);
      idlePrewarmed.delete(proc);
    }
    // Capture process-bound work even if last-subscriber cleanup already
    // removed the session. Its slot must not linger forever in "stopping".
    const closingTaskId = runtimeTasks(connections).limiter.taskForProcess(targetSessionId, proc.pid);
    if (connections.getSession(targetSessionId)?.process !== proc) {
      unregisterCliProcess(proc.pid);
      if (closingTaskId) runtimeTasks(connections).limiter.release(targetSessionId, 'failed', closingTaskId);
      if (!connections.getSession(targetSessionId)) {
        clearMessagesForSession(targetSessionId);
        sessionsWithResult.delete(targetSessionId);
        openToolUses.delete(targetSessionId);
        workflowTracker?.stopSession(targetSessionId);
      }
      return;
    }
    // Its final buffered result can release this task and admit the next one.

    // Like the stdout handler, this close callback fires outside the handleMessage flow;
    // converge any unexpected throw at the single backend error reporting point.
    try {
      console.error('[node-backend]', `Claude CLI process exited with code: ${code}`);

      // Nothing held for this session will ever be delivered now — there is no
      // turn left to end. Dropped rather than kept, so it cannot surface in
      // whatever session reuses the id.
      clearMessagesForSession(targetSessionId);

      // We killed this process ourselves so the next message can respawn it with new
      // spawn-time settings or credentials. Skip failure reporting and STREAM_END,
      // which would otherwise flash an error between the old and replacement CLIs.
      // A prewarmed CLI that never received a message has no turn to fail or end
      // either; the next send starts a new one and reports what goes wrong.
      const restarting = sessionsRestarting.has(targetSessionId) || idleReaper !== undefined;

      // Flush the remaining buffer
      for (const remainingBuffer of stdoutReader.end()) {
        if (!remainingBuffer.trim()) continue;
        try {
          const event = JSON.parse(remainingBuffer) as Record<string, unknown>;
          handleStreamEvent(targetSessionId, event, connections, bridge, workingDir, proc.pid);
        } catch {
          const preview = diagnostics.preview(remainingBuffer);
          if (preview) console.error('[node-backend]', `Remaining buffer (non-JSON): ${preview}`);
        }
      }

      // Detect the "already in use" error -> add to spawnedSessions (the next attempt uses --resume)
      // This happens when a cold-started backend reaches an existing session
      if (code !== 0 && diagnostics.sessionAlreadyInUse) {
        spawnedSessions.add(targetSessionId);
      }

      // Abnormal exit without a result -> propagate the error
      let recovering = getSessionRecovery(connections, targetSessionId)?.recovery.waiting ?? false;
      if (code !== 0 && !sessionsWithResult.has(targetSessionId) && !restarting) {
        const errorMessage = diagnostics.stderr.trim() || `Claude CLI exited with code ${code}`;
        const recovery = getSessionRecovery(connections, targetSessionId)?.recovery;
        recovery?.observe({ type: 'error', error: errorMessage });
        recovering = recovery?.result({ type: 'result', is_error: true }) ?? false;
        // While a retry is scheduled the recovery status tells the user what
        // happened and what comes next; an error banner would claim the turn
        // failed. If the retries run out, recovery reports that failure itself.
        if (!recovering) {
          connections.broadcastToSession(targetSessionId, MessageType.SERVICE_ERROR, {
            type: MessageType.CLI_EXIT_ERROR,
            reason: errorMessage,
            error: errorMessage,
            exitCode: code,
          });
        }
        // Diagnose authentication errors
        diagnoseAuthError(targetSessionId, errorMessage, connections).catch(() => {});
      }

      // Clean up tracking
      sessionsWithResult.delete(targetSessionId);
      openToolUses.delete(targetSessionId);

      // On a deliberate restart the session continues in the replacement process, so
      // neither of these applies: tearing down the workflow tracker would drop progress
      // the new CLI still reports on, and STREAM_END would end a stream the user never
      // stopped. The respawn emits its own STREAM_START.
      if (!restarting) {
        workflowTracker?.stopSession(targetSessionId);
        connections.broadcastToSession(targetSessionId, MessageType.STREAM_END);
      }

      // Release only the process reference (keep the session record: subscribers may remain)
      connections.setProcess(targetSessionId, null);
      // Clean CLI exit — drop its registry entry (hard backend deaths skip this;
      // that is exactly what the startup orphan sweep is for).
      unregisterCliProcess(proc.pid);
      if (!restarting && !recovering && closingTaskId) runtimeTasks(connections).limiter.release(targetSessionId, 'failed', closingTaskId);
    } catch (err) {
      reportBackendError(err instanceof Error ? err : new Error(String(err)), {
        layer: 'claude_stream',
        phase: 'close',
      });
    }
  });
}

/**
 * Start a session's CLI while the user is still typing, so the send that
 * follows writes to a process that has already booted.
 *
 * Starting a CLI is the slowest local step of a first send: the process boots,
 * runs the SessionStart hooks and, on Windows, goes through the PowerShell job
 * wrapper first. Measured on macOS with the CLI this release was built against:
 * ~350 ms from spawn to the first answer of a cold CLI, ~20 ms for a warm one.
 *
 * Best effort by design. It does nothing when a process is alive or starting,
 * or when a task for the session will start one anyway; it reports no errors;
 * the send path still starts the CLI itself if this did not. An idle prewarmed
 * CLI is closed after {@link PREWARM_IDLE_TIMEOUT_MS}. Returns whether it started one.
 */
export async function prewarmClaudeProcess(
  connections: ConnectionManager,
  connectionId: string,
  workingDir: string,
  sessionId: string,
  inputMode: string | undefined,
  bridge: Bridge,
  model?: string,
): Promise<boolean> {
  if (connections.isShuttingDown()) return false;
  const live = connections.getSession(sessionId)?.process;
  if (live && live.exitCode == null && live.signalCode == null) return false;
  if (pendingProcessStarts.get(connections)?.has(sessionId)) return false;
  const manager = runtimeTasks(connections);
  await manager.ready;
  if (manager.limiter.snapshot().tasks.some(task => task.sessionId === sessionId)) return false;
  // Keep the session record alive exactly as long as this view holds it, the
  // way a send does: a view that moves on releases the prewarmed CLI with it.
  connections.subscribe(connectionId, sessionId, workingDir);
  await ensureClaudeProcess(connections, connectionId, workingDir, sessionId, inputMode, bridge, model, false, { quiet: true });
  return connections.getSession(sessionId)?.process != null;
}

/**
 * Writes a JSON message to the existing process's stdin.
 * Returns false when there is no process or its stdin is not writable.
 */
export function validateSteeringMessage(connections: ConnectionManager, sessionId: string, content: string): void {
  const recovery = getSessionRecovery(connections, sessionId)?.recovery;
  if (content.trimStart().startsWith('/') || (recovery && !recovery.canSteer)) {
    throw new Error('Steering is unavailable during commands or API recovery. The message remains queued.');
  }
}

export async function sendMessageToProcess(
  connections: ConnectionManager,
  sessionId: string,
  content: string,
  attachments?: Array<
    | { type: 'image'; fileName: string; mimeType: string; base64: string }
    | { type: 'file'; fileName: string; absolutePath: string }
    | { type: 'folder'; folderName: string; absolutePath: string }
  >,
  internalRecovery = false,
  steeringMessageId?: string,
): Promise<boolean> {
  const session = connections.getSession(sessionId);
  const proc = session?.process;
  const stdin = proc?.stdin;
  if (!proc || !stdin?.writable || stdin.destroyed || stdin.writableEnded || proc.exitCode != null || proc.signalCode != null) {
    console.error('[node-backend]', `No writable stdin for session: ${sessionId}`);
    return false;
  }

  const recoveryState = getSessionRecovery(connections, sessionId);
  if (recoveryState && !internalRecovery && !steeringMessageId) {
    const limiter = runtimeTasks(connections).limiter;
    limiter.setProcess(sessionId, proc.pid);
    recoveryState.taskId = limiter.taskForProcess(sessionId, proc.pid);
    const prompt: RecoveryPrompt = recoveryState.recovery.begin({ content, attachments });
    if (prompt.content !== content) {
      connections.broadcastToSession(sessionId, MessageType.USER_MESSAGE_BROADCAST, { sessionId, content: prompt.content });
    }
    content = prompt.content;
    attachments = prompt.attachments;
  }
  sessionsWithResult.delete(sessionId);

  // Put file/folder paths in front of the prompt
  const fileRefs = attachments?.filter(a => a.type !== 'image') ?? [];
  let finalContent = content;
  if (fileRefs.length > 0) {
    const pathLines = fileRefs.map(r => (r as { absolutePath: string }).absolutePath).join('\n');
    finalContent = `${pathLines}\n\n${content}`;
  }

  // Only images become image blocks
  const imageAtts = attachments?.filter(a => a.type === 'image') ?? [];

  let messageContent: string | Array<Record<string, unknown>>;
  if (imageAtts.length > 0) {
    const blocks: Array<Record<string, unknown>> = [];
    if (finalContent) {
      blocks.push({ type: 'text', text: finalContent });
    }
    for (const att of imageAtts) {
      if (att.type === 'image') {
        blocks.push({
          type: 'image',
          source: { type: 'base64', media_type: att.mimeType, data: att.base64 },
        });
      }
    }
    messageContent = blocks;
  } else {
    messageContent = finalContent;
  }

  // Send now, while the model is thinking or writing: interrupt that response
  // first, in the same write. The CLI then goes on to the message waiting in
  // stdin; an interrupt that finds the turn already over changes nothing. The
  // other order could interrupt the turn this very message just started.
  const interruptFirst = steeringMessageId && !hasOpenToolUse(sessionId)
    ? JSON.stringify({ type: 'control_request', request_id: `steer-${steeringMessageId}`, request: { subtype: 'interrupt' } }) + '\n'
    : '';
  const stdinMessage =
    interruptFirst +
    JSON.stringify({
      type: 'user',
      ...(steeringMessageId ? { uuid: steeringMessageId } : {}),
      message: { role: 'user', content: messageContent },
    }) + '\n';

  // Truncate log to avoid flooding with base64 data
  const logPreview = stdinMessage.length > 200
    ? stdinMessage.substring(0, 200) + `... (${stdinMessage.length} bytes total)`
    : stdinMessage.trimEnd();
  console.error('[node-backend]', `Sending to stdin: ${logPreview}`);
  const limiter = runtimeTasks(connections).limiter;
  limiter.setProcess(sessionId, proc.pid);
  const sendingTaskId = limiter.taskForProcess(sessionId, proc.pid);
  await new Promise<void>((resolve, reject) => {
    let settled = false;
    const finish = (error?: Error | null) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      proc.off('close', onClose);
      stdin.off('error', onError);
      if (error) reject(error);
      else resolve();
    };
    const onClose = () => finish(new Error('Claude closed before accepting the message.'));
    const onError = (error: Error) => finish(error);
    const timer = setTimeout(() => {
      // Do not let a timed-out buffered prompt get written after its task failed.
      finish(new Error('Claude did not accept the message within 30 seconds.'));
      stdin.destroy();
    }, 30_000);
    proc.once('close', onClose);
    stdin.once('error', onError);
    try {
      // false is ordinary backpressure. The callback, not the return value,
      // tells us whether this write reached the pipe or failed asynchronously.
      stdin.write(stdinMessage, (error) => finish(error));
    } catch (error) {
      finish(error instanceof Error ? error : new Error(String(error)));
    }
  });
  // The CLI now has a message to record, so a later respawn resumes this session.
  spawnedSessions.add(sessionId);
  const idleReaper = idlePrewarmed.get(proc);
  if (idleReaper !== undefined) {
    clearTimeout(idleReaper);
    idlePrewarmed.delete(proc);
  }
  // Turn in flight — cleared on the CLI `result` event (turn end) or on
  // STREAM_END (process death safety net inside broadcastToSession).
  if (!sendingTaskId || limiter.taskForProcess(sessionId, proc.pid) === sendingTaskId) {
    connections.setStreaming(sessionId, true);
  }
  return true;
}

/**
 * Sends an interrupt control_request to the CLI.
 * Stops the current generation gracefully over stdin instead of SIGTERM.
 * On interrupt the CLI stops the current turn and goes on to the next message waiting in stdin.
 */
export function sendInterruptToProcess(
  connections: ConnectionManager,
  sessionId: string,
): boolean {
  cancelApiRecovery(connections, sessionId);
  const session = connections.getSession(sessionId);
  if (!session?.process?.stdin?.writable) {
    console.error('[node-backend]', `No writable stdin for session: ${sessionId}`);
    return false;
  }

  // An interrupt cannot withdraw input already buffered by the CLI. Explicit
  // Stop must also prevent that input starting another turn.
  if (runtimeTasks(connections).limiter.hasPendingSteering(sessionId)) {
    Claude.killTree(session.process);
    return true;
  }

  const requestId = Math.random().toString(36).substring(2, 15);
  const stdinMessage =
    JSON.stringify({
      type: 'control_request',
      request_id: requestId,
      request: { subtype: 'interrupt' },
    }) + '\n';

  console.error('[node-backend]', `Sending interrupt to stdin: ${stdinMessage.trimEnd()}`);
  session.process.stdin.write(stdinMessage);
  return true;
}

/**
 * Sends a tool_result to the CLI's stdin.
 * Unlike a plain user message, the content is an array of tool_result blocks.
 */
export function sendToolResultToProcess(
  connections: ConnectionManager,
  sessionId: string,
  toolResult: { type: string; tool_use_id: string; content: string; is_error: boolean },
): boolean {
  const session = connections.getSession(sessionId);
  if (!session?.process?.stdin?.writable) {
    console.error('[node-backend]', `No writable stdin for session: ${sessionId}`);
    return false;
  }

  const stdinMessage =
    JSON.stringify({
      type: 'user',
      message: { role: 'user', content: [toolResult] },
    }) + '\n';

  const logPreview = stdinMessage.length > 200
    ? stdinMessage.substring(0, 200) + `... (${stdinMessage.length} bytes total)`
    : stdinMessage.trimEnd();
  console.error('[node-backend]', `Sending tool_result to stdin: ${logPreview}`);
  session.process.stdin.write(stdinMessage);
  return true;
}

/**
 * Sends a set_model control_request to the CLI's stdin.
 * For session-level model changes (valid only for the process lifetime).
 */
export function sendSetModelToProcess(
  connections: ConnectionManager,
  sessionId: string,
  model: string,
): boolean {
  getSessionRecovery(connections, sessionId)?.recovery.budget.setModel(model);
  const session = connections.getSession(sessionId);
  if (!session?.process?.stdin?.writable) {
    console.error('[node-backend]', `No writable stdin for session: ${sessionId}`);
    return false;
  }

  const stdinMessage =
    JSON.stringify({
      type: 'control_request',
      request_id: `set_model_${Date.now()}`,
      request: { subtype: 'set_model', model },
    }) + '\n';

  console.error('[node-backend]', `Sending set_model "${model}" to stdin`);
  session.process.stdin.write(stdinMessage);
  return true;
}

/**
 * Ask a LIVE CLI to switch its permission mode right now.
 *
 * Why this exists: `--permission-mode` is a spawn-time flag, so a mode the user
 * picks WHILE Claude is working reached the CLI only on the next message, via
 * the respawn in [ensureClaudeProcess]. The reported case is exactly that gap —
 * a plan approved with "auto-accept" kept asking for every edit of the very turn
 * it was approved for, and re-picking the mode by hand changed the label on
 * screen and nothing else (#393).
 *
 * Measured against CLI 2.1.170 before this was written, with a control group in
 * the same run: the CLI asked for the first edit, took `set_permission_mode`
 * mid-turn with `{"subtype":"success"}`, announced the new mode on
 * `system/status`, and made the remaining two edits without asking again.
 *
 * `set_permission_mode` is an undocumented subtype, so this is a BEST-EFFORT
 * optimization and never the only path (CLAUDE.md principle 4). The official
 * fallback needs no extra code and cannot be forgotten:
 *
 * - accepted → the CLI announces the mode on `system/status`, [readReportedMode]
 *   adopts it, and the next message finds `liveMode` already equal, so no
 *   respawn happens.
 * - refused / no live process → `liveMode` stays as it was, so the next message
 *   goes through [needsRestartForMode] and respawns under the new flag exactly
 *   as before.
 *
 * Takes our InputMode vocabulary rather than the CLI's flag, so callers never
 * translate on their own and the mapping stays in the one place that spawns.
 */
export function sendSetPermissionModeToProcess(
  connections: ConnectionManager,
  sessionId: string,
  inputMode: string,
): boolean {
  const cliFlag = INPUT_MODE_TO_CLI_FLAG[inputMode];
  if (!cliFlag) {
    console.error('[node-backend]', `Unknown input mode "${inputMode}"; not sending to CLI`);
    return false;
  }

  const session = connections.getSession(sessionId);
  if (!session?.process?.stdin?.writable) {
    // Not an error: with no live CLI there is nothing to switch, and the mode
    // the webview holds will be passed as `--permission-mode` on the next spawn.
    console.error(
      '[node-backend]',
      `No live CLI for session ${sessionId}; "${inputMode}" applies at next spawn`,
    );
    return false;
  }

  const stdinMessage =
    JSON.stringify({
      type: 'control_request',
      request_id: `set_permission_mode_${Date.now()}`,
      request: { subtype: 'set_permission_mode', mode: cliFlag },
    }) + '\n';

  console.error('[node-backend]', `Sending set_permission_mode "${cliFlag}" to stdin`);
  session.process.stdin.write(stdinMessage);
  return true;
}

/**
 * Sends an arbitrary control_request to the CLI's stdin.
 *
 * The way to run slash commands the CLI refuses in a non-interactive
 * (stream-json) session (`/reload-plugins`, `/btw`). Sent as command text,
 * the CLI refuses with `isn't available in this environment`, but it
 * accepts the control_request that does the same work (#270).
 *
 * The caller picks request_id: the control_response is broadcast as a CLI
 * event as-is, so the WebView picks out the answer to its own request by
 * this id.
 */
export function sendControlRequestToProcess(
  connections: ConnectionManager,
  sessionId: string,
  requestId: string,
  request: Record<string, unknown>,
): boolean {
  const session = connections.getSession(sessionId);
  if (!session?.process?.stdin?.writable) {
    console.error('[node-backend]', `No writable stdin for session: ${sessionId}`);
    return false;
  }

  const stdinMessage =
    JSON.stringify({
      type: 'control_request',
      request_id: requestId,
      request,
    }) + '\n';

  console.error(
    '[node-backend]',
    `Sending control_request "${String(request.subtype)}" to stdin (request_id: ${requestId})`,
  );
  session.process.stdin.write(stdinMessage);
  return true;
}

/**
 * Sends a control_response to the CLI's stdin.
 * Answers control_requests such as AskUserQuestion.
 */
export function sendControlResponseToProcess(
  connections: ConnectionManager,
  sessionId: string,
  response: Record<string, unknown>,
): boolean {
  const session = connections.getSession(sessionId);
  if (!session?.process?.stdin?.writable) {
    console.error('[node-backend]', `No writable stdin for session: ${sessionId}`);
    return false;
  }

  const stdinMessage =
    JSON.stringify({
      type: 'control_response',
      response,
    }) + '\n';

  const logPreview = stdinMessage.length > 200
    ? stdinMessage.substring(0, 200) + `... (${stdinMessage.length} bytes total)`
    : stdinMessage.trimEnd();
  console.error('[node-backend]', `Sending control_response to stdin: ${logPreview}`);
  try {
    session.process.stdin.write(stdinMessage);
  } catch (error) {
    console.error('[node-backend]', 'Failed to write permission response:', error);
    return false;
  }
  if (typeof response.request_id === 'string') {
    connections.broadcastToSession(sessionId, MessageType.PERMISSION_RESOLVED, {
      controlRequestId: response.request_id,
    });
  }
  return true;
}

/**
 * When the CLI asks permission for a file edit, make that edit reviewable while
 * the user decides.
 *
 * The change is always stored, because it is what a review reads. The
 * `diffSurface` setting — read per session working directory, so a project can
 * choose on its own — decides only whether the IDE opens a diff tab for it. Set
 * to the built-in surface, the webview draws the review from the same entry,
 * which is also what happens on a host that has no IDE diff to open at all.
 *
 * Deliberately not awaited by the caller: reading the setting and the file both
 * touch disk, and the permission prompt must reach the WebView immediately.
 */
function maybeOpenPermissionDiff(
  targetSessionId: string,
  event: Record<string, unknown>,
  connections: ConnectionManager,
  bridge: Bridge,
): void {
  if (event.type !== 'control_request') return;
  const request = event.request as Record<string, unknown> | undefined;
  if (request?.subtype !== 'can_use_tool') return;

  const toolName = request.tool_name;
  const input = request.input;
  if (typeof toolName !== 'string' || typeof input !== 'object' || input === null) return;

  const workingDir = connections.getSession(targetSessionId)?.workingDir || undefined;
  const toolUseId = request.tool_use_id as string | undefined;
  const toolInput = input as Record<string, unknown>;

  void preparePermissionReview({
    bridge,
    sessionId: targetSessionId,
    workingDir,
    toolName,
    toolInput,
    toolUseId,
    controlRequestId: String(event.request_id ?? ''),
    connections,
  }).catch((err) => {
    console.error('[node-backend]', 'Permission diff preview failed:', err);
  });
}

/**
 * Store the proposed change for review, and open the IDE's diff on it when that
 * is where the review happens.
 *
 * Split out from its caller so the storing and the opening can be tested apart:
 * the two used to be one decision, and collapsing them again would take the
 * review away from every host that does not use the IDE's viewer.
 */
export async function preparePermissionReview(params: {
  bridge: Bridge;
  sessionId: string;
  workingDir: string | undefined;
  toolName: string;
  toolInput: Record<string, unknown>;
  toolUseId: string | undefined;
  controlRequestId: string;
  /**
   * Who to tell when the reviewed file moves while the question is open (#359).
   * Optional so the existing tests, which only assert what gets stored and
   * opened, do not have to supply one.
   */
  connections?: ConnectionManager;
}): Promise<void> {
  const { settings } = await readMergedSettings(params.workingDir);

  const preview = await resolveDiffPreview(params.toolName, params.toolInput);
  if (!preview) return;

  // Hold the change backend-side so an answer can name hunks rather than ship
  // file contents back: what gets written is then the text we diffed, not
  // something reassembled from what a viewer rendered.
  //
  // Stored whatever the setting says. It decides WHERE the change is reviewed,
  // not whether it is: with the IDE viewer off, the webview draws the review
  // from this same entry, and skipping it would leave that reviewer with
  // nothing to look at.
  if (params.toolUseId) {
    rememberPreview(params.toolUseId, {
      ...preview,
      input: params.toolInput,
      toolName: params.toolName,
      sessionId: params.sessionId,
      controlRequestId: params.controlRequestId,
    });

    // Watch from the moment the review exists, so a change that lands while the
    // user is still reading is reported rather than discovered at approval
    // (#359). Not awaited: the permission prompt is what the user is waiting on.
    if (params.connections) {
      void watchReviewBase(
        params.bridge,
        params.connections,
        params.toolUseId,
        preview.filePath,
      );
    }
  }

  /*
   * The review is not opened from here.
   *
   * Storing the change and putting it on screen used to happen together in this
   * function, which made this the second place that decided which surface draws
   * a review — the webview being the first, for the file-name link. The two read
   * their settings for different working directories and disagreed, so a project
   * that asked for the IDE's viewer got the IDE's viewer here and the built-in
   * page from the link, both for the same edit (#359).
   *
   * Now one side asks and one side decides. The webview asks for every review it
   * wants on screen, unprompted ones included (useAutoOpenDiffReview), and
   * openDiffHandler answers with the surface resolveReviewTarget names. This
   * function only stores the change, which is what a review reads.
   *
   * `autoOpenDiffOnPermission` is read by the webview for the same reason: the
   * setting governs whether a review opens without being asked for, and the
   * asking now happens there.
   */
}

function handleStreamEvent(
  targetSessionId: string,
  event: Record<string, unknown>,
  connections: ConnectionManager,
  bridge: Bridge,
  // Needed to find this session's transcript on disk when a turn ends (#356).
  workingDir: string,
  processId: number | undefined,
): void {
  const eventType = event.type as string;
  const recovery = getSessionRecovery(connections, targetSessionId)?.recovery;
  recovery?.observe(event);
  trackToolUses(targetSessionId, event);
  if (eventType === 'user' && event.isReplay === true && typeof event.uuid === 'string') {
    runtimeTasks(connections).limiter.acceptSteering(targetSessionId, processId, event.uuid);
  }

  // Hand a control_response to whichever backend caller is awaiting it (MCP
  // status, for one). Read-only: the event is still forwarded below unchanged,
  // so a WebView-issued request still matches its own reply exactly as before.
  settleControlResponse(event);

  // Detect files Claude edited and, once each edit completes on disk, ask the
  // IDE to reload them (issue #72 — CLI writes bypass the IDE, and the native
  // file watcher misses changes on Windows). Record intents from assistant
  // events; emit refreshes when the matching tool_result succeeds.
  editedFileTracker.recordEdits(event);
  const pathsToRefresh = editedFileTracker.collectRefreshPaths(event);
  if (pathsToRefresh.length > 0) {
    bridge.refreshFiles({ paths: pathsToRefresh }).catch((err) => {
      console.error('[node-backend]', 'Failed to refresh files in IDE:', err);
    });
  }

  // Detect background dynamic workflows and stream their live progress. Pure
  // side-effect — the raw CLI event is still forwarded unchanged below.
  getWorkflowTracker(connections).handleEvent(targetSessionId, event);

  // Show the pending file edit in the IDE's diff viewer while the permission
  // prompt is up, so the user sees what they are approving rather than only the
  // file name (#41, #109). Fire-and-forget: the prompt itself is forwarded
  // below either way, and a diff we cannot open must not delay it.
  maybeOpenPermissionDiff(targetSessionId, event, connections, bridge);

  // Keep the recorded permission mode in step with what the CLI says it is running
  // under. The CLI reports this on `system/init` (spawn) and again on `system/status`
  // when it changes mode by itself — approving an ExitPlanMode plan leaves plan mode
  // with no respawn. Without adopting that, the record would still read `plan`, the
  // user re-picking Plan Mode would compare equal, and the CLI would be reused while
  // actually out of plan — the "Plan Mode turns itself off" report (#172).
  const reportedMode = readReportedMode(event);
  if (reportedMode && reportedMode !== connections.getInputMode(targetSessionId)) {
    console.error(
      '[node-backend]',
      `CLI reports permission mode "${reportedMode}" for session ${targetSessionId} ` +
        `(was "${connections.getInputMode(targetSessionId)}")`,
    );
    connections.setInputMode(targetSessionId, reportedMode);
  }

  // Backend-only side effects (server-internal logic unrelated to forwarding to the WebView)
  if (eventType === 'result' && !event.parent_tool_use_id && !event.parentToolUseID) {
    sessionsWithResult.add(targetSessionId);
    // Turn ended (success, error and interrupt alike emit a result event).
    const limiter = runtimeTasks(connections).limiter;
    const awaitingSteering = limiter.holdForSteering(targetSessionId);
    connections.setStreaming(targetSessionId, awaitingSteering);
    const finishedTaskId = limiter.taskForProcess(targetSessionId, processId);
    const recovering = awaitingSteering || (recovery?.result(event) ?? false);
    if (finishedTaskId && !recovering) limiter.release(targetSessionId, event.is_error === true ? 'failed' : 'completed', finishedTaskId);
    connections.broadcastToAll(MessageType.SESSIONS_UPDATED, {
      action: 'upsert',
      session: {
        sessionId: event.session_id ?? targetSessionId,
      },
    });

    /*
     * Hand the webview the uuid the CLI just recorded for this send (#356).
     *
     * The CLI does not echo user messages back on stdout, so up to this moment
     * the webview only has the id it minted itself — and no CLI command accepts
     * that id. Without this, rewinding the edit you just watched go wrong would
     * mean reopening the session first, which is a strange thing to ask of
     * someone looking straight at it.
     *
     * Read after `result` because that is when the entries are on disk. Failure
     * is silent by design: the actions stay hidden, which is exactly where they
     * were before, and no turn should fail over a menu.
     */
    void readLastRecordedSend(targetSessionId, workingDir).then((recorded) => {
      if (!recorded) return;
      connections.broadcastToSession(targetSessionId, MessageType.SEND_RECORDED, {
        sessionId: targetSessionId,
        uuid: recorded.uuid,
        canRewind: recorded.canRewind,
        text: recorded.text,
      });
    });

    // Diagnose authentication errors (async; failures are ignored)
    const errorData = event.error as { message?: string } | null;
    if (errorData?.message) {
      diagnoseAuthError(targetSessionId, errorData.message, connections).catch(() => {});
    }

    /*
     * Anything that had to wait for this turn to end — see afterTurn.
     *
     * Internal notifications deliberately wait for completion. User-requested
     * steering takes a separate path with CLI consumption acknowledgements.
    */
    for (const content of takeMessagesForFinishedTurn(targetSessionId)) {
      const limiter = runtimeTasks(connections).limiter;
      const task = limiter.enqueue(targetSessionId, workingDir, async () => {
        /*
         * Told to the chat as well as to the CLI, the way an ordinary user
         * message is (see sendMessage: it writes to stdin AND broadcasts).
         *
         * Writing to stdin alone puts the message in the transcript and in front
         * of the model, but NOT in the chat's own list: the CLI does not echo
         * user messages back on stdout — measured, only `tool_result` entries
         * come back that way — so the webview never learns about anything it did
         * not send itself. The reminder was reaching Claude and staying invisible
         * to the session it belonged to.
         */
        // Echo before writing so even an immediate CLI response follows its
        // prompt in the chat. A failed write remains visible via SERVICE_ERROR.
        connections.broadcastToSession(targetSessionId, MessageType.USER_MESSAGE_BROADCAST, {
          content,
          sessionId: targetSessionId,
        });
        const sent = await sendMessageToProcess(connections, targetSessionId, content);
        console.error(
          '[node-backend]',
          `Held message for ${targetSessionId} after turn: ${sent ? 'sent' : 'FAILED to send'}`,
        );
        if (!sent) throw new Error('Claude could not accept a message held for the next turn.');
        if (limiter.get(task.id)) connections.broadcastToSession(targetSessionId, MessageType.STREAM_START);
        return true;
      }, (error) => connections.broadcastToSession(targetSessionId, MessageType.SERVICE_ERROR, {
        error: error instanceof Error ? error.message : String(error),
      }));
    }
  }

  // Forward every CLI event as-is: no per-type branching or reshaping
  connections.broadcastToSession(targetSessionId, MessageType.CLI_EVENT, event);
  if (recovery && !event.parent_tool_use_id && !event.parentToolUseID &&
    (eventType === 'result' || eventType === 'assistant' ||
      (eventType === 'system' && (event.subtype === 'init' || event.subtype === 'compact_boundary')))) {
    connections.broadcastToSession(targetSessionId, MessageType.CONTEXT_BUDGET, { ...recovery.budget.view() });
  }
}
