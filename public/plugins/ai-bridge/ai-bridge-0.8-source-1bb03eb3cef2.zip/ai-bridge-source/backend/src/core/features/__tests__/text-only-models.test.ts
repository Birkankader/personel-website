import { describe, expect, it } from 'vitest';
import { isTextOnlyModel, validTextOnlyModels } from '../text-only-models';
import { ContextBudget } from '../context-budget';

describe('isTextOnlyModel', () => {
  it('matches an id without regard to case', () => {
    expect(isTextOnlyModel(['GLM-5.3-Flash'], ['glm-5.3-flash'])).toBe(true);
    expect(isTextOnlyModel(['glm-5.3-flash'], ['glm-5.3'])).toBe(false);
  });

  it('treats * as any run of characters, and nothing else as special', () => {
    expect(isTextOnlyModel(['glm-*'], ['glm-5.3-flash'])).toBe(true);
    expect(isTextOnlyModel(['*'], ['default'])).toBe(true);
    // The dot is literal: "glm-5x3" is not "glm-5.3".
    expect(isTextOnlyModel(['glm-5.3'], ['glm-5x3'])).toBe(false);
    expect(isTextOnlyModel(['glm-[5]'], ['glm-[5]'])).toBe(true);
  });

  it('matches the id after a provider prefix', () => {
    expect(isTextOnlyModel(['glm-5.3-flash'], ['office/glm-5.3-flash'])).toBe(true);
    expect(isTextOnlyModel(['office/*'], ['office/glm-5.3-flash'])).toBe(true);
  });

  it('is off for an empty or malformed setting, or no model names', () => {
    expect(isTextOnlyModel([], ['glm'])).toBe(false);
    expect(isTextOnlyModel(undefined, ['glm'])).toBe(false);
    expect(isTextOnlyModel('glm', ['glm'])).toBe(false);
    expect(isTextOnlyModel(['*'], [])).toBe(false);
  });
});

describe('validTextOnlyModels', () => {
  it('takes a list of non-empty strings', () => {
    expect(validTextOnlyModels(['glm-*'])).toBe(true);
    expect(validTextOnlyModels([])).toBe(true);
    expect(validTextOnlyModels([' '])).toBe(false);
    expect(validTextOnlyModels([1])).toBe(false);
    expect(validTextOnlyModels(Array(51).fill('m'))).toBe(false);
  });
});

describe('ContextBudget.modelNames', () => {
  it('is the model itself once the model is named', () => {
    expect(new ContextBudget({}, {}, 'glm-5.3-flash').modelNames()).toEqual(['glm-5.3-flash']);
    expect(new ContextBudget({ env: { ANTHROPIC_MODEL: 'glm-5.3-flash' } }, {}).modelNames()).toEqual(['glm-5.3-flash']);
  });

  it('adds what the env maps an alias or the default to', () => {
    const env = { ANTHROPIC_DEFAULT_SONNET_MODEL: 'glm-5.3-flash', ANTHROPIC_DEFAULT_OPUS_MODEL: 'glm-5.3' };
    expect(new ContextBudget({ env }, {}, 'sonnet').modelNames()).toEqual(['sonnet', 'glm-5.3-flash']);
    expect(new ContextBudget({ env }, {}).modelNames()).toEqual(['default', 'glm-5.3', 'glm-5.3-flash']);
  });
});
