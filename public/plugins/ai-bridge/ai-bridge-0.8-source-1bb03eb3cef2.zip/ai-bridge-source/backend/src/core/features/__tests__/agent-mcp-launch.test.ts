import { mkdtempSync, readFileSync, rmSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { afterAll, beforeAll, describe, expect, it, vi } from 'vitest';

const home = vi.hoisted(() => ({ dir: '' }));
vi.mock('os', async (original) => {
  const os = await original<typeof import('os')>();
  return { ...os, homedir: () => home.dir, default: { ...os, homedir: () => home.dir } };
});

const { agentMcpArgs, agentMcpBridgeEnv, agentMcpServers } = await import('../agent-mcp-launch');

beforeAll(() => { home.dir = mkdtempSync(join(tmpdir(), 'ai-bridge-mcp-test-')); });
afterAll(() => rmSync(home.dir, { recursive: true, force: true }));

describe('agentMcpServers', () => {
  it('gives each chosen server, in text mode for a text-only model', () => {
    const servers = agentMcpServers({ computerUse: true, webTools: true, textOnly: true });
    expect(servers.map(s => s.name)).toEqual(['ai-bridge-computer-use', 'ai-bridge-web']);
    expect(servers[0].args.slice(-2)).toEqual(['computer-use-mcp', '--text-screenshots']);
    expect(servers[1].args.slice(-2)).toEqual(['web-mcp', '--text-screenshots']);
    expect(agentMcpServers({ computerUse: false, webTools: true, textOnly: false })[0].args.at(-1)).toBe('web-mcp');
  });

  it('gives no flags or env when none is chosen', async () => {
    const none = { computerUse: false, webTools: false, textOnly: true };
    expect(agentMcpServers(none)).toEqual([]);
    expect(await agentMcpArgs(none)).toEqual([]);
    expect(agentMcpBridgeEnv(none)).toEqual({});
  });
});

describe('agentMcpArgs', () => {
  it('writes one --mcp-config file per choice', async () => {
    const [flag, file] = await agentMcpArgs({ computerUse: true, webTools: true, textOnly: false });
    expect(flag).toBe('--mcp-config');
    expect(file.replace(/"/g, '')).toBe(join(home.dir, '.ai-bridge', 'mcp', 'computer-use+web.json'));
    const config = JSON.parse(readFileSync(file.replace(/"/g, ''), 'utf8'));
    expect(Object.keys(config.mcpServers)).toEqual(['ai-bridge-computer-use', 'ai-bridge-web']);
    expect(config.mcpServers['ai-bridge-web'].type).toBe('stdio');
    // The computer-use file keeps the name it had before the web tools came.
    expect((await agentMcpArgs({ computerUse: true, webTools: false, textOnly: true }))[1].replace(/"/g, '')).toBe(join(home.dir, '.ai-bridge', 'mcp', 'computer-use-text.json'));
  });
});

describe('agentMcpBridgeEnv', () => {
  it('hands the ACP bridge the same servers', () => {
    const env = agentMcpBridgeEnv({ computerUse: false, webTools: true, textOnly: false });
    expect(JSON.parse(env.AI_BRIDGE_MCP_SERVERS).map((s: { name: string }) => s.name)).toEqual(['ai-bridge-web']);
  });
});
