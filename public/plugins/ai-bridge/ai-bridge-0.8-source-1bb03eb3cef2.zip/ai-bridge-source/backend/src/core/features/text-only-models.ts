/**
 * The textOnlyModels setting: models that do not read images.
 *
 * A model without an image encoder cannot use an image block, and the server in
 * front of it usually fails the whole request. The image then stays in the
 * conversation, so every later turn fails the same way and the chat looks dead.
 * For these models a message's images go as a text description instead
 * (image-summary.ts), and the computer-use screenshot tool answers in text.
 *
 * Each entry is a model id, matched without regard to case, where `*` stands for
 * any run of characters: "glm-5.3-flash", "glm-*", or "*" for every model. An
 * entry also matches the id after a provider prefix, so "glm-5.3-flash" covers
 * "office/glm-5.3-flash" the way an ACP harness names it.
 */
export const MAX_TEXT_ONLY_MODELS = 50;

export function validTextOnlyModels(value: unknown): value is string[] {
  return Array.isArray(value) && value.length <= MAX_TEXT_ONLY_MODELS &&
    value.every(entry => typeof entry === 'string' && entry.trim().length > 0 && entry.length <= 200);
}

function entryPattern(entry: string): RegExp {
  const parts = entry.trim().toLowerCase().split('*').map(part => part.replace(/[.+?^${}()|[\]\\]/g, '\\$&'));
  return new RegExp(`^${parts.join('.*')}$`);
}

/** Whether any of a model's names matches an entry of the textOnlyModels setting. */
export function isTextOnlyModel(entries: unknown, modelNames: readonly string[]): boolean {
  if (!validTextOnlyModels(entries) || entries.length === 0) return false;
  const patterns = entries.map(entryPattern);
  const names = modelNames.flatMap((name) => {
    const lower = name.toLowerCase();
    const tail = lower.slice(lower.lastIndexOf('/') + 1);
    return tail === lower ? [lower] : [lower, tail];
  });
  return names.some(name => patterns.some(pattern => pattern.test(name)));
}
