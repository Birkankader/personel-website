import { existsSync, mkdirSync, readdirSync, readFileSync, renameSync, statSync, writeFileSync } from 'fs';
import { createHash } from 'crypto';
import { homedir } from 'os';
import { join, resolve } from 'path';
import { Document, isMap, isSeq, parseDocument, type YAMLMap } from 'yaml';

/**
 * The model providers a dsh user set up, carried into the `acp` profile AI Bridge runs.
 *
 * dsh writes the providers added on its Models page ("Custom model API", a
 * DeepSeek endpoint, the default model) into the `cordis.patch.yml` of the
 * profile that was running — usually `web`. AI Bridge starts dsh with
 * `--profile acp`, whose own patch is empty and whose acp bundle pins the chat
 * to `deepseek-official`, so a user with only a corporate endpoint gets "no API
 * key for provider route deepseek-official" although `pnpm dsh` works.
 *
 * So AI Bridge copies those rows, unedited, into a patch file of its own and
 * hands it to dsh with the launcher's `--patch` flag, plus an `acp` row that
 * starts chats on the user's default model. Nothing under DSH_HOME is written;
 * credentials stay in dsh's own store, which every profile shares.
 */

/** The base-bundle rows that hold provider routes and the default model. */
const PROVIDER_ROWS = ['llm', 'llm-retry', 'llm-pi-ai', 'llm-deepseek', 'llm-deepseek-account', 'agent-default-model'] as const;
const PATCH_FILENAME = 'cordis.patch.yml';
const ACP_PROFILE = 'acp';
/** The routes the base bundle's DeepSeek adapters register in every profile. */
const BASE_ROUTES = ['deepseek-official', 'deepseek-account'] as const;

export interface DshProviderPatch {
  /** The patch file to pass with `--patch`. */
  file: string;
  /** The profile patch the rows were copied from; absent when only the model pin was needed. */
  source?: string;
  /** The model chats start on, when one was chosen. */
  selection?: { provider: string; model: string };
}

/** `$DSH_HOME`, as dsh resolves it: the environment variable, else `~/.dsh`. */
export function dshHome(env: NodeJS.ProcessEnv = process.env, home: string = homedir()): string {
  const configured = env.DSH_HOME?.trim();
  return configured ? resolve(configured) : join(home, '.dsh');
}

/** The top-level rows of a patch file by id; empty when it is missing or unreadable. */
function patchRows(file: string): Map<string, YAMLMap> {
  const rows = new Map<string, YAMLMap>();
  let text: string;
  try { text = readFileSync(file, 'utf8'); } catch { return rows; }
  const doc = parseDocument(text, { logLevel: 'silent' });
  if (doc.errors.length || !isSeq(doc.contents)) return rows;
  for (const item of doc.contents.items) {
    if (!isMap(item)) continue;
    const id = item.get('id');
    if (typeof id === 'string') rows.set(id, item);
  }
  return rows;
}

function rowConfig(row: YAMLMap | undefined): Record<string, unknown> | undefined {
  const config = row?.toJSON()?.config;
  return config && typeof config === 'object' && !Array.isArray(config) ? config : undefined;
}

/** A row that changes something: a config or a disabled flag, on a base-bundle package. */
function carriesSettings(row: YAMLMap): boolean {
  const { name, config, disabled } = row.toJSON() ?? {};
  if (name !== undefined && !(typeof name === 'string' && name.startsWith('@deepseek-ai/'))) return false;
  if (disabled !== undefined) return true;
  if (!config || typeof config !== 'object') return false;
  const providers = (config as { providers?: unknown }).providers;
  return providers === undefined || (typeof providers === 'object' && providers !== null && Object.keys(providers).length > 0);
}

/** The provider rows of one profile's patch that would change an acp launch. */
function providerRowsOf(file: string): Map<string, YAMLMap> {
  const rows = patchRows(file);
  return new Map(PROVIDER_ROWS.flatMap(id => {
    const row = rows.get(id);
    return row && carriesSettings(row) ? [[id, row] as const] : [];
  }));
}

/** The profile patch holding the user's providers: the most recently saved one that has any. */
function sourceProfile(home: string): { file: string; rows: Map<string, YAMLMap> } | null {
  let names: string[];
  try { names = readdirSync(join(home, 'profiles')); } catch { return null; }
  let best: { file: string; rows: Map<string, YAMLMap>; mtime: number } | null = null;
  for (const name of names) {
    if (name === ACP_PROFILE) continue;
    const file = join(home, 'profiles', name, PATCH_FILENAME);
    let mtime: number;
    try { mtime = statSync(file).mtimeMs; } catch { continue; }
    if (best && mtime <= best.mtime) continue;
    const rows = providerRowsOf(file);
    if (rows.size) best = { file, rows, mtime };
  }
  return best;
}

/** The routes a provider row set registers, with the models a chat can start on. */
function routes(piAi: Record<string, unknown> | undefined): Map<string, string[]> {
  const providers = piAi?.providers;
  const found = new Map<string, string[]>(BASE_ROUTES.map(route => [route, []]));
  if (!providers || typeof providers !== 'object') return found;
  for (const [route, profile] of Object.entries(providers)) {
    const models = (profile as { models?: unknown } | null)?.models;
    const ids = Array.isArray(models) ? models.map(m => (m as { id?: unknown })?.id).filter((id): id is string => typeof id === 'string') : [];
    found.set(route, ids);
  }
  return found;
}

/**
 * The model acp chats start on: the user's default model when its route exists
 * in acp, else the first model of the first custom route. None means acp keeps
 * its own pin (`deepseek-official`).
 */
function chooseSelection(defaults: Record<string, unknown> | undefined, available: Map<string, string[]>): { provider: string; model: string } | undefined {
  const { provider, model } = defaults ?? {};
  if (typeof provider === 'string' && typeof model === 'string' && available.has(provider)) return { provider, model };
  for (const [route, models] of available) {
    if (models.length) return { provider: route, model: models[0] };
  }
  return undefined;
}

/** Writes [text] to [file] unless it is already there, so a reading launch never sees a half-written file. */
function writeOnce(file: string, text: string): void {
  if (existsSync(file)) return;
  mkdirSync(join(file, '..'), { recursive: true });
  const temp = `${file}.${process.pid}.tmp`;
  writeFileSync(temp, text);
  renameSync(temp, file);
}

/**
 * The patch that carries the user's dsh providers into an acp launch, written
 * under [outDir]; null when there is nothing to carry: no providers anywhere,
 * or the user set the acp profile up itself.
 *
 * Mirrors the layering of the profile the rows come from: a row the home patch
 * (`$DSH_HOME/cordis.patch.yml`) or the acp profile's own patch already sets is
 * left to them, since `--patch` would otherwise outrank both. Providers that
 * live in the home patch reach acp on their own; only the model pin is added.
 */
export function dshProviderPatch(outDir: string, options: { env?: NodeJS.ProcessEnv; home?: string } = {}): DshProviderPatch | null {
  const home = dshHome(options.env, options.home);
  const source = sourceProfile(home);
  const sourceRows = source?.rows ?? new Map<string, YAMLMap>();
  const homeRows = patchRows(join(home, PATCH_FILENAME));
  const acpRows = patchRows(join(home, 'profiles', ACP_PROFILE, PATCH_FILENAME));

  const effective = (id: string) => rowConfig(homeRows.get(id) ?? acpRows.get(id) ?? sourceRows.get(id));
  const available = routes(effective('llm-pi-ai'));
  // A default model on a route only that profile's plugins provide (a subscription) would fail in acp.
  const defaultRoute = rowConfig(sourceRows.get('agent-default-model'))?.provider;
  const copied = [...sourceRows].filter(([id]) => !homeRows.has(id) && !acpRows.has(id)
    && (id !== 'agent-default-model' || (typeof defaultRoute === 'string' && available.has(defaultRoute))));
  const selection = homeRows.has(ACP_PROFILE) || acpRows.has(ACP_PROFILE)
    ? undefined
    : chooseSelection(effective('agent-default-model'), available);
  if (!copied.length && !selection) return null;

  const doc = new Document([]);
  for (const [, row] of copied) doc.add(row.clone());
  if (selection) doc.add(doc.createNode({ id: ACP_PROFILE, config: selection }));
  const origin = copied.length && source ? `provider rows copied from\n# ${source.file}` : `the default model from\n# ${join(home, PATCH_FILENAME)}`;
  const text = `# Written by AI Bridge for \`dsh --profile acp\`: ${origin}\n${String(doc)}`;

  const file = join(outDir, `providers-${createHash('sha256').update(text).digest('hex').slice(0, 12)}.patch.yml`);
  writeOnce(file, text);
  return { file, ...(copied.length && source ? { source: source.file } : {}), ...(selection ? { selection } : {}) };
}
