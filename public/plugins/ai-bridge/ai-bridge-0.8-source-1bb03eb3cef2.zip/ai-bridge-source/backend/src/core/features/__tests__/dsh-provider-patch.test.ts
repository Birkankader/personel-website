import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { mkdirSync, mkdtempSync, readFileSync, rmSync, utimesSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { parse } from 'yaml';
import { dshHome, dshProviderPatch } from '../dsh-provider-patch';

/** What the dsh web Models page saves after "Custom model API" and a default model. */
const WEB_PATCH = `- id: ui-settings-general
  name: "@deepseek-ai/dsh-client-ui-settings-general"
  config:
    welcomeNoticeVersion: 2026-09-28.1
- id: llm-pi-ai
  name: "@deepseek-ai/dsh-llm-pi-ai"
  config:
    providers:
      corp:
        displayName: Corp Gateway
        api: openai-completions
        baseURL: https://llm.corp.example/v1
        apiKeyEnv: CORP_API_KEY
        models:
          - id: corp-coder
          - id: corp-chat
- id: agent-default-model
  name: "@deepseek-ai/dsh-agent-default-model"
  config:
    provider: corp
    model: corp-chat
    reasoningEffort: high
- id: llm-subscriptions
  name: dsh-plugin-subscriptions
  config:
    providers: [ claude, codex ]
- id: session-persistence-jsonl
  config:
    root: !!js dshHomePath('sessions')
`;

describe('dsh provider patch', () => {
  let root: string;
  let dshDir: string;
  let out: string;

  beforeEach(() => {
    root = mkdtempSync(join(tmpdir(), 'ai-bridge-dsh-'));
    dshDir = join(root, '.dsh');
    out = join(root, 'out');
  });

  afterEach(() => {
    rmSync(root, { recursive: true, force: true });
  });

  function writeProfile(name: string, text: string, mtime?: number): string {
    const dir = join(dshDir, 'profiles', name);
    mkdirSync(dir, { recursive: true });
    const file = join(dir, 'cordis.patch.yml');
    writeFileSync(file, text);
    if (mtime !== undefined) utimesSync(file, mtime, mtime);
    return file;
  }

  const make = () => dshProviderPatch(out, { env: {}, home: root });

  it('copies the provider rows unedited and starts acp chats on the default model', () => {
    const source = writeProfile('web', WEB_PATCH);
    writeProfile('acp', '[]\n');

    const patch = make();

    expect(patch).toMatchObject({ source, selection: { provider: 'corp', model: 'corp-chat' } });
    const rows = parse(readFileSync(patch!.file, 'utf8'), { logLevel: 'silent' }) as Array<{ id: string }>;
    expect(rows.map(row => row.id)).toEqual(['llm-pi-ai', 'agent-default-model', 'acp']);
    expect(rows[0]).toEqual(parse(WEB_PATCH, { logLevel: 'silent' })[1]);
    expect(rows[1]).toEqual(parse(WEB_PATCH, { logLevel: 'silent' })[2]);
    expect(rows[2]).toEqual({ id: 'acp', config: { provider: 'corp', model: 'corp-chat' } });
  });

  it('starts on the first custom model when the default model is on a route acp does not have', () => {
    writeProfile('web', WEB_PATCH.replace('provider: corp\n    model: corp-chat', 'provider: codex\n    model: gpt-6'));

    const patch = make();

    expect(patch!.selection).toEqual({ provider: 'corp', model: 'corp-coder' });
    const ids = (parse(readFileSync(patch!.file, 'utf8'), { logLevel: 'silent' }) as Array<{ id: string }>).map(row => row.id);
    expect(ids).toEqual(['llm-pi-ai', 'acp']);
  });

  it('keeps a DeepSeek endpoint and the default model on the official route', () => {
    writeProfile('web', `- id: llm-deepseek
  config:
    baseURL: https://deepseek.corp.example
- id: agent-default-model
  config:
    provider: deepseek-official
    model: deepseek-v4-pro
`);

    expect(make()!.selection).toEqual({ provider: 'deepseek-official', model: 'deepseek-v4-pro' });
  });

  it('takes the most recently saved profile that has providers', () => {
    writeProfile('web', WEB_PATCH, 1_000);
    const newer = writeProfile('mine', WEB_PATCH.replace(/corp/g, 'lab'), 2_000);
    writeProfile('headless', '- id: hmr\n  disabled: true\n', 3_000);

    expect(make()).toMatchObject({ source: newer, selection: { provider: 'lab', model: 'lab-chat' } });
  });

  it('leaves rows the home patch or the acp profile already set to them', () => {
    writeProfile('web', WEB_PATCH);
    writeFileSync(join(dshDir, 'cordis.patch.yml'), '- id: llm-pi-ai\n  config:\n    providers:\n      corp: { api: openai-completions, baseURL: http://h, models: [{ id: corp-chat }] }\n');
    writeProfile('acp', '- id: acp\n  config:\n    provider: corp\n    model: corp-coder\n');

    const patch = make();

    const ids = (parse(readFileSync(patch!.file, 'utf8'), { logLevel: 'silent' }) as Array<{ id: string }>).map(row => row.id);
    expect(ids).toEqual(['agent-default-model']);
    expect(patch!.selection).toBeUndefined();
  });

  it('starts acp on the default model when the providers live in the home patch', () => {
    mkdirSync(dshDir, { recursive: true });
    writeFileSync(join(dshDir, 'cordis.patch.yml'), WEB_PATCH);

    const patch = make();

    expect(patch).toMatchObject({ selection: { provider: 'corp', model: 'corp-chat' } });
    expect(patch!.source).toBeUndefined();
    expect(parse(readFileSync(patch!.file, 'utf8'), { logLevel: 'silent' })).toEqual([{ id: 'acp', config: { provider: 'corp', model: 'corp-chat' } }]);
  });

  it('is null when no profile has providers', () => {
    writeProfile('web', '- id: llm-pi-ai\n  config:\n    providers: {}\n');
    expect(make()).toBeNull();
    rmSync(dshDir, { recursive: true, force: true });
    expect(make()).toBeNull();
  });

  it('writes one file per content and reuses it', () => {
    writeProfile('web', WEB_PATCH);
    expect(make()!.file).toBe(make()!.file);
  });

  it('follows DSH_HOME', () => {
    expect(dshHome({ DSH_HOME: join(root, 'elsewhere') }, root)).toBe(join(root, 'elsewhere'));
    expect(dshHome({}, root)).toBe(join(root, '.dsh'));
  });
});
