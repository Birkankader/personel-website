import { mkdir, readFile, writeFile } from 'fs/promises';
import { homedir } from 'os';
import { join } from 'path';
import { agentToolsLaunch } from '../harness-launch';

/** The names the tools appear under (`mcp__ai-bridge-computer-use__screenshot`, `mcp__ai-bridge-web__open_page`). */
export const COMPUTER_USE_MCP_NAME = 'ai-bridge-computer-use';
export const WEB_MCP_NAME = 'ai-bridge-web';

/**
 * Which of AI Bridge's own MCP servers (agent-tools.mjs) a chat gets: computer
 * use (screen, mouse, keyboard) and the web page and shader tools. `textOnly`
 * is for a model that does not read images (textOnlyModels): their screenshots
 * and drawings come back as a text description.
 */
export interface AgentMcpChoice {
  computerUse: boolean;
  webTools: boolean;
  textOnly: boolean;
}

export function agentMcpServers(choice: AgentMcpChoice): Array<{ name: string; command: string; args: string[] }> {
  const tools = agentToolsLaunch();
  const text = choice.textOnly ? ['--text-screenshots'] : [];
  const servers: Array<{ name: string; command: string; args: string[] }> = [];
  if (choice.computerUse) servers.push({ name: COMPUTER_USE_MCP_NAME, command: tools.command, args: [...tools.args, 'computer-use-mcp', ...text] });
  if (choice.webTools) servers.push({ name: WEB_MCP_NAME, command: tools.command, args: [...tools.args, 'web-mcp', ...text] });
  return servers;
}

/**
 * The flags that add the chosen servers to a Claude CLI launch, none when no
 * server is chosen.
 *
 * `--mcp-config` is the CLI's documented way to load extra MCP servers for one
 * run, on top of the user's own; nothing is written into their configuration.
 * The config goes in a file because JSON does not survive the Windows command
 * line, and the file is only rewritten when its content changes. Each choice
 * has its own file, so chats on different models never rewrite each other's.
 */
export async function agentMcpArgs(choice: AgentMcpChoice): Promise<string[]> {
  const servers = agentMcpServers(choice);
  if (servers.length === 0) return [];
  const dir = join(homedir(), '.ai-bridge', 'mcp');
  const parts = [choice.computerUse ? 'computer-use' : '', choice.webTools ? 'web' : ''].filter(Boolean);
  const file = join(dir, `${parts.join('+')}${choice.textOnly ? '-text' : ''}.json`);
  const content = JSON.stringify({ mcpServers: Object.fromEntries(servers.map(({ name, ...server }) => [name, { type: 'stdio', ...server }])) }, null, 2);
  const current = await readFile(file, 'utf8').catch(() => null);
  if (current !== content) {
    await mkdir(dir, { recursive: true });
    await writeFile(file, content, 'utf8');
  }
  const quoted = process.platform === 'win32' && /\s/.test(file) ? `"${file}"` : file;
  return ['--mcp-config', quoted];
}

/** The env that tells the ACP bridge to hand the same servers to a harness session. */
export function agentMcpBridgeEnv(choice: AgentMcpChoice): Record<string, string> {
  const servers = agentMcpServers(choice);
  return servers.length ? { AI_BRIDGE_MCP_SERVERS: JSON.stringify(servers) } : {};
}
