import { beforeEach, describe, expect, it, vi } from 'vitest';
import { PNG } from 'pngjs';
import { encode as encodeJpeg } from 'jpeg-js';
import { GifWriter } from 'omggif';
import { recognizeText, parseTesseractTsv, type OcrResult } from '../image-ocr';
import {
  analyzePixels,
  decodeImage,
  imageBlocks,
  summarizeImages,
  textItems,
  type Pixels,
} from '../image-summary';

vi.mock('../image-ocr', async (original) => ({
  ...(await original<typeof import('../image-ocr')>()),
  recognizeText: vi.fn(),
}));

type Rgb = [number, number, number];

/**
 * A small settings dialog: a page, a white card with a 1px border, and two
 * buttons in a row where the second sits 4px lower than the first.
 */
function dialog(): Pixels {
  const width = 400, height = 200;
  const data = new Uint8Array(width * height * 4);
  const paint = (x: number, y: number): Rgb => {
    const inside = (x0: number, y0: number, w: number, h: number) => x >= x0 && x < x0 + w && y >= y0 && y < y0 + h;
    if (inside(200, 140, 80, 30)) return [229, 231, 235];
    if (inside(290, 144, 80, 30)) return [37, 99, 235];
    if (inside(21, 21, 358, 158)) return [255, 255, 255];
    if (inside(20, 20, 360, 160)) return [192, 196, 204];
    return [245, 246, 248];
  };
  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const [r, g, b] = paint(x, y);
      data.set([r, g, b, 255], (y * width + x) * 4);
    }
  }
  return { width, height, data };
}

function pngOf(pixels: Pixels): Buffer {
  const png = new PNG({ width: pixels.width, height: pixels.height });
  png.data = Buffer.from(pixels.data);
  return PNG.sync.write(png);
}

const ocrSaying = (lines: Array<{ text: string; x: number; y: number; w: number; h: number }>): OcrResult =>
  ({ engine: 'Fake OCR', language: 'en-US', lines: lines.map(word => ({ words: [word] })) });

beforeEach(() => {
  vi.mocked(recognizeText).mockReset();
});

describe('decodeImage', () => {
  it('reads PNG, JPEG and the first frame of a GIF', () => {
    const pixels = dialog();
    expect(decodeImage(pngOf(pixels))).toMatchObject({ width: 400, height: 200 });
    const jpeg = encodeJpeg({ data: Buffer.from(pixels.data), width: 400, height: 200 }, 90).data;
    const decodedJpeg = decodeImage(jpeg)!;
    expect(decodedJpeg).toMatchObject({ width: 400, height: 200 });
    // The blue button survives JPEG within a few levels.
    const i = (150 * 400 + 340) * 4;
    expect(Math.abs(decodedJpeg.data[i + 2] - 235)).toBeLessThan(8);

    const gif = Buffer.alloc(1024);
    const writer = new GifWriter(gif, 4, 2, { palette: [0xff0000, 0x0000ff] });
    writer.addFrame(0, 0, 4, 2, [0, 0, 1, 1, 0, 0, 1, 1]);
    const decodedGif = decodeImage(gif.subarray(0, writer.end()))!;
    expect(decodedGif).toMatchObject({ width: 4, height: 2 });
    expect([...decodedGif.data.subarray(8, 12)]).toEqual([0, 0, 255, 255]);
  });

  it('gives null for anything else', () => {
    expect(decodeImage(Buffer.from('not an image at all'))).toBeNull();
  });
});

describe('analyzePixels', () => {
  it('nests the shapes and puts each text in the shape it sits in', () => {
    const analysis = analyzePixels(dialog(), [{ text: 'Save', x: 325, y: 152, w: 30, h: 12 }]);
    const describe = (i: number) => {
      const r = analysis.regions[i];
      return `${r.kind} ${r.x},${r.y} ${r.w}x${r.h}`;
    };
    const page = analysis.regions.findIndex(r => r.color === 0xf5f6f8);
    const frame = analysis.regions.findIndex(r => r.kind === 'frame');
    const card = analysis.regions.findIndex(r => r.color === 0xffffff);
    const blue = analysis.regions.findIndex(r => r.color === 0x2563eb);
    expect(describe(page)).toBe('area 0,0 400x200');
    expect(describe(frame)).toBe('frame 20,20 360x160');
    expect(describe(card)).toBe('area 21,21 358x158');
    expect(describe(blue)).toBe('area 290,144 80x30');
    expect(analysis.regions[frame].parent).toBe(page);
    expect(analysis.regions[card].parent).toBe(frame);
    expect(analysis.regions[blue].parent).toBe(card);
    expect(analysis.regions[blue].texts).toEqual(['Save']);
    expect(analysis.factor).toBe(1);
  });

  it('averages a very large image down before tracing it', () => {
    const width = 4000, height = 3000;
    const data = new Uint8Array(width * height * 4).fill(255);
    expect(analyzePixels({ width, height, data }).factor).toBe(2);
  });
});

describe('textItems', () => {
  it('splits a line where its words are far apart', () => {
    const items = textItems({
      engine: 'Fake OCR',
      lines: [{ words: [
        { text: 'File', x: 10, y: 5, w: 30, h: 12 },
        { text: 'name', x: 44, y: 5, w: 36, h: 12 },
        { text: 'Help', x: 300, y: 6, w: 30, h: 12 },
      ] }],
    });
    expect(items).toEqual([
      { text: 'File name', x: 10, y: 5, w: 70, h: 12 },
      { text: 'Help', x: 300, y: 6, w: 30, h: 12 },
    ]);
  });
});

describe('parseTesseractTsv', () => {
  it('groups word rows into lines', () => {
    const tsv = [
      'level\tpage_num\tblock_num\tpar_num\tline_num\tword_num\tleft\ttop\twidth\theight\tconf\ttext',
      '4\t1\t1\t1\t1\t0\t10\t5\t70\t12\t-1\t',
      '5\t1\t1\t1\t1\t1\t10\t5\t30\t12\t96\tFile',
      '5\t1\t1\t1\t1\t2\t44\t5\t36\t12\t95\tname',
      '5\t1\t1\t1\t2\t1\t10\t30\t40\t12\t91\tSave',
    ].join('\n');
    expect(parseTesseractTsv(tsv).map(line => line.words.map(word => word.text).join(' '))).toEqual(['File name', 'Save']);
  });
});

describe('summarizeImages', () => {
  it('writes text, layout and the near miss into one block', async () => {
    vi.mocked(recognizeText).mockResolvedValue([ocrSaying([{ text: 'Save', x: 325, y: 152, w: 30, h: 12 }])]);
    const [summary] = await summarizeImages([{ fileName: 'dialog.png', mimeType: 'image/png', base64: pngOf(dialog()).toString('base64') }]);
    expect(summary).toMatch(/^<image-summary file="dialog.png" format="PNG" size="400x200">/);
    expect(summary).toContain('Text (Fake OCR, read as en-US');
    expect(summary).toContain('- "Save" 325,152 30x12');
    expect(summary).toContain('      - area #2563EB 290,144 80x30 "Save"');
    expect(summary).toContain('area #E5E7EB 200,140 80x30 and area #2563EB 290,144 80x30 "Save": top 140 vs 144, bottom 170 vs 174');
    expect(summary).toContain('Color grid (16x8 cells');
    expect(summary.trimEnd().endsWith('</image-summary>')).toBe(true);
  });

  it('scales every position, as for a screenshot read from a sharper capture', async () => {
    vi.mocked(recognizeText).mockResolvedValue([ocrSaying([{ text: 'Save', x: 325, y: 152, w: 30, h: 12 }])]);
    const pixels = dialog();
    pixels.data[0] = 3;
    const [summary] = await summarizeImages([{ fileName: 'screen.png', mimeType: 'image/png', base64: pngOf(pixels).toString('base64') }], { scale: 0.5 });
    expect(summary).toMatch(/^<image-summary file="screen.png" format="PNG" size="200x100">/);
    expect(summary).toContain('- "Save" 163,76 15x6');
    expect(summary).toContain('area #2563EB 145,72 40x15 "Save"');
    expect(summary).toContain(': top 70 vs 72, bottom 85 vs 87');
  });

  it('reads an image once and answers from the cache after that', async () => {
    vi.mocked(recognizeText).mockResolvedValue([ocrSaying([])]);
    const pixels = dialog();
    pixels.data[0] = 1; // a different image from the other tests
    const image = { fileName: 'again.png', mimeType: 'image/png', base64: pngOf(pixels).toString('base64') };
    const first = await summarizeImages([image]);
    const second = await summarizeImages([image]);
    expect(second).toEqual(first);
    expect(recognizeText).toHaveBeenCalledTimes(1);
  });

  it('still reads the text of a WebP, which it does not decode', async () => {
    vi.mocked(recognizeText).mockResolvedValue([ocrSaying([{ text: 'Hello', x: 1, y: 2, w: 3, h: 4 }])]);
    // A lossless WebP header for a 640x480 image; nothing after it is read.
    const webp = Buffer.alloc(40);
    webp.write('RIFF', 0, 'latin1');
    webp.write('WEBPVP8L', 8, 'latin1');
    webp[20] = 0x2f;
    webp.writeUInt32LE((639) | (479 << 14), 21);
    const [summary] = await summarizeImages([{ fileName: 'shot.webp', mimeType: 'image/webp', base64: webp.toString('base64') }]);
    expect(summary).toContain('format="WebP" size="640x480"');
    expect(summary).toContain('- "Hello" 1,2 3x4');
    expect(summary).toContain('Layout and colors: not available (WebP is not decoded here).');
  });

  it('says why the text is missing when OCR fails', async () => {
    vi.mocked(recognizeText).mockResolvedValue([{ engine: 'Tesseract', lines: [], error: 'no OCR engine found' }]);
    const pixels = dialog();
    pixels.data[0] = 2;
    const [summary] = await summarizeImages([{ fileName: 'x.png', mimeType: 'image/png', base64: pngOf(pixels).toString('base64') }]);
    expect(summary).toContain('Text: not read (Tesseract: no OCR engine found).');
    expect(summary).toContain('area #2563EB 290,144 80x30');
  });
});

describe('imageBlocks', () => {
  const image = { fileName: 'a.png', mimeType: 'image/png', base64: 'ZmFrZQ==' };

  it('keeps image blocks for a model that reads images', async () => {
    expect(await imageBlocks([image], false)).toEqual([{ type: 'image', source: { type: 'base64', media_type: 'image/png', data: 'ZmFrZQ==' } }]);
  });

  it('turns each image into its description for a text-only model', async () => {
    expect(await imageBlocks([image, image], true, async images => images.map((_, i) => `summary ${i}`)))
      .toEqual([{ type: 'text', text: 'summary 0' }, { type: 'text', text: 'summary 1' }]);
  });

  it('leaves the images out rather than sending them when the description fails', async () => {
    const blocks = await imageBlocks([image], true, async () => { throw new Error('disk full'); });
    expect(blocks).toEqual([{ type: 'text', text: expect.stringContaining('could not describe them (disk full)') }]);
  });
});
