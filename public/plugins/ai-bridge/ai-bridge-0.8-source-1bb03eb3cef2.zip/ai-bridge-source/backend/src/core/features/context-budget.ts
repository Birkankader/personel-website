import { createHash } from 'node:crypto';
import { existsSync } from 'node:fs';
import { open } from 'node:fs/promises';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { readJsonFileSafe } from './claude-settings';
import { updateJsonFile } from './atomic-json';
import { getProjectSessionsPath } from './getProjectSessionsPath';

const CACHE_TTL = 7 * 24 * 60 * 60 * 1000;
const SAFETY_TOKENS = 8000;
export const COMPACT_PERCENT = 75;
const positive = (value: unknown): number | undefined => {
  const n = typeof value === 'number' ? value : typeof value === 'string' ? Number(value.replace(/[,_]/g, '')) : NaN;
  return Number.isSafeInteger(n) && n > 0 ? n : undefined;
};
const record = (value: unknown): Record<string, unknown> =>
  value && typeof value === 'object' && !Array.isArray(value) ? value as Record<string, unknown> : {};

export function contextLimitFromError(text: string): number | undefined {
  const match = /(?:maximum context length|context (?:window|length)(?: limit)?|maximum context window)(?:\s*(?:is|of|:|=))?\s*([\d,]+)\s*tokens/i.exec(text);
  return match ? positive(match[1]) : undefined;
}

export interface ContextBudgetView {
  model: string;
  totalTokens: number;
  contextWindow: number;
  maxOutputTokens: number;
  compactAt: number;
}

/** Latest request usage, never cumulative billing totals. Provider errors take
 * precedence over CLI model tables. No transcript or credential is persisted. */
export class ContextBudget {
  readonly configurationKey: string;
  model: string;
  inputTokens = 0;
  outputTokens = 0;
  hasUsage = false;
  private reportedWindow?: number;
  private reportedOutput?: number;
  private limits = new Map<string, number>();
  private configuredWindow?: number;
  private configuredOutput?: number;
  private env: Record<string, unknown>;
  private cacheFile: string;
  private gateway: boolean;

  constructor(settings: Record<string, unknown>, inherited: NodeJS.ProcessEnv, model?: string) {
    this.env = { ...inherited, ...record(settings.env) };
    this.model = model && model !== 'default' ? model : String(this.env.ANTHROPIC_MODEL || settings.model || 'default');
    this.configuredWindow = positive(this.env.CLAUDE_CODE_MAX_CONTEXT_TOKENS);
    this.configuredOutput = positive(this.env.CLAUDE_CODE_MAX_OUTPUT_TOKENS);
    this.gateway = !!this.env.ANTHROPIC_BASE_URL && !/^https:\/\/api\.anthropic\.com\/?$/.test(String(this.env.ANTHROPIC_BASE_URL));
    const scope = createHash('sha256').update(JSON.stringify([
      inherited.CLAUDE_CONFIG_DIR ?? '', this.env.ANTHROPIC_BASE_URL ?? '',
      this.env.ANTHROPIC_BEDROCK_BASE_URL ?? '', this.env.ANTHROPIC_VERTEX_BASE_URL ?? '',
      this.env.CLAUDE_CODE_USE_BEDROCK ?? '', this.env.CLAUDE_CODE_USE_VERTEX ?? '',
      this.env.ANTHROPIC_DEFAULT_OPUS_MODEL ?? '', this.env.ANTHROPIC_DEFAULT_SONNET_MODEL ?? '',
    ])).digest('hex');
    this.cacheFile = join(homedir(), '.ai-bridge', 'context-limits', `${scope}.json`);
    this.configurationKey = createHash('sha256').update(JSON.stringify([
      scope, this.configuredWindow, this.configuredOutput, this.env.CLAUDE_CODE_AUTO_COMPACT_WINDOW,
      this.env.CLAUDE_AUTOCOMPACT_PCT_OVERRIDE, this.env.ANTHROPIC_MODEL, settings.model,
    ])).digest('hex');
  }

  async load(sessionId?: string, workingDir?: string): Promise<void> {
    let cached: Record<string, unknown> = {};
    try { cached = await readJsonFileSafe(this.cacheFile); } catch { /* Optional cache must not prevent a launch. */ }
    for (const [key, value] of Object.entries(cached)) {
      const row = record(value);
      const limit = positive(row.limit);
      if (limit && typeof row.at === 'number' && Date.now() - row.at < CACHE_TTL && row.at <= Date.now()) this.limits.set(key, limit);
    }
    if (!sessionId || !workingDir || !/^[a-zA-Z0-9_-]+$/.test(sessionId)) return;
    // Reopened sessions need a preflight before their first API request too.
    // Read at most 2 MiB; never load a large conversation into backend memory.
    try {
      const path = join(await getProjectSessionsPath(workingDir), `${sessionId}.jsonl`);
      if (!existsSync(path)) return;
      const file = await open(path, 'r');
      try {
        const { size } = await file.stat();
        const start = Math.max(0, size - 2 * 1024 * 1024);
        const buffer = Buffer.alloc(size - start);
        const { bytesRead } = await file.read(buffer, 0, buffer.length, start);
        const lines = buffer.subarray(0, bytesRead).toString('utf8').split('\n');
        if (start) lines.shift();
        for (const line of lines) {
          try {
            const event = JSON.parse(line) as Record<string, unknown>;
            if (event.isSidechain) continue;
            this.observe(event);
            const timestamp = typeof event.timestamp === 'string' ? Date.parse(event.timestamp) : NaN;
            if ((event.isApiErrorMessage || event.is_api_error_message) &&
              (!Number.isFinite(timestamp) || Date.now() - timestamp < CACHE_TTL)) {
              const blocks = record(event.message).content;
              if (Array.isArray(blocks)) this.learnError(blocks.filter(b => b?.type === 'text').map(b => b.text).join('\n'));
            }
          } catch { /* Partial trailing entry is not a failure. */ }
        }
      } finally { await file.close(); }
    } catch { /* Missing or unreadable transcript: native CLI compaction still applies. */ }
  }

  setModel(model: string): void {
    if (model === this.model) return;
    this.model = model;
    this.reportedWindow = undefined;
    this.reportedOutput = undefined;
    this.inputTokens = this.outputTokens = 0;
    this.hasUsage = false;
  }

  /**
   * The model's id, plus the ids the env maps it to while it is 'default' or a
   * family alias (ANTHROPIC_DEFAULT_SONNET_MODEL and so on). Before the CLI's
   * first init names the real model, these are the only names a gateway's model
   * goes by.
   */
  modelNames(): string[] {
    const alias = /^(opus|sonnet|haiku)(?:\[.*\])?$/.exec(this.model)?.[1];
    if (this.model !== 'default' && !alias) return [this.model];
    const families = alias ? [alias] : ['opus', 'sonnet', 'haiku'];
    const mapped = families.map(family => this.env[`ANTHROPIC_DEFAULT_${family.toUpperCase()}_MODEL`]);
    return [this.model, ...mapped.filter((name): name is string => typeof name === 'string' && name.length > 0)];
  }

  learnError(text: string): void {
    const limit = contextLimitFromError(text);
    if (!limit) return;
    // Persist only a hash of the model name and its numeric limit.
    const key = this.modelKey();
    this.limits.set(key, limit);
    void updateJsonFile(this.cacheFile, (current) => {
      const entries = Object.entries(current).filter(([k, v]) => k !== key &&
        typeof record(v).at === 'number' && Date.now() - Number(record(v).at) < CACHE_TTL).slice(-127);
      return { ...Object.fromEntries(entries), [key]: { limit, at: Date.now() } };
    }).catch(() => {});
    const input = /(?:prompt contains at leas[et]\s+|input_tokens?\s*[=:]\s*)([\d,]+)/i.exec(text);
    if (input) { this.inputTokens = positive(input[1]) ?? this.inputTokens; this.hasUsage = true; }
  }

  observe(event: Record<string, unknown>): void {
    if (event.parent_tool_use_id || event.parentToolUseID) return;
    const message = record(event.message);
    if (event.type === 'system' && event.subtype === 'init' && typeof event.model === 'string') this.setModel(event.model);
    if (event.type === 'assistant' && !event.is_api_error_message && !event.isApiErrorMessage && !event.error) {
      if (typeof message.model === 'string' && message.model !== '<synthetic>') this.setModel(message.model);
      const usage = record(message.usage);
      if (typeof usage.input_tokens === 'number' && Number.isSafeInteger(usage.input_tokens) && usage.input_tokens >= 0) {
        this.inputTokens = usage.input_tokens + (positive(usage.cache_creation_input_tokens) ?? 0) + (positive(usage.cache_read_input_tokens) ?? 0);
        this.outputTokens = positive(usage.output_tokens) ?? 0;
        this.hasUsage = true;
      }
    }
    if (event.type === 'system' && event.subtype === 'compact_boundary') {
      // pre_tokens describes the discarded context, not the new summary size.
      this.inputTokens = this.outputTokens = 0;
      this.hasUsage = false;
    }
    if (event.type === 'result') {
      const usage = record(event.modelUsage);
      const keys = Object.keys(usage);
      const alias = /^(opus|sonnet|haiku)(?:\[.*\])?$/.exec(this.model)?.[1];
      const matchingAlias = alias ? keys.filter(key => key.includes(alias)) : [];
      const entry = usage[this.model] ?? usage[this.model.replace(/\[.*\]$/, '')] ??
        (matchingAlias.length === 1 ? usage[matchingAlias[0]] : this.model === 'default' && keys.length === 1 ? usage[keys[0]] : undefined);
      const data = record(entry);
      this.reportedWindow = positive(data.contextWindow) ?? this.reportedWindow;
      this.reportedOutput = positive(data.maxOutputTokens) ?? this.reportedOutput;
    }
  }

  private modelKey(): string { return createHash('sha256').update(this.model).digest('hex'); }
  get window(): number {
    const limits = [this.configuredWindow, this.limits.get(this.modelKey()), this.reportedWindow].filter((n): n is number => !!n);
    return limits.length ? Math.min(...limits) : 0;
  }
  get maxOutput(): number {
    // modelUsage reports a capability cap, not necessarily the requested output
    // budget. Never turn a 128K capability into a 128K reservation by accident.
    const base = Math.min(this.configuredOutput ?? 32000, this.reportedOutput ?? Infinity);
    // Keep long generated answers from reserving most of a constrained gateway
    // window. Respect an explicitly smaller output budget.
    const constrained = this.gateway || this.configuredWindow || this.limits.has(this.modelKey());
    const headroom = this.window && this.hasUsage ? Math.max(1024, this.window - this.inputTokens - this.outputTokens - SAFETY_TOKENS) : Infinity;
    const unconfirmedGateway = this.gateway && !this.configuredWindow && !this.limits.has(this.modelKey());
    return constrained
      ? Math.min(base, this.window && !unconfirmedGateway ? Math.max(1024, Math.floor(this.window * 0.1)) : 8192, headroom) : base;
  }
  get compactAt(): number {
    return this.window ? Math.max(1, Math.min(Math.floor(this.window * COMPACT_PERCENT / 100), this.window - this.maxOutput - SAFETY_TOKENS)) : 0;
  }
  shouldCompact(extraTokens = 0): boolean {
    return this.hasUsage && this.compactAt > 0 && this.inputTokens + this.outputTokens + extraTokens >= this.compactAt;
  }
  view(): ContextBudgetView {
    return { model: this.model, totalTokens: this.inputTokens, contextWindow: this.window, maxOutputTokens: this.maxOutput, compactAt: this.compactAt };
  }
  launchEnv(): Record<string, string> {
    // The CLI protects tool-loop requests too; the wrapper additionally checks
    // message boundaries. Its window has a 100K floor, so use the percentage
    // control to support gateways below that floor without disabling compact.
    const constrained = !!(this.gateway || this.configuredWindow || this.limits.has(this.modelKey()));
    const unconfirmedGateway = this.gateway && !this.configuredWindow && !this.limits.has(this.modelKey());
    // CLI metadata may be its native model table, not the gateway's capacity.
    // Never relax the initial gateway guard merely because that table arrives.
    const window = Math.max(100000, Math.min(unconfirmedGateway ? 100000 : 1000000, this.window || 1000000));
    const requestedWindow = positive(this.env.CLAUDE_CODE_AUTO_COMPACT_WINDOW);
    const actualWindow = requestedWindow ? Math.min(window, Math.max(100000, requestedWindow)) : window;
    const threshold = this.compactAt || Math.floor(actualWindow * COMPACT_PERCENT / 100);
    const percent = Math.max(1, Math.min(COMPACT_PERCENT, Math.floor(threshold / actualWindow * 100), positive(this.env.CLAUDE_AUTOCOMPACT_PCT_OVERRIDE) ?? 100));
    return {
      ...(constrained ? { CLAUDE_CODE_AUTO_COMPACT_WINDOW: String(actualWindow) } : {}),
      CLAUDE_AUTOCOMPACT_PCT_OVERRIDE: String(percent),
      ...(constrained ? { CLAUDE_CODE_MAX_OUTPUT_TOKENS: String(this.maxOutput) } : {}),
    };
  }
}

/** Conservative UTF-8 estimate for admission, not a claim of exact tokenization.
 * Image bytes are not text tokens; reserve a fixed image allowance instead. */
export function estimatePromptTokens(content: string, attachments?: Array<{ type: string; absolutePath?: string }>): number {
  return Buffer.byteLength(content, 'utf8') + (attachments ?? []).reduce((sum, att) =>
    sum + (att.type === 'image' ? 4096 : Buffer.byteLength(att.absolutePath ?? '', 'utf8') + 2), 0);
}
