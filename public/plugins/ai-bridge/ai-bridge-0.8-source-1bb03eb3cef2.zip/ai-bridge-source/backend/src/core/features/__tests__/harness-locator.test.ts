import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { mkdirSync, mkdtempSync, readFileSync, rmSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { fileURLToPath, pathToFileURL } from 'url';
import { harnessNode, locateHarness, managedHarnessDir, withDshProviders } from '../harness-locator';

/** Writes an installed package the way npm lays it out: package.json plus its bin file. */
function writePackage(dir: string, name: string, command: string, bin: string, content = '#!/usr/bin/env node\n'): string {
  mkdirSync(join(dir, bin, '..'), { recursive: true });
  writeFileSync(join(dir, 'package.json'), JSON.stringify({ name, bin: { [command]: bin } }));
  writeFileSync(join(dir, bin), content);
  return join(dir, bin);
}

describe('harness locator', () => {
  let home: string;
  const noEnv: NodeJS.ProcessEnv = {};

  beforeEach(() => {
    home = mkdtempSync(join(tmpdir(), 'ai-bridge-harness-'));
  });

  afterEach(() => {
    rmSync(home, { recursive: true, force: true });
  });

  it('runs the copy AI Bridge installed, with its own node, before looking at PATH', async () => {
    const pkg = join(managedHarnessDir('deepseek', home), 'node_modules', '@deepseek-ai', 'dsh');
    const entry = writePackage(pkg, '@deepseek-ai/dsh', 'dsh', 'lib/bin.js');

    const { located } = await locateHarness('deepseek', null, { home, env: noEnv });

    expect(located).toEqual({ command: [harnessNode(), entry, '--profile', 'acp'], source: 'managed', location: entry });
  });

  /** A deepseek-harness checkout with tsx installed; `api` adds tsx's `./esm/api` export. */
  function writeCheckout(api: boolean): { repo: string; tsx: string } {
    const repo = join(home, 'deepseek-harness');
    mkdirSync(join(repo, 'apps', 'cli', 'src'), { recursive: true });
    writeFileSync(join(repo, 'apps', 'cli', 'src', 'bin.ts'), '');
    const tsx = join(repo, 'node_modules', 'tsx');
    mkdirSync(join(tsx, 'dist', 'esm', 'api'), { recursive: true });
    const exports = { './esm': './dist/esm/index.mjs', ...(api ? { './esm/api': { import: { default: './dist/esm/api/index.mjs' } } } : {}) };
    writeFileSync(join(tsx, 'package.json'), JSON.stringify({ name: 'tsx', exports }));
    writeFileSync(join(tsx, 'dist', 'esm', 'index.mjs'), '');
    if (api) writeFileSync(join(tsx, 'dist', 'esm', 'api', 'index.mjs'), '');
    return { repo, tsx };
  }

  it('runs a deepseek-harness source checkout like `pnpm dsh`, with the checkout\'s tsconfig', async () => {
    const { repo, tsx } = writeCheckout(true);

    const { located } = await locateHarness('deepseek', repo, { home, env: noEnv });

    const [node, flag, loaderUrl, ...rest] = located!.command;
    expect([node, flag, ...rest]).toEqual([harnessNode(), '--import', join(repo, 'apps', 'cli', 'src', 'bin.ts'), '--profile', 'acp']);
    expect(located).toMatchObject({ source: 'setting', location: repo });
    // The project is the working directory, so tsx is told where the checkout's tsconfig is.
    const loader = fileURLToPath(loaderUrl);
    expect(loader.startsWith(join(managedHarnessDir('deepseek', home), 'source'))).toBe(true);
    const text = readFileSync(loader, 'utf8');
    expect(text).toContain(`import { register } from ${JSON.stringify(pathToFileURL(join(tsx, 'dist', 'esm', 'api', 'index.mjs')).href)};`);
    expect(text).toContain(`register({ tsconfig: ${JSON.stringify(join(repo, 'tsconfig.json'))} });`);

    const again = await locateHarness('deepseek', repo, { home, env: noEnv });
    expect(again.located!.command).toEqual(located!.command);
  });

  it('falls back to tsx/esm when the checkout\'s tsx has no register API', async () => {
    const { repo, tsx } = writeCheckout(false);

    const { located } = await locateHarness('deepseek', repo, { home, env: noEnv });

    expect(located!.command.slice(0, 3)).toEqual([harnessNode(), '--import', pathToFileURL(join(tsx, 'dist', 'esm', 'index.mjs')).href]);
  });

  it('accepts an npm install folder and runs a native bin directly', async () => {
    const prefix = join(home, 'tools');
    const entry = writePackage(join(prefix, 'node_modules', '@opencode', 'cli'), '@opencode/cli', 'opencode', 'bin/opencode.exe', 'MZ');

    const { located } = await locateHarness('opencode', prefix, { home, env: noEnv });

    expect(located).toEqual({ command: [entry, 'acp'], source: 'setting', location: entry });
  });

  it('reports a location that does not exist and still finds the harness elsewhere', async () => {
    const pkg = join(managedHarnessDir('deepseek', home), 'node_modules', '@deepseek-ai', 'dsh');
    writePackage(pkg, '@deepseek-ai/dsh', 'dsh', 'lib/bin.js');
    const missing = join(home, 'nowhere');

    const { located, settingError } = await locateHarness('deepseek', missing, { home, env: noEnv });

    expect(settingError).toBe(`${missing} does not exist.`);
    expect(located?.source).toBe('managed');
  });

  it('prefers the AI_BRIDGE_HARNESS_COMMAND override over AI Bridge\'s copy', async () => {
    writePackage(join(managedHarnessDir('deepseek', home), 'node_modules', '@deepseek-ai', 'dsh'), '@deepseek-ai/dsh', 'dsh', 'lib/bin.js');

    const { located } = await locateHarness('deepseek', null, {
      home,
      env: { AI_BRIDGE_HARNESS_COMMAND: JSON.stringify(['C:/tools/dsh.exe', '--profile', 'acp']) },
    });

    expect(located).toEqual({ command: ['C:/tools/dsh.exe', '--profile', 'acp'], source: 'env', location: 'C:/tools/dsh.exe --profile acp' });
  });

  it('hands dsh the user\'s providers with --patch, before the app\'s --profile acp', () => {
    const profile = join(home, '.dsh', 'profiles', 'web');
    mkdirSync(profile, { recursive: true });
    writeFileSync(join(profile, 'cordis.patch.yml'), '- id: agent-default-model\n  config:\n    provider: deepseek-official\n    model: deepseek-v4-pro\n');
    const command = ['node', 'bin.ts', '--profile', 'acp'];

    const patched = withDshProviders(command, { home, env: {} });

    expect(patched.slice(0, 3)).toEqual(['node', 'bin.ts', '--patch']);
    expect(patched.slice(4)).toEqual(['--profile', 'acp']);
    expect(patched[3].startsWith(join(managedHarnessDir('deepseek', home), 'patches'))).toBe(true);
    expect(withDshProviders(command, { home: join(home, 'empty'), env: {} })).toEqual(command);
  });

  it('runs scripts on this backend\'s node only when it is new enough for dsh', () => {
    expect(harnessNode('24.1.0', '/opt/node')).toBe('/opt/node');
    expect(harnessNode('22.19.0', '/opt/node')).toBe('/opt/node');
    expect(harnessNode('22.12.0', '/opt/node')).toBe('node');
    expect(harnessNode('20.18.1', '/opt/node')).toBe('node');
  });
});
