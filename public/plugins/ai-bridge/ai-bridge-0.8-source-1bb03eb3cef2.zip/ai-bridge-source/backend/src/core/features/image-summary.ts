import { createHash } from 'crypto';
import { mkdtemp, rm, writeFile } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import { PNG } from 'pngjs';
import { decode as decodeJpeg } from 'jpeg-js';
import { GifReader } from 'omggif';
import { recognizeText, type OcrImage, type OcrResult } from './image-ocr';

/**
 * Describes an image in text for a model that cannot see images (the
 * textOnlyModels setting). Everything runs on the CPU, in this process plus
 * the operating system's own OCR:
 *
 *   - Text: what the OCR engine reads, with where each piece sits.
 *   - Layout: the one-color shapes (panels, buttons, frames, divider lines),
 *     nested by containment, each with the text inside it.
 *   - Almost aligned: neighbouring shapes whose edges miss by a few pixels.
 *   - Colors and a coarse color grid, for images that are not interfaces.
 *
 * It is not sight. Positions, sizes, colors and text survive; shapes of icons,
 * photos and "does this look right" do not.
 */

export interface ImageAttachment { fileName: string; mimeType: string; base64: string }

/** RGBA, row by row. */
export interface Pixels { width: number; height: number; data: Uint8Array }

type Format = 'PNG' | 'JPEG' | 'GIF' | 'WebP';

function sniff(bytes: Buffer): Format | null {
  if (bytes.length >= 8 && bytes.readUInt32BE(0) === 0x89504e47) return 'PNG';
  if (bytes.length >= 3 && bytes[0] === 0xff && bytes[1] === 0xd8) return 'JPEG';
  if (bytes.length >= 6 && bytes.toString('latin1', 0, 4) === 'GIF8') return 'GIF';
  if (bytes.length >= 30 && bytes.toString('latin1', 0, 4) === 'RIFF' && bytes.toString('latin1', 8, 12) === 'WEBP') return 'WebP';
  return null;
}

/** The pixels of a PNG, a JPEG or a GIF's first frame; null for other formats. */
export function decodeImage(bytes: Buffer): Pixels | null {
  switch (sniff(bytes)) {
    case 'PNG': {
      const png = PNG.sync.read(bytes);
      return { width: png.width, height: png.height, data: png.data };
    }
    case 'JPEG': {
      const image = decodeJpeg(bytes, { useTArray: true, formatAsRGBA: true, maxResolutionInMP: 200, maxMemoryUsageInMB: 1024 });
      return { width: image.width, height: image.height, data: image.data };
    }
    case 'GIF': {
      const gif = new GifReader(bytes);
      const data = new Uint8Array(gif.width * gif.height * 4);
      gif.decodeAndBlitFrameRGBA(0, data);
      return { width: gif.width, height: gif.height, data };
    }
    default:
      return null;
  }
}

/** A WebP's size from its header. WebP is not decoded here, but OCR still reads it. */
function webpSize(bytes: Buffer): { width: number; height: number } | null {
  switch (bytes.toString('latin1', 12, 16)) {
    case 'VP8X': return { width: 1 + bytes.readUIntLE(24, 3), height: 1 + bytes.readUIntLE(27, 3) };
    case 'VP8L': {
      const bits = bytes.readUInt32LE(21);
      return { width: 1 + (bits & 0x3fff), height: 1 + ((bits >>> 14) & 0x3fff) };
    }
    case 'VP8 ': return { width: bytes.readUInt16LE(26) & 0x3fff, height: bytes.readUInt16LE(28) & 0x3fff };
    default: return null;
  }
}

// ─── Analysis ────────────────────────────────────────────────────────────────

export interface Box { x: number; y: number; w: number; h: number }
export interface TextItem extends Box { text: string }

export interface Region extends Box {
  /** area: a filled shape; frame: a border around something; line: a divider. */
  kind: 'area' | 'frame' | 'line';
  color: number;
  /** Index of the smallest shape this one lies inside, or -1. */
  parent: number;
  texts: string[];
}

export interface ImageAnalysis {
  /** Original pixels per analysed pixel (1 unless the image was very large). */
  factor: number;
  regions: Region[];
  palette: Array<{ color: number; share: number }>;
  grid: { cols: number; rows: number; cellW: number; cellH: number; colors: number[] };
}

/**
 * Above this many pixels the image is averaged down before the shapes are
 * traced. A 4K screen still fits, so its few-pixel misses are still found.
 */
const MAX_ANALYSED_PIXELS = 3840 * 2400;
/** How far (per channel) a pixel may be from where its shape started and still belong to it. */
const TOLERANCE = 12;
const MAX_SHAPES = 60;
const MAX_LINES = 20;

/** Packs RGB in one int, with transparency laid over white and blocks of `factor`² averaged. */
function flatten(pixels: Pixels, factor: number): { rgb: Int32Array; w: number; h: number } {
  const w = Math.max(1, Math.floor(pixels.width / factor));
  const h = Math.max(1, Math.floor(pixels.height / factor));
  const rgb = new Int32Array(w * h);
  const { data, width } = pixels;
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      let r = 0, g = 0, b = 0;
      for (let dy = 0; dy < factor; dy++) {
        for (let dx = 0; dx < factor; dx++) {
          const i = ((y * factor + dy) * width + x * factor + dx) * 4;
          const a = data[i + 3];
          r += (data[i] * a + 255 * (255 - a)) / 255;
          g += (data[i + 1] * a + 255 * (255 - a)) / 255;
          b += (data[i + 2] * a + 255 * (255 - a)) / 255;
        }
      }
      const n = factor * factor;
      rgb[y * w + x] = (Math.round(r / n) << 16) | (Math.round(g / n) << 8) | Math.round(b / n);
    }
  }
  return { rgb, w, h };
}

interface Traced { count: number; minX: number; minY: number; maxX: number; maxY: number; r: number; g: number; b: number }

/** Splits the image into connected runs of nearly one color (4-neighbour flood fill). */
function trace(rgb: Int32Array, w: number, h: number): { labels: Int32Array; shapes: Traced[] } {
  const n = w * h;
  const labels = new Int32Array(n).fill(-1);
  const stack = new Int32Array(n);
  const shapes: Traced[] = [];
  for (let start = 0; start < n; start++) {
    if (labels[start] !== -1) continue;
    const id = shapes.length;
    const seed = rgb[start];
    const r0 = (seed >> 16) & 255, g0 = (seed >> 8) & 255, b0 = seed & 255;
    const shape: Traced = { count: 0, minX: w, minY: h, maxX: 0, maxY: 0, r: 0, g: 0, b: 0 };
    let top = 0;
    const visit = (q: number) => {
      if (labels[q] !== -1) return;
      const c = rgb[q];
      if (Math.abs(((c >> 16) & 255) - r0) > TOLERANCE || Math.abs(((c >> 8) & 255) - g0) > TOLERANCE || Math.abs((c & 255) - b0) > TOLERANCE) return;
      labels[q] = id;
      stack[top++] = q;
    };
    labels[start] = id;
    stack[top++] = start;
    while (top > 0) {
      const p = stack[--top];
      const y = (p / w) | 0;
      const x = p - y * w;
      const c = rgb[p];
      shape.count++;
      shape.r += (c >> 16) & 255;
      shape.g += (c >> 8) & 255;
      shape.b += c & 255;
      if (x < shape.minX) shape.minX = x;
      if (x > shape.maxX) shape.maxX = x;
      if (y < shape.minY) shape.minY = y;
      if (y > shape.maxY) shape.maxY = y;
      if (x > 0) visit(p - 1);
      if (x < w - 1) visit(p + 1);
      if (y > 0) visit(p - w);
      if (y < h - 1) visit(p + w);
    }
    shapes.push(shape);
  }
  return { labels, shapes };
}

/** Whether a thin shape runs along all four sides of its box, like a border. */
function isFrame(labels: Int32Array, w: number, id: number, s: Traced): boolean {
  const band = 3;
  const covered = (from: number, to: number, at: (i: number, d: number) => number) => {
    let hits = 0;
    for (let i = from; i <= to; i++) {
      for (let d = 0; d < band; d++) {
        if (labels[at(i, d)] === id) { hits++; break; }
      }
    }
    return hits / (to - from + 1);
  };
  return covered(s.minX, s.maxX, (x, d) => (s.minY + d) * w + x) >= 0.6 &&
    covered(s.minX, s.maxX, (x, d) => (s.maxY - d) * w + x) >= 0.6 &&
    covered(s.minY, s.maxY, (y, d) => y * w + s.minX + d) >= 0.6 &&
    covered(s.minY, s.maxY, (y, d) => y * w + s.maxX - d) >= 0.6;
}

const contains = (outer: Box, inner: Box, margin = 0) =>
  inner.x >= outer.x - margin && inner.y >= outer.y - margin &&
  inner.x + inner.w <= outer.x + outer.w + margin && inner.y + inner.h <= outer.y + outer.h + margin;

/**
 * The shapes, colors and grid of an image. `texts` (from OCR) keeps glyphs from
 * being listed as shapes and is attached to the shape it sits in.
 */
export function analyzePixels(pixels: Pixels, texts: TextItem[] = []): ImageAnalysis {
  const factor = Math.max(1, Math.ceil(Math.sqrt(pixels.width * pixels.height / MAX_ANALYSED_PIXELS)));
  const { rgb, w, h } = flatten(pixels, factor);
  const { labels, shapes } = trace(rgb, w, h);
  const minArea = Math.max(64, w * h * 0.0004);
  const kept: Region[] = [];
  const lines: Region[] = [];
  shapes.forEach((s, id) => {
    const bw = s.maxX - s.minX + 1;
    const bh = s.maxY - s.minY + 1;
    const fill = s.count / (bw * bh);
    let kind: Region['kind'] | null = null;
    if ((bh <= 3 && bw >= 24) || (bw <= 3 && bh >= 24)) kind = fill >= 0.8 ? 'line' : null;
    else if (bw >= 16 && bh >= 12 && fill < 0.5 && s.count <= 6 * (bw + bh) && isFrame(labels, w, id, s)) kind = 'frame';
    else if (s.count >= minArea && bw >= 4 && bh >= 4) kind = 'area';
    if (!kind) return;
    const region: Region = {
      kind,
      color: (Math.round(s.r / s.count) << 16) | (Math.round(s.g / s.count) << 8) | Math.round(s.b / s.count),
      x: s.minX * factor, y: s.minY * factor, w: bw * factor, h: bh * factor,
      parent: -1, texts: [],
    };
    // Big letters are shapes of their own; the OCR already has them as text.
    if (kind !== 'line' && texts.some(t => contains(t, region, 3))) return;
    (kind === 'line' ? lines : kept).push(region);
  });
  const boxArea = (b: Box) => b.w * b.h;
  kept.sort((a, b) => boxArea(b) - boxArea(a));
  lines.sort((a, b) => Math.max(b.w, b.h) - Math.max(a.w, a.h));
  const shapesKept = kept.slice(0, MAX_SHAPES);
  const regions = [...shapesKept, ...lines.slice(0, MAX_LINES)];
  regions.forEach((region, i) => {
    let best = -1;
    for (let j = 0; j < shapesKept.length; j++) {
      if (j === i || boxArea(shapesKept[j]) < boxArea(region) || (boxArea(shapesKept[j]) === boxArea(region) && j > i)) continue;
      if (contains(shapesKept[j], region) && (best === -1 || boxArea(shapesKept[j]) < boxArea(shapesKept[best]))) best = j;
    }
    region.parent = best;
  });
  for (const text of texts) {
    const cx = text.x + text.w / 2, cy = text.y + text.h / 2;
    let best = -1;
    shapesKept.forEach((region, i) => {
      if (cx >= region.x && cx < region.x + region.w && cy >= region.y && cy < region.y + region.h &&
        (best === -1 || boxArea(region) < boxArea(shapesKept[best]))) best = i;
    });
    if (best >= 0) shapesKept[best].texts.push(text.text);
  }
  return { factor, regions, palette: palette(rgb), grid: grid(rgb, w, h, factor) };
}

/** The most common colors (5 bits per channel), each at least 1% of the image. */
function palette(rgb: Int32Array): ImageAnalysis['palette'] {
  const counts = new Float64Array(32768);
  const sums = new Float64Array(32768 * 3);
  for (let i = 0; i < rgb.length; i++) {
    const c = rgb[i];
    const key = ((c >> 19) & 31) << 10 | ((c >> 11) & 31) << 5 | ((c >> 3) & 31);
    counts[key]++;
    sums[key * 3] += (c >> 16) & 255;
    sums[key * 3 + 1] += (c >> 8) & 255;
    sums[key * 3 + 2] += c & 255;
  }
  const keys = [...counts.keys()].filter(k => counts[k] / rgb.length >= 0.01).sort((a, b) => counts[b] - counts[a]).slice(0, 8);
  return keys.map(k => ({
    color: (Math.round(sums[k * 3] / counts[k]) << 16) | (Math.round(sums[k * 3 + 1] / counts[k]) << 8) | Math.round(sums[k * 3 + 2] / counts[k]),
    share: counts[k] / rgb.length,
  }));
}

/** Average colors over a grid of 16 cells along the longer side. */
function grid(rgb: Int32Array, w: number, h: number, factor: number): ImageAnalysis['grid'] {
  const cols = w >= h ? Math.min(16, w) : Math.max(1, Math.min(w, Math.round(16 * w / h)));
  const rows = h >= w ? Math.min(16, h) : Math.max(1, Math.min(h, Math.round(16 * h / w)));
  const colors: number[] = [];
  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      const x0 = Math.floor(col * w / cols), x1 = Math.floor((col + 1) * w / cols);
      const y0 = Math.floor(row * h / rows), y1 = Math.floor((row + 1) * h / rows);
      let r = 0, g = 0, b = 0;
      for (let y = y0; y < y1; y++) {
        for (let x = x0; x < x1; x++) {
          const c = rgb[y * w + x];
          r += (c >> 16) & 255; g += (c >> 8) & 255; b += c & 255;
        }
      }
      const n = Math.max(1, (x1 - x0) * (y1 - y0));
      colors.push((Math.round(r / n) << 16) | (Math.round(g / n) << 8) | Math.round(b / n));
    }
  }
  return { cols, rows, cellW: Math.round(w * factor / cols), cellH: Math.round(h * factor / rows), colors };
}

// ─── Text ────────────────────────────────────────────────────────────────────

const MAX_TEXTS = 150;

/**
 * OCR lines as positioned pieces. A line is split where its words are far
 * apart, since an engine reading a toolbar puts separate buttons on one line.
 */
export function textItems(ocr: OcrResult | undefined): TextItem[] {
  const items: TextItem[] = [];
  for (const line of ocr?.lines ?? []) {
    const words = [...line.words].sort((a, b) => a.x - b.x);
    const height = Math.max(...words.map(word => word.h));
    let piece = [words[0]];
    const flush = () => {
      const x = Math.min(...piece.map(word => word.x)), y = Math.min(...piece.map(word => word.y));
      items.push({
        text: piece.map(word => word.text).join(' ').slice(0, 120),
        x: Math.round(x), y: Math.round(y),
        w: Math.round(Math.max(...piece.map(word => word.x + word.w)) - x),
        h: Math.round(Math.max(...piece.map(word => word.y + word.h)) - y),
      });
    };
    for (const word of words.slice(1)) {
      const previous = piece[piece.length - 1];
      if (word.x - (previous.x + previous.w) > Math.max(2 * height, 20)) {
        flush();
        piece = [word];
      } else {
        piece.push(word);
      }
    }
    flush();
  }
  return items.sort((a, b) => a.y - b.y || a.x - b.x).slice(0, MAX_TEXTS);
}

// ─── Formatting ──────────────────────────────────────────────────────────────

const hex = (color: number) => `#${color.toString(16).padStart(6, '0').toUpperCase()}`;
const box = (b: Box) => `${b.x},${b.y} ${b.w}x${b.h}`;

function describeRegion(region: Region): string {
  const text = region.texts.length ? ` "${region.texts.join(' / ').slice(0, 60)}"` : '';
  return `${region.kind} ${hex(region.color)} ${box(region)}${text}`;
}

/** Neighbouring shapes (same parent) whose edges miss each other by 1–6 pixels. */
export function nearMisses(regions: Region[], minimum = 1): string[] {
  const out: string[] = [];
  const shapes = regions.map((region, index) => ({ region, index })).filter(({ region }) => region.kind !== 'line' && region.w >= 8 && region.h >= 8);
  const off = (a: number, b: number) => { const d = Math.abs(a - b); return d >= minimum && d <= 6; };
  for (let i = 0; i < shapes.length; i++) {
    for (let j = i + 1; j < shapes.length; j++) {
      const a = shapes[i].region, b = shapes[j].region;
      if (a.parent !== b.parent) continue;
      const rowOverlap = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
      const colOverlap = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x);
      const notes: string[] = [];
      if (rowOverlap >= Math.min(a.h, b.h) / 2) {
        if (off(a.y, b.y)) notes.push(`top ${a.y} vs ${b.y}`);
        if (off(a.y + a.h, b.y + b.h)) notes.push(`bottom ${a.y + a.h} vs ${b.y + b.h}`);
        if (off(a.h, b.h)) notes.push(`height ${a.h} vs ${b.h}`);
      }
      if (colOverlap >= Math.min(a.w, b.w) / 2) {
        if (off(a.x, b.x)) notes.push(`left ${a.x} vs ${b.x}`);
        if (off(a.x + a.w, b.x + b.w)) notes.push(`right ${a.x + a.w} vs ${b.x + b.w}`);
        if (off(a.w, b.w)) notes.push(`width ${a.w} vs ${b.w}`);
      }
      if (notes.length) out.push(`${describeRegion(a)} and ${describeRegion(b)}: ${notes.join(', ')}`);
      if (out.length >= 12) return out;
    }
  }
  return out;
}

export interface SummaryInput {
  fileName: string;
  format: string;
  width?: number;
  height?: number;
  analysis?: ImageAnalysis;
  /** Why there is no analysis, when there is none. */
  analysisNote?: string;
  ocr?: OcrResult;
  texts: TextItem[];
}

/** The Layout, Almost aligned, Colors and Color grid lines of a description. */
export function formatAnalysis(analysis: ImageAnalysis, format: string): string[] {
  const out: string[] = [];
  const { regions } = analysis;
  if (regions.length === 0) out.push('Layout: no clear one-color shapes.');
  else {
    out.push('Layout (one-color shapes: area = filled, frame = border, line = divider; indented = inside the shape above; largest first):');
    const children = new Map<number, number[]>();
    regions.forEach((region, index) => children.set(region.parent, [...(children.get(region.parent) ?? []), index]));
    const walk = (parent: number, depth: number) => {
      for (const index of children.get(parent) ?? []) {
        out.push(`${'  '.repeat(depth)}- ${describeRegion(regions[index])}`);
        walk(index, depth + 1);
      }
    };
    walk(-1, 0);
    // Averaging a huge image down blurs edges by more than these misses.
    const misses = analysis.factor === 1 ? nearMisses(regions, format === 'JPEG' ? 2 : 1) : [];
    if (misses.length) {
      out.push('', 'Almost aligned (shapes side by side whose edges differ by a few pixels, often a layout slip):');
      for (const miss of misses) out.push(`- ${miss}`);
    }
  }
  out.push('', analysis.palette.length
    ? `Colors: ${analysis.palette.map(p => `${hex(p.color)} ${Math.round(p.share * 100)}%`).join(', ')}`
    : 'Colors: no one color covers 1% of the image (a gradient or noise); see the grid.');
  const { cols, rows, cellW, cellH, colors } = analysis.grid;
  out.push('', `Color grid (${cols}x${rows} cells of about ${cellW}x${cellH} px, average color, rows top to bottom):`);
  for (let row = 0; row < rows; row++) {
    out.push(colors.slice(row * cols, (row + 1) * cols).map(c => hex(c).slice(1)).join(' '));
  }
  return out;
}

export function formatSummary(input: SummaryInput): string {
  const attr = (value: string) => value.replace(/["<>]/g, '_');
  const size = input.width && input.height ? ` size="${input.width}x${input.height}"` : '';
  const out = [
    `<image-summary file="${attr(input.fileName)}" format="${input.format}"${size}>`,
    'An image is attached here. The current model does not read images, so AI Bridge describes it in text instead. ' +
      'Positions are in the image\'s pixels, x to the right and y down from the top-left corner; a box is "x,y WxH".',
    '',
  ];

  const ocr = input.ocr;
  if (!ocr) out.push('Text: not read.');
  else if (ocr.error) out.push(`Text: not read (${ocr.engine}: ${ocr.error}).`);
  else if (input.texts.length === 0) out.push(`Text (${ocr.engine}): none found.`);
  else {
    const language = ocr.language ? `, read as ${ocr.language}; letters that language lacks may come out wrong` : '';
    out.push(`Text (${ocr.engine}${language}):`);
    for (const item of input.texts) out.push(`- ${JSON.stringify(item.text)} ${box(item)}`);
  }
  out.push('');

  if (!input.analysis) out.push(`Layout and colors: not available (${input.analysisNote ?? 'the image could not be decoded'}).`);
  else out.push(...formatAnalysis(input.analysis, input.format));
  out.push('</image-summary>');
  return out.join('\n');
}

// ─── Entry point ─────────────────────────────────────────────────────────────

const cache = new Map<string, string>();
const CACHE_SIZE = 32;

export interface SummaryOptions {
  /**
   * Multiplies every position and size in the description. A screenshot is read
   * from a sharper capture than the one its coordinates refer to, since small
   * text in a scaled-down screen is past reading.
   */
  scale?: number;
}

/** The same description with positions and sizes multiplied by `scale`. */
function scaleInput(input: SummaryInput, scale: number): SummaryInput {
  if (scale === 1) return input;
  const n = (value: number) => Math.round(value * scale);
  const box = <T extends Box>(b: T): T => ({ ...b, x: n(b.x), y: n(b.y), w: Math.max(1, n(b.w)), h: Math.max(1, n(b.h)) });
  const analysis = input.analysis && {
    ...input.analysis,
    regions: input.analysis.regions.map(box),
    grid: { ...input.analysis.grid, cellW: n(input.analysis.grid.cellW), cellH: n(input.analysis.grid.cellH) },
  };
  return {
    ...input,
    width: input.width && n(input.width),
    height: input.height && n(input.height),
    texts: input.texts.map(box),
    analysis,
  };
}

/**
 * A text description for each image, in order. Images seen recently come from
 * a cache, so a retried or re-sent message does not read them again.
 */
export async function summarizeImages(images: ImageAttachment[], options: SummaryOptions = {}): Promise<string[]> {
  const scale = options.scale ?? 1;
  const keys = images.map(image => `${createHash('sha256').update(image.base64).digest('hex')}:${scale}`);
  const pending = images
    .map((image, index) => ({ image, index, key: keys[index] }))
    .filter(({ key }) => !cache.has(key));

  if (pending.length > 0) {
    const dir = await mkdtemp(join(tmpdir(), 'ai-bridge-image-'));
    try {
      const prepared = await Promise.all(pending.map(async ({ image, index, key }) => {
        const bytes = Buffer.from(image.base64, 'base64');
        const format = sniff(bytes);
        let pixels: Pixels | null = null;
        let note: string | undefined;
        try {
          pixels = decodeImage(bytes);
          if (!pixels) note = format === 'WebP' ? 'WebP is not decoded here' : 'not a PNG, JPEG, GIF or WebP image';
        } catch (error) {
          note = `could not decode it: ${error instanceof Error ? error.message : String(error)}`;
        }
        const size = pixels ?? (format === 'WebP' ? webpSize(bytes) : null);
        const path = join(dir, `${index}.${(format ?? 'bin').toLowerCase()}`);
        if (size) await writeFile(path, bytes);
        return { image, key, format, pixels, note, size, path };
      }));
      const readable = prepared.filter(p => p.size);
      const ocrImages: OcrImage[] = readable.map(p => ({ path: p.path, width: p.size!.width, height: p.size!.height }));
      const ocrResults = await recognizeText(ocrImages);
      for (const p of prepared) {
        const ocr = p.size ? ocrResults[readable.indexOf(p)] : undefined;
        const texts = textItems(ocr && !ocr.error ? ocr : undefined);
        const summary = formatSummary(scaleInput({
          fileName: p.image.fileName,
          format: p.format ?? p.image.mimeType,
          width: p.size?.width,
          height: p.size?.height,
          analysis: p.pixels ? analyzePixels(p.pixels, texts) : undefined,
          analysisNote: p.note,
          ocr,
          texts,
        }, scale));
        cache.set(p.key, summary);
        if (cache.size > CACHE_SIZE) cache.delete(cache.keys().next().value!);
      }
    } finally {
      await rm(dir, { recursive: true, force: true });
    }
  }
  return keys.map(key => cache.get(key)!);
}

/**
 * A message's images as content blocks: image blocks, or with `asText` (a
 * text-only model) one text block describing each. A description that fails
 * still never lets the image through to a model that would fail on it.
 */
export async function imageBlocks(
  images: ImageAttachment[],
  asText: boolean,
  describe: (images: ImageAttachment[]) => Promise<string[]> = summarizeImages,
): Promise<Array<Record<string, unknown>>> {
  if (!asText) {
    return images.map(image => ({ type: 'image', source: { type: 'base64', media_type: image.mimeType, data: image.base64 } }));
  }
  try {
    return (await describe(images)).map(text => ({ type: 'text', text }));
  } catch (error) {
    const reason = error instanceof Error ? error.message : String(error);
    console.error('[node-backend]', `Could not describe the images: ${reason}`);
    return [{
      type: 'text',
      text: `[${images.length} attached image(s) left out: the current model does not read images, and AI Bridge could not describe them (${reason}).]`,
    }];
  }
}
