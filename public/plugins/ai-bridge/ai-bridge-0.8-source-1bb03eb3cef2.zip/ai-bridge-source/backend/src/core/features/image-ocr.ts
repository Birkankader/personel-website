import { spawn } from 'child_process';

/**
 * Reads the text in images with the OCR engine the operating system already
 * has, so it runs on the CPU and installs nothing:
 *
 *   - Windows: Windows.Media.Ocr (Windows 10 and 11), through PowerShell.
 *   - macOS: the Vision framework, through osascript (JavaScript for Automation).
 *   - Linux: `tesseract`, when it is on PATH.
 *
 * Used by image-summary.ts to describe an image to a model that cannot see it.
 * Failure is never fatal: the image is then described without its text.
 */

/** A recognized word (or a whole line, when the engine gives no words), in the image's pixels. */
export interface OcrWord { text: string; x: number; y: number; w: number; h: number }
export interface OcrLine { words: OcrWord[] }
export interface OcrResult {
  engine: string;
  /** The language the engine read in, when it says. */
  language?: string;
  lines: OcrLine[];
  error?: string;
}
export interface OcrImage { path: string; width: number; height: number }

const TIMEOUT_MS = 30_000;

/**
 * Windows.Media.Ocr. The user's own languages come first; when none of them has
 * an OCR pack installed, any installed one is better than nothing. Small UI
 * text reads better, and its boxes come out tighter, at twice the size, so the
 * image is scaled up for recognition and the boxes scaled back.
 */
const WINDOWS_SCRIPT = String.raw`
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics, ContentType = WindowsRuntime]
$asTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation${'`'}1'
} | Select-Object -First 1
function Await($operation, [Type]$type) {
  $task = $asTask.MakeGenericMethod($type).Invoke($null, @($operation))
  [void]$task.Wait(-1)
  $task.Result
}
$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if ($engine -eq $null) {
  foreach ($l in [Windows.Media.Ocr.OcrEngine]::AvailableRecognizerLanguages) {
    $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage($l)
    if ($engine -ne $null) { break }
  }
}
foreach ($path in (ConvertFrom-Json $env:AI_BRIDGE_OCR_FILES)) {
  $r = @{}
  $stream = $null
  try {
    if ($engine -eq $null) { throw 'No OCR language is installed in Windows.' }
    $file = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
    $stream = Await ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    $decoder = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
    $w = $decoder.PixelWidth; $h = $decoder.PixelHeight
    $scale = [Math]::Min(2.0, [Windows.Media.Ocr.OcrEngine]::MaxImageDimension / [Math]::Max($w, $h))
    $transform = New-Object Windows.Graphics.Imaging.BitmapTransform
    $transform.ScaledWidth = [uint32][Math]::Round($w * $scale)
    $transform.ScaledHeight = [uint32][Math]::Round($h * $scale)
    $transform.InterpolationMode = [Windows.Graphics.Imaging.BitmapInterpolationMode]::Fant
    $bitmap = Await ($decoder.GetSoftwareBitmapAsync([Windows.Graphics.Imaging.BitmapPixelFormat]::Bgra8, [Windows.Graphics.Imaging.BitmapAlphaMode]::Premultiplied, $transform, [Windows.Graphics.Imaging.ExifOrientationMode]::IgnoreExifOrientation, [Windows.Graphics.Imaging.ColorManagementMode]::DoNotColorManage)) ([Windows.Graphics.Imaging.SoftwareBitmap])
    $result = Await ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
    $r.language = $engine.RecognizerLanguage.LanguageTag
    $r.lines = @($result.Lines | ForEach-Object {
      @{ words = @($_.Words | ForEach-Object {
        $b = $_.BoundingRect
        @{ text = $_.Text; x = $b.X / $scale; y = $b.Y / $scale; w = $b.Width / $scale; h = $b.Height / $scale }
      }) }
    })
  } catch { $r.error = $_.Exception.Message }
  finally { if ($stream -ne $null) { $stream.Dispose() } }
  [Console]::Out.WriteLine((ConvertTo-Json $r -Compress -Depth 6))
}
`;

/**
 * VNRecognizeTextRequest. Its boxes are fractions of the image with the origin
 * at the bottom-left; they are turned into pixels on our side.
 */
const MAC_SCRIPT = `
ObjC.import('Foundation');
ObjC.import('Vision');
function run(argv) {
  const results = [];
  for (const path of argv) {
    try {
      const url = $.NSURL.fileURLWithPath(path);
      const handler = $.VNImageRequestHandler.alloc.initWithURLOptions(url, $.NSDictionary.dictionary);
      const request = $.VNRecognizeTextRequest.alloc.init;
      request.recognitionLevel = 0;
      request.usesLanguageCorrection = true;
      if (request.respondsToSelector('setAutomaticallyDetectsLanguage:')) request.automaticallyDetectsLanguage = true;
      if (!handler.performRequestsError($([request]), null)) throw new Error('Vision could not read the image');
      const lines = [];
      const observations = request.results;
      for (let i = 0; i < observations.count; i++) {
        const observation = observations.objectAtIndex(i);
        const box = observation.boundingBox;
        lines.push({
          text: ObjC.unwrap(observation.topCandidates(1).firstObject.string),
          x: box.origin.x, y: 1 - box.origin.y - box.size.height, w: box.size.width, h: box.size.height,
        });
      }
      results.push({ lines });
    } catch (e) {
      results.push({ error: String(e) });
    }
  }
  return JSON.stringify(results);
}
`;

interface RunResult { stdout: string; stderr: string; code: number | null }

function run(command: string, args: string[], env?: NodeJS.ProcessEnv): Promise<RunResult> {
  return new Promise((resolve, reject) => {
    const child = spawn(command, args, { stdio: ['ignore', 'pipe', 'pipe'], windowsHide: true, env: env ?? process.env });
    const stdout: Buffer[] = [];
    const stderr: Buffer[] = [];
    const timer = setTimeout(() => {
      child.kill();
      reject(new Error(`${command} did not finish within ${TIMEOUT_MS / 1000} seconds`));
    }, TIMEOUT_MS);
    child.stdout.on('data', (chunk: Buffer) => stdout.push(chunk));
    child.stderr.on('data', (chunk: Buffer) => stderr.push(chunk));
    child.on('error', (error) => { clearTimeout(timer); reject(error); });
    child.on('close', (code) => {
      clearTimeout(timer);
      resolve({ stdout: Buffer.concat(stdout).toString('utf8'), stderr: Buffer.concat(stderr).toString('utf8'), code });
    });
  });
}

function finite(value: unknown): number {
  return typeof value === 'number' && Number.isFinite(value) ? value : 0;
}

function toWord(raw: unknown, scaleX = 1, scaleY = 1): OcrWord | null {
  const word = raw as Record<string, unknown> | null;
  if (!word || typeof word.text !== 'string' || !word.text.trim()) return null;
  return { text: word.text.trim(), x: finite(word.x) * scaleX, y: finite(word.y) * scaleY, w: finite(word.w) * scaleX, h: finite(word.h) * scaleY };
}

async function windowsOcr(images: OcrImage[]): Promise<OcrResult[]> {
  const engine = 'Windows OCR';
  const encoded = Buffer.from(WINDOWS_SCRIPT, 'utf16le').toString('base64');
  const { stdout, stderr } = await run('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded],
    { ...process.env, AI_BRIDGE_OCR_FILES: JSON.stringify(images.map(image => image.path)) });
  const rows = stdout.split('\n').map(line => line.trim()).filter(line => line.startsWith('{'));
  return images.map((_, index) => {
    if (!rows[index]) return { engine, lines: [], error: stderr.trim().split('\n')[0] || 'no answer from PowerShell' };
    const row = JSON.parse(rows[index]) as Record<string, unknown>;
    if (typeof row.error === 'string') return { engine, lines: [], error: row.error };
    const lines = (Array.isArray(row.lines) ? row.lines : []).map((line: { words?: unknown }) => ({
      words: (Array.isArray(line?.words) ? line.words : []).map(word => toWord(word)).filter((word): word is OcrWord => word !== null),
    })).filter(line => line.words.length > 0);
    return { engine, language: typeof row.language === 'string' ? row.language : undefined, lines };
  });
}

async function macOcr(images: OcrImage[]): Promise<OcrResult[]> {
  const engine = 'macOS Vision';
  const { stdout, stderr } = await run('osascript', ['-l', 'JavaScript', '-e', MAC_SCRIPT, ...images.map(image => image.path)]);
  if (!stdout.trim().startsWith('[')) throw new Error(stderr.trim().split('\n')[0] || 'no answer from osascript');
  const rows = JSON.parse(stdout) as Array<Record<string, unknown>>;
  return images.map((image, index) => {
    const row = rows[index] ?? { error: 'no answer for this image' };
    if (typeof row.error === 'string') return { engine, lines: [], error: row.error };
    const lines = (Array.isArray(row.lines) ? row.lines : [])
      .map(line => toWord(line, image.width, image.height))
      .filter((word): word is OcrWord => word !== null)
      .map(word => ({ words: [word] }));
    return { engine, lines };
  });
}

/** `tesseract <image> stdout tsv`: one row per word, grouped back into lines. */
export function parseTesseractTsv(tsv: string): OcrLine[] {
  const lines = new Map<string, OcrWord[]>();
  for (const row of tsv.split('\n').slice(1)) {
    const cells = row.split('\t');
    if (cells.length < 12 || cells[0] !== '5' || Number(cells[10]) < 0) continue;
    const text = cells.slice(11).join('\t').trim();
    if (!text) continue;
    const key = cells.slice(1, 5).join('.');
    const words = lines.get(key) ?? [];
    words.push({ text, x: Number(cells[6]), y: Number(cells[7]), w: Number(cells[8]), h: Number(cells[9]) });
    lines.set(key, words);
  }
  return [...lines.values()].map(words => ({ words }));
}

async function tesseractOcr(images: OcrImage[]): Promise<OcrResult[]> {
  const engine = 'Tesseract';
  const results: OcrResult[] = [];
  for (const image of images) {
    const { stdout, stderr, code } = await run('tesseract', [image.path, 'stdout', 'tsv']);
    results.push(code === 0
      ? { engine, lines: parseTesseractTsv(stdout) }
      : { engine, lines: [], error: stderr.trim().split('\n')[0] || `tesseract exited with code ${code}` });
  }
  return results;
}

/** The text in each image, in the same order; an image that could not be read has `error` set. */
export async function recognizeText(images: OcrImage[]): Promise<OcrResult[]> {
  if (images.length === 0) return [];
  const [engine, read] = process.platform === 'win32' ? ['Windows OCR', windowsOcr]
    : process.platform === 'darwin' ? ['macOS Vision', macOcr]
      : ['Tesseract', tesseractOcr];
  try {
    return await (read as (images: OcrImage[]) => Promise<OcrResult[]>)(images);
  } catch (error) {
    const missing = (error as NodeJS.ErrnoException).code === 'ENOENT';
    const message = missing && engine === 'Tesseract'
      ? 'no OCR engine found (install tesseract to read text in images)'
      : error instanceof Error ? error.message : String(error);
    return images.map(() => ({ engine: engine as string, lines: [], error: message }));
  }
}
