/**
 * agent-tools.mjs — helper processes the backend starts next to the chat.
 *
 *   node agent-tools.mjs acp-bridge --harness <id> [claude flags...]
 *       Runs a third-party agent over ACP while speaking the Claude CLI's
 *       stream-json protocol on stdio (see acp/bridge.ts).
 *
 *   node agent-tools.mjs computer-use-mcp [--text-screenshots]
 *       A stdio MCP server exposing screenshot / mouse / keyboard tools
 *       (see computer-use/server.ts). --text-screenshots: for a model that
 *       does not read images, screenshots come back as a text description.
 *
 *   node agent-tools.mjs web-mcp [--text-screenshots]
 *       A stdio MCP server with web page and shader tools in a headless
 *       Chrome or Edge (see web/server.ts). --text-screenshots as above.
 *
 * Kept out of backend.mjs because each runs as its own child process, under the
 * same supervision (job object, process group) as the CLI it stands beside.
 */
import { AcpBridge } from './acp/bridge';
import { harnessAgentEnv, parseBridgeArgs } from './acp/translate';
import { HARNESS_ACP_COMMANDS, isAcpHarness } from '../shared';

function harnessCommand(harness: keyof typeof HARNESS_ACP_COMMANDS): readonly string[] {
  // An override for a harness installed off PATH, as a JSON array (`["C:/tools/opencode.exe","acp"]`).
  const override = process.env.AI_BRIDGE_HARNESS_COMMAND;
  if (override) {
    try {
      const parsed = JSON.parse(override) as unknown;
      if (Array.isArray(parsed) && parsed.length > 0 && parsed.every(p => typeof p === 'string')) return parsed as string[];
    } catch {
      process.stderr.write('[acp-bridge] ignoring malformed AI_BRIDGE_HARNESS_COMMAND\n');
    }
  }
  return HARNESS_ACP_COMMANDS[harness];
}

/**
 * MCP servers the backend asks us to hand the harness session, in ACP's
 * `McpServer` (stdio) shape: AI Bridge's computer-use and web servers.
 */
function sessionMcpServers(): unknown[] {
  const raw = process.env.AI_BRIDGE_MCP_SERVERS;
  if (!raw) return [];
  try {
    const servers = JSON.parse(raw) as Array<{ name: string; command: string; args: string[] }>;
    return servers.map(server => ({ name: server.name, command: server.command, args: server.args, env: [] }));
  } catch {
    process.stderr.write('[acp-bridge] ignoring malformed AI_BRIDGE_MCP_SERVERS\n');
    return [];
  }
}

/** The textOnlyModels setting the backend passes along (a JSON list), or none. */
function textOnlyModels(): unknown {
  const raw = process.env.AI_BRIDGE_TEXT_ONLY_MODELS;
  if (!raw) return undefined;
  try {
    return JSON.parse(raw) as unknown;
  } catch {
    process.stderr.write('[acp-bridge] ignoring malformed AI_BRIDGE_TEXT_ONLY_MODELS\n');
    return undefined;
  }
}

async function main(): Promise<void> {
  const [tool, ...rest] = process.argv.slice(2);
  if (tool === 'acp-bridge') {
    const index = rest.indexOf('--harness');
    const harness = index >= 0 ? rest[index + 1] : undefined;
    if (!isAcpHarness(harness)) {
      process.stderr.write(`[acp-bridge] unknown harness: ${String(harness)}\n`);
      process.exit(2);
    }
    // This process exists only for the bridge, so the agent inherits it as-is.
    Object.assign(process.env, harnessAgentEnv(harness, process.env));
    new AcpBridge({
      harness,
      agentCommand: harnessCommand(harness),
      cwd: process.cwd(),
      args: parseBridgeArgs(rest, process.env),
      input: process.stdin,
      output: process.stdout,
      mcpServers: sessionMcpServers(),
      textOnlyModels: textOnlyModels(),
    });
    return;
  }
  if (tool === 'computer-use-mcp') {
    const { runComputerUseServer } = await import('./computer-use/server');
    await runComputerUseServer({ textScreenshots: rest.includes('--text-screenshots') });
    return;
  }
  if (tool === 'web-mcp') {
    const { runWebServer } = await import('./web/server');
    await runWebServer({ textScreenshots: rest.includes('--text-screenshots') });
    return;
  }
  process.stderr.write('usage: agent-tools.mjs <acp-bridge|computer-use-mcp|web-mcp> [...]\n');
  process.exit(2);
}

main().catch((error) => {
  process.stderr.write(`[agent-tools] ${error instanceof Error ? error.stack ?? error.message : String(error)}\n`);
  process.exit(1);
});
