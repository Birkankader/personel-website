import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { CallToolRequestSchema, ListToolsRequestSchema } from '@modelcontextprotocol/sdk/types.js';
import { createDriver, fitInside, MODIFIERS, parseKeyCombo, type Driver, type MouseButton, type WindowQuery } from './driver';
import { formatWindowLayout, parseWindowTree, unsupportedMessage } from './window-layout';
import { summarizeImages, type ImageAttachment, type SummaryOptions } from '../../core/features/image-summary';

/**
 * Experimental computer use as a local stdio MCP server.
 *
 * The Claude CLI's own computer use is macOS-only and not available to the
 * harnesses at all, so this is ours: a plain MCP server any agent can load —
 * Claude through `--mcp-config`, an ACP harness through the session's
 * `mcpServers`. Every tool is an ordinary MCP tool, so the agent's usual
 * permission prompt applies to each action.
 *
 * Coordinates in and out are in the pixels of the last screenshot the model
 * received (scaled to fit 1280×800); the server converts them to the screen's.
 */
export const COMPUTER_USE_SERVER_NAME = 'ai-bridge-computer-use';

const MAX_WIDTH = 1280;
const MAX_HEIGHT = 800;
/**
 * The capture a text screenshot is described from (textScreenshots): the
 * screen's own pixels up to 4K, since OCR misreads text that was scaled down.
 */
const TEXT_MAX_WIDTH = 3840;
const TEXT_MAX_HEIGHT = 2400;
const MAX_TEXT = 5000;
/** How long window_layout walks a window's tree before answering with what it has. */
const WINDOW_BUDGET_MS = 8000;

type Args = Record<string, unknown>;

const point = (description: string) => ({
  type: 'object',
  properties: {
    x: { type: 'number', description: `${description} x, in screenshot pixels` },
    y: { type: 'number', description: `${description} y, in screenshot pixels` },
  },
});

const clickSchema = {
  type: 'object',
  properties: {
    x: { type: 'number', description: 'Target x in screenshot pixels. Omit to click where the cursor is.' },
    y: { type: 'number', description: 'Target y in screenshot pixels. Omit to click where the cursor is.' },
    modifiers: { type: 'string', description: 'Keys held during the click, e.g. "ctrl" or "ctrl+shift".' },
  },
};

const SCREENSHOT_AS_TEXT = 'Capture the primary screen, scaled to fit 1280x800, and describe it in text: the text on it, ' +
  'the shapes of the interface with their positions, and its colors. Every other tool takes coordinates in these pixels.';

export const TOOLS = [
  {
    name: 'screenshot',
    description: 'Capture the primary screen. Returns a PNG scaled to fit 1280x800; every other tool takes coordinates in this image\'s pixels.',
    inputSchema: { type: 'object', properties: {} },
  },
  { name: 'cursor_position', description: 'Report the mouse position in screenshot pixels.', inputSchema: { type: 'object', properties: {} } },
  { name: 'mouse_move', description: 'Move the mouse.', inputSchema: { ...point('Target'), required: ['x', 'y'] } },
  { name: 'left_click', description: 'Left-click, optionally after moving to (x, y).', inputSchema: clickSchema },
  { name: 'right_click', description: 'Right-click, optionally after moving to (x, y).', inputSchema: clickSchema },
  { name: 'middle_click', description: 'Middle-click, optionally after moving to (x, y).', inputSchema: clickSchema },
  { name: 'double_click', description: 'Double-click, optionally after moving to (x, y).', inputSchema: clickSchema },
  { name: 'triple_click', description: 'Triple-click (select a line), optionally after moving to (x, y).', inputSchema: clickSchema },
  {
    name: 'left_click_drag',
    description: 'Press the left button at (start_x, start_y), drag to (x, y) and release.',
    inputSchema: {
      type: 'object',
      properties: {
        start_x: { type: 'number' }, start_y: { type: 'number' }, x: { type: 'number' }, y: { type: 'number' },
      },
      required: ['start_x', 'start_y', 'x', 'y'],
    },
  },
  {
    name: 'scroll',
    description: 'Scroll the mouse wheel, optionally after moving to (x, y).',
    inputSchema: {
      type: 'object',
      properties: {
        x: { type: 'number' }, y: { type: 'number' },
        direction: { type: 'string', enum: ['up', 'down', 'left', 'right'] },
        amount: { type: 'number', description: 'Wheel notches, 1-20 (default 3).' },
      },
      required: ['direction'],
    },
  },
  {
    name: 'type',
    description: 'Type text into the focused window, as if from the keyboard.',
    inputSchema: { type: 'object', properties: { text: { type: 'string' } }, required: ['text'] },
  },
  {
    name: 'key',
    description: 'Press a key or combination, e.g. "enter", "ctrl+c", "alt+tab", "ctrl+shift+t".',
    inputSchema: { type: 'object', properties: { keys: { type: 'string' } }, required: ['keys'] },
  },
  {
    name: 'window_layout',
    description: 'Describe a desktop window\'s controls in text, from the tree the app shows to accessibility tools: each control with a ref, its type, name, ' +
      'automation id, state and box in screenshot pixels, then the layout slips found (siblings a few pixels out of line, controls cut off by their container, overlaps). ' +
      'Reads WPF, WinForms, JavaFX, Qt and Win32 apps, and Java Swing when the Java Access Bridge is on; the window may be behind others. ' +
      'Games and other GPU-drawn windows (Unity, Unreal) show no controls; use the screenshot for those.',
    inputSchema: {
      type: 'object',
      properties: {
        window: { type: 'string', description: 'A part of the window\'s title, or its process id. Default: the window in front.' },
        max_elements: { type: 'number', description: 'How many elements to list at most, 20-1000 (default 200).' },
      },
    },
  },
  {
    name: 'wait',
    description: 'Wait before the next action, e.g. for a window to open.',
    inputSchema: { type: 'object', properties: { seconds: { type: 'number', description: '0.1-30' } }, required: ['seconds'] },
  },
];

function num(value: unknown, name: string): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) throw new Error(`${name} must be a number`);
  return value;
}

function optionalPoint(args: Args): { x: number; y: number } | null {
  if (args.x === undefined && args.y === undefined) return null;
  return { x: num(args.x, 'x'), y: num(args.y, 'y') };
}

const text = (value: string) => ({ content: [{ type: 'text', text: value }] });

/** window_layout's arguments: a title part or a process id, and how many elements to list. */
export function windowQuery(args: Args): WindowQuery {
  const max = args.max_elements === undefined ? 200 : num(args.max_elements, 'max_elements');
  if (max < 20 || max > 1000) throw new Error('max_elements must be a number from 20 to 1000');
  const query: WindowQuery = { maxElements: Math.round(max), budgetMs: WINDOW_BUDGET_MS };
  const window = typeof args.window === 'number' ? String(args.window) : args.window;
  if (window === undefined || window === null || window === '') return query;
  if (typeof window !== 'string' || !window.trim()) throw new Error('window must be a part of a window\'s title, or a process id');
  if (/^\d+$/.test(window.trim())) query.pid = Number(window.trim());
  else query.title = window.trim();
  return query;
}

export interface ComputerUseOptions {
  /**
   * For a model that does not read images (the textOnlyModels setting): the
   * screenshot comes back as a text description of the screen instead of a PNG.
   */
  textScreenshots?: boolean;
  /** Test seam: describe images in text (image-summary.ts). */
  describeImages?: (images: ImageAttachment[], options?: SummaryOptions) => Promise<string[]>;
}

/** Runs one tool. Exported for tests with a fake driver. */
export class ComputerUse {
  constructor(private readonly driver: Driver, private readonly options: ComputerUseOptions = {}) {}

  /** Screenshot pixels → screen coordinates, against the current screen size. */
  private async toScreen(p: { x: number; y: number }): Promise<{ x: number; y: number }> {
    const screen = await this.driver.screenSize();
    const shot = fitInside(screen, MAX_WIDTH, MAX_HEIGHT);
    const x = Math.round(p.x * screen.width / shot.width);
    const y = Math.round(p.y * screen.height / shot.height);
    if (x < 0 || y < 0 || x >= screen.width || y >= screen.height) {
      throw new Error(`(${p.x}, ${p.y}) is outside the ${shot.width}x${shot.height} screenshot`);
    }
    return { x, y };
  }

  private async toShot(p: { x: number; y: number }): Promise<{ x: number; y: number }> {
    const screen = await this.driver.screenSize();
    const shot = fitInside(screen, MAX_WIDTH, MAX_HEIGHT);
    return { x: Math.round(p.x * shot.width / screen.width), y: Math.round(p.y * shot.height / screen.height) };
  }

  private async moveIfGiven(args: Args): Promise<void> {
    const target = optionalPoint(args);
    if (target) {
      const screen = await this.toScreen(target);
      await this.driver.moveMouse(screen.x, screen.y);
    }
  }

  private async click(args: Args, button: MouseButton, count: number) {
    const modifiers = typeof args.modifiers === 'string' && args.modifiers ? parseKeyCombo(args.modifiers) : [];
    const unknown = modifiers.filter(m => !MODIFIERS.has(m));
    if (unknown.length) throw new Error(`Not a modifier key: ${unknown.join(', ')}`);
    await this.moveIfGiven(args);
    await this.driver.click(button, count, modifiers);
    return text('Clicked.');
  }

  async call(name: string, args: Args): Promise<{ content: Array<Record<string, unknown>>; isError?: boolean }> {
    switch (name) {
      case 'screenshot': {
        if (this.options.textScreenshots) {
          // UI text in a screen scaled down to 1280 px is too small to read, so the
          // description comes from a full-size capture, with its positions scaled
          // to the screenshot pixels the other tools take.
          const shot = fitInside(await this.driver.screenSize(), MAX_WIDTH, MAX_HEIGHT);
          const sharp = await this.driver.screenshot(TEXT_MAX_WIDTH, TEXT_MAX_HEIGHT);
          const [summary] = await (this.options.describeImages ?? summarizeImages)(
            [{ fileName: 'screenshot.png', mimeType: 'image/png', base64: sharp.data }],
            { scale: shot.width / sharp.width },
          );
          return text(`${summary}\nScreenshot ${shot.width}x${shot.height}. The positions above are in these pixels, which the other tools take too.`);
        }
        const shot = await this.driver.screenshot(MAX_WIDTH, MAX_HEIGHT);
        return {
          content: [
            { type: 'image', data: shot.data, mimeType: 'image/png' },
            { type: 'text', text: `Screenshot ${shot.width}x${shot.height}. Use these pixel coordinates for the other tools.` },
          ],
        };
      }
      case 'cursor_position': {
        const p = await this.toShot(await this.driver.cursorPosition());
        return text(JSON.stringify(p));
      }
      case 'mouse_move': {
        const p = await this.toScreen({ x: num(args.x, 'x'), y: num(args.y, 'y') });
        await this.driver.moveMouse(p.x, p.y);
        return text('Moved.');
      }
      case 'left_click': return this.click(args, 'left', 1);
      case 'right_click': return this.click(args, 'right', 1);
      case 'middle_click': return this.click(args, 'middle', 1);
      case 'double_click': return this.click(args, 'left', 2);
      case 'triple_click': return this.click(args, 'left', 3);
      case 'left_click_drag': {
        const from = await this.toScreen({ x: num(args.start_x, 'start_x'), y: num(args.start_y, 'start_y') });
        const to = await this.toScreen({ x: num(args.x, 'x'), y: num(args.y, 'y') });
        await this.driver.moveMouse(from.x, from.y);
        await this.driver.mouseButton('left', true);
        try {
          await this.driver.moveMouse(Math.round((from.x + to.x) / 2), Math.round((from.y + to.y) / 2));
          await this.driver.moveMouse(to.x, to.y);
        } finally {
          await this.driver.mouseButton('left', false);
        }
        return text('Dragged.');
      }
      case 'scroll': {
        const amount = Math.min(20, Math.max(1, Math.round(typeof args.amount === 'number' ? args.amount : 3)));
        await this.moveIfGiven(args);
        const direction = String(args.direction);
        const dy = direction === 'down' ? amount : direction === 'up' ? -amount : 0;
        const dx = direction === 'right' ? amount : direction === 'left' ? -amount : 0;
        if (!dx && !dy) throw new Error('direction must be up, down, left or right');
        await this.driver.scroll(dx, dy);
        return text('Scrolled.');
      }
      case 'type': {
        if (typeof args.text !== 'string') throw new Error('text must be a string');
        if (args.text.length > MAX_TEXT) throw new Error(`text is limited to ${MAX_TEXT} characters per call`);
        await this.driver.typeText(args.text);
        return text('Typed.');
      }
      case 'key': {
        if (typeof args.keys !== 'string' || !args.keys.trim()) throw new Error('keys must be a key name such as "enter" or "ctrl+c"');
        await this.driver.pressKeys(parseKeyCombo(args.keys));
        return text('Pressed.');
      }
      case 'window_layout': {
        if (!this.driver.windowTree) return text(unsupportedMessage(process.platform));
        const query = windowQuery(args);
        const tree = parseWindowTree(await this.driver.windowTree(query));
        const screen = await this.driver.screenSize();
        return text(formatWindowLayout(tree, { query, screen, shot: fitInside(screen, MAX_WIDTH, MAX_HEIGHT) }));
      }
      case 'wait': {
        const seconds = Math.min(30, Math.max(0.1, num(args.seconds, 'seconds')));
        await new Promise(r => setTimeout(r, seconds * 1000));
        return text(`Waited ${seconds}s.`);
      }
      default:
        throw new Error(`Unknown tool: ${name}`);
    }
  }
}

export async function runComputerUseServer(options: ComputerUseOptions = {}): Promise<void> {
  const driver = await createDriver();
  const tools = new ComputerUse(driver, options);
  const server = new Server({ name: COMPUTER_USE_SERVER_NAME, version: '1.0.0' }, { capabilities: { tools: {} } });
  const listed = options.textScreenshots
    ? TOOLS.map(tool => tool.name === 'screenshot' ? { ...tool, description: SCREENSHOT_AS_TEXT } : tool)
    : TOOLS;
  server.setRequestHandler(ListToolsRequestSchema, async () => ({ tools: listed }));
  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    try {
      return await tools.call(request.params.name, (request.params.arguments ?? {}) as Args);
    } catch (error) {
      return { content: [{ type: 'text', text: error instanceof Error ? error.message : String(error) }], isError: true };
    }
  });
  const transport = new StdioServerTransport();
  const stop = () => { driver.close(); process.exit(0); };
  process.stdin.on('end', stop);
  process.on('SIGTERM', stop);
  await server.connect(transport);
}
