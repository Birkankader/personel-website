import { analyzePixels, decodeImage, formatAnalysis } from '../../core/features/image-summary';
import { outsideBy, overlapSize, siblingPairs } from '../layout/geometry';
import type { ConsoleEntry } from './browser';
import type { LayoutNode, LayoutSnapshot, ShaderResult } from './page-scripts';

/**
 * What the web tools tell the model, in text: a page as its elements with
 * boxes and styles plus the layout slips found in them, the console, and a
 * shader's output as numbers.
 */

const num = (value: number) => Number.isInteger(value) ? String(value) : value.toFixed(1);
const boxText = ([x, y, w, h]: LayoutNode['box']) => `${num(x)},${num(y)} ${num(w)}x${num(h)}`;

/** rgb() and rgba() as #RRGGBB(AA); other color syntaxes (oklch, color()) stay as they are. */
export function cssColor(value: string): string {
  return value.replace(/rgba?\(([^)]*)\)/g, (match, inner: string) => {
    const parts = inner.split(/[\s,/]+/).filter(Boolean).map(Number);
    if (parts.length < 3 || parts.slice(0, 3).some(n => !Number.isFinite(n))) return match;
    const hex = (n: number) => Math.round(Math.min(255, Math.max(0, n))).toString(16).padStart(2, '0').toUpperCase();
    const alpha = parts.length >= 4 && parts[3] < 1 ? hex(parts[3] * 255) : '';
    return `#${hex(parts[0])}${hex(parts[1])}${hex(parts[2])}${alpha}`;
  });
}

const SHORT: Record<string, string> = {
  'background-color': 'bg', 'background-image': 'bg-image', 'border-radius': 'radius', 'justify-content': 'justify',
  'align-items': 'align', 'align-self': 'self', 'flex-grow': 'grow', 'flex-wrap': 'wrap', 'grid-template-columns': 'columns', 'z-index': 'z',
};

/** 656.0625px as 656.1px. */
const shortPx = (value: string) => value.replace(/(-?\d+\.\d{2,})px/g, (_, n: string) => `${Math.round(Number(n) * 10) / 10}px`);

export function cssText(css: Record<string, string>): string {
  const parts: string[] = [];
  for (const [name, value] of Object.entries(css)) {
    if (name === 'flex-direction') continue;
    if (name === 'display') parts.push(/flex/.test(value) && css['flex-direction'] ? `${value} ${css['flex-direction']}` : value);
    else parts.push(`${SHORT[name] ?? name} ${shortPx(cssColor(value))}`);
  }
  return parts.join(' · ');
}

export function nodeName(node: LayoutNode): string {
  let name = `${node.ref} ${node.tag}`;
  if (node.id) name += `#${node.id}`;
  for (const c of node.classes ?? []) name += `.${c}`;
  if (node.role) name += `[role=${node.role}]`;
  if (node.type) name += `[type=${node.type}]`;
  if (node.text) name += ` ${JSON.stringify(node.text)}`;
  else if (node.label) name += ` (${JSON.stringify(node.label)})`;
  return name;
}

function nodeLine(node: LayoutNode): string {
  const flags = [
    node.text && node.label ? `label ${JSON.stringify(node.label)}` : '',
    node.placeholder ? `placeholder ${JSON.stringify(node.placeholder)}` : '',
    node.disabled ? 'disabled' : '',
    node.checked !== undefined ? (node.checked ? 'checked' : 'unchecked') : '',
  ].filter(Boolean);
  const css = cssText(node.css);
  return [`${nodeName(node)} ${boxText(node.box)}`, ...flags, ...(css ? [css] : [])].join(' · ');
}

const LAYOUT_PROPS = ['margin', 'padding', 'border', 'font', 'line-height', 'vertical-align', 'align-self', 'position', 'top', 'bottom', 'left', 'right', 'transform'];

/** Siblings side by side or stacked whose edges miss each other by up to 6 px, with the styles that differ. */
export function elementNearMisses(nodes: LayoutNode[]): string[] {
  const out: string[] = [];
  const off = (d: number) => Math.abs(d) >= 0.5 && Math.abs(d) <= 6;
  for (const pair of siblingPairs(nodes, node => node.box[2] >= 8 && node.box[3] >= 8)) {
    const [ax, ay, aw, ah] = pair.a.box, [bx, by, bw, bh] = pair.b.box;
    const notes: string[] = [];
    if (pair.axis === 'row') {
      if (off(pair.start)) notes.push(`top ${num(ay)} vs ${num(by)}`);
      if (off(pair.end)) notes.push(`bottom ${num(ay + ah)} vs ${num(by + bh)}`);
      if (off(pair.size)) notes.push(`height ${num(ah)} vs ${num(bh)}`);
    } else {
      if (off(pair.start)) notes.push(`left ${num(ax)} vs ${num(bx)}`);
      if (off(pair.end)) notes.push(`right ${num(ax + aw)} vs ${num(bx + bw)}`);
      if (off(pair.size)) notes.push(`width ${num(aw)} vs ${num(bw)}`);
    }
    if (!notes.length) continue;
    const a = pair.a.css, b = pair.b.css;
    const differ = LAYOUT_PROPS.filter(prop => (a[prop] ?? '') !== (b[prop] ?? ''))
      .map(prop => `${prop} ${a[prop] ?? '(none)'} vs ${b[prop] ?? '(none)'}`);
    out.push(`${nodeName(pair.a)} and ${nodeName(pair.b)}: ${notes.join(', ')}${differ.length ? `; styles that differ: ${differ.join(', ')}` : ''}`);
    if (out.length >= 12) break;
  }
  return out;
}

/** Layout slips besides near misses: cut-off content, children out of their parent, overlaps, sideways scrolling. */
export function layoutFindings(snapshot: LayoutSnapshot): string[] {
  const { nodes } = snapshot;
  const out: string[] = [];
  for (const node of nodes) {
    const o = node.overflow;
    if (!o) continue;
    if (o.kind === 'cut') out.push(`${nodeName(node)}: content ${o.width}x${o.height} is cut off to ${o.clientWidth}x${o.clientHeight} (overflow ${node.css.overflow ?? 'hidden'}${node.css['text-overflow'] ? `, ${node.css['text-overflow']}` : ''})`);
    else if (o.kind === 'spills') out.push(`${nodeName(node)}: content ${o.width}x${o.height} spills out of its ${o.clientWidth}x${o.clientHeight} box`);
  }
  const positioned = (node: LayoutNode) => /absolute|fixed/.test(node.css.position ?? '');
  for (const node of nodes) {
    const parent = nodes[node.parent];
    if (!parent || positioned(node) || /hidden|clip|auto|scroll/.test(parent.css.overflow ?? '')) continue;
    if (parent.tag === 'body' || parent.tag === 'html') continue;
    const outside = outsideBy(node.box, parent.box).filter(([, d]) => d > 1).map(([side, d]) => `${num(Math.round(d * 10) / 10)} px on the ${side}`);
    if (outside.length) out.push(`${nodeName(node)} sticks out of ${nodeName(parent)} by ${outside.join(', ')}`);
  }
  const byParent = new Map<number, LayoutNode[]>();
  for (const node of nodes) byParent.set(node.parent, [...(byParent.get(node.parent) ?? []), node]);
  let overlaps = 0;
  for (const siblings of byParent.values()) {
    for (let i = 0; i < siblings.length && overlaps < 8; i++) {
      for (let j = i + 1; j < siblings.length && overlaps < 8; j++) {
        const a = siblings[i], b = siblings[j];
        if (!a.text && !b.text) continue;
        const [ix, iy] = overlapSize(a.box, b.box);
        if (ix > 2 && iy > 2) {
          out.push(`${nodeName(a)} and ${nodeName(b)} overlap by ${num(Math.round(ix * 10) / 10)}x${num(Math.round(iy * 10) / 10)} px`);
          overlaps++;
        }
      }
    }
  }
  const [vw] = snapshot.viewport;
  if (snapshot.document[0] > vw + 1) {
    const widest = nodes.filter(node => node.box[0] + node.box[2] > vw + 1)
      .sort((a, b) => (b.box[0] + b.box[2]) - (a.box[0] + a.box[2])).slice(0, 3)
      .map(node => `${nodeName(node)} reaches x=${num(node.box[0] + node.box[2])}`);
    out.push(`The page is ${snapshot.document[0]} px wide in a ${vw} px viewport, so it scrolls sideways${widest.length ? `: ${widest.join('; ')}` : ''}`);
  }
  return out.slice(0, 30);
}

export function formatConsoleSummary(log: ConsoleEntry[], limit = 5): string[] {
  const errors = log.filter(entry => entry.level === 'error' || entry.level === 'assert');
  const warnings = log.filter(entry => entry.level === 'warn');
  if (!errors.length && !warnings.length) return [`Console: no errors or warnings${log.length ? ` (${log.length} other message${log.length === 1 ? '' : 's'})` : ''}.`];
  const out = [`Console: ${errors.length} error${errors.length === 1 ? '' : 's'}, ${warnings.length} warning${warnings.length === 1 ? '' : 's'}${errors.length > limit ? ` (first ${limit} errors below; page_console has all)` : ''}.`];
  for (const entry of errors.slice(0, limit)) out.push(`- ${entry.text.split('\n')[0].slice(0, 300)}${entry.where ? ` (${entry.where})` : ''}`);
  return out;
}

export function formatConsole(log: ConsoleEntry[]): string {
  if (!log.length) return 'The console is empty since the page was opened.';
  return log.slice(-150).map(entry => `[${entry.level}] ${entry.text.slice(0, 1000)}${entry.where && !entry.text.includes(entry.where) ? ` (${entry.where})` : ''}`).join('\n');
}

export function formatLayout(snapshot: LayoutSnapshot, status?: number): string {
  const [vw, vh] = snapshot.viewport;
  const [dw, dh] = snapshot.document;
  const scrolls = [dh > vh + 1 ? 'down' : '', dw > vw + 1 ? 'sideways' : ''].filter(Boolean).join(' and ');
  const out = [
    `Page ${JSON.stringify(snapshot.title)} at ${snapshot.url}${status ? ` (HTTP ${status})` : ''}: viewport ${vw}x${vh}, page ${dw}x${dh}${scrolls ? ` (scrolls ${scrolls})` : ''}` +
      `${snapshot.scroll[0] || snapshot.scroll[1] ? `, scrolled to ${num(snapshot.scroll[0])},${num(snapshot.scroll[1])}` : ''}.`,
    '',
    'Elements (box x,y WxH in CSS pixels from the page\'s top-left; indented = inside the element above; a ref such as e12 can stand for a selector in the other tools):',
  ];
  const depth: number[] = [];
  for (const [index, node] of snapshot.nodes.entries()) {
    depth[index] = node.parent >= 0 ? depth[node.parent] + 1 : 0;
    out.push(`${'  '.repeat(depth[index])}- ${nodeLine(node)}`);
  }
  if (snapshot.total > snapshot.nodes.length) {
    out.push(`… ${snapshot.total - snapshot.nodes.length} more elements not listed. Pass page_layout a target (selector or ref) to see one part.`);
  }
  const misses = elementNearMisses(snapshot.nodes);
  if (misses.length) out.push('', 'Almost aligned (siblings whose edges differ by a few pixels, often a layout slip):', ...misses.map(m => `- ${m}`));
  const findings = layoutFindings(snapshot);
  if (findings.length) out.push('', 'Worth a look:', ...findings.map(f => `- ${f}`));
  return out.join('\n');
}

const fixed = (value: number | null) => value === null || Number.isNaN(value) ? 'NaN' : !Number.isFinite(value) ? (value > 0 ? 'Inf' : '-Inf') : value.toFixed(3);
const percent = (count: number, total: number) => {
  const p = count / total * 100;
  return p >= 1 ? `${Math.round(p)}%` : p > 0 ? `${p.toFixed(2)}%` : '0%';
};

/** "ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device ...))" as "SwiftShader on the CPU". */
const rendererName = (renderer: string) => /swiftshader/i.test(renderer) ? 'SwiftShader on the CPU' : renderer;

/** A shader's result as text: compile errors with their lines, or the output's numbers, and for a text-only model the image described. */
export function formatShader(result: ShaderResult, size: { width: number; height: number }, describe: boolean): string {
  const modes = { shadertoy: 'a Shadertoy mainImage', glsl300: 'GLSL ES 3.00', glsl100: 'GLSL ES 1.00' };
  const renderer = rendererName(result.renderer);
  if (!result.ok) {
    const out = [`The shader failed at the ${result.stage} stage (${modes[result.mode]}${renderer ? `, ${renderer}` : ''}):`];
    for (const error of result.errors ?? []) out.push(`- ${error.line ? `line ${error.line}: ` : ''}${error.message}${error.source ? `  ← ${error.source}` : ''}`);
    return out.join('\n');
  }
  const out = [
    `Drew ${size.width}x${size.height} with WebGL2 (${renderer || 'unknown renderer'}), as ${modes[result.mode]}${result.float ? '; the raw float output is read, before the 0–1 clamp' : '; read as 8-bit colors'}.`,
  ];
  const set = result.uniforms.filter(name => !result.unset.includes(name));
  if (set.length) out.push(`Uniforms set: ${set.join(', ')}.`);
  if (result.unset.length) out.push(`Uniforms left at 0 (pass them in uniforms): ${result.unset.join(', ')}.`);
  if (result.samplers.length) out.push(`Textures, which have no image here and read as black: ${result.samplers.join(', ')}.`);
  const total = size.width * size.height;
  const channels = ['r', 'g', 'b', 'a'];
  for (const frame of result.frames) {
    out.push('', `Frame at time ${frame.time} s (${frame.ms} ms):`);
    out.push(`  Output: ${channels.map((c, i) => `${c} ${fixed(frame.min[i])}..${fixed(frame.max[i])} (mean ${fixed(frame.mean[i])})`).join(', ')}.`);
    const outside = channels.flatMap((c, i) => [
      frame.above[i] ? `${c} above 1 in ${percent(frame.above[i], total)}` : '',
      frame.below[i] ? `${c} below 0 in ${percent(frame.below[i], total)}` : '',
    ]).filter(Boolean);
    if (outside.length && result.float) out.push(`  Outside 0–1 (clamped on screen): ${outside.join(', ')} of the pixels.`);
    if (frame.nan || frame.inf) out.push(`  ${frame.nan ? `NaN in ${frame.nan} pixels (${percent(frame.nan, total)})` : ''}${frame.nan && frame.inf ? ', ' : ''}${frame.inf ? `infinity in ${frame.inf} pixels (${percent(frame.inf, total)})` : ''}; drawn black here, undefined on a real GPU.`);
    out.push(`  Samples (fragCoord x,y from the bottom-left → r, g, b, a): ${frame.samples.map(s => `${s.name} ${s.x},${s.y} → ${s.rgba.map(v => fixed(v)).join(', ')}`).join('; ')}.`);
    if (describe) {
      const pixels = decodeImage(Buffer.from(frame.png, 'base64'));
      if (pixels) {
        out.push('  The image (positions here from the top-left, y down; the color channels only):');
        out.push(...formatAnalysis(analyzePixels(pixels), 'PNG').map(line => line ? `  ${line}` : ''));
      }
    }
  }
  return out.join('\n');
}
