import { describe, expect, it } from 'vitest';
import { mkdirSync, mkdtempSync, readdirSync, rmSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { pathToFileURL } from 'url';
import { browserCandidates, browserEnv, browserSaid, navigationError, removeOrphanProfiles } from '../web/browser';
import { pageUrl, TOOLS, WebTools } from '../web/server';

describe('browserCandidates', () => {
  it('looks for Chrome, then Edge, then Chromium in each Windows install root', () => {
    const list = browserCandidates('win32', { ProgramFiles: 'C:\\Program Files', 'ProgramFiles(x86)': 'C:\\Program Files (x86)', LOCALAPPDATA: 'C:\\Users\\u\\AppData\\Local' });
    expect(list[0]).toBe('C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe');
    expect(list).toContain('C:\\Users\\u\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe');
    expect(list).toContain('C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe');
    expect(list.indexOf('C:\\Program Files (x86)\\Microsoft\\Edge\\Application\\msedge.exe')).toBeGreaterThan(list.indexOf('C:\\Users\\u\\AppData\\Local\\Google\\Chrome\\Application\\chrome.exe'));
  });

  it('looks in the Applications folders on macOS and on PATH on Linux', () => {
    expect(browserCandidates('darwin', { HOME: '/Users/u' })).toContain('/Users/u/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge');
    expect(browserCandidates('linux', { PATH: '/usr/bin:/snap/bin' })).toContain('/snap/bin/chromium');
  });

  it('takes AI_BRIDGE_BROWSER as the only one', () => {
    expect(browserCandidates('win32', { AI_BRIDGE_BROWSER: 'D:\\tools\\chrome.exe', ProgramFiles: 'C:\\Program Files' })).toEqual(['D:\\tools\\chrome.exe']);
  });
});

describe('browserEnv', () => {
  it('gives the browser the account profile folder back on Windows', () => {
    const env = { USERPROFILE: 'C:\\isolated\\home', PATH: 'C:\\bin' };
    expect(browserEnv(env, 'win32', () => 'C:\\Users\\u')).toEqual({ USERPROFILE: 'C:\\Users\\u', PATH: 'C:\\bin' });
    expect(env.USERPROFILE).toBe('C:\\isolated\\home');
  });

  it('leaves the environment as it is elsewhere, or when there is no account folder', () => {
    const env = { USERPROFILE: 'C:\\Users\\u', HOME: '/home/u' };
    expect(browserEnv(env, 'win32', () => 'C:\\Users\\u')).toBe(env);
    expect(browserEnv(env, 'linux', () => '/other')).toBe(env);
    expect(browserEnv(env, 'win32', () => { throw new Error('no entry'); })).toBe(env);
  });
});

describe('browserSaid', () => {
  it('quotes the plain messages before the log lines', () => {
    const stderr = '[1:2:1017/233954.654:ERROR:a.cc:153] Failed to open cache\r\n\r\nDevTools remote debugging requires a non-default data directory. Specify this using --user-data-dir.\r\n[1:3:1017/233954.684:ERROR:b.cc:147] Missing value\r\n';
    expect(browserSaid(stderr)).toBe('; the browser said: DevTools remote debugging requires a non-default data directory. Specify this using --user-data-dir.');
    expect(browserSaid('[1:2:x:ERROR:a.cc:1] one\n[1:2:x:ERROR:a.cc:2] two\n')).toBe('; the browser said: [1:2:x:ERROR:a.cc:1] one [1:2:x:ERROR:a.cc:2] two');
    expect(browserSaid('')).toBe('');
  });
});

describe('removeOrphanProfiles', () => {
  it('removes the profiles of servers that are gone and keeps the rest', async () => {
    const dir = mkdtempSync(join(tmpdir(), 'ai-bridge-orphans-'));
    try {
      for (const name of ['ai-bridge-browser-111-abc', 'ai-bridge-browser-222-def', `ai-bridge-browser-${process.pid}-ghi`, 'something-else']) mkdirSync(join(dir, name));
      const removed = await removeOrphanProfiles(dir, pid => pid === 222);
      expect(removed).toEqual(['ai-bridge-browser-111-abc']);
      expect(readdirSync(dir).sort()).toEqual(['ai-bridge-browser-222-def', `ai-bridge-browser-${process.pid}-ghi`, 'something-else'].sort());
    } finally {
      rmSync(dir, { recursive: true, force: true });
    }
  });
});

describe('pageUrl', () => {
  it('keeps URLs and turns host:port and paths into ones', () => {
    expect(pageUrl('http://localhost:5173/app')).toBe('http://localhost:5173/app');
    expect(pageUrl('about:blank')).toBe('about:blank');
    expect(pageUrl('localhost:5173')).toBe('http://localhost:5173');
    expect(pageUrl('127.0.0.1:8080/index.html')).toBe('http://127.0.0.1:8080/index.html');
    const cwd = process.cwd();
    expect(pageUrl('./dist/index.html', cwd)).toBe(pathToFileURL(join(cwd, 'dist', 'index.html')).href);
    expect(pageUrl(join(cwd, 'page.html'), cwd)).toBe(pathToFileURL(join(cwd, 'page.html')).href);
  });
});

describe('navigationError', () => {
  it('names the likely cause of a refused connection', () => {
    expect(navigationError('http://localhost:5173', 'net::ERR_CONNECTION_REFUSED')).toBe(
      'Nothing answers at http://localhost:5173 (net::ERR_CONNECTION_REFUSED). Is the dev server running, and on this port?');
  });
});

describe('WebTools', () => {
  it('says so when there is no browser to run', async () => {
    const tools = new WebTools({ findBrowser: () => null });
    await expect(tools.call('open_page', { url: 'localhost:5173' })).rejects.toThrow(/No Chrome, Edge or Chromium was found/);
    await expect(tools.call('render_shader', { fragment: 'void mainImage(out vec4 c, in vec2 p) { c = vec4(1.0); }' })).rejects.toThrow(/AI_BRIDGE_BROWSER/);
  });

  it('asks for open_page before the page tools', async () => {
    const tools = new WebTools({ findBrowser: () => null });
    for (const name of ['page_layout', 'page_screenshot', 'page_console', 'page_evaluate']) {
      await expect(tools.call(name, { expression: '1', target: 'e1' })).rejects.toThrow('No page is open. Call open_page first.');
    }
  });

  it('checks shader arguments before starting a browser', async () => {
    const tools = new WebTools({ findBrowser: () => { throw new Error('should not be called'); } });
    await expect(tools.call('render_shader', { fragment: 'x', times: [0, 1, 2, 3, 4, 5, 6, 7, 8] })).rejects.toThrow('times must hold 1 to 8 numbers');
    await expect(tools.call('render_shader', { fragment: 'x', width: 4096 })).rejects.toThrow('width must be a number from 1 to 1024');
    await expect(tools.call('render_shader', { fragment: 'x', uniforms: { uColor: 'red' } })).rejects.toThrow('uniforms.uColor must be an array of numbers');
  });

  it('lists every tool it answers', () => {
    expect(TOOLS.map(tool => tool.name)).toEqual(['open_page', 'page_layout', 'page_screenshot', 'page_click', 'page_type', 'page_evaluate', 'page_console', 'render_shader']);
  });
});
