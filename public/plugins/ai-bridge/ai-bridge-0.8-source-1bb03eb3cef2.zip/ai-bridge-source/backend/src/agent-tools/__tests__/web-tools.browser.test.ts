import { mkdtempSync, rmSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { findBrowser } from '../web/browser';
import { WebTools } from '../web/server';

/**
 * Runs the web tools in the real Chrome or Edge of this computer. Off unless
 * AI_BRIDGE_BROWSER_TESTS=1, since a test machine may have no browser, or one
 * that cannot start headless.
 */
const enabled = process.env.AI_BRIDGE_BROWSER_TESTS === '1' && findBrowser() !== null;

const DIALOG = `<!doctype html><html><head><title>Settings</title><style>
  body { margin: 0; font-family: sans-serif; }
  .card { margin: 40px; padding: 32px; width: 600px; border: 1px solid #dce0e6; background: #fff; }
  .label { display: block; width: 120px; overflow: hidden; white-space: nowrap; text-overflow: ellipsis; }
  .wide { width: 700px; height: 10px; background: #fde68a; }
  .footer { display: flex; justify-content: flex-end; gap: 12px; }
  button { height: 36px; padding: 0 20px; border: 0; }
  .primary { background: #2563eb; color: #fff; margin-top: 4px; }
</style></head><body><div class="card">
  <span class="label">A label much too long for its box</span>
  <input id="name" placeholder="Name">
  <div class="wide"></div>
  <div class="footer"><button>Cancel</button><button class="primary" id="save" onclick="missing()">Save</button></div>
</div><script>console.warn('old option');</script></body></html>`;

describe.skipIf(!enabled)('web tools in a real browser', () => {
  let dir = '';
  let tools: WebTools;
  let textTools: WebTools;
  beforeAll(() => {
    dir = mkdtempSync(join(tmpdir(), 'ai-bridge-web-test-'));
    writeFileSync(join(dir, 'dialog.html'), DIALOG);
    tools = new WebTools();
    textTools = new WebTools({ textScreenshots: true });
  });
  afterAll(async () => {
    await Promise.all([tools.close(), textTools.close()]);
    rmSync(dir, { recursive: true, force: true });
  });

  it('describes a page with its layout slips and console', async () => {
    const result = await tools.call('open_page', { url: join(dir, 'dialog.html') });
    const text = String(result.content[0].text);
    expect(text).toContain('Page "Settings"');
    expect(text).toMatch(/button "Cancel" and e\d+ button#save\.primary "Save": top \d+ vs \d+, bottom \d+ vs \d+; styles that differ: margin \(none\) vs 4px 0px 0px/);
    expect(text).toMatch(/span\.label "A label much too long for its box": content \d+x\d+ is cut off to 120x\d+/);
    expect(text).toMatch(/div\.wide sticks out of e\d+ div\.card by 67 px on the right/);
    expect(text).toContain('Console: 0 errors, 1 warning.');
  }, 60_000);

  it('clicks, types and reads the page back', async () => {
    const click = String((await tools.call('page_click', { target: '#save' })).content[0].text);
    expect(click).toMatch(/^Clicked e\d+ button#save\.primary "Save"/);
    expect(click).toContain('ReferenceError: missing is not defined');
    await tools.call('page_type', { target: '#name', text: 'Ada' });
    expect((await tools.call('page_evaluate', { expression: 'document.querySelector("#name").value' })).content[0].text).toBe('"Ada"');
    const shot = await tools.call('page_screenshot', { target: '.footer' });
    expect(shot.content[0].type).toBe('image');
  }, 60_000);

  it('draws a shader and reads it back', async () => {
    const circle = 'void mainImage(out vec4 c, in vec2 p) { vec2 uv = (p - 0.5 * iResolution.xy) / iResolution.y; c = vec4(length(uv) < 0.25 ? vec3(1.0, 0.4, 0.1) : vec3(0.0), 1.0); }';
    const text = String((await textTools.call('render_shader', { fragment: circle, width: 128, height: 128 })).content[0].text);
    expect(text).toContain('as a Shadertoy mainImage');
    expect(text).toContain('center 64,64 → 1.000, 0.400, 0.100, 1.000');
    expect(text).toContain('area #FF661A 32,32 64x64');
    const broken = String((await textTools.call('render_shader', { fragment: 'void mainImage(out vec4 c, in vec2 p) {\n  vec3 x = vec3(1.0)\n  c = vec4(x, 1.0);\n}' })).content[0].text);
    expect(broken).toMatch(/^The shader failed at the fragment stage/);
    expect(broken).toContain('line 3:');
    expect(broken).toContain('(line 2: vec3 x = vec3(1.0))');
    const nan = String((await textTools.call('render_shader', { fragment: 'precision highp float;\nuniform vec2 u_resolution;\nvoid main() { gl_FragColor = vec4(sqrt(gl_FragCoord.x / u_resolution.x - 0.5), 2.0, 0.0, 1.0); }', width: 16, height: 16 })).content[0].text);
    expect(nan).toContain('as GLSL ES 1.00');
    expect(nan).toContain('g above 1 in 100%');
    expect(nan).toContain('NaN in 128 pixels (50%)');
  }, 60_000);
});
