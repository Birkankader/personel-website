/**
 * Box geometry the layout tools share (web pages, native windows): which
 * siblings sit side by side or stacked and how far their edges are apart,
 * how far a box sticks out of its parent, and how much two boxes overlap.
 *
 * Boxes are x, y, width, height in whatever unit the caller measures in. The
 * callers decide what counts as a slip and word the findings themselves.
 */
export type Box = readonly [number, number, number, number];

export interface Boxed {
  /** Index of the node this one is inside, -1 for the top. */
  parent: number;
  box: Box;
}

/**
 * Two siblings that line up along one axis, and how far b's edges are from
 * a's along it: positive means b's edge is further down (row) or right
 * (column), or b is bigger.
 */
export interface SiblingPair<T> {
  a: T;
  b: T;
  /** 'row': side by side, so tops and bottoms line up; 'column': stacked, so lefts and rights do. */
  axis: 'row' | 'column';
  start: number;
  center: number;
  end: number;
  size: number;
}

/** Every pair of siblings side by side or stacked, a before b in the nodes' order. */
export function siblingPairs<T extends Boxed>(nodes: readonly T[], include: (node: T) => boolean = () => true): SiblingPair<T>[] {
  const byParent = new Map<number, T[]>();
  for (const node of nodes) {
    if (!include(node)) continue;
    byParent.set(node.parent, [...(byParent.get(node.parent) ?? []), node]);
  }
  const pairs: SiblingPair<T>[] = [];
  for (const siblings of byParent.values()) {
    for (let i = 0; i < siblings.length; i++) {
      for (let j = i + 1; j < siblings.length; j++) {
        const a = siblings[i], b = siblings[j];
        const [ax, ay, aw, ah] = a.box, [bx, by, bw, bh] = b.box;
        const rowOverlap = Math.min(ay + ah, by + bh) - Math.max(ay, by);
        const colOverlap = Math.min(ax + aw, bx + bw) - Math.max(ax, bx);
        if (rowOverlap >= Math.min(ah, bh) / 2 && colOverlap <= 0) {
          pairs.push({ a, b, axis: 'row', start: by - ay, center: by + bh / 2 - (ay + ah / 2), end: by + bh - (ay + ah), size: bh - ah });
        } else if (colOverlap >= Math.min(aw, bw) / 2 && rowOverlap <= 0) {
          pairs.push({ a, b, axis: 'column', start: bx - ax, center: bx + bw / 2 - (ax + aw / 2), end: bx + bw - (ax + aw), size: bw - aw });
        }
      }
    }
  }
  return pairs;
}

export type Side = 'left' | 'top' | 'right' | 'bottom';

/** How far a box reaches past each side of its parent's box (negative = inside). */
export function outsideBy(box: Box, parent: Box): Array<[Side, number]> {
  const [x, y, w, h] = box, [px, py, pw, ph] = parent;
  return [['left', px - x], ['top', py - y], ['right', x + w - (px + pw)], ['bottom', y + h - (py + ph)]];
}

/** The width and height two boxes share (zero or negative when they do not overlap). */
export function overlapSize(a: Box, b: Box): [number, number] {
  return [
    Math.min(a[0] + a[2], b[0] + b[2]) - Math.max(a[0], b[0]),
    Math.min(a[1] + a[3], b[1] + b[3]) - Math.max(a[1], b[1]),
  ];
}
