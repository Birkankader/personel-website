/**
 * Windows: the window tree reader behind window_layout, compiled into the
 * computer-use PowerShell helper (win-driver.ts) the first time it is used.
 *
 * Most toolkits show their controls to UI Automation (UIAutomationClient):
 * WPF, WinForms, JavaFX, Qt, Win32. Swing does not; it draws its controls
 * itself and UI Automation sees one empty window. Its controls are readable
 * only through the Java Access Bridge's client API (windowsaccessbridge-64.dll,
 * which ships with Java and is documented by Oracle), when the bridge is on in
 * that Java. The reader uses it for AWT/Swing windows and falls back to UI
 * Automation, saying why, when it cannot.
 *
 * Read(title, pid, max, budgetMs) returns one JSON object: the window, then its
 * elements in breadth-first order with their parent's index, each with the
 * properties its source names (UI Automation's or the bridge's), boxes in
 * screen pixels. Nothing is renamed here; window-layout.ts does the rest.
 */
export const WINDOW_TREE_SOURCE = String.raw`
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows;
using System.Windows.Automation;

public static class AiBridgeTree {
  [StructLayout(LayoutKind.Sequential)] public struct RECT { public int Left, Top, Right, Bottom; }
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern IntPtr GetAncestor(IntPtr h, uint flags);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  [DllImport("user32.dll")] static extern bool GetWindowRect(IntPtr h, out RECT r);
  [DllImport("user32.dll")] static extern IntPtr GetDC(IntPtr h);
  [DllImport("user32.dll")] static extern int ReleaseDC(IntPtr h, IntPtr dc);
  [DllImport("gdi32.dll")] static extern int GetDeviceCaps(IntPtr dc, int index);
  [DllImport("dwmapi.dll")] static extern int DwmGetWindowAttribute(IntPtr h, int attribute, out RECT r, int size);

  const int MAX_TEXT = 200;

  static void Str(StringBuilder sb, string s) {
    sb.Append('"');
    if (s.Length > MAX_TEXT) s = s.Substring(0, char.IsHighSurrogate(s[MAX_TEXT - 1]) ? MAX_TEXT - 1 : MAX_TEXT) + "…";
    foreach (char c in s) {
      switch (c) {
        case '"': sb.Append("\\\""); break;
        case '\\': sb.Append("\\\\"); break;
        case '\n': sb.Append("\\n"); break;
        case '\r': sb.Append("\\r"); break;
        case '\t': sb.Append("\\t"); break;
        default:
          if (c < 0x20) sb.Append("\\u").Append(((int)c).ToString("x4"));
          else sb.Append(c);
          break;
      }
    }
    sb.Append('"');
  }

  static void Field(StringBuilder sb, string name, string value) {
    if (string.IsNullOrEmpty(value)) return;
    sb.Append(",\"").Append(name).Append("\":");
    Str(sb, value);
  }

  static void Flag(StringBuilder sb, string name, bool value) {
    sb.Append(",\"").Append(name).Append("\":").Append(value ? "true" : "false");
  }

  static void Number(StringBuilder sb, double value) {
    sb.Append(Math.Round(value, 2).ToString("0.##", CultureInfo.InvariantCulture));
  }

  static void Box(StringBuilder sb, double x, double y, double w, double h) {
    sb.Append(",\"boundingRectangle\":[");
    Number(sb, x); sb.Append(','); Number(sb, y); sb.Append(','); Number(sb, w); sb.Append(','); Number(sb, h);
    sb.Append(']');
  }

  static string ProcessName(int pid) {
    try { return Process.GetProcessById(pid).ProcessName; } catch { return ""; }
  }

  static int SystemDpi() {
    IntPtr dc = GetDC(IntPtr.Zero);
    try { return GetDeviceCaps(dc, 88); } finally { ReleaseDC(IntPtr.Zero, dc); }
  }

  // --- Choosing the window ---------------------------------------------------

  static CacheRequest TopRequest() {
    CacheRequest cr = new CacheRequest();
    cr.Add(AutomationElement.NameProperty);
    cr.Add(AutomationElement.ProcessIdProperty);
    cr.Add(AutomationElement.ClassNameProperty);
    cr.Add(AutomationElement.NativeWindowHandleProperty);
    cr.Add(AutomationElement.FrameworkIdProperty);
    cr.AutomationElementMode = AutomationElementMode.Full;
    return cr;
  }

  /** The top-level windows, front to back. */
  static List<AutomationElement> TopWindows() {
    List<AutomationElement> list = new List<AutomationElement>();
    AutomationElementCollection all;
    using (TopRequest().Activate()) { all = AutomationElement.RootElement.FindAll(TreeScope.Children, Condition.TrueCondition); }
    foreach (AutomationElement e in all) list.Add(e);
    return list;
  }

  static string Title(AutomationElement e) { return (e.Cached.Name ?? "").Trim(); }

  /** The window asked for, front-most first; the others that also match go to others. */
  static AutomationElement Choose(List<AutomationElement> tops, string title, int pid, List<AutomationElement> others) {
    List<AutomationElement> found = new List<AutomationElement>();
    if (pid > 0) {
      // A process's untitled windows are mostly helpers, so titled ones first.
      foreach (AutomationElement e in tops) if (e.Cached.ProcessId == pid && Title(e).Length > 0) found.Add(e);
      foreach (AutomationElement e in tops) if (e.Cached.ProcessId == pid && Title(e).Length == 0) found.Add(e);
    } else if (!string.IsNullOrEmpty(title)) {
      string wanted = title.Trim();
      foreach (AutomationElement e in tops) if (string.Equals(Title(e), wanted, StringComparison.OrdinalIgnoreCase)) found.Add(e);
      foreach (AutomationElement e in tops) {
        string name = Title(e);
        if (!string.Equals(name, wanted, StringComparison.OrdinalIgnoreCase) && name.IndexOf(wanted, StringComparison.OrdinalIgnoreCase) >= 0) found.Add(e);
      }
    } else {
      IntPtr fg = GetAncestor(GetForegroundWindow(), 2);
      foreach (AutomationElement e in tops) if (new IntPtr(e.Cached.NativeWindowHandle) == fg) found.Add(e);
      if (found.Count == 0 && fg != IntPtr.Zero) {
        try { found.Add(AutomationElement.FromHandle(fg).GetUpdatedCache(TopRequest())); } catch { }
      }
    }
    for (int i = 1; i < found.Count; i++) others.Add(found[i]);
    return found.Count > 0 ? found[0] : null;
  }

  public static string Read(string title, int pid, int max, int budgetMs) {
    Stopwatch clock = Stopwatch.StartNew();
    StringBuilder sb = new StringBuilder();
    List<AutomationElement> tops = TopWindows();
    List<AutomationElement> others = new List<AutomationElement>();
    AutomationElement window = Choose(tops, title, pid, others);
    sb.Append("{\"dpi\":").Append(SystemDpi());
    if (window == null) {
      sb.Append(",\"windows\":[");
      bool first = true;
      foreach (AutomationElement e in tops) {
        if (Title(e).Length == 0) continue;
        if (!first) sb.Append(',');
        first = false;
        TopEntry(sb, e);
      }
      sb.Append("]}");
      return sb.ToString();
    }
    IntPtr hwnd = new IntPtr(window.Cached.NativeWindowHandle);
    string className = window.Cached.ClassName ?? "";
    sb.Append(",\"window\":{\"title\":");
    Str(sb, window.Cached.Name ?? "");
    sb.Append(",\"pid\":").Append(window.Cached.ProcessId);
    Field(sb, "process", ProcessName(window.Cached.ProcessId));
    Field(sb, "className", className);
    Field(sb, "frameworkId", window.Cached.FrameworkId);
    RECT frame;
    // The frame as drawn, without the invisible resize borders GetWindowRect includes.
    if (hwnd != IntPtr.Zero && (DwmGetWindowAttribute(hwnd, 9, out frame, Marshal.SizeOf(typeof(RECT))) == 0 || GetWindowRect(hwnd, out frame)))
      Box(sb, frame.Left, frame.Top, frame.Right - frame.Left, frame.Bottom - frame.Top);
    Flag(sb, "isMinimized", hwnd != IntPtr.Zero && IsIconic(hwnd));
    Flag(sb, "isForeground", hwnd != IntPtr.Zero && hwnd == GetAncestor(GetForegroundWindow(), 2));
    sb.Append('}');
    if (others.Count > 0) {
      sb.Append(",\"alsoMatched\":[");
      for (int i = 0; i < others.Count && i < 10; i++) { if (i > 0) sb.Append(','); TopEntry(sb, others[i]); }
      sb.Append(']');
    }
    if (className.StartsWith("SunAwt", StringComparison.Ordinal) && hwnd != IntPtr.Zero) {
      string problem = Jab.Read(sb, hwnd, window.Cached.ProcessId, max, budgetMs, clock);
      if (problem == null) { sb.Append('}'); return sb.ToString(); }
      Field(sb, "java", problem);
    }
    Uia(sb, window, max, budgetMs, clock);
    sb.Append('}');
    return sb.ToString();
  }

  static void TopEntry(StringBuilder sb, AutomationElement e) {
    sb.Append("{\"title\":");
    Str(sb, e.Cached.Name ?? "");
    sb.Append(",\"pid\":").Append(e.Cached.ProcessId);
    Field(sb, "process", ProcessName(e.Cached.ProcessId));
    Field(sb, "className", e.Cached.ClassName);
    sb.Append('}');
  }

  // --- UI Automation ---------------------------------------------------------

  static void Uia(StringBuilder sb, AutomationElement window, int max, int budgetMs, Stopwatch clock) {
    CacheRequest cr = new CacheRequest();
    cr.Add(AutomationElement.ControlTypeProperty);
    cr.Add(AutomationElement.NameProperty);
    cr.Add(AutomationElement.AutomationIdProperty);
    cr.Add(AutomationElement.ClassNameProperty);
    cr.Add(AutomationElement.FrameworkIdProperty);
    cr.Add(AutomationElement.BoundingRectangleProperty);
    cr.Add(AutomationElement.IsEnabledProperty);
    cr.Add(AutomationElement.IsOffscreenProperty);
    cr.Add(AutomationElement.HasKeyboardFocusProperty);
    cr.Add(AutomationElement.IsPasswordProperty);
    cr.Add(AutomationElement.IsScrollPatternAvailableProperty);
    cr.Add(TogglePattern.ToggleStateProperty);
    cr.Add(ValuePattern.ValueProperty);
    cr.Add(SelectionItemPattern.IsSelectedProperty);
    cr.TreeFilter = Automation.ControlViewCondition;
    cr.AutomationElementMode = AutomationElementMode.Full;
    TreeWalker walker = TreeWalker.ControlViewWalker;

    sb.Append(",\"source\":\"uia\",\"elements\":[");
    Queue<KeyValuePair<AutomationElement, int>> queue = new Queue<KeyValuePair<AutomationElement, int>>();
    AutomationElement top;
    try { top = window.GetUpdatedCache(cr); } catch { top = window; }
    Element(sb, top, -1, true);
    queue.Enqueue(new KeyValuePair<AutomationElement, int>(top, 0));
    int count = 1;
    bool timedOut = false, full = false;
    while (queue.Count > 0 && !timedOut && !full) {
      if (clock.ElapsedMilliseconds > budgetMs) { timedOut = true; break; }
      KeyValuePair<AutomationElement, int> item = queue.Dequeue();
      AutomationElement child;
      try { child = walker.GetFirstChild(item.Key, cr); } catch { child = null; }
      while (child != null) {
        if (count >= max) { full = true; break; }
        Element(sb, child, item.Value, false);
        queue.Enqueue(new KeyValuePair<AutomationElement, int>(child, count++));
        if (clock.ElapsedMilliseconds > budgetMs) { timedOut = true; break; }
        try { child = walker.GetNextSibling(child, cr); } catch { child = null; }
      }
    }
    sb.Append(']');
    End(sb, full, timedOut, queue.Count);
  }

  /** How the walk ended: the list full or the time up, and how many listed elements' children were never read. */
  static void End(StringBuilder sb, bool full, bool timedOut, int unread) {
    Flag(sb, "full", full);
    Flag(sb, "timedOut", timedOut);
    sb.Append(",\"unread\":").Append(unread);
  }

  static object Cached(AutomationElement e, AutomationProperty p) {
    try {
      object v = e.GetCachedPropertyValue(p, true);
      return v == AutomationElement.NotSupported ? null : v;
    } catch { return null; }
  }

  static bool Is(object value) { return value is bool && (bool)value; }

  static void Element(StringBuilder sb, AutomationElement e, int parent, bool first) {
    if (!first) sb.Append(',');
    sb.Append("{\"parent\":").Append(parent);
    ControlType type = Cached(e, AutomationElement.ControlTypeProperty) as ControlType;
    string typeName = type == null ? "" : type.ProgrammaticName;
    if (typeName.StartsWith("ControlType.", StringComparison.Ordinal)) typeName = typeName.Substring(12);
    Field(sb, "controlType", typeName);
    Field(sb, "name", Cached(e, AutomationElement.NameProperty) as string);
    Field(sb, "automationId", Cached(e, AutomationElement.AutomationIdProperty) as string);
    Field(sb, "className", Cached(e, AutomationElement.ClassNameProperty) as string);
    Field(sb, "frameworkId", Cached(e, AutomationElement.FrameworkIdProperty) as string);
    object rect = Cached(e, AutomationElement.BoundingRectangleProperty);
    if (rect is Rect) {
      Rect r = (Rect)rect;
      if (!r.IsEmpty && !double.IsInfinity(r.Width) && !double.IsInfinity(r.Height)) Box(sb, r.X, r.Y, r.Width, r.Height);
    }
    object enabled = Cached(e, AutomationElement.IsEnabledProperty);
    if (enabled is bool && !(bool)enabled) Flag(sb, "isEnabled", false);
    if (Is(Cached(e, AutomationElement.IsOffscreenProperty))) Flag(sb, "isOffscreen", true);
    if (Is(Cached(e, AutomationElement.HasKeyboardFocusProperty))) Flag(sb, "hasKeyboardFocus", true);
    if (Is(Cached(e, AutomationElement.IsScrollPatternAvailableProperty))) Flag(sb, "isScrollPatternAvailable", true);
    object toggle = Cached(e, TogglePattern.ToggleStateProperty);
    if (toggle is ToggleState) Field(sb, "toggleState", toggle.ToString());
    if (Is(Cached(e, SelectionItemPattern.IsSelectedProperty))) Flag(sb, "isSelected", true);
    if (Is(Cached(e, AutomationElement.IsPasswordProperty))) Flag(sb, "isPassword", true);
    else Field(sb, "value", Cached(e, ValuePattern.ValueProperty) as string);
    sb.Append('}');
  }

  // --- Java Access Bridge ----------------------------------------------------

  /**
   * The bridge talks to each Java over window messages, so it runs on a thread
   * of its own that keeps pumping them; calls are handed to that thread.
   */
  static class Jab {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
    public struct Info {
      [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1024)] public string name;
      [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 1024)] public string description;
      [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string role;
      [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string role_en_US;
      [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string states;
      [MarshalAs(UnmanagedType.ByValTStr, SizeConst = 256)] public string states_en_US;
      public int indexInParent, childrenCount, x, y, width, height;
      public int accessibleComponent, accessibleAction, accessibleSelection, accessibleText, accessibleInterfaces;
    }

    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void RunFn();
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int IsJavaWindowFn(IntPtr hwnd);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int ContextFromHwndFn(IntPtr hwnd, out int vm, out long ac);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate int ContextInfoFn(int vm, long ac, out Info info);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate long ChildFn(int vm, long ac, int index);
    [UnmanagedFunctionPointer(CallingConvention.Cdecl)] delegate void ReleaseFn(int vm, long obj);

    [StructLayout(LayoutKind.Sequential)] struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam; public IntPtr lParam; public uint time; public int x; public int y; }
    [DllImport("kernel32.dll", CharSet = CharSet.Unicode, SetLastError = true)] static extern IntPtr LoadLibrary(string path);
    [DllImport("kernel32.dll", CharSet = CharSet.Ansi)] static extern IntPtr GetProcAddress(IntPtr module, string name);
    [DllImport("user32.dll")] static extern uint MsgWaitForMultipleObjects(uint count, IntPtr[] handles, bool all, uint ms, uint mask);
    [DllImport("user32.dll")] static extern bool PeekMessage(out MSG msg, IntPtr hwnd, uint min, uint max, uint remove);
    [DllImport("user32.dll")] static extern bool TranslateMessage(ref MSG msg);
    [DllImport("user32.dll")] static extern IntPtr DispatchMessage(ref MSG msg);

    static IsJavaWindowFn isJavaWindow;
    static ContextFromHwndFn contextFromHwnd;
    static ContextInfoFn contextInfo;
    static ChildFn child;
    static ReleaseFn release;
    static string loadError;
    static Thread thread;
    static readonly Stopwatch sinceStart = new Stopwatch();
    static readonly Queue<Action> work = new Queue<Action>();
    static readonly AutoResetEvent wake = new AutoResetEvent(false);

    static T Proc<T>(IntPtr dll, string name) where T : class {
      IntPtr p = GetProcAddress(dll, name);
      if (p == IntPtr.Zero) throw new Exception(name + " is missing from the bridge");
      return Marshal.GetDelegateForFunctionPointer(p, typeof(T)) as T;
    }

    static void Loop(object state) {
      object[] args = (object[])state;
      string path = (string)args[0];
      ManualResetEvent started = (ManualResetEvent)args[1];
      try {
        IntPtr dll = LoadLibrary(path);
        if (dll == IntPtr.Zero) throw new Exception("could not load " + path + " (error " + Marshal.GetLastWin32Error() + ")");
        RunFn run = Proc<RunFn>(dll, "Windows_run");
        isJavaWindow = Proc<IsJavaWindowFn>(dll, "isJavaWindow");
        contextFromHwnd = Proc<ContextFromHwndFn>(dll, "getAccessibleContextFromHWND");
        contextInfo = Proc<ContextInfoFn>(dll, "getAccessibleContextInfo");
        child = Proc<ChildFn>(dll, "getAccessibleChildFromContext");
        release = Proc<ReleaseFn>(dll, "releaseJavaObject");
        run();
      } catch (Exception e) {
        loadError = e.Message;
        started.Set();
        return;
      }
      sinceStart.Start();
      started.Set();
      IntPtr[] handles = { wake.SafeWaitHandle.DangerousGetHandle() };
      while (true) {
        MsgWaitForMultipleObjects(1, handles, false, 0xFFFFFFFF, 0x04FF);
        MSG msg;
        while (PeekMessage(out msg, IntPtr.Zero, 0, 0, 1)) { TranslateMessage(ref msg); DispatchMessage(ref msg); }
        while (true) {
          Action next = null;
          lock (work) { if (work.Count > 0) next = work.Dequeue(); }
          if (next == null) break;
          next();
        }
      }
    }

    static T Call<T>(Func<T> f, int timeoutMs) {
      T result = default(T);
      Exception error = null;
      ManualResetEvent done = new ManualResetEvent(false);
      lock (work) work.Enqueue(delegate { try { result = f(); } catch (Exception e) { error = e; } done.Set(); });
      wake.Set();
      if (!done.WaitOne(timeoutMs)) throw new TimeoutException("the Java Access Bridge did not answer");
      if (error != null) throw error;
      return result;
    }

    /** windowsaccessbridge-64.dll next to the app's own Java, in JAVA_HOME, or in System32. */
    static string FindClient(int pid) {
      List<string> dirs = new List<string>();
      try { dirs.Add(Path.GetDirectoryName(Process.GetProcessById(pid).MainModule.FileName)); } catch { }
      string home = Environment.GetEnvironmentVariable("JAVA_HOME");
      if (!string.IsNullOrEmpty(home)) dirs.Add(Path.Combine(home, "bin"));
      dirs.Add(Environment.GetFolderPath(Environment.SpecialFolder.System));
      foreach (string dir in dirs) {
        if (string.IsNullOrEmpty(dir)) continue;
        string path = Path.Combine(dir, "windowsaccessbridge-64.dll");
        if (File.Exists(path)) return path;
      }
      return null;
    }

    static string Start(int pid) {
      if (thread != null) return loadError == null ? null : "load-failed: " + loadError;
      string path = FindClient(pid);
      if (path == null) return "no-client";
      ManualResetEvent started = new ManualResetEvent(false);
      thread = new Thread(Loop);
      thread.IsBackground = true;
      thread.Start(new object[] { path, started });
      started.WaitOne(10000);
      return loadError == null ? null : "load-failed: " + loadError;
    }

    /** Writes the elements and returns null, or returns why the bridge could not read the window. */
    public static string Read(StringBuilder sb, IntPtr hwnd, int pid, int max, int budgetMs, Stopwatch clock) {
      try {
        string problem = Start(pid);
        if (problem != null) return problem;
        // Each Java answers the bridge's hello by message; a bridge just started needs a moment to hear them.
        bool java = Call(() => isJavaWindow(hwnd) != 0, 5000);
        while (!java && sinceStart.ElapsedMilliseconds < 1500) {
          Thread.Sleep(100);
          java = Call(() => isJavaWindow(hwnd) != 0, 5000);
        }
        if (!java) return "off";
        RECT wr;
        GetWindowRect(hwnd, out wr);
        StringBuilder elements = new StringBuilder();
        string result = Call(() => Walk(elements, hwnd, wr, max, budgetMs, clock), Math.Max(1000, budgetMs - (int)clock.ElapsedMilliseconds) + 10000);
        if (result == null) sb.Append(elements.ToString());
        return result;
      } catch (Exception e) {
        return "failed: " + e.Message;
      }
    }

    static string Walk(StringBuilder sb, IntPtr hwnd, RECT wr, int max, int budgetMs, Stopwatch clock) {
      int vm; long root;
      if (contextFromHwnd(hwnd, out vm, out root) == 0) return "off";
      List<long> held = new List<long>();
      held.Add(root);
      try {
        Info info;
        if (contextInfo(vm, root, out info) == 0) return "off";
        // Java reports its own scaled pixels; map them onto the window's screen pixels.
        double scale = info.width > 0 ? (double)(wr.Right - wr.Left) / info.width : 1;
        if (scale < 0.5 || scale > 4) scale = 1;
        StringBuilder list = new StringBuilder();
        // Each entry: the element's context, its index in the list, its number of children.
        Queue<long[]> queue = new Queue<long[]>();
        Item(list, info, -1, true, wr, info.x, info.y, scale);
        if (info.childrenCount > 0 && Has(info.states_en_US, "showing")) queue.Enqueue(new long[] { root, 0, info.childrenCount });
        int count = 1;
        int ox = info.x, oy = info.y;
        bool timedOut = false, full = false;
        while (queue.Count > 0 && !timedOut && !full) {
          if (clock.ElapsedMilliseconds > budgetMs) { timedOut = true; break; }
          long[] item = queue.Dequeue();
          for (int i = 0; i < item[2]; i++) {
            if (count >= max) { full = true; break; }
            if (clock.ElapsedMilliseconds > budgetMs) { timedOut = true; break; }
            long c = child(vm, item[0], i);
            if (c == 0) continue;
            held.Add(c);
            Info ci;
            if (contextInfo(vm, c, out ci) == 0) continue;
            Item(list, ci, (int)item[1], false, wr, ox, oy, scale);
            // Hidden parts (another tab, a closed menu) are listed but not opened.
            if (ci.childrenCount > 0 && Has(ci.states_en_US, "showing")) queue.Enqueue(new long[] { c, count, ci.childrenCount });
            count++;
          }
        }
        sb.Append(",\"source\":\"java-access-bridge\",\"elements\":[").Append(list.ToString()).Append(']');
        End(sb, full, timedOut, queue.Count);
        return null;
      } finally {
        foreach (long o in held) release(vm, o);
      }
    }

    public static bool Has(string states, string state) {
      foreach (string s in (states ?? "").Split(',')) if (s.Trim() == state) return true;
      return false;
    }

    static void Item(StringBuilder sb, Info info, int parent, bool first, RECT wr, int ox, int oy, double scale) {
      if (!first) sb.Append(',');
      sb.Append("{\"parent\":").Append(parent);
      Field(sb, "role", info.role_en_US);
      Field(sb, "name", info.name);
      Field(sb, "description", info.description);
      Field(sb, "states", info.states_en_US);
      sb.Append(",\"childrenCount\":").Append(info.childrenCount);
      if (info.width > 0 || info.height > 0) Box(sb, wr.Left + (info.x - ox) * scale, wr.Top + (info.y - oy) * scale, info.width * scale, info.height * scale);
      sb.Append('}');
    }
  }
}
`;
