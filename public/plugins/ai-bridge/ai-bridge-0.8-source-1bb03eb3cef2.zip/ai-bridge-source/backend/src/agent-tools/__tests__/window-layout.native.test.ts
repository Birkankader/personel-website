import { spawn, spawnSync, type ChildProcess } from 'child_process';
import { mkdtempSync, rmSync, writeFileSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { ComputerUse } from '../computer-use/server';
import { WindowsDriver } from '../computer-use/win-driver';
import { parseWindowTree } from '../computer-use/window-layout';

/**
 * window_layout against real windows this test opens: WinForms and WPF
 * through UI Automation, and Swing through the Java Access Bridge when a JDK
 * is on PATH. Each has a Cancel button set 4 px lower than OK. Off unless
 * AI_BRIDGE_NATIVE_TESTS=1 on Windows, since the windows pop up on the screen.
 *
 * Only these windows' own text is ever printed. The window in front (the
 * user's) is read too, but only its counts are checked, never its text.
 */
const enabled = process.platform === 'win32' && process.env.AI_BRIDGE_NATIVE_TESTS === '1';
const hasJava = enabled && spawnSync('java', ['-version'], { windowsHide: true }).status === 0;
const tag = Math.random().toString(36).slice(2, 8);

const WINFORMS = (title: string) => `
Add-Type -AssemblyName System.Windows.Forms, System.Drawing
$f = New-Object Windows.Forms.Form
$f.Text = '${title}'; $f.StartPosition = 'Manual'; $f.Location = New-Object Drawing.Point(120, 120); $f.ClientSize = New-Object Drawing.Size(360, 200)
$ok = New-Object Windows.Forms.Button; $ok.Text = 'OK'; $ok.Name = 'okButton'; $ok.SetBounds(20, 140, 80, 28)
$cancel = New-Object Windows.Forms.Button; $cancel.Text = 'Cancel'; $cancel.Name = 'cancelButton'; $cancel.SetBounds(110, 144, 80, 28)
$label = New-Object Windows.Forms.Label; $label.Text = 'Name'; $label.Name = 'nameLabel'; $label.SetBounds(20, 20, 60, 20)
$box = New-Object Windows.Forms.TextBox; $box.Name = 'nameBox'; $box.SetBounds(90, 20, 200, 24)
$panel = New-Object Windows.Forms.Panel; $panel.Name = 'tools'; $panel.SetBounds(20, 60, 120, 44); $panel.BorderStyle = 'FixedSingle'
$wide = New-Object Windows.Forms.Button; $wide.Text = 'Too wide'; $wide.Name = 'wideButton'; $wide.SetBounds(60, 8, 100, 28)
$panel.Controls.Add($wide)
$f.Controls.AddRange(@($ok, $cancel, $label, $box, $panel))
# Started hidden (windowsHide), the first show of a process's window is hidden too; show it again.
$f.Add_Shown({ $f.Visible = $false; $f.Visible = $true })
[Windows.Forms.Application]::Run($f)
`;

const WPF = (title: string) => `
Add-Type -AssemblyName PresentationFramework
$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Title="${title}" Width="380" Height="220" Left="520" Top="120" ShowActivated="False">
  <Canvas>
    <TextBox Canvas.Left="20" Canvas.Top="20" Width="200" Height="24" Name="nameBox" />
    <Button Canvas.Left="20" Canvas.Top="100" Width="80" Height="28" Name="okButton">OK</Button>
    <Button Canvas.Left="110" Canvas.Top="104" Width="80" Height="28" Name="cancelButton">Cancel</Button>
    <CheckBox Canvas.Left="210" Canvas.Top="60" IsChecked="True" Name="remember">Remember</CheckBox>
  </Canvas>
</Window>
"@
[void]([Windows.Markup.XamlReader]::Parse($xaml)).ShowDialog()
`;

const SWING = `
import javax.swing.*;
public class LayoutTest {
  public static void main(String[] args) throws Exception {
    SwingUtilities.invokeAndWait(() -> {
      JFrame f = new JFrame(args[0]);
      f.setLayout(null);
      JButton ok = new JButton("OK"); ok.setBounds(20, 20, 80, 30);
      JButton cancel = new JButton("Cancel"); cancel.setBounds(110, 24, 80, 30);
      JCheckBox remember = new JCheckBox("Remember", true); remember.setBounds(20, 70, 120, 24);
      f.add(ok); f.add(cancel); f.add(remember);
      f.setSize(320, 170); f.setLocation(920, 120); f.setFocusableWindowState(false); f.setVisible(true);
    });
    Thread.sleep(120000);
    System.exit(0);
  }
}
`;

describe.skipIf(!enabled)('window_layout on real windows', () => {
  const titles = {
    winforms: `AI Bridge Düzen WinForms ${tag}`,
    wpf: `AI Bridge WPF ${tag}`,
    swing: `AI Bridge Swing ${tag}`,
    swingOff: `AI Bridge Swing off ${tag}`,
  };
  const children: ChildProcess[] = [];
  let dir = '';
  let driver: WindowsDriver;
  let tools: ComputerUse;

  const powershell = (script: string) => {
    children.push(spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(script, 'utf16le').toString('base64')], { stdio: 'ignore', windowsHide: true }));
  };

  /** Waits until a window with this title shows up, with what the reader found in it. */
  const waitFor = async (title: string, timeoutMs = 20000) => {
    const end = Date.now() + timeoutMs;
    for (;;) {
      const tree = parseWindowTree(await driver.windowTree({ title, maxElements: 200, budgetMs: 8000 }));
      if (tree.window && tree.elements.length > 1) return tree;
      if (Date.now() > end) throw new Error(`no window ${title}`);
      await new Promise(r => setTimeout(r, 300));
    }
  };

  beforeAll(async () => {
    dir = mkdtempSync(join(tmpdir(), 'ai-bridge-window-test-'));
    driver = new WindowsDriver();
    tools = new ComputerUse(driver);
    powershell(WINFORMS(titles.winforms));
    powershell(WPF(titles.wpf));
    if (hasJava) {
      writeFileSync(join(dir, 'LayoutTest.java'), SWING);
      const java = (title: string, bridge: boolean) => children.push(spawn('java', [
        ...(bridge ? ['-Djavax.accessibility.assistive_technologies=com.sun.java.accessibility.AccessBridge'] : []),
        join(dir, 'LayoutTest.java'), title,
      ], { stdio: 'ignore', windowsHide: true }));
      java(titles.swing, true);
      java(titles.swingOff, false);
    }
  }, 30000);

  afterAll(() => {
    for (const child of children) child.kill();
    driver?.close();
    if (dir) rmSync(dir, { recursive: true, force: true });
  });

  const layout = async (window: string) => {
    const result = await tools.call('window_layout', { window });
    return String(result.content[0].text);
  };

  it('reads a WinForms window by a part of its title and finds the slip and the cut-off button', async () => {
    await waitFor(titles.winforms);
    const text = await layout(`Düzen WinForms ${tag}`);
    console.log(text);
    expect(text).toContain(`Window "${titles.winforms}": WinForms, read through UI Automation`);
    expect(text).toMatch(/w\d+ Button "Cancel" #cancelButton sits 4 px (\(\d+(\.\d)? screen px\) )?lower than w\d+ Button "OK" #okButton/);
    expect(text).toMatch(/Button "Too wide" #wideButton is cut off by w\d+ Pane( "[^"]*")? #tools: \d+(\.\d)? px/);
    expect(text).not.toMatch(/nameLabel.*(lower|higher)/);
  }, 40000);

  it('reads a WPF window, its check box state and the same slip', async () => {
    await waitFor(titles.wpf);
    const text = await layout(titles.wpf);
    console.log(text);
    expect(text).toContain('WPF, read through UI Automation');
    expect(text).toMatch(/CheckBox "Remember" #remember .*checked/);
    expect(text).toMatch(/Button "Cancel" #cancelButton sits 4 px (\(\d+(\.\d)? screen px\) )?lower than w\d+ Button "OK" #okButton/);
  }, 40000);

  it.skipIf(!hasJava)('reads a Swing window through the Java Access Bridge, and says how to turn the bridge on', async () => {
    await waitFor(titles.swing, 40000);
    const text = await layout(titles.swing);
    console.log(text);
    expect(text).toContain('Java Swing/AWT, read through the Java Access Bridge');
    expect(text).toMatch(/push button "Cancel" sits 4 px (\(\d+(\.\d)? screen px\) )?lower than w\d+ push button "OK"/);
    expect(text).toMatch(/check box "Remember" .*checked/);
    await waitFor(titles.swingOff, 40000).catch(() => undefined);
    const off = await layout(titles.swingOff);
    console.log(off);
    expect(off).toContain('jabswitch -enable');
  }, 90000);

  it('reads the window in front without printing any of its text', async () => {
    const text = await layout('');
    const elements = text.split('\n').filter(line => /^\s*- w\d+ /.test(line)).length;
    // Counts only: the window in front is the user's.
    console.log(`window in front: ${elements} elements, ${text.split('\n').length} lines`);
    expect(text.length).toBeGreaterThan(0);
    const missing = await layout(`no such window ${tag}`);
    expect(missing.startsWith(`No window's title contains "no such window ${tag}".`)).toBe(true);
  }, 40000);
});
