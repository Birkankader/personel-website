import { existsSync } from 'fs';
import { isAbsolute, resolve } from 'path';
import { pathToFileURL } from 'url';
import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { CallToolRequestSchema, ListToolsRequestSchema } from '@modelcontextprotocol/sdk/types.js';
import { summarizeImages, type ImageAttachment } from '../../core/features/image-summary';
import { Browser, findBrowser, type Page } from './browser';
import { formatConsole, formatConsoleSummary, formatLayout, formatShader } from './format';
import { collectLayout, locateElement, renderShader, type LayoutSnapshot, type ShaderOptions, type ShaderResult } from './page-scripts';

/**
 * Web page and shader tools as a local stdio MCP server, for checking the UI
 * and shaders an agent builds: a page as its elements with boxes and styles
 * plus the layout slips in them, its console, clicks and typing, and a GLSL
 * fragment shader drawn on the CPU with its output in numbers.
 *
 * Everything runs in a headless Chrome or Edge already on the computer
 * (browser.ts), started at the first call. For a model that does not read
 * images (--text-screenshots), screenshots and shader output come back as text.
 */
export const WEB_SERVER_NAME = 'ai-bridge-web';

type Args = Record<string, unknown>;
type Content = Array<Record<string, unknown>>;

const target = (description: string) => ({ type: 'string', description: `${description}: a ref from page_layout (such as e12) or a CSS selector.` });

export const TOOLS = [
  {
    name: 'open_page',
    description: 'Open a web page in a headless browser (the Chrome or Edge on this computer; no GPU needed) and describe it: each visible element with its ref, box and ' +
      'styles, the layout slips found (almost-aligned siblings with the styles that differ, cut-off text, elements out of their parent, overlaps, sideways scroll) and console errors. ' +
      'Use it to check a page you build, e.g. a dev server at http://localhost:5173. Call it again to reload.',
    inputSchema: {
      type: 'object',
      properties: {
        url: { type: 'string', description: 'An http(s) or file URL, a local HTML file path, or host:port such as localhost:5173.' },
        width: { type: 'number', description: 'Viewport width in CSS pixels, 320-3840 (default 1280).' },
        height: { type: 'number', description: 'Viewport height in CSS pixels, 200-2400 (default 800).' },
      },
      required: ['url'],
    },
  },
  {
    name: 'page_layout',
    description: 'Describe the open page again as open_page does, e.g. after a click or after your change reached it (a dev server with hot reload updates it by itself), or one part of it.',
    inputSchema: {
      type: 'object',
      properties: {
        target: target('Describe only this element and what is inside it'),
        max_elements: { type: 'number', description: 'How many elements to list at most, 20-1000 (default 200).' },
      },
    },
  },
  {
    name: 'page_screenshot',
    description: 'Capture the open page, or one element of it.',
    inputSchema: {
      type: 'object',
      properties: {
        target: target('Capture only this element'),
        full_page: { type: 'boolean', description: 'The whole page rather than the viewport.' },
      },
    },
  },
  {
    name: 'page_click',
    description: 'Click an element of the open page, in its middle, as a user would; it is scrolled into view first.',
    inputSchema: { type: 'object', properties: { target: target('The element to click') }, required: ['target'] },
  },
  {
    name: 'page_type',
    description: 'Type text into an input, textarea or editable element of the open page.',
    inputSchema: {
      type: 'object',
      properties: {
        target: target('The field'),
        text: { type: 'string' },
        clear: { type: 'boolean', description: 'Replace what the field holds (default true); false adds to the end.' },
        submit: { type: 'boolean', description: 'Press Enter afterwards.' },
      },
      required: ['target', 'text'],
    },
  },
  {
    name: 'page_evaluate',
    description: 'Run a JavaScript expression in the open page and return its value as JSON (a promise is awaited), e.g. to read app state, scroll, or check computed styles.',
    inputSchema: { type: 'object', properties: { expression: { type: 'string' } }, required: ['expression'] },
  },
  {
    name: 'page_console',
    description: 'The console messages, uncaught errors and failed requests of the open page since it was opened.',
    inputSchema: { type: 'object', properties: {} },
  },
  {
    name: 'render_shader',
    description: 'Compile and draw a GLSL fragment shader over the whole canvas on the CPU (WebGL2 with SwiftShader; no GPU needed) and report what it drew: ' +
      'compile errors with their lines, each channel\'s range, values outside 0-1, NaN, and exact samples. Takes a Shadertoy shader (mainImage with iTime, iResolution, iMouse), ' +
      'GLSL ES 3.00 (#version 300 es) or GLSL ES 1.00 (gl_FragColor); u_time, u_resolution, u_mouse and time, resolution, mouse are set too.',
    inputSchema: {
      type: 'object',
      properties: {
        fragment: { type: 'string', description: 'The fragment shader source.' },
        width: { type: 'number', description: '1-1024 (default 256).' },
        height: { type: 'number', description: '1-1024 (default 256).' },
        times: { type: 'array', items: { type: 'number' }, description: 'Times in seconds to draw a frame at, up to 8 (default [0]).' },
        mouse: { type: 'array', items: { type: 'number' }, description: '[x, y] in pixels from the bottom-left (default the center).' },
        uniforms: { type: 'object', description: 'Values for other uniforms by name: a number, boolean, or array for vectors and matrices.' },
        samples: { type: 'array', items: { type: 'array', items: { type: 'number' } }, description: 'More [x, y] fragCoord points to report exactly (the center and corners always are).' },
      },
      required: ['fragment'],
    },
  },
];

const SCREENSHOT_AS_TEXT = 'Capture the open page, or one element of it, and describe the picture in text: the text read from it, its shapes with their positions, and its colors. ' +
  'page_layout describes the elements themselves more exactly.';
const SHADER_AS_TEXT = ' The drawn image is described in text: its shapes with their positions, and its colors.';

const NO_BROWSER = 'No Chrome, Edge or Chromium was found on this computer. Install one, or set AI_BRIDGE_BROWSER to the browser program\'s path.';
const NO_PAGE = 'No page is open. Call open_page first.';
const SHADER_TIMEOUT_MS = 20_000;

function text(value: string) {
  return { content: [{ type: 'text', text: value }] as Content };
}

function str(value: unknown, name: string): string {
  if (typeof value !== 'string' || !value.trim()) throw new Error(`${name} must be a non-empty string`);
  return value;
}

function bounded(value: unknown, name: string, min: number, max: number, fallback: number): number {
  if (value === undefined) return fallback;
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max) throw new Error(`${name} must be a number from ${min} to ${max}`);
  return Math.round(value);
}

/** What the model may write for a page: a URL, a file path, or host:port. */
export function pageUrl(input: string, cwd = process.cwd()): string {
  const value = input.trim();
  if (/^[a-z][a-z0-9+.-]*:\/\//i.test(value) || /^(about|data|blob):/i.test(value)) return value;
  if (/^[a-z]:[\\/]/i.test(value) || isAbsolute(value) || value.startsWith('.')) return pathToFileURL(resolve(cwd, value)).href;
  if (/^[\w.-]+:\d+(\/|$)/.test(value) || /^localhost(\/|$)/i.test(value)) return `http://${value}`;
  const local = resolve(cwd, value);
  return existsSync(local) ? pathToFileURL(local).href : `http://${value}`;
}

export interface WebToolsOptions {
  /** For a model that does not read images: screenshots and shader output come back as text. */
  textScreenshots?: boolean;
  /** Test seams. */
  findBrowser?: () => string | null;
  describeImages?: (images: ImageAttachment[]) => Promise<string[]>;
}

/** Runs one tool. Exported for tests. */
export class WebTools {
  private browser: Promise<Browser> | null = null;
  private page: Page | null = null;
  private shaderPage: Page | null = null;

  constructor(private readonly options: WebToolsOptions = {}) {}

  private async getBrowser(): Promise<Browser> {
    const current = this.browser && await this.browser.catch(() => null);
    if (current && !current.cdp.isClosed) return current;
    // A browser that crashed or was closed takes its tabs with it.
    this.page = null;
    this.shaderPage = null;
    const executable = (this.options.findBrowser ?? findBrowser)();
    if (!executable) throw new Error(NO_BROWSER);
    const launching = Browser.launch(executable);
    this.browser = launching;
    launching.catch(() => { if (this.browser === launching) this.browser = null; });
    return launching;
  }

  private openPage(): Page {
    if (!this.page) throw new Error(NO_PAGE);
    return this.page;
  }

  private async layout(page: Page, target: string | undefined, maxNodes: number): Promise<string> {
    const snapshot = await page.call<LayoutSnapshot>(collectLayout, { target, maxNodes });
    return formatLayout(snapshot, page.documentStatus);
  }

  /** Console errors and warnings that arrived after `since` entries, as one line or none. */
  private consoleSince(page: Page, since: number): string[] {
    const fresh = page.log.slice(since).filter(entry => entry.level === 'error' || entry.level === 'warn');
    return fresh.length ? ['', ...formatConsoleSummary(fresh)] : [];
  }

  async call(name: string, args: Args): Promise<{ content: Content; isError?: boolean }> {
    switch (name) {
      case 'open_page': {
        const url = pageUrl(str(args.url, 'url'));
        const width = bounded(args.width, 'width', 320, 3840, 1280);
        const height = bounded(args.height, 'height', 200, 2400, 800);
        const browser = await this.getBrowser();
        if (!this.page) this.page = await browser.newPage(width, height);
        else await this.page.setViewport(width, height);
        const started = Date.now();
        const loaded = await this.page.navigate(url);
        const note = loaded ? `Loaded in ${((Date.now() - started) / 1000).toFixed(1)} s` : 'The page had not finished loading after 30 s; this is how it looks so far';
        const layout = await this.layout(this.page, undefined, 200);
        return text([`${note} (${browser.version}).`, layout, '', ...formatConsoleSummary(this.page.log)].join('\n'));
      }
      case 'page_layout': {
        const page = this.openPage();
        const maxNodes = bounded(args.max_elements, 'max_elements', 20, 1000, 200);
        const layout = await this.layout(page, args.target === undefined ? undefined : str(args.target, 'target'), maxNodes);
        return text([layout, '', ...formatConsoleSummary(page.log)].join('\n'));
      }
      case 'page_screenshot': {
        const page = this.openPage();
        let clip: { x: number; y: number; width: number; height: number } | undefined;
        if (args.target !== undefined) {
          const found = await page.call<{ box: [number, number, number, number] }>(locateElement, str(args.target, 'target'), null);
          clip = { x: found.box[0], y: found.box[1], width: Math.max(1, found.box[2]), height: Math.max(1, found.box[3]) };
        }
        const data = await page.screenshot({ clip, fullPage: args.full_page === true });
        if (this.options.textScreenshots) {
          const [summary] = await (this.options.describeImages ?? summarizeImages)([{ fileName: 'page.png', mimeType: 'image/png', base64: data }]);
          const origin = clip ? `; add ${clip.x},${clip.y} to a position for its place on the page` : '';
          return text(`${summary}\nPositions are CSS pixels of the capture${origin}.`);
        }
        return { content: [{ type: 'image', data, mimeType: 'image/png' }, { type: 'text', text: clip ? `Captured ${clip.width}x${clip.height} at ${clip.x},${clip.y}.` : 'Captured.' }] };
      }
      case 'page_click': {
        const page = this.openPage();
        const since = page.log.length;
        const before = await page.evaluate<string>('location.href');
        const found = await page.call<{ ref: string; tag: string; text: string; x: number; y: number; covered?: string }>(locateElement, str(args.target, 'target'), null);
        await page.click(found.x, found.y);
        await page.settle(300, 3000);
        const after = await page.evaluate<string>('location.href').catch(() => before);
        const lines = [`Clicked ${found.ref} ${found.tag}${found.text ? ` ${JSON.stringify(found.text)}` : ''} at ${Math.round(found.x)},${Math.round(found.y)} in the viewport.`];
        if (found.covered) lines.push(`Note: ${found.covered} lies on top of it there, so the click went to that.`);
        if (after !== before) lines.push(`The page went to ${after}.`);
        lines.push(...this.consoleSince(page, since), '', 'Call page_layout to see the page now.');
        return text(lines.join('\n'));
      }
      case 'page_type': {
        const page = this.openPage();
        const since = page.log.length;
        if (typeof args.text !== 'string') throw new Error('text must be a string');
        const value = args.text;
        const found = await page.call<{ ref: string; tag: string }>(locateElement, str(args.target, 'target'), { clear: args.clear !== false });
        if (value) await page.insertText(value);
        if (args.submit === true) await page.pressEnter();
        await page.settle(300, 3000);
        return text([`Typed ${value.length} characters into ${found.ref} ${found.tag}${args.submit === true ? ' and pressed Enter' : ''}.`, ...this.consoleSince(page, since)].join('\n'));
      }
      case 'page_evaluate': {
        const page = this.openPage();
        const value = await page.evaluate(str(args.expression, 'expression'));
        const json = value === undefined ? 'undefined' : JSON.stringify(value, null, 2) ?? String(value);
        return text(json.length > 20_000 ? `${json.slice(0, 20_000)}\n… (${json.length - 20_000} more characters)` : json);
      }
      case 'page_console':
        return text(formatConsole(this.openPage().log));
      case 'render_shader':
        return this.renderShader(args);
      default:
        throw new Error(`Unknown tool: ${name}`);
    }
  }

  private async renderShader(args: Args): Promise<{ content: Content }> {
    const fragment = str(args.fragment, 'fragment');
    if (fragment.length > 200_000) throw new Error('fragment is longer than 200000 characters');
    const width = bounded(args.width, 'width', 1, 1024, 256);
    const height = bounded(args.height, 'height', 1, 1024, 256);
    const numbers = (value: unknown, name: string): number[] => {
      if (!Array.isArray(value) || !value.every(v => typeof v === 'number' && Number.isFinite(v))) throw new Error(`${name} must be an array of numbers`);
      return value as number[];
    };
    const times = args.times === undefined ? [0] : numbers(args.times, 'times');
    if (times.length < 1 || times.length > 8) throw new Error('times must hold 1 to 8 numbers');
    const mouse = args.mouse === undefined ? [width / 2, height / 2] : numbers(args.mouse, 'mouse');
    if (mouse.length !== 2) throw new Error('mouse must be [x, y]');
    const uniforms: ShaderOptions['uniforms'] = {};
    if (args.uniforms !== undefined) {
      if (typeof args.uniforms !== 'object' || args.uniforms === null || Array.isArray(args.uniforms)) throw new Error('uniforms must be an object of name: value');
      for (const [key, value] of Object.entries(args.uniforms)) {
        if (typeof value === 'number' || typeof value === 'boolean') uniforms[key] = value;
        else uniforms[key] = numbers(value, `uniforms.${key}`);
      }
    }
    const samples = args.samples === undefined ? [] : (Array.isArray(args.samples) ? args.samples : [null]).map((point) => {
      const p = numbers(point, 'samples');
      if (p.length !== 2) throw new Error('each sample must be [x, y]');
      return [p[0], p[1]] as [number, number];
    }).slice(0, 16);

    const browser = await this.getBrowser();
    this.shaderPage ??= await browser.newPage(64, 64);
    const page = this.shaderPage;
    const options: ShaderOptions = { fragment, width, height, times, mouse: [mouse[0], mouse[1]], uniforms, samples };
    let result: ShaderResult;
    try {
      result = await page.callWithin<ShaderResult>(SHADER_TIMEOUT_MS, renderShader, options);
    } catch (error) {
      if (!/got no answer/.test(error instanceof Error ? error.message : '')) throw error;
      // The draw still runs in the GPU process and holds up every tab, so that
      // process is ended (the browser starts it again) and the tab replaced.
      this.shaderPage = null;
      const restarted = await browser.restartGpu().catch(() => false);
      await page.close();
      throw new Error(`The shader did not finish in ${SHADER_TIMEOUT_MS / 1000} s; a loop that runs too long, or forever, is the usual cause.` +
        (restarted ? ' The browser\'s GPU process was restarted to stop it.' : ''));
    }
    const describe = this.options.textScreenshots === true;
    const content: Content = [{ type: 'text', text: formatShader(result, { width, height }, describe) }];
    if (!describe) for (const frame of result.frames) content.push({ type: 'image', data: frame.png, mimeType: 'image/png' });
    return { content };
  }

  async close(): Promise<void> {
    const browser = this.browser && await this.browser.catch(() => null);
    this.browser = null;
    if (browser) await browser.close();
  }

  /** Synchronous, for process exit. */
  kill(): void {
    void this.browser?.then(browser => browser.kill(), () => {});
  }
}

export async function runWebServer(options: WebToolsOptions = {}): Promise<void> {
  const tools = new WebTools(options);
  const server = new Server({ name: WEB_SERVER_NAME, version: '1.0.0' }, { capabilities: { tools: {} } });
  const listed = TOOLS.map((tool) => {
    if (!options.textScreenshots) return tool;
    if (tool.name === 'page_screenshot') return { ...tool, description: SCREENSHOT_AS_TEXT };
    if (tool.name === 'render_shader') return { ...tool, description: tool.description + SHADER_AS_TEXT };
    return tool;
  });
  server.setRequestHandler(ListToolsRequestSchema, async () => ({ tools: listed }));
  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    try {
      return await tools.call(request.params.name, (request.params.arguments ?? {}) as Args);
    } catch (error) {
      return { content: [{ type: 'text', text: error instanceof Error ? error.message : String(error) }], isError: true };
    }
  });
  const transport = new StdioServerTransport();
  let stopping = false;
  const stop = () => {
    if (stopping) return;
    stopping = true;
    const exit = setTimeout(() => { tools.kill(); process.exit(0); }, 5000);
    void tools.close().finally(() => { clearTimeout(exit); process.exit(0); });
  };
  process.stdin.on('end', stop);
  process.on('SIGTERM', stop);
  process.on('SIGINT', stop);
  await server.connect(transport);
}

