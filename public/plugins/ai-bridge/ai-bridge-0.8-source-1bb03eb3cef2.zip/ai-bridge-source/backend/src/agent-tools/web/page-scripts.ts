/**
 * Functions that run inside the page, not here: Page.call sends their source
 * (Function.prototype.toString) with Runtime.evaluate. Each one must be
 * self-contained, using nothing from outside its own body but its arguments
 * and the page's globals, and give back plain JSON.
 *
 * Elements found once keep a short ref (`e12`) in a page global, so the model
 * can point at what page_layout listed without writing a selector. The refs go
 * when the page navigates.
 */

export interface LayoutNode {
  ref: string;
  /** Index of the listed element this one is inside, -1 for the top. */
  parent: number;
  tag: string;
  id?: string;
  classes?: string[];
  role?: string;
  /** aria-label, alt or title. */
  label?: string;
  text?: string;
  /** An input's type, when it is not text. */
  type?: string;
  placeholder?: string;
  disabled?: boolean;
  checked?: boolean;
  /** x, y, width, height in CSS pixels from the page's top-left corner. */
  box: [number, number, number, number];
  /** Computed styles, only those that differ from the usual default. */
  css: Record<string, string>;
  /** Content bigger than the box: cut off (overflow hidden), scrolling, or spilling out. */
  overflow?: { kind: 'cut' | 'scrolls' | 'spills'; width: number; height: number; clientWidth: number; clientHeight: number };
}

export interface LayoutSnapshot {
  url: string;
  title: string;
  viewport: [number, number];
  document: [number, number];
  scroll: [number, number];
  nodes: LayoutNode[];
  /** Elements worth listing in the part asked for, listed or not. */
  total: number;
}

export function collectLayout(options: { target?: string; maxNodes: number }): LayoutSnapshot {
  const w = window as unknown as { __aiBridge?: { refs: Element[]; ids: WeakMap<Element, string> } };
  const state = w.__aiBridge ?? (w.__aiBridge = { refs: [], ids: new WeakMap() });
  const refOf = (el: Element) => {
    let ref = state.ids.get(el);
    if (!ref) {
      state.refs.push(el);
      ref = `e${state.refs.length}`;
      state.ids.set(el, ref);
    }
    return ref;
  };
  const find = (target: string): Element => {
    const byRef = /^e(\d+)$/.exec(target.trim());
    const el = byRef ? state.refs[Number(byRef[1]) - 1] : document.querySelector(target);
    if (!el) throw new Error(byRef ? `${target} is not a ref page_layout gave on this page` : `Nothing matches ${target}`);
    if (!el.isConnected) throw new Error(`${target} is no longer on the page; run page_layout again`);
    return el;
  };

  const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE', 'HEAD', 'META', 'LINK', 'TITLE', 'BR', 'WBR', 'SOURCE', 'TRACK']);
  const SHOWN = new Set(['A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA', 'IMG', 'SVG', 'CANVAS', 'VIDEO', 'IFRAME', 'LABEL',
    'H1', 'H2', 'H3', 'H4', 'H5', 'H6', 'LI', 'TD', 'TH', 'SUMMARY', 'DIALOG', 'PROGRESS', 'METER', 'HR']);
  const TEXT_TAGS = new Set(['INPUT', 'TEXTAREA', 'SELECT', 'BUTTON']);
  const transparent = (color: string) => !color || color === 'transparent' || /^rgba\(.*,\s*0\)$/.test(color);
  const px = (value: string) => parseFloat(value) || 0;
  const round = (value: number) => Math.round(value * 10) / 10;
  const sides = (values: string[]) => {
    const [t, r, b, l] = values;
    if (t === r && r === b && b === l) return t;
    if (t === b && r === l) return `${t} ${r}`;
    if (r === l) return `${t} ${r} ${b}`;
    return `${t} ${r} ${b} ${l}`;
  };
  const sx = window.scrollX, sy = window.scrollY;

  interface Item {
    el: Element;
    record: LayoutNode | null;
    self: boolean;
    textOnly: boolean;
    container: boolean;
    children: Item[];
    keep: boolean;
  }
  let walked = 0;

  const build = (el: Element, forced: boolean): Item | null => {
    if (SKIP.has(el.tagName.toUpperCase()) || walked++ > 20_000) return null;
    const cs = getComputedStyle(el);
    if (cs.display === 'none') return null;
    const children: Item[] = [];
    const kids = [...Array.from(el.children), ...Array.from(el.shadowRoot?.children ?? [])];
    if (el.tagName.toUpperCase() !== 'SVG' && el.tagName.toUpperCase() !== 'SELECT') {
      for (const child of kids) {
        const item = build(child, false);
        if (item) children.push(item);
      }
    }
    const rect = el.getBoundingClientRect();
    const visible = rect.width > 0 && rect.height > 0 && cs.visibility !== 'hidden' && parseFloat(cs.opacity) > 0;
    const tag = el.tagName.toUpperCase();
    let text = '';
    for (const node of Array.from(el.childNodes)) if (node.nodeType === 3) text += node.textContent ?? '';
    text = text.replace(/\s+/g, ' ').trim();
    const input = el as HTMLInputElement;
    let placeholder: string | undefined;
    if (tag === 'INPUT' || tag === 'TEXTAREA') {
      text = input.type === 'password' ? (input.value ? '•••' : '') : (input.value ?? '');
      placeholder = input.placeholder || undefined;
    } else if (tag === 'SELECT') {
      const select = el as HTMLSelectElement;
      text = select.selectedOptions[0]?.textContent?.trim() ?? '';
    }
    const borderWidths = ['top', 'right', 'bottom', 'left'].map(side => px(cs.getPropertyValue(`border-${side}-width`)));
    const bordered = cs.borderStyle !== 'none' && borderWidths.some(width => width > 0) && !transparent(cs.borderColor);
    const visual = !transparent(cs.backgroundColor) || cs.backgroundImage !== 'none' || bordered || cs.boxShadow !== 'none';
    const marked = SHOWN.has(tag) || el.hasAttribute('role') || el.hasAttribute('aria-label') || (el as HTMLElement).isContentEditable && !(el.parentElement as HTMLElement | null)?.isContentEditable;
    const self = forced || visible && (marked || visual || text.length > 0);
    const container = visible && /flex|grid/.test(cs.display);
    const item: Item = { el, record: null, self, textOnly: self && !forced && !marked && !visual, container, children, keep: false };
    if (!visible && !forced) return item;

    const css: Record<string, string> = {};
    const put = (name: string, value: string, skip: string[]) => { if (value && !skip.includes(value)) css[name] = value; };
    put('display', cs.display, ['block', 'inline']);
    put('position', cs.position, ['static']);
    // A relatively placed element without offsets reads 0px on every side.
    if (cs.position !== 'static') for (const side of ['top', 'right', 'bottom', 'left']) put(side, cs.getPropertyValue(side), cs.position === 'relative' ? ['auto', '0px'] : ['auto']);
    if (/flex/.test(cs.display)) {
      put('flex-direction', cs.flexDirection, []);
      put('flex-wrap', cs.flexWrap, ['nowrap']);
    }
    if (/flex|grid/.test(cs.display)) {
      put('justify-content', cs.justifyContent, ['normal', 'flex-start', 'start']);
      put('align-items', cs.alignItems, ['normal', 'stretch']);
      put('gap', cs.gap, ['normal', '0px', 'normal normal']);
    }
    if (/grid/.test(cs.display)) put('grid-template-columns', cs.gridTemplateColumns, ['none']);
    put('align-self', cs.alignSelf, ['auto']);
    put('flex-grow', cs.flexGrow, ['0']);
    put('margin', sides(['top', 'right', 'bottom', 'left'].map(side => cs.getPropertyValue(`margin-${side}`))), ['0px']);
    put('padding', sides(['top', 'right', 'bottom', 'left'].map(side => cs.getPropertyValue(`padding-${side}`))), ['0px']);
    if (bordered) put('border', `${sides(borderWidths.map(width => `${width}px`))} ${cs.borderStyle.split(' ')[0]} ${cs.borderColor.split(/ (?=rgb)/)[0]}`, []);
    put('border-radius', cs.borderRadius, ['0px']);
    put('background-color', cs.backgroundColor, ['rgba(0, 0, 0, 0)', 'transparent']);
    if (cs.backgroundImage !== 'none') css['background-image'] = cs.backgroundImage.slice(0, 80);
    if (text || TEXT_TAGS.has(tag)) {
      put('color', cs.color, []);
      css.font = `${cs.fontSize}/${cs.fontWeight} ${cs.fontFamily.split(',')[0].replace(/["']/g, '').trim()}`;
      put('line-height', cs.lineHeight, ['normal']);
      put('text-align', cs.textAlign, ['start', 'left']);
      put('white-space', cs.whiteSpace, ['normal']);
      put('text-overflow', cs.textOverflow, ['clip']);
    }
    put('vertical-align', cs.verticalAlign, ['baseline']);
    // Form controls clip by default.
    put('overflow', cs.overflow, TEXT_TAGS.has(tag) ? ['visible', 'visible visible', 'clip'] : ['visible', 'visible visible']);
    put('opacity', cs.opacity, ['1']);
    put('z-index', cs.zIndex, ['auto']);
    put('transform', cs.transform, ['none']);
    if (cs.boxShadow !== 'none') css['box-shadow'] = cs.boxShadow.slice(0, 60);
    put('cursor', cs.cursor, ['auto', 'default', 'text']);

    const record: LayoutNode = {
      ref: '',
      parent: -1,
      tag: tag.toLowerCase(),
      box: [round(rect.left + sx), round(rect.top + sy), round(rect.width), round(rect.height)],
      css,
    };
    if (el.id) record.id = el.id;
    const classes = Array.from(el.classList).slice(0, 4);
    if (classes.length) record.classes = classes;
    const role = el.getAttribute('role');
    if (role) record.role = role;
    const label = el.getAttribute('aria-label') ?? el.getAttribute('alt') ?? el.getAttribute('title');
    if (label) record.label = label.slice(0, 80);
    if (text) record.text = text.length > 80 ? `${text.slice(0, 79)}…` : text;
    if (placeholder) record.placeholder = placeholder.slice(0, 80);
    if (tag === 'INPUT' && input.type !== 'text') record.type = input.type;
    if ((el as HTMLButtonElement).disabled) record.disabled = true;
    if (tag === 'INPUT' && (input.type === 'checkbox' || input.type === 'radio')) record.checked = input.checked;
    const html = el as HTMLElement;
    if (tag !== 'HTML' && tag !== 'BODY' && html.clientWidth > 0 && (html.scrollWidth > html.clientWidth + 1 || html.scrollHeight > html.clientHeight + 1)) {
      const clipped = /hidden|clip/.test(cs.overflow) || cs.textOverflow === 'ellipsis';
      const scrolls = /auto|scroll/.test(cs.overflow);
      const spills = html.scrollWidth > html.clientWidth + 2 || html.scrollHeight > html.clientHeight + 2;
      if (clipped || scrolls || spills) {
        record.overflow = { kind: clipped ? 'cut' : scrolls ? 'scrolls' : 'spills', width: html.scrollWidth, height: html.scrollHeight, clientWidth: html.clientWidth, clientHeight: html.clientHeight };
      }
    }
    item.record = record;
    return item;
  };

  /** The listed elements right under an item, through the ones not listed. */
  const shown = (item: Item): Item[] => item.children.flatMap(child => child.keep ? [child] : shown(child));
  const decide = (item: Item) => {
    item.children.forEach(decide);
    item.keep = !!item.record && (item.self || item.container && shown(item).length >= 2);
    // A label inside a button: show its text on the button rather than as a child.
    const below = shown(item);
    if (item.keep && item.record && !item.record.text && below.length === 1 && below[0].textOnly && shown(below[0]).length === 0 && below[0].record?.text) {
      item.record.text = below[0].record.text;
      for (const key of ['color', 'font', 'line-height', 'text-align', 'white-space', 'text-overflow']) {
        const value = below[0].record.css[key];
        if (value) item.record.css[key] = value;
      }
      below[0].keep = false;
    }
  };

  const root = options.target ? find(options.target) : document.body ?? document.documentElement;
  const top = build(root, true);
  const nodes: LayoutNode[] = [];
  let total = 0;
  if (top) {
    decide(top);
    const flatten = (item: Item, parent: number) => {
      if (item.keep && item.record) {
        total++;
        // Past the limit nothing more is listed, so a listed parent is always listed first.
        if (nodes.length < options.maxNodes) {
          item.record.ref = refOf(item.el);
          item.record.parent = parent;
          nodes.push(item.record);
          parent = nodes.length - 1;
        }
      }
      for (const child of item.children) flatten(child, parent);
    };
    flatten(top, -1);
  }
  const doc = document.documentElement;
  return {
    url: location.href,
    title: document.title,
    viewport: [window.innerWidth, window.innerHeight],
    document: [Math.max(doc.scrollWidth, document.body?.scrollWidth ?? 0), Math.max(doc.scrollHeight, document.body?.scrollHeight ?? 0)],
    scroll: [sx, sy],
    nodes,
    total,
  };
}

/**
 * Finds an element by ref or CSS selector, scrolls it into view and gives the
 * point to click in viewport pixels, and what the page has on top there.
 */
export function locateElement(target: string, focus: { clear: boolean } | null): {
  ref: string; tag: string; text: string; x: number; y: number; box: [number, number, number, number]; covered?: string; editable?: boolean;
} {
  const w = window as unknown as { __aiBridge?: { refs: Element[]; ids: WeakMap<Element, string> } };
  const state = w.__aiBridge ?? (w.__aiBridge = { refs: [], ids: new WeakMap() });
  const byRef = /^e(\d+)$/.exec(target.trim());
  const el = byRef ? state.refs[Number(byRef[1]) - 1] : document.querySelector(target);
  if (!el) throw new Error(byRef ? `${target} is not a ref page_layout gave on this page` : `Nothing matches ${target}`);
  if (!el.isConnected) throw new Error(`${target} is no longer on the page; run page_layout again`);
  let ref = state.ids.get(el);
  if (!ref) {
    state.refs.push(el);
    ref = `e${state.refs.length}`;
    state.ids.set(el, ref);
  }
  el.scrollIntoView({ block: 'center', inline: 'center' });
  const rect = el.getBoundingClientRect();
  if (rect.width === 0 || rect.height === 0) throw new Error(`${target} (${el.tagName.toLowerCase()}) takes no space on the page`);
  const x = rect.left + rect.width / 2, y = rect.top + rect.height / 2;
  const describe = (node: Element) => `${node.tagName.toLowerCase()}${node.id ? `#${node.id}` : ''}${Array.from(node.classList).slice(0, 2).map(c => `.${c}`).join('')}`;
  const hit = document.elementFromPoint(x, y);
  const covered = hit && hit !== el && !el.contains(hit) && !hit.contains(el) ? describe(hit) : undefined;
  const text = ((el as HTMLElement).innerText ?? el.textContent ?? '').replace(/\s+/g, ' ').trim().slice(0, 60);
  const result = {
    ref, tag: describe(el), text, x, y,
    box: [rect.left + window.scrollX, rect.top + window.scrollY, rect.width, rect.height].map(v => Math.round(v * 10) / 10) as [number, number, number, number],
    ...(covered ? { covered } : {}),
  };
  if (!focus) return result;
  const html = el as HTMLElement;
  const field = el as HTMLInputElement;
  const isField = (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA') && !field.readOnly && !field.disabled;
  if (!isField && !html.isContentEditable) throw new Error(`${target} (${describe(el)}) does not take text`);
  html.focus();
  if (focus.clear) {
    if (isField) field.select();
    else {
      const range = document.createRange();
      range.selectNodeContents(el);
      const selection = window.getSelection();
      selection?.removeAllRanges();
      selection?.addRange(range);
    }
  } else if (isField) {
    const end = field.value.length;
    try { field.setSelectionRange(end, end); } catch { /* an input type without a caret */ }
  }
  return { ...result, editable: true };
}

export interface ShaderOptions {
  fragment: string;
  width: number;
  height: number;
  times: number[];
  /** iMouse / u_mouse, in pixels from the bottom-left like fragCoord. */
  mouse: [number, number];
  uniforms: Record<string, number | number[] | boolean>;
  /** fragCoord points to report the exact output of, besides the center and corners. */
  samples: Array<[number, number]>;
}

export interface ShaderFrame {
  time: number;
  ms: number;
  /** PNG of the color channels, without the data: prefix. */
  png: string;
  min: number[];
  max: number[];
  mean: number[];
  /** Pixels with a NaN or an infinite channel. */
  nan: number;
  inf: number;
  /** Per channel: pixels above 1 and below 0, before the output is clamped. */
  above: number[];
  below: number[];
  samples: Array<{ name: string; x: number; y: number; rgba: number[] }>;
}

export interface ShaderResult {
  ok: boolean;
  stage?: 'context' | 'vertex' | 'fragment' | 'link' | 'draw';
  errors?: Array<{ line?: number; message: string; source?: string }>;
  mode: 'shadertoy' | 'glsl300' | 'glsl100';
  /** Whether the raw output was read as floats, before the 0–1 clamp. */
  float: boolean;
  renderer: string;
  uniforms: string[];
  unset: string[];
  samplers: string[];
  frames: ShaderFrame[];
}

/**
 * Draws a fragment shader over a full-screen triangle with WebGL2, in this
 * browser's CPU renderer, and reads back what it wrote. A Shadertoy shader
 * (mainImage, iTime, iResolution...) is wrapped with what Shadertoy declares.
 */
export function renderShader(o: ShaderOptions): ShaderResult {
  const canvas = document.createElement('canvas');
  canvas.width = o.width;
  canvas.height = o.height;
  const gl = canvas.getContext('webgl2', { preserveDrawingBuffer: true, antialias: false, premultipliedAlpha: false });
  const base = { mode: 'glsl100' as ShaderResult['mode'], float: false, renderer: '', uniforms: [] as string[], unset: [] as string[], samplers: [] as string[], frames: [] as ShaderFrame[] };
  if (!gl) return { ...base, ok: false, stage: 'context', errors: [{ message: 'WebGL2 is not available in this browser' }] };
  const debug = gl.getExtension('WEBGL_debug_renderer_info');
  base.renderer = String(debug ? gl.getParameter(debug.UNMASKED_RENDERER_WEBGL) : gl.getParameter(gl.RENDERER));

  const source = o.fragment;
  const userLines = source.split('\n');
  const shadertoy = /\bmainImage\s*\(/.test(source) && !/\bvoid\s+main\s*\(/.test(source);
  const v300 = /^\s*#version\s+300\s+es/.test(source);
  let fragment = source;
  let offset = 0;
  if (shadertoy) {
    base.mode = 'shadertoy';
    const declared = (name: string) => new RegExp(`\\buniform\\s+\\w+\\s+${name}\\b`).test(source);
    const head = ['#version 300 es', 'precision highp float;', 'precision highp int;'];
    const builtins: Array<[string, string]> = [['vec3', 'iResolution'], ['float', 'iTime'], ['float', 'iTimeDelta'], ['float', 'iFrameRate'], ['int', 'iFrame'],
      ['vec4', 'iMouse'], ['vec4', 'iDate'], ['sampler2D', 'iChannel0'], ['sampler2D', 'iChannel1'], ['sampler2D', 'iChannel2'], ['sampler2D', 'iChannel3']];
    for (const [type, name] of builtins) if (!declared(name)) head.push(`uniform ${type} ${name};`);
    head.push('out vec4 aiBridgeColor;');
    offset = head.length;
    fragment = `${head.join('\n')}\n${source}\nvoid main() { vec4 color = vec4(0.0, 0.0, 0.0, 1.0); mainImage(color, gl_FragCoord.xy); aiBridgeColor = color; }\n`;
  } else if (v300) {
    base.mode = 'glsl300';
  } else if (!/\bprecision\s+\w+\s+float\b/.test(source) && !/^\s*#(version|extension)/m.test(source)) {
    fragment = `precision highp float;\n${source}`;
    offset = 1;
  }
  const vertex = base.mode === 'glsl100'
    ? 'attribute vec2 aiBridgePosition;\nvoid main() { gl_Position = vec4(aiBridgePosition, 0.0, 1.0); }'
    : '#version 300 es\nin vec2 aiBridgePosition;\nvoid main() { gl_Position = vec4(aiBridgePosition, 0.0, 1.0); }';

  const errorsOf = (log: string, mapLines: boolean) => log.split('\n').map(line => line.trim()).filter(Boolean).map((line) => {
    const match = /^(?:ERROR|WARNING):\s*\d+:(\d+):\s*(.*)$/.exec(line);
    if (!match || !mapLines) return { message: line };
    const n = Number(match[1]) - offset;
    if (n < 1 || n > userLines.length) return { message: match[2] };
    // A missing ; or ) is reported at the token after it, often on the next line.
    let before = n - 1;
    while (before >= 1 && !userLines[before - 1].trim()) before--;
    const context = /syntax error/.test(match[2]) && before >= 1 ? ` (line ${before}: ${userLines[before - 1].trim().slice(0, 120)})` : '';
    return { line: n, message: match[2], source: userLines[n - 1].trim().slice(0, 160) + context };
  });
  const compile = (type: number, text: string) => {
    const shader = gl.createShader(type)!;
    gl.shaderSource(shader, text);
    gl.compileShader(shader);
    return shader;
  };
  const vs = compile(gl.VERTEX_SHADER, vertex);
  if (!gl.getShaderParameter(vs, gl.COMPILE_STATUS)) return { ...base, ok: false, stage: 'vertex', errors: errorsOf(gl.getShaderInfoLog(vs) ?? '', false) };
  const fs = compile(gl.FRAGMENT_SHADER, fragment);
  if (!gl.getShaderParameter(fs, gl.COMPILE_STATUS)) return { ...base, ok: false, stage: 'fragment', errors: errorsOf(gl.getShaderInfoLog(fs) ?? '', true) };
  const program = gl.createProgram()!;
  gl.attachShader(program, vs);
  gl.attachShader(program, fs);
  gl.bindAttribLocation(program, 0, 'aiBridgePosition');
  gl.linkProgram(program);
  if (!gl.getProgramParameter(program, gl.LINK_STATUS)) return { ...base, ok: false, stage: 'link', errors: errorsOf(gl.getProgramInfoLog(program) ?? '', true) };
  gl.useProgram(program);

  const w = o.width, h = o.height;
  const active: Array<{ name: string; type: number; location: WebGLUniformLocation }> = [];
  const samplerTypes: number[] = [gl.SAMPLER_2D, gl.SAMPLER_CUBE, gl.SAMPLER_3D, gl.SAMPLER_2D_ARRAY, gl.SAMPLER_2D_SHADOW, gl.INT_SAMPLER_2D, gl.UNSIGNED_INT_SAMPLER_2D];
  const count = gl.getProgramParameter(program, gl.ACTIVE_UNIFORMS) as number;
  for (let i = 0; i < count; i++) {
    const info = gl.getActiveUniform(program, i);
    if (!info) continue;
    const name = info.name.replace(/\[0\]$/, '');
    if (samplerTypes.includes(info.type)) { base.samplers.push(name); continue; }
    const location = gl.getUniformLocation(program, info.name);
    if (location) active.push({ name, type: info.type, location });
  }
  base.uniforms = active.map(u => u.name);
  const now = new Date();
  const values = (time: number): Record<string, number | number[] | boolean> => ({
    iResolution: [w, h, 1], iTime: time, iTimeDelta: 1 / 60, iFrameRate: 60, iFrame: Math.round(time * 60),
    iMouse: [o.mouse[0], o.mouse[1], 0, 0], iDate: [now.getFullYear(), now.getMonth(), now.getDate(), now.getHours() * 3600 + now.getMinutes() * 60 + now.getSeconds()],
    u_resolution: [w, h], u_time: time, u_mouse: [o.mouse[0], o.mouse[1]],
    resolution: [w, h], time, mouse: [o.mouse[0], o.mouse[1]],
    ...o.uniforms,
  });
  base.unset = base.uniforms.filter(name => !(name in values(0)));
  const set = (u: { type: number; location: WebGLUniformLocation }, value: number | number[] | boolean) => {
    const raw = Array.isArray(value) ? value : [typeof value === 'boolean' ? (value ? 1 : 0) : value];
    const v = (n: number) => Array.from({ length: n }, (_, i) => Number(raw[i] ?? 0));
    switch (u.type) {
      case gl.FLOAT: gl.uniform1f(u.location, v(1)[0]); break;
      case gl.FLOAT_VEC2: gl.uniform2fv(u.location, v(2)); break;
      case gl.FLOAT_VEC3: gl.uniform3fv(u.location, v(3)); break;
      case gl.FLOAT_VEC4: gl.uniform4fv(u.location, v(4)); break;
      case gl.INT: case gl.BOOL: gl.uniform1i(u.location, Math.round(v(1)[0])); break;
      case gl.INT_VEC2: case gl.BOOL_VEC2: gl.uniform2iv(u.location, v(2).map(Math.round)); break;
      case gl.INT_VEC3: case gl.BOOL_VEC3: gl.uniform3iv(u.location, v(3).map(Math.round)); break;
      case gl.INT_VEC4: case gl.BOOL_VEC4: gl.uniform4iv(u.location, v(4).map(Math.round)); break;
      case gl.UNSIGNED_INT: gl.uniform1ui(u.location, Math.max(0, Math.round(v(1)[0]))); break;
      case gl.FLOAT_MAT2: gl.uniformMatrix2fv(u.location, false, v(4)); break;
      case gl.FLOAT_MAT3: gl.uniformMatrix3fv(u.location, false, v(9)); break;
      case gl.FLOAT_MAT4: gl.uniformMatrix4fv(u.location, false, v(16)); break;
      default: break;
    }
  };

  let float = !!gl.getExtension('EXT_color_buffer_float');
  if (float) {
    const texture = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, texture);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA32F, w, h, 0, gl.RGBA, gl.FLOAT, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.NEAREST);
    const framebuffer = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, framebuffer);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, texture, 0);
    if (gl.checkFramebufferStatus(gl.FRAMEBUFFER) !== gl.FRAMEBUFFER_COMPLETE) {
      gl.bindFramebuffer(gl.FRAMEBUFFER, null);
      float = false;
    }
    gl.bindTexture(gl.TEXTURE_2D, null);
  }
  base.float = float;
  const buffer = gl.createBuffer();
  gl.bindBuffer(gl.ARRAY_BUFFER, buffer);
  gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
  gl.enableVertexAttribArray(0);
  gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
  gl.viewport(0, 0, w, h);

  const image = document.createElement('canvas');
  image.width = w;
  image.height = h;
  const context = image.getContext('2d')!;
  const points: Array<[string, number, number]> = [
    ['center', Math.floor(w / 2), Math.floor(h / 2)], ['bottom-left', 0, 0], ['bottom-right', w - 1, 0], ['top-left', 0, h - 1], ['top-right', w - 1, h - 1],
    ...o.samples.map(([x, y]) => [`at ${x},${y}`, Math.min(w - 1, Math.max(0, Math.floor(x))), Math.min(h - 1, Math.max(0, Math.floor(y)))] as [string, number, number]),
  ];
  for (const time of o.times) {
    const started = performance.now();
    const frameValues = values(time);
    for (const u of active) if (u.name in frameValues) set(u, frameValues[u.name]);
    gl.clearColor(0, 0, 0, 0);
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    let data: Float32Array;
    if (float) {
      data = new Float32Array(w * h * 4);
      gl.readPixels(0, 0, w, h, gl.RGBA, gl.FLOAT, data);
    } else {
      const bytes = new Uint8Array(w * h * 4);
      gl.readPixels(0, 0, w, h, gl.RGBA, gl.UNSIGNED_BYTE, bytes);
      data = Float32Array.from(bytes, b => b / 255);
    }
    if (gl.isContextLost()) return { ...base, ok: false, stage: 'draw', errors: [{ message: 'The browser stopped the shader while it drew (the GPU watchdog); a loop may run too long' }] };
    const ms = Math.round(performance.now() - started);
    const min = [Infinity, Infinity, Infinity, Infinity], max = [-Infinity, -Infinity, -Infinity, -Infinity], sum = [0, 0, 0, 0], counted = [0, 0, 0, 0];
    const above = [0, 0, 0, 0], below = [0, 0, 0, 0];
    let nan = 0, inf = 0;
    const pixels = context.createImageData(w, h);
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        const o8 = ((h - 1 - y) * w + x) * 4;
        let bad = false, infinite = false;
        for (let c = 0; c < 4; c++) {
          const value = data[i + c];
          if (Number.isNaN(value)) { bad = true; continue; }
          if (!Number.isFinite(value)) { infinite = true; continue; }
          if (value < min[c]) min[c] = value;
          if (value > max[c]) max[c] = value;
          sum[c] += value;
          counted[c]++;
          if (value > 1) above[c]++;
          if (value < 0) below[c]++;
        }
        if (bad) nan++;
        else if (infinite) inf++;
        for (let c = 0; c < 3; c++) {
          const value = data[i + c];
          pixels.data[o8 + c] = Number.isFinite(value) ? Math.round(Math.min(1, Math.max(0, value)) * 255) : 0;
        }
        pixels.data[o8 + 3] = 255;
      }
    }
    context.putImageData(pixels, 0, 0);
    base.frames.push({
      time, ms,
      png: image.toDataURL('image/png').replace(/^data:image\/png;base64,/, ''),
      min: min.map(v => Number.isFinite(v) ? v : 0), max: max.map(v => Number.isFinite(v) ? v : 0), mean: sum.map((v, c) => v / Math.max(1, counted[c])),
      nan, inf, above, below,
      samples: points.map(([name, x, y]) => ({ name, x, y, rgba: Array.from(data.subarray((y * w + x) * 4, (y * w + x) * 4 + 4)) })),
    });
  }
  return { ...base, ok: true };
}
