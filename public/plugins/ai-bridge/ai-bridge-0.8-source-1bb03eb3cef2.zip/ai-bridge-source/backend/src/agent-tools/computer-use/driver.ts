/**
 * The OS side of computer use: one small interface, one implementation per
 * platform. Coordinates here are always the screen's own (physical pixels on
 * Windows and Linux, points on macOS); scaling to and from the screenshot the
 * model sees happens in the server, in one place.
 */
export type MouseButton = 'left' | 'right' | 'middle';

export interface Screenshot {
  /** PNG, base64. */
  data: string;
  /** Size of the image the model sees. */
  width: number;
  height: number;
}

export interface ScreenSize {
  width: number;
  height: number;
}

/** The window window_layout reads: by a part of its title, by process id, or else the foreground one. */
export interface WindowQuery {
  title?: string;
  pid?: number;
  maxElements: number;
  /** How long to walk the tree before stopping with what was read so far. */
  budgetMs: number;
}

export interface Driver {
  screenSize(): Promise<ScreenSize>;
  /**
   * A window's UI tree as the platform's reader reports it, in screen
   * coordinates (window-layout.ts checks and describes it). Absent on the
   * platforms that have no reader yet.
   */
  windowTree?(query: WindowQuery): Promise<unknown>;
  /** A PNG of the primary screen, scaled to fit inside maxWidth × maxHeight. */
  screenshot(maxWidth: number, maxHeight: number): Promise<Screenshot>;
  cursorPosition(): Promise<{ x: number; y: number }>;
  moveMouse(x: number, y: number): Promise<void>;
  click(button: MouseButton, count: number, modifiers: string[]): Promise<void>;
  mouseButton(button: MouseButton, down: boolean): Promise<void>;
  scroll(dx: number, dy: number): Promise<void>;
  typeText(text: string): Promise<void>;
  /** A combination such as `ctrl+shift+t`, pressed and released in order. */
  pressKeys(keys: string[]): Promise<void>;
  close(): void;
}

/** Fit a screen inside the box the screenshot is scaled to, never enlarging it. */
export function fitInside(screen: ScreenSize, maxWidth: number, maxHeight: number): ScreenSize {
  const ratio = Math.min(1, maxWidth / screen.width, maxHeight / screen.height);
  return { width: Math.max(1, Math.round(screen.width * ratio)), height: Math.max(1, Math.round(screen.height * ratio)) };
}

/** Split `ctrl+shift+t` / `Ctrl + T` into normalized key names. */
export function parseKeyCombo(combo: string): string[] {
  return combo
    .split('+')
    .map(k => k.trim().toLowerCase())
    .filter(Boolean)
    .map(k => KEY_ALIASES[k] ?? k);
}

const KEY_ALIASES: Record<string, string> = {
  control: 'ctrl', cmd: 'meta', command: 'meta', super: 'meta', win: 'meta', windows: 'meta', option: 'alt',
  return: 'enter', esc: 'escape', del: 'delete', pgup: 'pageup', pgdn: 'pagedown', page_up: 'pageup',
  page_down: 'pagedown', arrowup: 'up', arrowdown: 'down', arrowleft: 'left', arrowright: 'right', backspace: 'backspace',
  ' ': 'space', spacebar: 'space',
};

export const MODIFIERS = new Set(['ctrl', 'shift', 'alt', 'meta']);

export async function createDriver(): Promise<Driver> {
  if (process.platform === 'win32') {
    const { WindowsDriver } = await import('./win-driver');
    return new WindowsDriver();
  }
  if (process.platform === 'darwin') {
    const { MacDriver } = await import('./posix-driver');
    return new MacDriver();
  }
  const { LinuxDriver } = await import('./posix-driver');
  return new LinuxDriver();
}
