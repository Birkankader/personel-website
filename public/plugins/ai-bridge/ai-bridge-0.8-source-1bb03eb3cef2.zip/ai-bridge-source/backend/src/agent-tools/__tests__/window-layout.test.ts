import { describe, expect, it } from 'vitest';
import { ComputerUse, windowQuery } from '../computer-use/server';
import { fitInside, type Driver, type WindowQuery } from '../computer-use/driver';
import { formatWindowLayout, parseWindowTree, windowNodes, type RawElement, type Scale, type WindowTree } from '../computer-use/window-layout';
import { WINDOW_TREE_SOURCE } from '../computer-use/win-tree';
import { outsideBy, overlapSize, siblingPairs } from '../layout/geometry';

type Rect = [number, number, number, number];

const SCREEN = { width: 1920, height: 1200 };
/** At 100%, so 96-DPI pixels are screen pixels; the screenshot is the screen at 2/3. */
const scale100: Scale = { screen: SCREEN, shot: fitInside(SCREEN, 1280, 800), display: 1 };

/** A WinForms dialog as UI Automation reports it, top-level breadth-first like the reader. */
function dialog(extra: RawElement[] = [], dpi = 96): WindowTree {
  return parseWindowTree({
    dpi,
    window: { title: 'Settings', pid: 42, process: 'MyApp', className: 'WindowsForms10.Window.8.app', frameworkId: 'WinForm', boundingRectangle: [300, 150, 480, 300], isMinimized: false, isForeground: true },
    source: 'uia',
    elements: [
      { parent: -1, controlType: 'Window', name: 'Settings', frameworkId: 'WinForm', boundingRectangle: [300, 150, 480, 300] },
      { parent: 0, controlType: 'TitleBar', name: 'Settings', automationId: 'TitleBar', frameworkId: 'WinForm', boundingRectangle: [300, 150, 480, 30] },
      { parent: 0, controlType: 'Button', name: 'OK', automationId: 'okButton', frameworkId: 'WinForm', boundingRectangle: [500, 400, 80, 28], hasKeyboardFocus: true },
      { parent: 0, controlType: 'Button', name: 'Cancel', automationId: 'cancelButton', frameworkId: 'WinForm', boundingRectangle: [590, 404, 80, 28] },
      // Title bar buttons, drawn by Windows, a pixel apart: never a finding.
      { parent: 1, controlType: 'Button', name: 'Minimize', frameworkId: 'WinForm', boundingRectangle: [650, 150, 40, 29] },
      { parent: 1, controlType: 'Button', name: 'Close', frameworkId: 'WinForm', boundingRectangle: [700, 151, 40, 29] },
      ...extra,
    ],
    full: false, timedOut: false, unread: 0,
  });
}

const layout = (tree: WindowTree, query: Partial<WindowQuery> = {}) =>
  formatWindowLayout(tree, { query: { maxElements: 200, ...query }, screen: SCREEN, shot: scale100.shot });

describe('parseWindowTree', () => {
  it('keeps well-formed fields and drops the rest', () => {
    const tree = parseWindowTree({
      dpi: 'big',
      window: { title: 'A', pid: '7', boundingRectangle: [1, 2, 3] },
      source: 'something',
      elements: [
        { parent: -1, controlType: 'Window', boundingRectangle: [0, 0, 10, 10], isEnabled: 'no' },
        'junk',
        { parent: 5, controlType: 'Button', name: 3, boundingRectangle: [0, 0, 1, NaN] },
      ],
      full: 'yes',
    });
    expect(tree.dpi).toBe(96);
    expect(tree.window).toMatchObject({ title: 'A', pid: 0, boundingRectangle: undefined });
    expect(tree.source).toBeUndefined();
    expect(tree.elements).toHaveLength(2);
    expect(tree.elements[0]).toMatchObject({ parent: -1, controlType: 'Window', boundingRectangle: [0, 0, 10, 10], isEnabled: undefined });
    // A parent that does not come first is read as a top element.
    expect(tree.elements[1]).toMatchObject({ parent: -1, name: undefined, boundingRectangle: undefined });
    expect(tree).toMatchObject({ full: false, timedOut: false, unread: 0 });
    expect(() => parseWindowTree('nope')).toThrow(/no result/);
  });
});

describe('windowNodes', () => {
  it('lists the tree depth-first with refs, in screenshot and 96-DPI pixels', () => {
    const nodes = windowNodes(dialog([], 120), { ...scale100, display: 1.25 });
    expect(nodes.map(n => `${n.ref} ${n.kind} ${n.raw.name}`)).toEqual([
      'w1 Window Settings', 'w2 TitleBar Settings', 'w3 Button Minimize', 'w4 Button Close', 'w5 Button OK', 'w6 Button Cancel',
    ]);
    expect(nodes.map(n => n.parent)).toEqual([-1, 0, 1, 1, 0, 0]);
    const ok = nodes[4];
    expect(ok.shot!.map(n => Math.round(n * 100) / 100)).toEqual([333.33, 266.67, 53.33, 18.67]);
    expect(ok.box).toEqual([400, 320, 64, 22.4]);
    expect(ok.focused).toBe(true);
    expect(nodes.filter(n => n.chrome).map(n => n.ref)).toEqual(['w2', 'w3', 'w4']);
  });

  it('reads the Java Access Bridge\'s roles and states', () => {
    const tree = parseWindowTree({
      dpi: 96, source: 'java-access-bridge', window: { title: 'Swing', pid: 1, className: 'SunAwtFrame' },
      elements: [
        { parent: -1, role: 'frame', name: 'Swing', states: 'enabled,showing', boundingRectangle: [0, 0, 400, 300] },
        { parent: 0, role: 'check box', name: 'Remember', states: 'enabled,showing,checked,focused', boundingRectangle: [10, 10, 100, 20] },
        { parent: 0, role: 'check box', name: 'Again', states: 'showing', boundingRectangle: [10, 40, 100, 20] },
        { parent: 0, role: 'panel', states: 'enabled' },
      ],
    });
    const [, remember, again, hidden] = windowNodes(tree, scale100);
    expect(remember).toMatchObject({ kind: 'check box', checked: 'checked', focused: true, enabled: true, offscreen: false });
    expect(again).toMatchObject({ checked: 'unchecked', enabled: false });
    expect(hidden).toMatchObject({ offscreen: true, shot: undefined });
    expect(layout(tree)).toContain('- w2 check box "Remember" 6.7,6.7 66.7x13.3 · focused · checked');
  });
});

describe('formatWindowLayout', () => {
  it('describes the window, its elements, and a button 4 px lower than its neighbour', () => {
    const text = layout(dialog());
    expect(text).toContain('Window "Settings": WinForms, read through UI Automation; process MyApp (pid 42), at 200,100 320x200.');
    expect(text).toContain('Boxes are x,y WxH in screenshot pixels (the 1920x1200 screen shown at 1280x800), which the other tools take.');
    expect(text).toContain('  - w5 Button "OK" #okButton 333.3,266.7 53.3x18.7 · focused');
    expect(text).toContain('- w6 Button "Cancel" #cancelButton sits 4 px lower than w5 Button "OK" #okButton');
    expect(text).not.toMatch(/Minimize.*(lower|higher|taller)/);
    expect(text).not.toContain('Worth a look');
  });

  it('gives the screen pixels too on a scaled display', () => {
    // At 150% the 4 px slip is 6 screen pixels; boxes stay in screenshot pixels.
    const tree = dialog([], 144);
    for (const e of tree.elements) e.boundingRectangle = e.boundingRectangle?.map(n => n * 1.5) as Rect;
    const text = layout(tree);
    expect(text).toContain('The display is scaled to 150%.');
    expect(text).toContain('Distances are in 96-DPI pixels (screen pixels ÷ 1.5)');
    expect(text).toContain('sits 4 px (6 screen px) lower than w5 Button "OK"');
  });

  it('names the odd one out once when it is off from several siblings', () => {
    const text = layout(dialog([{ parent: 0, controlType: 'Button', name: 'Help', frameworkId: 'WinForm', boundingRectangle: [680, 400, 80, 28] }]));
    expect(text).toContain('w6 Button "Cancel" #cancelButton sits 4 px lower than w5 Button "OK" #okButton and w7 Button "Help"');
    expect(text.match(/sits/g)).toHaveLength(1);
  });

  it('leaves alone what lines up on purpose, and words sizes and edges', () => {
    const text = layout(dialog([
      // A label centred on a taller field: a choice, not a slip.
      { parent: 0, controlType: 'Text', name: 'Name', boundingRectangle: [320, 204, 60, 16] },
      { parent: 0, controlType: 'Edit', name: 'Name', boundingRectangle: [390, 200, 200, 24] },
      // Stacked fields, the lowest 3 px further right.
      { parent: 0, controlType: 'Edit', name: 'Email', boundingRectangle: [390, 240, 200, 24] },
      { parent: 0, controlType: 'Edit', name: 'Phone', boundingRectangle: [393, 280, 200, 24] },
      // Stacked, one 2 px narrower with its left edge in line.
      { parent: 0, controlType: 'Edit', name: 'City', boundingRectangle: [390, 320, 198, 24] },
      // Side by side, the same type, 2 px taller with tops aligned.
      { parent: 0, controlType: 'CheckBox', name: 'A', boundingRectangle: [320, 380, 60, 20] },
      { parent: 0, controlType: 'CheckBox', name: 'B', boundingRectangle: [400, 380, 60, 22] },
    ]));
    expect(text).not.toMatch(/Text "Name".*(lower|higher)/);
    expect(text).toContain('w10 Edit "Phone" sits 3 px further right than w8 Edit "Name", w9 Edit "Email" and w11 Edit "City"');
    expect(text).toContain('w11 Edit "City" is 2 px narrower than w8 Edit "Name", w9 Edit "Email" and w10 Edit "Phone"');
    expect(text.match(/Edit "City"/g)).toHaveLength(3);
    expect(text).toContain('w13 CheckBox "B" is 2 px taller than w12 CheckBox "A"');
  });

  it('finds controls cut off by their container, overlaps, and skips what scrolls', () => {
    const text = layout(dialog([
      { parent: 0, controlType: 'Pane', automationId: 'tools', frameworkId: 'WinForm', boundingRectangle: [320, 200, 100, 40] },
      { parent: 0, controlType: 'List', automationId: 'items', frameworkId: 'WinForm', boundingRectangle: [320, 260, 100, 60], isScrollPatternAvailable: true },
      { parent: 0, controlType: 'Button', name: 'Apply', frameworkId: 'WinForm', boundingRectangle: [640, 404, 60, 28] },
      { parent: 6, controlType: 'Button', name: 'Wide', frameworkId: 'WinForm', boundingRectangle: [360, 206, 90, 28] },
      { parent: 7, controlType: 'ListItem', name: 'Row 9', frameworkId: 'WinForm', boundingRectangle: [320, 330, 100, 20] },
    ]));
    expect(text).toContain('- w8 Button "Wide" is cut off by w7 Pane #tools: 30 px past its right edge');
    expect(text).not.toContain('Row 9" is cut off');
    expect(text).toContain('- w6 Button "Cancel" #cancelButton and w11 Button "Apply" overlap by 30x28 px');
    // Cancel and Apply share a top, so OK is the one out of line.
    expect(text).toContain('- w5 Button "OK" #okButton sits 4 px higher than w6 Button "Cancel" #cancelButton and w11 Button "Apply"');
  });

  it('says a WPF child sticks out rather than is cut off', () => {
    const tree = parseWindowTree({
      dpi: 96, source: 'uia', window: { title: 'W', pid: 1, frameworkId: 'WPF', boundingRectangle: [0, 0, 500, 400] },
      elements: [
        { parent: -1, controlType: 'Window', frameworkId: 'WPF', boundingRectangle: [0, 0, 500, 400] },
        { parent: 0, controlType: 'Group', name: 'Box', frameworkId: 'WPF', boundingRectangle: [10, 40, 200, 100] },
        { parent: 1, controlType: 'Button', name: 'Go', frameworkId: 'WPF', boundingRectangle: [150, 120, 80, 30] },
      ],
    });
    expect(layout(tree)).toContain('w3 Button "Go" sticks out of w2 Group "Box": 20 px past its right edge, 10 px past its bottom edge');
  });

  it('explains Swing without the Java Access Bridge, game engines and empty trees', () => {
    const frameOnly = (window: Record<string, unknown>, extra: Record<string, unknown> = {}) => parseWindowTree({
      dpi: 96, source: 'uia', window: { title: 'App', pid: 9, boundingRectangle: [0, 0, 800, 600], ...window }, ...extra,
      elements: [
        { parent: -1, controlType: 'Window', boundingRectangle: [0, 0, 800, 600] },
        { parent: 0, controlType: 'TitleBar', boundingRectangle: [0, 0, 800, 30] },
      ],
    });
    expect(layout(frameOnly({ className: 'SunAwtFrame', process: 'java' }, { java: 'off' }))).toContain('Turn it on with "jabswitch -enable"');
    expect(layout(frameOnly({ className: 'SunAwtFrame' }, { java: 'no-client' }))).toContain('(windowsaccessbridge-64.dll) was not found');
    expect(layout(frameOnly({ className: 'UnityWndClass', process: 'MyGame' }))).toContain('Unity draws its interface on the GPU');
    expect(layout(frameOnly({ className: 'UnrealWindow' }))).toContain('Unreal Engine draws its interface on the GPU');
    expect(layout(frameOnly({ className: 'Canvas' }))).toContain('shows almost no controls to UI Automation');
    expect(layout(frameOnly({ isMinimized: true }))).toContain('The window is minimized');
  });

  it('says where the window is when the screenshot cannot show all of it', () => {
    const at = (box: Rect, extra: Record<string, unknown> = {}) => layout(parseWindowTree({
      ...extra, dpi: 96, source: 'uia', window: { title: 'X', pid: 1, boundingRectangle: box, isForeground: false, ...extra.window as object },
      elements: [{ parent: -1, controlType: 'Window', boundingRectangle: box }, { parent: 0, controlType: 'Button', boundingRectangle: [box[0] + 10, box[1] + 40, 80, 28] }],
    }));
    expect(at([1800, 100, 400, 300])).toContain('The window reaches past the screen (186.7 px past the right); that part is not in the screenshot.');
    expect(at([2000, 100, 400, 300])).toContain('not on the primary screen');
    expect(at([2000, 100, 400, 300])).toContain('outside the screenshot');
    expect(at([100, 100, 400, 300])).toContain('It is not the window in front');
    expect(at([100, 100, 400, 300], { alsoMatched: [{ title: 'X (2)', pid: 5, process: 'app' }] })).toContain('Other windows match too: "X (2)" (app, pid 5). Pass window their pid');
  });

  it('says when the list stopped early', () => {
    const tree = dialog();
    expect(layout({ ...tree, full: true, unread: 3 })).toContain('… The list stops at 200 elements, so what is inside 3 of the elements above was not read. Pass a higher max_elements');
    expect(layout({ ...tree, timedOut: true, unread: 1 })).toContain('… Reading stopped at the time limit, so what is inside 1 of the elements above was not read.');
  });

  it('lists the open windows when none matches', () => {
    const tree = parseWindowTree({ dpi: 96, windows: [{ title: 'Notes', pid: 3, process: 'notepad' }, { title: 'Mail', pid: 4 }] });
    expect(layout(tree, { title: 'Settings' })).toBe('No window\'s title contains "Settings". Open windows, front to back: "Notes" (notepad, pid 3); "Mail" (pid 4). Pass window a part of a title, or a process id.');
    expect(layout(tree, { pid: 77 })).toMatch(/^No window belongs to process 77\./);
  });
});

/** A 1920×1200 screen whose reader returns the dialog above. */
function fakeDriver(tree: unknown = dialog()) {
  const queries: WindowQuery[] = [];
  const driver: Driver = {
    screenSize: async () => SCREEN,
    screenshot: async (w, h) => ({ data: 'PNG', ...fitInside(SCREEN, w, h) }),
    windowTree: async (query) => { queries.push(query); return tree; },
    cursorPosition: async () => ({ x: 0, y: 0 }),
    moveMouse: async () => {}, click: async () => {}, mouseButton: async () => {}, scroll: async () => {},
    typeText: async () => {}, pressKeys: async () => {}, close: () => {},
  };
  return { driver, queries };
}

describe('window_layout tool', () => {
  it('passes a title or a process id and describes the window in screenshot pixels', async () => {
    const { driver, queries } = fakeDriver();
    const cu = new ComputerUse(driver);
    const result = await cu.call('window_layout', { window: 'Sett', max_elements: 50 });
    expect(result.content[0].text).toContain('w6 Button "Cancel" #cancelButton sits 4 px lower');
    await cu.call('window_layout', { window: 4242 });
    await cu.call('window_layout', {});
    expect(queries).toEqual([
      { title: 'Sett', maxElements: 50, budgetMs: 8000 },
      { pid: 4242, maxElements: 200, budgetMs: 8000 },
      { maxElements: 200, budgetMs: 8000 },
    ]);
  });

  it('checks its arguments', () => {
    expect(windowQuery({ window: ' 123 ' })).toMatchObject({ pid: 123 });
    expect(windowQuery({ window: 'Calc 2' })).toMatchObject({ title: 'Calc 2' });
    expect(() => windowQuery({ max_elements: 5 })).toThrow(/20 to 1000/);
    expect(() => windowQuery({ window: '   ' })).toThrow(/title/);
    expect(() => windowQuery({ window: { a: 1 } })).toThrow(/title/);
  });

  it('says so on a platform with no reader yet', async () => {
    const { driver } = fakeDriver();
    delete driver.windowTree;
    const text = String((await new ComputerUse(driver).call('window_layout', {})).content[0].text);
    expect(text).toMatch(/^window_layout is not supported on \w+ yet/);
  });

  it('fits the Windows reader in an environment variable', () => {
    // win-driver.ts hands it to PowerShell as AI_BRIDGE_CU_TREE, capped at 32767 characters.
    expect(WINDOW_TREE_SOURCE.length).toBeLessThan(32000);
    expect(WINDOW_TREE_SOURCE).toContain('public static string Read(string title, int pid, int max, int budgetMs)');
  });
});

describe('layout geometry', () => {
  const node = (parent: number, box: Rect) => ({ parent, box });
  it('pairs siblings side by side or stacked, with their edge offsets', () => {
    const pairs = siblingPairs([node(-1, [0, 0, 500, 500]), node(0, [10, 10, 80, 30]), node(0, [100, 14, 80, 30]), node(0, [10, 60, 80, 30])]);
    expect(pairs.map(p => [p.axis, p.start, p.center, p.end, p.size])).toEqual([
      ['row', 4, 4, 4, 0],
      ['column', 0, 0, 0, 0],
    ]);
  });

  it('measures how far a box sticks out and how much two overlap', () => {
    expect(outsideBy([90, 10, 20, 20], [0, 0, 100, 100]).filter(([, d]) => d > 0)).toEqual([['right', 10]]);
    expect(overlapSize([0, 0, 50, 50], [40, 30, 50, 50])).toEqual([10, 20]);
  });
});
