import { describe, expect, it } from 'vitest';
import { ComputerUse, TOOLS } from '../computer-use/server';
import { fitInside, parseKeyCombo, type Driver } from '../computer-use/driver';
import { virtualKey } from '../computer-use/win-driver';

/** Records what the OS would have been asked to do, on a 1920×1200 screen. */
function fakeDriver() {
  const log: string[] = [];
  const driver: Driver = {
    screenSize: async () => ({ width: 1920, height: 1200 }),
    screenshot: async (w, h) => ({ data: 'PNG', ...fitInside({ width: 1920, height: 1200 }, w, h) }),
    cursorPosition: async () => ({ x: 960, y: 600 }),
    moveMouse: async (x, y) => { log.push(`move ${x},${y}`); },
    click: async (button, count, mods) => { log.push(`click ${button} x${count}${mods.length ? ` +${mods.join('+')}` : ''}`); },
    mouseButton: async (button, down) => { log.push(`${button} ${down ? 'down' : 'up'}`); },
    scroll: async (dx, dy) => { log.push(`scroll ${dx},${dy}`); },
    typeText: async (text) => { log.push(`type ${text}`); },
    pressKeys: async (keys) => { log.push(`keys ${keys.join('+')}`); },
    close: () => {},
  };
  return { driver, log };
}

describe('ComputerUse', () => {
  it('describes the screenshot in text for a model that does not read images', async () => {
    const seen: unknown[] = [];
    const cu = new ComputerUse(fakeDriver().driver, {
      textScreenshots: true,
      describeImages: async (images, options) => images.map(image => { seen.push([image.base64, options]); return '<image-summary>screen</image-summary>'; }),
    });
    const shot = await cu.call('screenshot', {});
    // Read from the full 1920-wide screen, its positions scaled to the 1280-wide screenshot.
    expect(seen).toEqual([['PNG', { scale: 1280 / 1920 }]]);
    expect(shot.content).toHaveLength(1);
    expect(shot.content[0]).toMatchObject({ type: 'text' });
    expect(shot.content[0].text).toMatch(/^<image-summary>screen<\/image-summary>\nScreenshot 1280x800\./);
  });

  it('scales screenshot coordinates to the screen and back', async () => {
    const { driver, log } = fakeDriver();
    const cu = new ComputerUse(driver);
    const shot = await cu.call('screenshot', {});
    expect(shot.content[1].text).toContain('1280x800');
    await cu.call('left_click', { x: 640, y: 400 });
    expect(log).toEqual(['move 960,600', 'click left x1']);
    expect((await cu.call('cursor_position', {})).content[0].text).toBe('{"x":640,"y":400}');
  });

  it('refuses points outside the screenshot', async () => {
    const cu = new ComputerUse(fakeDriver().driver);
    await expect(cu.call('mouse_move', { x: 1280, y: 10 })).rejects.toThrow(/outside/);
    await expect(cu.call('mouse_move', { x: -1, y: 10 })).rejects.toThrow(/outside/);
  });

  it('drags with the button held and always releases it', async () => {
    const { driver, log } = fakeDriver();
    await new ComputerUse(driver).call('left_click_drag', { start_x: 0, start_y: 0, x: 100, y: 100 });
    expect(log).toEqual(['move 0,0', 'left down', 'move 75,75', 'move 150,150', 'left up']);
  });

  it('validates modifiers, scroll direction and text length', async () => {
    const { driver, log } = fakeDriver();
    const cu = new ComputerUse(driver);
    await cu.call('double_click', { modifiers: 'Ctrl+Shift' });
    expect(log.at(-1)).toBe('click left x2 +ctrl+shift');
    await expect(cu.call('left_click', { modifiers: 'ctrl+a' })).rejects.toThrow(/modifier/);
    await cu.call('scroll', { direction: 'up', amount: 50 });
    expect(log.at(-1)).toBe('scroll 0,-20');
    await expect(cu.call('scroll', { direction: 'sideways' })).rejects.toThrow(/direction/);
    await expect(cu.call('type', { text: 'x'.repeat(5001) })).rejects.toThrow(/limited/);
    await cu.call('key', { keys: 'cmd+Return' });
    expect(log.at(-1)).toBe('keys meta+enter');
  });

  it('lists every tool it can run', async () => {
    const cu = new ComputerUse(fakeDriver().driver);
    for (const tool of TOOLS) {
      if (['screenshot', 'cursor_position'].includes(tool.name)) await cu.call(tool.name, {});
    }
    await expect(cu.call('nope', {})).rejects.toThrow(/Unknown tool/);
  });
});

describe('key helpers', () => {
  it('parses combinations and maps Windows virtual keys', () => {
    expect(parseKeyCombo('Control + Alt + Del')).toEqual(['ctrl', 'alt', 'delete']);
    expect(virtualKey('a')).toBe(0x41);
    expect(virtualKey('7')).toBe(0x37);
    expect(virtualKey('f12')).toBe(0x7b);
    expect(virtualKey('enter')).toBe(0x0d);
    expect(virtualKey('nonsense')).toBeUndefined();
  });

  it('fits a screen inside the screenshot box without enlarging it', () => {
    expect(fitInside({ width: 1920, height: 1080 }, 1280, 800)).toEqual({ width: 1280, height: 720 });
    expect(fitInside({ width: 1024, height: 768 }, 1280, 800)).toEqual({ width: 1024, height: 768 });
  });
});
