import { describe, expect, it } from 'vitest';
import { PNG } from 'pngjs';
import { cssColor, cssText, elementNearMisses, formatConsoleSummary, formatLayout, formatShader, layoutFindings } from '../web/format';
import type { LayoutNode, LayoutSnapshot, ShaderResult } from '../web/page-scripts';

const node = (ref: string, parent: number, tag: string, box: LayoutNode['box'], extra: Partial<LayoutNode> = {}): LayoutNode =>
  ({ ref, parent, tag, box, css: {}, ...extra });

/** A card with a cut-off label and two buttons in a row, the second 4px lower for its margin. */
function dialog(): LayoutSnapshot {
  return {
    url: 'http://localhost:5173/', title: 'Settings', viewport: [1280, 800], document: [1280, 800], scroll: [0, 0], total: 5,
    nodes: [
      node('e1', -1, 'body', [0, 0, 1280, 800], { css: { 'background-color': 'rgb(245, 246, 248)' } }),
      node('e2', 0, 'div', [40, 96, 600, 200], { classes: ['card'], css: { 'background-color': 'rgb(255, 255, 255)', 'border-radius': '8px' } }),
      node('e3', 1, 'span', [72, 120, 120, 21], {
        classes: ['label'], text: 'A long label', css: { overflow: 'hidden', 'text-overflow': 'ellipsis' },
        overflow: { kind: 'cut', width: 200, height: 21, clientWidth: 120, clientHeight: 21 },
      }),
      node('e4', 1, 'button', [400, 224, 86, 36], { text: 'Cancel' }),
      node('e5', 1, 'button', [498, 228, 84, 36], { id: 'save', text: 'Save', css: { margin: '4px 0px 0px', 'background-color': 'rgba(37, 99, 235, 0.5)' } }),
    ],
  };
}

describe('cssColor and cssText', () => {
  it('writes rgb colors as hex and leaves other color syntaxes', () => {
    expect(cssColor('rgb(37, 99, 235)')).toBe('#2563EB');
    expect(cssColor('rgba(0, 0, 0, 0.5)')).toBe('#00000080');
    expect(cssColor('1px solid rgb(220, 224, 230)')).toBe('1px solid #DCE0E6');
    expect(cssColor('oklch(0.5 0.1 200)')).toBe('oklch(0.5 0.1 200)');
  });

  it('joins the styles, with the flex direction beside display and long pixel values rounded', () => {
    expect(cssText({ display: 'flex', 'flex-direction': 'column', gap: '6px', 'background-color': 'rgb(255, 255, 255)', left: '656.0625px' }))
      .toBe('flex column · gap 6px · bg #FFFFFF · left 656.1px');
  });
});

describe('elementNearMisses', () => {
  it('finds siblings a few pixels apart and names the styles that differ', () => {
    const [miss, ...rest] = elementNearMisses(dialog().nodes);
    expect(rest).toEqual([]);
    expect(miss).toBe('e4 button "Cancel" and e5 button#save "Save": top 224 vs 228, bottom 260 vs 264; styles that differ: margin (none) vs 4px 0px 0px');
  });

  it('leaves exact alignment and gaps over 6px alone', () => {
    const nodes = dialog().nodes;
    nodes[4].box = [498, 224, 84, 36];
    expect(elementNearMisses(nodes)).toEqual([]);
    nodes[4].box = [498, 240, 84, 36];
    expect(elementNearMisses(nodes)).toEqual([]);
  });
});

describe('layoutFindings', () => {
  it('reports cut-off content, a child out of its parent, overlapping text and sideways scrolling', () => {
    const snapshot = dialog();
    snapshot.nodes.push(node('e6', 1, 'div', [72, 270, 700, 10], { classes: ['wide'] }));
    snapshot.nodes.push(node('e7', 1, 'p', [80, 122, 60, 18], { text: 'Over' }));
    snapshot.nodes.push(node('e8', 0, 'div', [0, 700, 1400, 20], { classes: ['banner'] }));
    snapshot.document = [1400, 800];
    const findings = layoutFindings(snapshot);
    expect(findings).toContain('e3 span.label "A long label": content 200x21 is cut off to 120x21 (overflow hidden, ellipsis)');
    expect(findings).toContain('e6 div.wide sticks out of e2 div.card by 132 px on the right');
    expect(findings).toContain('e3 span.label "A long label" and e7 p "Over" overlap by 60x18 px');
    expect(findings).toContain('The page is 1400 px wide in a 1280 px viewport, so it scrolls sideways: e8 div.banner reaches x=1400');
  });

  it('does not count an absolutely placed badge as sticking out', () => {
    const snapshot = dialog();
    snapshot.nodes.push(node('e6', 1, 'span', [630, 90, 20, 20], { classes: ['badge'], css: { position: 'absolute' } }));
    expect(layoutFindings(snapshot).some(f => f.includes('badge'))).toBe(false);
  });
});

describe('formatLayout', () => {
  it('lists the elements as an indented tree after the page line', () => {
    const snapshot = dialog();
    snapshot.total = 9;
    const text = formatLayout(snapshot, 200);
    expect(text.split('\n')[0]).toBe('Page "Settings" at http://localhost:5173/ (HTTP 200): viewport 1280x800, page 1280x800.');
    expect(text).toContain('\n- e1 body 0,0 1280x800 · bg #F5F6F8\n  - e2 div.card 40,96 600x200 · bg #FFFFFF · radius 8px\n    - e3 span.label "A long label" 72,120 120x21');
    expect(text).toContain('    - e5 button#save "Save" 498,228 84x36 · margin 4px 0px 0px · bg #2563EB80');
    expect(text).toContain('… 4 more elements not listed.');
    expect(text).toContain('Almost aligned (siblings whose edges differ by a few pixels, often a layout slip):\n- e4 button "Cancel" and e5 button#save "Save"');
    expect(text).toContain('Worth a look:\n- e3 span.label');
  });
});

describe('formatConsoleSummary', () => {
  it('counts errors and warnings and shows the first errors with where they came from', () => {
    expect(formatConsoleSummary([])).toEqual(['Console: no errors or warnings.']);
    expect(formatConsoleSummary([{ level: 'log', text: 'hi' }])).toEqual(['Console: no errors or warnings (1 other message).']);
    expect(formatConsoleSummary([
      { level: 'warn', text: 'deprecated' },
      { level: 'error', text: 'ReferenceError: x is not defined\n    at save', where: 'app.js:3:5' },
    ])).toEqual(['Console: 1 error, 1 warning.', '- ReferenceError: x is not defined (app.js:3:5)']);
  });
});

function frame(extra: Partial<ShaderResult['frames'][number]> = {}): ShaderResult['frames'][number] {
  return {
    time: 0, ms: 3, png: '', min: [0, 0, 0, 1], max: [1.5, 1, 1, 1], mean: [0.5, 0.5, 0.5, 1], nan: 0, inf: 0,
    above: [16, 0, 0, 0], below: [0, 0, 0, 0], samples: [{ name: 'center', x: 4, y: 4, rgba: [1, 0.5, 0, 1] }], ...extra,
  };
}

const result = (extra: Partial<ShaderResult> = {}): ShaderResult => ({
  ok: true, mode: 'shadertoy', float: true, renderer: 'ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero)), SwiftShader driver)',
  uniforms: ['iResolution', 'uGain'], unset: ['uGain'], samplers: ['iChannel0'], frames: [frame()], ...extra,
});

describe('formatShader', () => {
  it('gives compile errors with their line', () => {
    const text = formatShader(result({ ok: false, stage: 'fragment', frames: [], errors: [{ line: 5, message: "'fragColor' : syntax error", source: 'fragColor = c;' }] }), { width: 8, height: 8 }, false);
    expect(text).toBe("The shader failed at the fragment stage (a Shadertoy mainImage, SwiftShader on the CPU):\n- line 5: 'fragColor' : syntax error  ← fragColor = c;");
  });

  it('gives the output range, values outside 0-1, NaN and samples', () => {
    const text = formatShader(result({ frames: [frame({ nan: 8, samples: [{ name: 'center', x: 4, y: 4, rgba: [1, null as unknown as number, 0, 1] }] })] }), { width: 8, height: 8 }, false);
    expect(text).toContain('Drew 8x8 with WebGL2 (SwiftShader on the CPU), as a Shadertoy mainImage; the raw float output is read');
    expect(text).toContain('Uniforms set: iResolution.');
    expect(text).toContain('Uniforms left at 0 (pass them in uniforms): uGain.');
    expect(text).toContain('read as black: iChannel0.');
    expect(text).toContain('Output: r 0.000..1.500 (mean 0.500)');
    expect(text).toContain('Outside 0–1 (clamped on screen): r above 1 in 25% of the pixels.');
    expect(text).toContain('NaN in 8 pixels (13%)');
    expect(text).toContain('center 4,4 → 1.000, NaN, 0.000, 1.000');
    expect(text).not.toContain('Color grid');
  });

  it('describes the drawn image for a model that does not read images', () => {
    const png = new PNG({ width: 8, height: 8 });
    png.data.fill(255);
    const text = formatShader(result({ frames: [frame({ png: PNG.sync.write(png).toString('base64') })] }), { width: 8, height: 8 }, true);
    expect(text).toContain('  The image (positions here from the top-left, y down; the color channels only):');
    expect(text).toContain('  Colors: #FFFFFF 100%');
  });
});
