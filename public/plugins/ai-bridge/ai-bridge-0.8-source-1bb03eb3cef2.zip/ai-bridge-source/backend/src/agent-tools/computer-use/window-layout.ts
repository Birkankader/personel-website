import { outsideBy, overlapSize, siblingPairs, type Box, type SiblingPair } from '../layout/geometry';
import type { ScreenSize, WindowQuery } from './driver';

/**
 * window_layout: a desktop window's controls as text, from the UI tree the
 * app shows to accessibility tools, so a model that cannot see images can
 * still say "the Cancel button sits 4 px lower than OK". The web tools do the
 * same for pages (web/format.ts); the box geometry is shared (layout/geometry.ts).
 *
 * The platform reader (win-tree.ts on Windows) reports the window and its
 * elements in screen pixels with the properties its source names. Here they
 * are checked, put in tree order, given refs, scaled to the screenshot pixels
 * the other computer-use tools take, and searched for layout slips.
 */

type Rect = [number, number, number, number];

/** One element as the reader reports it: UI Automation's properties, or the Java Access Bridge's. */
export interface RawElement {
  parent: number;
  controlType?: string;
  name?: string;
  automationId?: string;
  className?: string;
  frameworkId?: string;
  /** x, y, width, height in screen pixels. */
  boundingRectangle?: Rect;
  isEnabled?: boolean;
  isOffscreen?: boolean;
  hasKeyboardFocus?: boolean;
  isPassword?: boolean;
  isScrollPatternAvailable?: boolean;
  toggleState?: string;
  isSelected?: boolean;
  value?: string;
  /** The Java Access Bridge's role and comma-separated states, in en_US. */
  role?: string;
  description?: string;
  states?: string;
  childrenCount?: number;
}

export interface WindowSummary {
  title: string;
  pid: number;
  process?: string;
  className?: string;
}

export interface WindowInfo extends WindowSummary {
  frameworkId?: string;
  /** The frame as drawn, in screen pixels. */
  boundingRectangle?: Rect;
  isMinimized?: boolean;
  isForeground?: boolean;
}

export interface WindowTree {
  /** The display's DPI; 96 is 100%. */
  dpi: number;
  window?: WindowInfo;
  /** Every titled top-level window, when none matched. */
  windows?: WindowSummary[];
  /** Other windows that matched as well, front to back. */
  alsoMatched?: WindowSummary[];
  source?: 'uia' | 'java-access-bridge';
  /** Why the Java Access Bridge could not read a Java window: off, no-client, load-failed: …, failed: … */
  java?: string;
  /** Breadth-first, each after its parent. */
  elements: RawElement[];
  /** The list reached max_elements with more left. */
  full: boolean;
  /** The time ran out first. */
  timedOut: boolean;
  /** Listed elements whose children were never read. */
  unread: number;
}

// ─── Checking what the reader sent ───────────────────────────────────────────

const isObject = (value: unknown): value is Record<string, unknown> => typeof value === 'object' && value !== null && !Array.isArray(value);
const str = (value: unknown) => typeof value === 'string' ? value : undefined;
const bool = (value: unknown) => typeof value === 'boolean' ? value : undefined;
const int = (value: unknown, fallback: number) => typeof value === 'number' && Number.isFinite(value) ? Math.round(value) : fallback;

function rect(value: unknown): Rect | undefined {
  if (!Array.isArray(value) || value.length !== 4 || !value.every(n => typeof n === 'number' && Number.isFinite(n))) return undefined;
  return value as Rect;
}

function summary(value: unknown): WindowSummary | undefined {
  if (!isObject(value)) return undefined;
  return { title: str(value.title) ?? '', pid: int(value.pid, 0), process: str(value.process), className: str(value.className) };
}

function summaries(value: unknown): WindowSummary[] | undefined {
  return Array.isArray(value) ? value.map(summary).filter((s): s is WindowSummary => s !== undefined) : undefined;
}

/** The reader's JSON as a WindowTree, keeping only well-formed fields. */
export function parseWindowTree(raw: unknown): WindowTree {
  if (!isObject(raw)) throw new Error('The window reader returned no result.');
  const elements: RawElement[] = [];
  for (const item of Array.isArray(raw.elements) ? raw.elements : []) {
    if (!isObject(item)) continue;
    const parent = int(item.parent, -1);
    elements.push({
      // A parent always comes first; anything else is read as a top element.
      parent: parent >= 0 && parent < elements.length ? parent : -1,
      controlType: str(item.controlType), name: str(item.name), automationId: str(item.automationId),
      className: str(item.className), frameworkId: str(item.frameworkId), boundingRectangle: rect(item.boundingRectangle),
      isEnabled: bool(item.isEnabled), isOffscreen: bool(item.isOffscreen), hasKeyboardFocus: bool(item.hasKeyboardFocus),
      isPassword: bool(item.isPassword), isScrollPatternAvailable: bool(item.isScrollPatternAvailable),
      toggleState: str(item.toggleState), isSelected: bool(item.isSelected), value: str(item.value),
      role: str(item.role), description: str(item.description), states: str(item.states),
      childrenCount: typeof item.childrenCount === 'number' ? item.childrenCount : undefined,
    });
  }
  const window = summary(raw.window);
  const w = isObject(raw.window) ? raw.window : {};
  return {
    dpi: int(raw.dpi, 96) > 0 ? int(raw.dpi, 96) : 96,
    window: window && {
      ...window, frameworkId: str(w.frameworkId), boundingRectangle: rect(w.boundingRectangle),
      isMinimized: bool(w.isMinimized), isForeground: bool(w.isForeground),
    },
    windows: summaries(raw.windows),
    alsoMatched: summaries(raw.alsoMatched),
    source: raw.source === 'uia' || raw.source === 'java-access-bridge' ? raw.source : undefined,
    java: str(raw.java),
    elements,
    full: raw.full === true,
    timedOut: raw.timedOut === true,
    unread: int(raw.unread, 0),
  };
}

// ─── Elements in tree order, in three units ──────────────────────────────────

/** An element ready to describe and measure. */
export interface WindowNode {
  ref: string;
  /** Index of the node this one is inside, -1 for the top. */
  parent: number;
  depth: number;
  /** UI Automation's control type, or the Java role. */
  kind: string;
  raw: RawElement;
  /** Screen pixels. */
  screen?: Box;
  /** Screenshot pixels, the ones the other tools take. */
  shot?: Box;
  /** 96-DPI pixels (screen pixels ÷ the display scale), the unit WinForms, WPF, Swing and Qt layouts are usually written in. */
  box?: Box;
  enabled: boolean;
  offscreen: boolean;
  focused: boolean;
  selected: boolean;
  /** checked, unchecked or partly checked, for what can be checked. */
  checked?: string;
  /** Drawn by Windows or the toolkit rather than laid out by the app: the title bar, scroll bars. */
  chrome: boolean;
  /** Its children may scroll past its edges. */
  scrolls: boolean;
}

const TOGGLE: Record<string, string> = { On: 'checked', Off: 'unchecked', Indeterminate: 'partly checked' };
const CHROME = new Set(['TitleBar', 'ScrollBar', 'scroll bar']);
const SCROLLERS = new Set(['List', 'Tree', 'DataGrid', 'Table', 'Document', 'viewport', 'scroll pane', 'list', 'table', 'tree']);
/** Controls that should never cover each other; containers may. */
const LEAVES = new Set([
  'Button', 'CheckBox', 'RadioButton', 'Edit', 'Text', 'ComboBox', 'Hyperlink', 'Slider', 'Spinner', 'ProgressBar', 'SplitButton',
  'push button', 'toggle button', 'check box', 'radio button', 'text', 'password text', 'label', 'combo box', 'slider', 'spin box', 'progress bar', 'hyperlink',
]);

function hasState(element: RawElement, state: string): boolean {
  return (element.states ?? '').split(',').some(s => s.trim() === state);
}

export interface Scale {
  screen: ScreenSize;
  shot: ScreenSize;
  /** Screen pixels per 96-DPI pixel. */
  display: number;
}

/** The elements depth-first, as they nest, with refs w1, w2, … in that order. */
export function windowNodes(tree: WindowTree, scale: Scale): WindowNode[] {
  const children = new Map<number, number[]>();
  tree.elements.forEach((element, index) => children.set(element.parent, [...(children.get(element.parent) ?? []), index]));
  const java = tree.source === 'java-access-bridge';
  const fx = scale.shot.width / scale.screen.width, fy = scale.shot.height / scale.screen.height;
  const nodes: WindowNode[] = [];
  const visit = (index: number, parent: number, depth: number, chrome: boolean) => {
    const raw = tree.elements[index];
    const kind = (java ? raw.role : raw.controlType) || raw.role || raw.controlType || 'element';
    const s = raw.boundingRectangle;
    const inChrome = chrome || CHROME.has(kind);
    const node: WindowNode = {
      ref: `w${nodes.length + 1}`, parent, depth, kind, raw,
      screen: s,
      shot: s && [s[0] * fx, s[1] * fy, s[2] * fx, s[3] * fy],
      box: s && [s[0] / scale.display, s[1] / scale.display, s[2] / scale.display, s[3] / scale.display],
      enabled: java ? hasState(raw, 'enabled') : raw.isEnabled !== false,
      offscreen: java ? !hasState(raw, 'showing') : raw.isOffscreen === true,
      focused: java ? hasState(raw, 'focused') : raw.hasKeyboardFocus === true,
      selected: java ? hasState(raw, 'selected') : raw.isSelected === true,
      checked: java
        ? (hasState(raw, 'checked') ? 'checked' : /check box|radio button|toggle button/.test(kind) ? 'unchecked' : undefined)
        : TOGGLE[raw.toggleState ?? ''],
      chrome: inChrome,
      scrolls: raw.isScrollPatternAvailable === true || SCROLLERS.has(kind),
    };
    const at = nodes.push(node) - 1;
    for (const child of children.get(index) ?? []) visit(child, at, depth + 1, inChrome);
  };
  for (const top of children.get(-1) ?? []) visit(top, -1, 0, false);
  return nodes;
}

// ─── Wording ─────────────────────────────────────────────────────────────────

/** 12 as "12", 12.345 as "12.3". */
const num = (value: number) => String(Math.round(value * 10) / 10);
const boxText = ([x, y, w, h]: Box) => `${num(x)},${num(y)} ${num(w)}x${num(h)}`;
const clip = (text: string, max = 80) => text.length > max ? `${text.slice(0, max)}…` : text;
const quoted = (text: string) => JSON.stringify(clip(text));

const READABLE_CLASS = /^[A-Za-z][A-Za-z0-9_]{0,39}$/;

export function nodeName(node: WindowNode): string {
  let name = `${node.ref} ${node.kind}`;
  const { className, name: label, automationId } = node.raw;
  // A toolkit's own class (TextBlock, QPushButton) says what the code calls it; WinForms' generated ones do not.
  if (className && className !== node.kind && READABLE_CLASS.test(className)) name += `.${className}`;
  if (label) name += ` ${quoted(label)}`;
  if (automationId && !/^\d+$/.test(automationId)) name += ` #${/^[\w.:-]+$/.test(automationId) ? automationId : JSON.stringify(automationId)}`;
  return name;
}

function nodeLine(node: WindowNode, parent: WindowNode | undefined, scale: Scale): string {
  const { raw } = node;
  const outside = node.screen && (node.screen[0] >= scale.screen.width || node.screen[1] >= scale.screen.height ||
    node.screen[0] + node.screen[2] <= 0 || node.screen[1] + node.screen[3] <= 0);
  const framework = raw.frameworkId && parent?.raw.frameworkId && raw.frameworkId !== parent.raw.frameworkId && !node.chrome ? `[${raw.frameworkId}]` : '';
  const flags = [
    node.shot ? boxText(node.shot) : 'no box',
    framework,
    !node.enabled ? 'disabled' : '',
    node.offscreen ? 'offscreen' : '',
    outside ? 'outside the screenshot' : '',
    node.focused ? 'focused' : '',
    node.checked ?? '',
    node.selected ? 'selected' : '',
    raw.isPassword ? 'password' : '',
    raw.value ? `value ${quoted(raw.value)}` : '',
    raw.description && raw.description !== raw.name ? `description ${quoted(raw.description)}` : '',
  ].filter(Boolean);
  return `${nodeName(node)} ${flags.join(' · ')}`;
}

/** "4 px", and the screen pixels too when the display is scaled. */
function px(value: number, scale: Scale): string {
  const app = Math.abs(value);
  return scale.display === 1 ? `${num(app)} px` : `${num(app)} px (${num(app * scale.display)} screen px)`;
}

// ─── Findings ────────────────────────────────────────────────────────────────

const near = (d: number) => Math.abs(d) >= 0.5 && Math.abs(d) <= 6;
const aligned = (d: number) => Math.abs(d) < 0.5;

interface Note {
  subject: WindowNode;
  other: WindowNode;
  axis: 'row' | 'column';
  /** 'shift': the subject sits off the other; 'size': it is bigger or smaller. */
  kind: 'shift' | 'size';
  /** Which edges are off, for a shift: all of them, or the closest of start, middle and end. */
  edge: 'all' | 'start' | 'center' | 'end';
  /** Subject minus other, in 96-DPI pixels. */
  d: number;
}

const flip = (note: Note): Note => ({ ...note, subject: note.other, other: note.subject, d: -note.d });

/** What is off between two siblings in a row or column, if anything. */
function pairNotes(pair: SiblingPair<{ parent: number; box: Box; node: WindowNode }>): Note[] {
  const a = pair.a.node, b = pair.b.node;
  const notes: Note[] = [];
  const base = { subject: b, other: a, axis: pair.axis };
  // The same control type side by side should be the same size; a label and a field need not be.
  const sameKind = a.kind === b.kind;
  if (sameKind && near(pair.size)) notes.push({ ...base, kind: 'size', edge: 'all', d: pair.size });
  // Lined up by start, middle or end is a choice; none of them, by a few pixels, is a slip.
  const edges = [['start', pair.start], ['center', pair.center], ['end', pair.end]] as const;
  if (!edges.some(([, d]) => aligned(d))) {
    const [edge, d] = [...edges].sort((x, y) => Math.abs(x[1]) - Math.abs(y[1]))[0];
    if (near(d)) notes.push({ ...base, kind: 'shift', edge: aligned(pair.size) ? 'all' : edge, d });
  }
  return notes;
}

const WORDS = {
  row: { shift: ['lower', 'higher'], size: ['taller', 'shorter'], start: 'top', center: 'middle', end: 'bottom' },
  column: { shift: ['further right', 'further left'], size: ['wider', 'narrower'], start: 'left edge', center: 'middle', end: 'right edge' },
} as const;

function listNames(nodes: WindowNode[]): string {
  const names = nodes.slice(0, 3).map(nodeName);
  if (nodes.length > 3) names.push(`${nodes.length - 3} more`);
  return names.length > 1 ? `${names.slice(0, -1).join(', ')} and ${names.at(-1)}` : names[0];
}

/**
 * Siblings a few pixels out of line. A pair's note names the odd one out: the
 * one off the same way (shifted, or sized) from more of its siblings, else the
 * one further right or down. One element off from several siblings by the same
 * amount is one line.
 */
export function windowNearMisses(nodes: WindowNode[], scale: Scale): string[] {
  const candidates = nodes
    .filter(n => n.box && n.parent >= 0 && !n.offscreen && !n.chrome && n.box[2] >= 8 && n.box[3] >= 8)
    .map(node => ({ parent: node.parent, box: node.box!, node }));
  const notes = siblingPairs(candidates).flatMap(pairNotes);
  const involved = new Map<string, number>();
  const key = (node: WindowNode, note: Note) => `${node.ref} ${note.kind}`;
  for (const note of notes) for (const n of [note.subject, note.other]) involved.set(key(n, note), (involved.get(key(n, note)) ?? 0) + 1);
  const oriented = notes.map(note => {
    const s = involved.get(key(note.subject, note)) ?? 0, o = involved.get(key(note.other, note)) ?? 0;
    const axisIndex = note.axis === 'row' ? 0 : 1;
    const later = note.subject.box![axisIndex] >= note.other.box![axisIndex];
    return s > o || (s === o && later) ? note : flip(note);
  });
  const groups = new Map<string, Note[]>();
  for (const note of oriented) {
    const id = [note.subject.ref, note.axis, note.kind, Math.sign(note.d), Math.round(Math.abs(note.d) * 2)].join(' ');
    groups.set(id, [...(groups.get(id) ?? []), note]);
  }
  const out: string[] = [];
  for (const group of groups.values()) {
    const { subject, axis, kind, d } = group[0];
    // "Its middle is 2 px lower" only when that is the one thing off from every sibling named.
    const edge = group.every(note => note.edge === group[0].edge) ? group[0].edge : 'all';
    const words = WORDS[axis];
    const others = listNames(group.map(note => note.other));
    const direction = words[kind][d > 0 ? 0 : 1];
    if (kind === 'size') out.push(`${nodeName(subject)} is ${px(d, scale)} ${direction} than ${others}`);
    else if (edge === 'all') out.push(`${nodeName(subject)} sits ${px(d, scale)} ${direction} than ${others}`);
    else out.push(`${nodeName(subject)}: its ${words[edge]} is ${px(d, scale)} ${direction} than that of ${others}, and no edge lines up`);
    if (out.length >= 12) break;
  }
  return out;
}

/** Controls cut off by their container or the window, overlapping controls, a window past the screen's edge. */
export function windowFindings(tree: WindowTree, nodes: WindowNode[], scale: Scale): string[] {
  const out: string[] = [];
  const java = tree.source === 'java-access-bridge';
  for (const node of nodes) {
    const parent = nodes[node.parent];
    if (!parent?.box || !node.box || node.offscreen || node.chrome || parent.scrolls) continue;
    const past = outsideBy(node.box, parent.box).filter(([, d]) => d > 1);
    if (!past.length) continue;
    const sides = past.map(([side, d]) => `${px(d, scale)} past its ${side} edge`).join(', ');
    // Windows clips a child window to its parent, and Swing paints children inside theirs; WPF may draw past.
    const clips = java || parent.parent < 0 || /^(WinForm|Win32)$/.test(node.raw.frameworkId ?? '');
    out.push(`${nodeName(node)} ${clips ? 'is cut off by' : 'sticks out of'} ${nodeName(parent)}: ${sides}`);
    if (out.length >= 15) break;
  }
  let overlaps = 0;
  const leaves = nodes.filter(n => n.box && !n.offscreen && !n.chrome && LEAVES.has(n.kind));
  for (let i = 0; i < leaves.length && overlaps < 8; i++) {
    for (let j = i + 1; j < leaves.length && overlaps < 8; j++) {
      const a = leaves[i], b = leaves[j];
      if (a.parent !== b.parent) continue;
      const [w, h] = overlapSize(a.box!, b.box!);
      if (w > 2 && h > 2) {
        out.push(`${nodeName(a)} and ${nodeName(b)} overlap by ${num(w)}x${num(h)} px`);
        overlaps++;
      }
    }
  }
  return out.slice(0, 30);
}

// ─── The whole answer ────────────────────────────────────────────────────────

const FRAMEWORKS: Record<string, string> = { WinForm: 'WinForms', WPF: 'WPF', Win32: 'Win32', DirectUI: 'DirectUI', XAML: 'XAML (WinUI/UWP)', Qt: 'Qt' };

/** A game engine's window, which draws everything on the GPU. */
function engineOf(window: WindowInfo): string | undefined {
  const cls = window.className ?? '', process = window.process ?? '';
  if (/^Unity(Wnd|Container)/.test(cls) || /^Unity$/i.test(process)) return 'Unity';
  if (cls === 'UnrealWindow' || /^(UnrealEditor|UE4Editor|UE5Editor)$/i.test(process)) return 'Unreal Engine';
  return undefined;
}

const JAVA_ON = 'Turn it on with "jabswitch -enable" (jabswitch is in the JDK\'s bin folder) and restart the app, or start the app with ' +
  '-Djavax.accessibility.assistive_technologies=com.sun.java.accessibility.AccessBridge.';

function javaNote(problem: string): string {
  const lead = 'This is a Java AWT/Swing window. Swing draws its controls itself, so they can only be read through the Java Access Bridge';
  if (problem === 'off') return `${lead}, which is off for this app. ${JAVA_ON} Until then only the window frame is listed.`;
  if (problem === 'no-client') {
    return `${lead}, and its client (windowsaccessbridge-64.dll) was not found next to the app's java.exe, in JAVA_HOME\\bin or in System32. ` +
      'It comes with Java 8 and later; set JAVA_HOME to a 64-bit JDK. Until then only the window frame is listed.';
  }
  return `${lead}, which could not be used (${problem}). Only the window frame is listed.`;
}

function windowList(windows: WindowSummary[] | undefined): string {
  const list = (windows ?? []).slice(0, 25).map(w => `${quoted(w.title)} (${w.process ? `${w.process}, ` : ''}pid ${w.pid})`);
  return list.length ? `Open windows, front to back: ${list.join('; ')}.` : 'No titled windows are open.';
}

export interface LayoutContext {
  query: Pick<WindowQuery, 'title' | 'pid' | 'maxElements'>;
  screen: ScreenSize;
  shot: ScreenSize;
}

export function formatWindowLayout(tree: WindowTree, context: LayoutContext): string {
  const { query } = context;
  const window = tree.window;
  if (!window) {
    const missing = query.pid ? `No window belongs to process ${query.pid}.`
      : query.title ? `No window's title contains ${quoted(query.title)}.`
      : 'No window is in front.';
    return `${missing} ${windowList(tree.windows)} Pass window a part of a title, or a process id.`;
  }
  const scale: Scale = { screen: context.screen, shot: context.shot, display: tree.dpi / 96 };
  const nodes = windowNodes(tree, scale);
  const frame = window.boundingRectangle;
  const fx = scale.shot.width / scale.screen.width, fy = scale.shot.height / scale.screen.height;
  const toolkit = tree.source === 'java-access-bridge' ? 'Java Swing/AWT, read through the Java Access Bridge'
    : `${FRAMEWORKS[window.frameworkId ?? ''] ?? (window.frameworkId || 'unknown toolkit')}, read through UI Automation`;
  const out = [
    `Window ${quoted(window.title)}: ${toolkit}; process ${window.process ?? '?'} (pid ${window.pid})` +
      `${frame ? `, at ${boxText([frame[0] * fx, frame[1] * fy, frame[2] * fx, frame[3] * fy])}` : ''}.`,
    `Boxes are x,y WxH in screenshot pixels (the ${scale.screen.width}x${scale.screen.height} screen shown at ${scale.shot.width}x${scale.shot.height}), which the other tools take.` +
      `${scale.display !== 1 ? ` The display is scaled to ${Math.round(scale.display * 100)}%.` : ''}`,
  ];
  const notes: string[] = [];
  if (window.isMinimized) {
    notes.push('The window is minimized, so it has no layout to read. Restore it (click it on the taskbar) and call window_layout again.');
    return [...out, '', ...notes].join('\n');
  }
  const engine = engineOf(window);
  const content = nodes.filter(n => n.parent >= 0 && !n.chrome);
  if (tree.java) notes.push(javaNote(tree.java));
  else if (engine) notes.push(`${engine} draws its interface on the GPU and shows no controls to accessibility tools beyond the window frame and native menus. The screenshot's text description is the way to see what is inside.`);
  else if (content.length <= 1 && frame && frame[2] * frame[3] > 200 * 150 * scale.display * scale.display) {
    notes.push('The window shows almost no controls to UI Automation, so it likely draws its own interface (a game engine, a canvas, a custom-drawn toolkit). The screenshot\'s text description is the way to see what is inside.');
  }
  if (frame) {
    const past = outsideBy(frame, [0, 0, scale.screen.width, scale.screen.height]).filter(([, d]) => d > 2);
    if (past.some(([side, d]) => d >= (side === 'left' || side === 'right' ? frame[2] : frame[3]))) {
      notes.push('The window is not on the primary screen, so it is not in the screenshot and the other tools cannot reach it.');
    } else if (past.length) {
      notes.push(`The window reaches past the screen (${past.map(([side, d]) => `${num(d * fx)} px past the ${side}`).join(', ')}); that part is not in the screenshot.`);
    }
  }
  if (window.isForeground === false) notes.push('It is not the window in front, so other windows may cover parts of it in a screenshot.');
  if (tree.alsoMatched?.length) {
    notes.push(`Other windows match too: ${tree.alsoMatched.map(w => `${quoted(w.title)} (${w.process ? `${w.process}, ` : ''}pid ${w.pid})`).join('; ')}. Pass window their pid to read one of them.`);
  }
  if (notes.length) out.push('', ...notes);

  out.push('', 'Elements (indented = inside the element above; "#" an automation id, "." a toolkit class):');
  for (const node of nodes) out.push(`${'  '.repeat(node.depth)}- ${nodeLine(node, nodes[node.parent], scale)}`);
  if (tree.full || tree.timedOut) {
    const inside = tree.unread ? `, so what is inside ${tree.unread} of the elements above was not read` : '';
    out.push(tree.timedOut
      ? `… Reading stopped at the time limit${inside}.`
      : `… The list stops at ${query.maxElements} elements${inside}. Pass a higher max_elements (up to 1000) to see more.`);
  }

  const misses = windowNearMisses(nodes, scale);
  const unit = scale.display !== 1 ? ` Distances are in 96-DPI pixels (screen pixels ÷ ${Math.round(scale.display * 100) / 100}), the unit layout code is usually written in.` : '';
  if (misses.length) out.push('', `Almost aligned (siblings a few pixels out of line, often a layout slip).${unit}`, ...misses.map(m => `- ${m}`));
  const findings = windowFindings(tree, nodes, scale);
  if (findings.length) out.push('', `Worth a look:${misses.length ? '' : unit}`, ...findings.map(f => `- ${f}`));
  return out.join('\n');
}

export const WINDOW_LAYOUT_UNSUPPORTED: Record<string, string> = {
  darwin: 'window_layout is not supported on macOS yet: it reads a window\'s controls from the accessibility tree, and only the Windows reader (UI Automation) exists so far. ' +
    'Use the screenshot tool to see the window for now.',
  linux: 'window_layout is not supported on Linux yet: it reads a window\'s controls from the accessibility tree, and only the Windows reader (UI Automation) exists so far; AT-SPI is still to come. ' +
    'Use the screenshot tool to see the window for now.',
};

export function unsupportedMessage(platform: string): string {
  return WINDOW_LAYOUT_UNSUPPORTED[platform] ?? `window_layout is not supported on ${platform} yet. Use the screenshot tool to see the window for now.`;
}
