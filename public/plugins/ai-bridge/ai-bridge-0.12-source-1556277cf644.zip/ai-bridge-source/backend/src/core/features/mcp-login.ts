import { chmodSync, statSync } from 'fs';
import { createRequire } from 'module';
import { dirname, join } from 'path';
import { Claude } from '../claude';
import { assertResolvedWindowsLauncher, planWindowsLaunch } from '../win-exec';
import { resolveWslCwd } from '../wsl-path';
import {
  McpAuthenticationState,
  type McpAuthenticateResponse,
  type McpServerAuthenticationStatus,
} from '../../shared';

/**
 * GUI sign-in for an MCP server: runs the official `claude mcp login --no-browser
 * <name>` inside a pseudo-terminal and turns what it prints into progress updates.
 *
 * ## Why a PTY
 *
 * `claude mcp login` is an interactive terminal program. It prints an
 * authorization URL, then waits on two things at once: a loopback listener that
 * the browser's redirect reaches when the browser runs on this machine, and a
 * "paste the redirect URL here" prompt for when it does not (remote backend,
 * tunnel). Both only exist when stdin and stdout are a terminal, so plain pipes
 * (as `claude auth login` gets in login.ts) do not work. A terminal user runs the
 * same command; this is that command with the URL and the paste field moved into
 * the UI (CLI equivalence). `--no-browser` makes the CLI leave opening the URL to
 * the caller, because the backend may be headless or remote and the UI knows
 * which machine the browser is on.
 *
 * ## node-pty is optional
 *
 * `@lydell/node-pty` is a native addon, loaded lazily here and never imported
 * anywhere else. If it cannot load (unsupported platform, an extraction that
 * skipped it, `AI_BRIDGE_DISABLE_PTY=1`) or a spawn fails for a platform reason,
 * the verdict is remembered and the answer becomes `terminal-required` with the
 * command to run by hand. The backend never depends on the package to start.
 *
 * ## Reading a terminal
 *
 * ConPTY (Windows) redraws the screen: spaces come as `ESC[nC`, line breaks as
 * absolute cursor moves, and a chunk may end inside an escape sequence. So the
 * accumulated buffer is re-parsed on every chunk and markers are matched on text
 * normalized from it, never on a chunk. The URL is taken from the OSC 8 hyperlink
 * the CLI emits around it where there is one (exact bytes, no layout involved),
 * and from the visible text otherwise.
 *
 * ## What is never logged
 *
 * The authorization URL and the pasted redirect URL carry `code`/`state`. Neither
 * appears in a log line or in a failure message (URLs are redacted from the CLI's
 * last lines before they are reported).
 */

export const MCP_LOGIN_TIMEOUT_MS = 5 * 60_000;
const CANCEL_GRACE_MS = 1_500;
const MAX_CALLBACK_URL_LENGTH = 8_192;
// Wide enough that the CLI never wraps the authorization URL across rows.
const PTY_COLS = 1_000;
const PTY_ROWS = 40;
const MAX_BUFFER_CHARS = 256 * 1024;
const MAX_FAILURE_CHARS = 500;
const MAX_REJECTION_CHARS = 300;

export interface PtyProcess {
  pid: number;
  onData(cb: (data: string) => void): { dispose(): void };
  onExit(cb: (event: { exitCode: number; signal?: number }) => void): { dispose(): void };
  write(data: string): void;
  kill(): void;
}

export interface PtyModule {
  spawn(
    file: string,
    args: string[] | string,
    options: { name?: string; cols: number; rows: number; cwd?: string; env: Record<string, string> },
  ): PtyProcess;
}

export interface McpLoginDeps {
  loadPty(): Promise<PtyModule>;
  resolveLauncher(): Promise<string>;
  baseEnv(): NodeJS.ProcessEnv;
  platform: NodeJS.Platform;
  timeoutMs: number;
  cancelGraceMs: number;
}

interface Session {
  key: string;
  connectionId: string;
  name: string;
  workingDir?: string;
  pty: PtyProcess;
  state: McpAuthenticationState;
  /** Everything the CLI wrote, tail-capped. Escape sequences intact. */
  raw: string;
  /** `raw` normalized to plain text. */
  text: string;
  /** Raw output since the last paste, to tell the answer to that paste from older output. */
  rawSinceSubmit: string;
  url?: string;
  /** The CLI's reason for refusing the last paste, shown again if the state is re-reported. */
  lastError?: string;
  onUpdate: (update: McpServerAuthenticationStatus) => void;
  timeoutTimer?: NodeJS.Timeout;
  graceTimer?: NodeJS.Timeout;
  listeners: Array<{ dispose(): void }>;
}

interface StartOptions {
  connectionId: string;
  name: string;
  workingDir?: string;
  onUpdate(update: McpServerAuthenticationStatus): void;
}

// ─── Dependencies and process-wide state ──────────────────────────────────────

async function loadNodePty(): Promise<PtyModule> {
  if (process.env.AI_BRIDGE_DISABLE_PTY === '1') throw new Error('PTY disabled by AI_BRIDGE_DISABLE_PTY');
  // The only import of the package, and a literal one: esbuild keeps it external and the
  // bundle resolves it from the node_modules folder shipped beside it.
  const m = await import('@lydell/node-pty');
  return (typeof m.spawn === 'function' ? m : (m as unknown as { default: PtyModule }).default) as unknown as PtyModule;
}

const defaultDeps: McpLoginDeps = {
  loadPty: loadNodePty,
  // Resolved to an absolute path on every platform: a PTY looks a bare name up in the
  // backend's own PATH, which lacks what Claude.env adds (where the CLI usually lives
  // when an IDE, not a shell, started the backend). On win32 an unresolved launcher is
  // refused in [launch] rather than guessed at.
  resolveLauncher: () => Claude.resolveLauncher(),
  baseEnv: () => Claude.env,
  platform: process.platform,
  timeoutMs: MCP_LOGIN_TIMEOUT_MS,
  cancelGraceMs: CANCEL_GRACE_MS,
};

let deps: McpLoginDeps = defaultDeps;

/** Why a PTY cannot be used on this machine, once found out. Lives as long as the backend. */
let ptyUnavailable: string | null = null;

const sessions = new Map<string, Session>();
/** Launches between the call and the registered session, so a double click spawns once. */
const launching = new Map<string, Promise<McpAuthenticateResponse>>();
/**
 * Keys of launches called off (their connection closed, or the user cancelled) while
 * still between the call and the spawn. There is no session to kill yet, so the launch
 * itself checks this right before it would spawn. Only keys that are launching get in,
 * and the launch's end removes them, so nothing outlives the run it was set for.
 */
const cancelledLaunches = new Set<string>();
let exitHookInstalled = false;

/** Test hook. `null` restores the defaults. Either way it kills every run and forgets the PTY verdict. */
export function setMcpLoginDepsForTesting(overrides: Partial<McpLoginDeps> | null): void {
  killAllMcpLogins();
  ptyUnavailable = null;
  launching.clear();
  cancelledLaunches.clear();
  deps = overrides === null ? defaultDeps : { ...defaultDeps, ...overrides };
}

// ─── Public API ───────────────────────────────────────────────────────────────

// Characters that are inert inside double quotes in cmd.exe, PowerShell and POSIX shells alike.
const PORTABLE_NAME = /^[A-Za-z0-9 ._-]+$/;
// eslint-disable-next-line no-control-regex -- matching control characters is the point
const CONTROL_CHARACTERS = /[\x00-\x1f\x7f-\x9f]/;
// What can end or escape a single-quoted string in some shell a macOS/Linux user may paste
// into: `'` everywhere, `\` in fish, and the typographic single quotes PowerShell treats as `'`.
const SINGLE_QUOTE_BREAKERS = /['\\‘-‛]/;

/**
 * What to type in a terminal when the GUI cannot run the sign-in itself, or `null`
 * when the name cannot be put into a command line safely.
 *
 * The command is offered with a Copy button, so a hostile name (config comes from the
 * user's files and from cloned projects, where nothing restricts it to the letters
 * `claude mcp add` takes) must not be able to end its quoting. An ordinary name keeps
 * the plain double-quoted form. Any other name is single-quoted for macOS and Linux,
 * where sh, bash, zsh, fish and pwsh all take the inside of `'...'` literally as long as
 * it holds none of SINGLE_QUOTE_BREAKERS. No quoting works for both cmd.exe and
 * PowerShell, and a control character cannot be pasted on one line, so those get `null`.
 */
export function terminalLoginCommand(name: string, platform: NodeJS.Platform = process.platform): string | null {
  if (PORTABLE_NAME.test(name)) return `claude mcp login "${name}"`;
  if (platform === 'win32' || CONTROL_CHARACTERS.test(name) || SINGLE_QUOTE_BREAKERS.test(name)) return null;
  return `claude mcp login '${name}'`;
}

/**
 * Start `claude mcp login --no-browser <name>` for one connection and report its
 * progress through `onUpdate`. Resolves as soon as the process is running (or cannot
 * be): a sign-in lasts minutes, so the outcome is a stream of updates, not this answer.
 *
 * One run per connection and server: starting again while it is active reports its
 * current state and spawns nothing.
 */
export function startMcpLogin(options: StartOptions): Promise<McpAuthenticateResponse> {
  const key = sessionKey(options.connectionId, options.name);

  const live = sessions.get(key);
  if (live && !isFinished(live.state)) {
    live.onUpdate = options.onUpdate;
    emit(live, live.state === McpAuthenticationState.AWAITING_CALLBACK ? { error: live.lastError } : {});
    return Promise.resolve({ status: 'started' });
  }

  const inFlight = launching.get(key);
  if (inFlight) {
    return inFlight.then((answer) => {
      const session = sessions.get(key);
      if (answer.status === 'started' && session) {
        session.onUpdate = options.onUpdate;
        emit(session, session.state === McpAuthenticationState.AWAITING_CALLBACK ? { error: session.lastError } : {});
      }
      return answer;
    });
  }

  // Read before any await: the dispatcher has just projected this request's
  // CLAUDE_CONFIG_DIR onto process.env, and another request may change it again.
  const env = toPtyEnv(deps.baseEnv(), deps.platform);
  const run = launch(options, key, env).finally(() => {
    if (launching.get(key) === run) {
      launching.delete(key);
      cancelledLaunches.delete(key);
    }
  });
  launching.set(key, run);
  return run;
}

/**
 * Type the pasted redirect URL into the running CLI's prompt. The URL is checked
 * here (one line, http(s), a sane length, no control character) so that nothing else can be typed into
 * the terminal through this entry point.
 */
export function submitMcpLoginCallbackUrl(
  connectionId: string,
  name: string,
  callbackUrl: string,
): { status: 'ok' } | { status: 'error'; error: string } {
  const session = sessions.get(sessionKey(connectionId, name));
  if (!session || isFinished(session.state)) {
    return { status: 'error', error: 'No sign-in is running for this server.' };
  }
  if (session.state !== McpAuthenticationState.AWAITING_CALLBACK) {
    return { status: 'error', error: 'The sign-in is not waiting for a redirect URL.' };
  }
  const url = callbackUrl.trim();
  if (!isPastableUrl(url)) {
    return { status: 'error', error: 'Paste the full redirect address (http://… or https://…).' };
  }
  try {
    session.pty.write(`${url}\r`);
  } catch (err) {
    console.error('[node-backend]', `mcp login "${session.name}": could not write to the terminal:`, errorMessage(err));
    return { status: 'error', error: 'The sign-in could not receive the address.' };
  }
  session.state = McpAuthenticationState.VERIFYING;
  session.rawSinceSubmit = '';
  session.lastError = undefined;
  emit(session);
  return { status: 'ok' };
}

/**
 * Cancel this connection's run for `name`: Ctrl+C, then a kill if the CLI does not leave.
 * A run still launching has no process to stop yet: it is called off before it spawns, its
 * start answers with an error, and this returns false (there was no run to report on).
 */
export function cancelMcpLogin(connectionId: string, name: string): boolean {
  const key = sessionKey(connectionId, name);
  const session = sessions.get(key);
  if (!session || isFinished(session.state)) {
    if (launching.has(key)) cancelledLaunches.add(key);
    return false;
  }
  session.state = McpAuthenticationState.CANCELLED;
  clearTimeout(session.timeoutTimer);
  emit(session);
  console.error('[node-backend]', `mcp login "${session.name}": cancelled`);
  try {
    session.pty.write('\x03');
  } catch {
    // The kill below covers a terminal that is already gone.
  }
  session.graceTimer = unrefTimer(setTimeout(() => {
    killQuietly(session);
    forget(session);
  }, deps.cancelGraceMs));
  return true;
}

/**
 * The connection is gone: end all its runs, without reporting to anyone. That includes
 * the ones still launching (they have no session yet; see [cancelledLaunches]).
 */
export function cancelAllMcpLogins(connectionId: string): void {
  for (const session of [...sessions.values()]) {
    if (session.connectionId !== connectionId) continue;
    killQuietly(session);
    forget(session);
  }
  for (const key of launching.keys()) {
    if (key.startsWith(`${connectionId}\0`)) cancelledLaunches.add(key);
  }
}

// ─── Launching ────────────────────────────────────────────────────────────────

async function launch(
  { connectionId, name, workingDir, onUpdate }: StartOptions,
  key: string,
  env: Record<string, string>,
): Promise<McpAuthenticateResponse> {
  if (ptyUnavailable !== null) return terminalRequired(name, ptyUnavailable);

  let pty: PtyModule;
  try {
    pty = await deps.loadPty();
  } catch (err) {
    return fallBackToTerminal(name, errorMessage(err));
  }

  const cliArgs = ['mcp', 'login', '--no-browser', name];
  let file: string;
  let args: string[] | string;
  try {
    const launcher = await deps.resolveLauncher();
    if (deps.platform === 'win32') {
      // The same rule Claude.execViaCmd applies: a bare `claude` (where failed) or an
      // extension-less path would be run as a batch command, and a native claude.exe
      // would then receive an extra caret level in a name holding a space or `&`.
      // Refuse instead of guessing which file PATHEXT would have found.
      assertResolvedWindowsLauncher(launcher);
      // A .cmd shim must go through cmd.exe as ONE pre-quoted command line (a name such as
      // `a & b` must stay one argument); node-pty takes a string as a ready command line.
      const plan = planWindowsLaunch(launcher, cliArgs);
      file = plan.file;
      args = plan.windowsVerbatimArguments ? plan.args.join(' ') : plan.args;
    } else {
      file = launcher;
      args = cliArgs;
    }
  } catch (err) {
    // Not a PTY problem (a '%' in the name, a launcher we cannot find): do not cache it.
    return { status: 'error', error: errorMessage(err) };
  }

  // The last await is behind us: everything up to the spawn is synchronous. A connection
  // that closed (or a user who cancelled) while the package or the launcher was being
  // looked up has nobody left to hear from this run, and no session yet to be killed
  // through, so it must not start at all.
  if (cancelledLaunches.has(key)) {
    console.error('[node-backend]', `mcp login "${name}": cancelled before it started`);
    return { status: 'error', error: 'The sign-in was cancelled before it started.' };
  }

  const resolvedCwd = typeof workingDir === 'string' && workingDir !== '' ? resolveWslCwd(workingDir) : undefined;
  const cwd = typeof resolvedCwd === 'string' ? resolvedCwd : undefined;
  if (cwd !== undefined && !isExistingDirectory(cwd)) {
    // Checked here so a bad project path is not mistaken, by the spawn error, for a PTY
    // that cannot work on this machine.
    return { status: 'error', error: `The working directory does not exist: ${cwd}` };
  }

  if (deps.platform === 'darwin') ensureSpawnHelperExecutable();

  let proc: PtyProcess;
  try {
    proc = pty.spawn(file, args, { name: 'xterm-256color', cols: PTY_COLS, rows: PTY_ROWS, cwd, env });
  } catch (err) {
    return fallBackToTerminal(name, errorMessage(err));
  }

  const session: Session = {
    key,
    connectionId,
    name,
    workingDir,
    pty: proc,
    state: McpAuthenticationState.STARTING,
    raw: '',
    text: '',
    rawSinceSubmit: '',
    onUpdate,
    listeners: [],
  };
  sessions.set(key, session);
  session.listeners.push(
    proc.onData((chunk) => handleData(session, chunk)),
    proc.onExit((event) => handleExit(session, event.exitCode)),
  );
  session.timeoutTimer = unrefTimer(setTimeout(() => handleTimeout(session), deps.timeoutMs));
  installExitHook();
  console.error('[node-backend]', `mcp login "${name}": started (cwd=${cwd ?? '-'})`);
  emit(session);
  return { status: 'started' };
}

function terminalRequired(name: string, reason: string): McpAuthenticateResponse {
  const command = terminalLoginCommand(name, deps.platform);
  if (command === null) {
    // Never echo the name: it is the thing that cannot be quoted.
    return {
      status: 'error',
      error:
        'this server\'s name cannot be put into a terminal command safely, and the app cannot run the sign-in itself here. ' +
        'Run "claude mcp login" for it yourself in a terminal, with its name quoted for your shell.',
    };
  }
  return { status: 'terminal-required', command, reason };
}

function fallBackToTerminal(name: string, reason: string): McpAuthenticateResponse {
  ptyUnavailable = reason;
  console.error('[node-backend]', 'MCP sign-in PTY unavailable, falling back to the terminal command:', reason);
  return terminalRequired(name, reason);
}

/** node-pty wants string values only, and on Windows names that differ only in case are one variable. */
function toPtyEnv(env: NodeJS.ProcessEnv, platform: NodeJS.Platform): Record<string, string> {
  const folded = new Map<string, [string, string]>();
  for (const [key, value] of Object.entries(env)) {
    if (value === undefined) continue;
    const id = platform === 'win32' ? key.toLowerCase() : key;
    // Delete first so the later entry (Claude.env sets PATH after spreading process.env) wins.
    folded.delete(id);
    folded.set(id, [key, value]);
  }
  return Object.fromEntries(folded.values());
}

function isExistingDirectory(path: string): boolean {
  try {
    return statSync(path).isDirectory();
  } catch (err) {
    const code = (err as NodeJS.ErrnoException).code;
    // Only a path that is certainly not there; anything else (permissions...) is left to the spawn.
    return !(code === 'ENOENT' || code === 'ENOTDIR');
  }
}

/**
 * macOS: node-pty starts children through a `spawn-helper` binary, and a package
 * extracted without its mode bits leaves it non-executable. Best effort, silent.
 */
function ensureSpawnHelperExecutable(): void {
  try {
    const entry = createRequire(import.meta.url).resolve('@lydell/node-pty');
    const arch = process.arch;
    const helper = join(dirname(entry), '..', `node-pty-darwin-${arch}`, 'prebuilds', `darwin-${arch}`, 'spawn-helper');
    if ((statSync(helper).mode & 0o111) === 0) chmodSync(helper, 0o755);
  } catch {
    // The spawn reports the real problem if there is one.
  }
}

function installExitHook(): void {
  if (exitHookInstalled) return;
  exitHookInstalled = true;
  // A PTY child is not tied to this process the way a pipe child is: do not leave it behind.
  process.once('exit', killAllMcpLogins);
}

// ─── Reading the terminal ─────────────────────────────────────────────────────

function handleData(session: Session, chunk: string): void {
  try {
    // After a cancel or a timeout the CLI's last words are not news.
    if (isFinished(session.state)) return;
    session.raw = tail(session.raw + chunk, MAX_BUFFER_CHARS);
    session.text = normalizePtyText(session.raw);
    if (session.state === McpAuthenticationState.STARTING) {
      detectAuthorizationUrl(session);
    } else if (session.state === McpAuthenticationState.VERIFYING) {
      session.rawSinceSubmit = tail(session.rawSinceSubmit + chunk, MAX_BUFFER_CHARS);
      detectRefusedPaste(session);
    }
  } catch (err) {
    // A parsing slip must not take the backend down; the timeout still bounds the run.
    console.error('[node-backend]', `mcp login "${session.name}": could not read the CLI output:`, errorMessage(err));
  }
}

// An OSC 8 hyperlink opener: ESC ] 8 ; <params> ; <target> (BEL | ESC \).
// eslint-disable-next-line no-control-regex -- terminal escape sequences start with ESC
const OSC8_TARGET = /\x1b\]8;[^;\x07\x1b]*;(https?:\/\/[^\x07\x1b]+)(?:\x07|\x1b\\)/;
const REFUSED_PASTE = /doesn['’]tlooklikearedirectURL/i;
const REFUSED_PASTE_LINE = /doesn['’]t look like a redirect URL/i;

function detectAuthorizationUrl(session: Session): void {
  const candidates = [OSC8_TARGET.exec(session.raw)?.[1], visibleUrl(session.text)];
  for (const candidate of candidates) {
    if (candidate === undefined || !isHttpUrl(candidate)) continue;
    session.url = candidate;
    session.state = McpAuthenticationState.AWAITING_CALLBACK;
    emit(session);
    return;
  }
}

/**
 * The first URL after the CLI's "Visit this URL" line. Only a URL that is already
 * followed by whitespace counts: the end of the chunk may be the middle of the URL.
 */
function visibleUrl(text: string): string | undefined {
  const marker = text.search(/Visit this URL/i);
  if (marker < 0) return undefined;
  return /https?:\/\/\S+(?=\s)/.exec(text.slice(marker))?.[0];
}

/**
 * The CLI answers a paste it does not accept with a sentence and asks again, and keeps
 * running. Spaces are dropped before matching because ConPTY may have drawn them as
 * cursor moves.
 */
function detectRefusedPaste(session: Session): void {
  const sinceSubmit = normalizePtyText(session.rawSinceSubmit);
  if (!REFUSED_PASTE.test(sinceSubmit.replace(/\s+/g, ''))) return;
  const sentence = sinceSubmit
    .split('\n')
    .filter((line) => REFUSED_PASTE_LINE.test(line))
    .pop()
    ?.trim()
    .slice(0, MAX_REJECTION_CHARS);
  const error = sentence || "That doesn't look like a redirect URL for this sign-in.";
  session.rawSinceSubmit = '';
  session.state = McpAuthenticationState.AWAITING_CALLBACK;
  session.lastError = error;
  emit(session, { error });
}

/**
 * Terminal output as plain text: hyperlink and title sequences dropped, `ESC[nC`
 * turned into spaces, cursor positioning into line breaks, every other escape sequence
 * removed. An escape sequence still being received at the end is dropped too.
 */
/* eslint-disable no-control-regex -- terminal escape sequences start with ESC */
function normalizePtyText(raw: string): string {
  return raw
    .replace(/\x1b\][^\x07\x1b]*(?:\x07|\x1b\\)/g, '')
    .replace(/\x1b(?:\][^\x07]*|\[[0-9;?]*[ -/]*)?$/, '')
    .replace(/\x1b\[(\d*)C/g, (_match, count: string) => ' '.repeat(Math.min(Number(count || '1') || 1, 1_000)))
    .replace(/\x1b\[[0-9;]*[HfEFd]/g, '\n')
    .replace(/\x1b\[[0-9;?]*[ -/]*[@-~]/g, '')
    .replace(/\x1b[()#][0-9A-Za-z]|\x1b[@-Z\\^_=>78]/g, '')
    .replace(/\r\n?/g, '\n');
}
/* eslint-enable no-control-regex */

// ─── Ending ───────────────────────────────────────────────────────────────────

function handleExit(session: Session, exitCode: number): void {
  // Cancelled or timed out: the user was told then, the exit adds nothing.
  if (isFinished(session.state)) {
    forget(session);
    return;
  }
  const succeeded = exitCode === 0;
  session.state = succeeded ? McpAuthenticationState.SUCCEEDED : McpAuthenticationState.FAILED;
  const error = succeeded ? undefined : failureText(session.text);
  emit(session, { error, exitCode });
  console.error('[node-backend]', `mcp login "${session.name}": ${succeeded ? 'succeeded' : `failed (exit ${exitCode})`}`);
  forget(session);
}

function handleTimeout(session: Session): void {
  if (isFinished(session.state)) return;
  session.state = McpAuthenticationState.TIMED_OUT;
  emit(session);
  console.error('[node-backend]', `mcp login "${session.name}": timed out`);
  killQuietly(session);
  // The exit event normally ends the session; this only guards against one that never comes.
  session.graceTimer = unrefTimer(setTimeout(() => forget(session), deps.cancelGraceMs));
}

/** The last lines the CLI printed, with every URL redacted: they may be an echoed paste. */
function failureText(text: string): string | undefined {
  const lines = text
    .split('\n')
    .map((line) => line.trim())
    .filter((line) => line !== '')
    .slice(-3);
  const redacted = lines.join('\n').replace(/https?:\/\/\S+/g, '[url]');
  return tail(redacted, MAX_FAILURE_CHARS) || undefined;
}

function killAllMcpLogins(): void {
  for (const session of [...sessions.values()]) {
    killQuietly(session);
    forget(session);
  }
}

function killQuietly(session: Session): void {
  try {
    // No signal argument: node-pty throws on Windows when it is given one.
    session.pty.kill();
  } catch {
    // Already gone.
  }
}

/** Drop a session: stop its timers and listeners and free its key. */
function forget(session: Session): void {
  clearTimeout(session.timeoutTimer);
  clearTimeout(session.graceTimer);
  for (const listener of session.listeners) {
    try {
      listener.dispose();
    } catch {
      // Nothing left to release.
    }
  }
  session.listeners = [];
  if (sessions.get(session.key) === session) sessions.delete(session.key);
}

// ─── Small helpers ────────────────────────────────────────────────────────────

function sessionKey(connectionId: string, name: string): string {
  return `${connectionId}\0${name}`;
}

function isFinished(state: McpAuthenticationState): boolean {
  return (
    state === McpAuthenticationState.SUCCEEDED ||
    state === McpAuthenticationState.FAILED ||
    state === McpAuthenticationState.CANCELLED ||
    state === McpAuthenticationState.TIMED_OUT
  );
}

function emit(session: Session, extra: { error?: string; exitCode?: number } = {}): void {
  const update: McpServerAuthenticationStatus = { name: session.name, state: session.state };
  if (session.workingDir !== undefined) update.workingDir = session.workingDir;
  if (session.url !== undefined) update.url = session.url;
  if (extra.error !== undefined) update.error = extra.error;
  if (extra.exitCode !== undefined) update.exitCode = extra.exitCode;
  try {
    session.onUpdate(update);
  } catch (err) {
    // The connection may have closed; the run is not the listener's to break.
    console.error('[node-backend]', `mcp login "${session.name}": could not report progress:`, errorMessage(err));
  }
}

function isHttpUrl(value: string): boolean {
  try {
    const { protocol } = new URL(value);
    return protocol === 'http:' || protocol === 'https:';
  } catch {
    return false;
  }
}

/**
 * One line of http(s) URL of a size the prompt can take, with no control character: the
 * raw text is what gets typed (`new URL()` would percent-encode one, so it cannot be left
 * to the parse), and a terminal acts on a Ctrl+C, an escape sequence or a line kill.
 */
function isPastableUrl(value: string): boolean {
  return (
    value !== '' &&
    value.length <= MAX_CALLBACK_URL_LENGTH &&
    !/\s/.test(value) &&
    !CONTROL_CHARACTERS.test(value) &&
    isHttpUrl(value)
  );
}

function tail(value: string, max: number): string {
  return value.length > max ? value.slice(-max) : value;
}

function unrefTimer(timer: NodeJS.Timeout): NodeJS.Timeout {
  // A pending timeout must not keep the backend alive on its own.
  timer.unref?.();
  return timer;
}

function errorMessage(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}
