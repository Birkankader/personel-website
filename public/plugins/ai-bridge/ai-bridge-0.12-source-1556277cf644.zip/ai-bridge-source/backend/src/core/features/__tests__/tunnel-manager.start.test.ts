import { beforeEach, describe, expect, it, vi } from 'vitest';

// startTunnel looks cloudflared up, opens its log file, then spawns it. These
// tests stop before the spawn, so no process is started.
const fsMock = vi.hoisted(() => ({ existsSync: vi.fn(), openSync: vi.fn() }));
vi.mock('fs', async (importOriginal) => ({ ...(await importOriginal<typeof import('fs')>()), ...fsMock }));
vi.mock('child_process', async (importOriginal) => ({
  ...(await importOriginal<typeof import('child_process')>()),
  // `which`/`where` finds nothing, so the per-user binary under ~/.ai-bridge/bin decides.
  exec: vi.fn((_command: string, _options: unknown, callback: (error: Error | null) => void) => callback(new Error('not found'))),
  spawn: vi.fn(),
}));
vi.mock('../../augmented-path', () => ({ augmentedEnv: () => ({}) }));

import { spawn } from 'child_process';
import { startTunnel } from '../tunnel-manager';

beforeEach(() => {
  vi.clearAllMocks();
});

describe('startTunnel', () => {
  it('rejects with cloudflared-missing when no binary is found', async () => {
    fsMock.existsSync.mockReturnValue(false);
    await expect(startTunnel(4100)).rejects.toMatchObject({ name: 'TunnelError', code: 'cloudflared-missing' });
    expect(spawn).not.toHaveBeenCalled();
  });

  it('rejects when the log file cannot be opened, instead of never settling', async () => {
    fsMock.existsSync.mockReturnValue(true);
    fsMock.openSync.mockImplementation(() => { throw new Error('EACCES: permission denied'); });
    await expect(startTunnel(4100)).rejects.toThrow('EACCES');
    expect(spawn).not.toHaveBeenCalled();
  });
});
