import { EventEmitter } from 'events';
import type { ChildProcess } from 'child_process';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
const mocks = vi.hoisted(() => ({ spawn: vi.fn(), execFile: vi.fn(), execFileSync: vi.fn() }));
vi.mock('child_process', () => mocks);
vi.mock('../features/settings', () => ({ readMergedSettings: vi.fn(), resolveClaudeConfigDirOverride: vi.fn() }));
vi.mock('../features/claude-settings', () => ({ getStrippableAuthEnvKeys: vi.fn(async () => []) }));
vi.mock('../mcp-container-reclaimer', () => ({ attachMcpContainerReclaim: vi.fn() }));
vi.mock('../features/mcp-config-files', async original => ({
  ...await original<typeof import('../features/mcp-config-files')>(),
  readClaudeJson: async () => ({}), readProjectMcpJson: async () => null, claudeJsonDisplayPath: () => '/fixture',
}));
vi.mock('../features/env-sources', () => ({ buildMcpEnvSource: async () => ({}) }));
import { Claude } from '../claude';
import { getMcpServers } from '../features/mcp-manager';
import { buildCmdCommandLine } from '../win-exec';
import { attachMcpContainerReclaim } from '../mcp-container-reclaimer';

type Lifecycle = { trackProcess: (proc: ChildProcess) => void; isShuttingDown: () => boolean };
const lifecycleClaude = Claude as typeof Claude & { configureProcessLifecycle?: (owner?: Lifecycle) => void };
const child = (pid: number) => Object.assign(new EventEmitter(), {
  pid, exitCode: null, signalCode: null, kill: vi.fn(),
}) as unknown as ChildProcess;
let shuttingDown: boolean;
let tracked: ChildProcess[];
const realPlatform = process.platform;
beforeEach(() => {
  vi.clearAllMocks(); shuttingDown = false; tracked = [];
  lifecycleClaude.configureProcessLifecycle?.({ trackProcess: proc => tracked.push(proc), isShuttingDown: () => shuttingDown });
});
afterEach(() => {
  lifecycleClaude.configureProcessLifecycle?.(); vi.restoreAllMocks(); vi.useRealTimers();
  Object.defineProperty(process, 'platform', { value: realPlatform, configurable: true });
});
const flush = async () => { for (let n = 0; n < 25; n++) await Promise.resolve(); };

describe('backend ownership of helper CLI processes', () => {
  it('tracks both config/auth spawns and exec metadata children until their lifecycle owner releases them', async () => {
    const config = child(41001), metadata = child(41002);
    mocks.spawn.mockReturnValue(config);
    mocks.execFile.mockImplementation((_command, _args, _options, callback) => {
      queueMicrotask(() => callback(null, Buffer.from('ok'), Buffer.alloc(0)));
      return metadata;
    });
    expect(Claude.spawn(['auth', 'login'])).toBe(config);
    await expect(Claude.exec(['--version'])).resolves.toEqual({ stdout: 'ok', stderr: '' });
    expect(tracked).toEqual([config, metadata]);
  });

  it('does not start spawn or exec work after its backend begins shutting down', async () => {
    shuttingDown = true;
    mocks.spawn.mockReturnValue(child(41003));
    mocks.execFile.mockImplementation((_command, _args, _options, callback) => {
      queueMicrotask(() => callback(null, Buffer.alloc(0), Buffer.alloc(0)));
      return child(41004);
    });
    expect(() => Claude.spawn(['auth', 'login'])).toThrow(/shutting down/i);
    await expect(Claude.exec(['--version'])).rejects.toThrow(/shutting down/i);
    expect(mocks.spawn).not.toHaveBeenCalled();
    expect(mocks.execFile).not.toHaveBeenCalled();
  });

  it('cancels through tree cleanup and bounds a missing process callback', async () => {
    vi.useFakeTimers();
    const proc = child(41005), controller = new AbortController();
    mocks.execFile.mockReturnValue(proc);
    const kill = vi.spyOn(Claude, 'killTreeNonBlocking').mockResolvedValue();
    const result = Claude.exec(['mcp', 'get', 'server'], { signal: controller.signal });
    const rejected = expect(result).rejects.toThrow(/cancel|abort/i);
    controller.abort();
    await vi.advanceTimersByTimeAsync(5000);
    await rejected;
    expect(kill).toHaveBeenCalledWith(proc);
    expect(mocks.execFile.mock.calls[0][2].signal).toBeUndefined();
  });

  it('starts tree cleanup at the deadline before native timeout can destroy the Windows shell', async () => {
    vi.useFakeTimers();
    const proc = child(41006);
    mocks.execFile.mockReturnValue(proc);
    let finishKill!: () => void;
    const kill = vi.spyOn(Claude, 'killTreeNonBlocking').mockImplementation(() => new Promise(resolve => { finishKill = resolve; }));
    const result = Claude.exec(['mcp', 'list'], { timeout: 100 });
    let settled = false;
    const observed = result.catch(error => { settled = true; return error; });
    expect(mocks.execFile.mock.calls[0][2].timeout).toBe(0);
    await vi.advanceTimersByTimeAsync(100);
    expect(kill).toHaveBeenCalledWith(proc);
    expect(proc.exitCode).toBeNull();
    mocks.execFile.mock.calls[0][3](new Error('terminated'), Buffer.from('raw output'), Buffer.from('raw stderr'));
    await flush(); expect(settled).toBe(false);
    finishKill();
    expect(await observed).toMatchObject({ code: 'ETIMEDOUT', killed: true, stdout: 'raw output', stderr: 'raw stderr' });
  });

  it('holds MCP slots through delayed cleanup when a closed panel is reopened immediately', async () => {
    // `mcp get` asks for shell:false, which on win32 means a pre-quoted cmd.exe line
    // instead of plain argv. This test is about slots and cleanup, so give it the
    // plain argv it reads (`args[1]`, `args[2]`) whatever platform runs it. The
    // afterEach hook puts the real platform back.
    Object.defineProperty(process, 'platform', { value: 'linux', configurable: true });
    const names = ['one', 'two', 'three'];
    const requests: Array<{ proc: ChildProcess; name: string; finish: () => void; done: boolean }> = [];
    const killing = new Map<ChildProcess, () => void>();
    let active = 0, peak = 0;
    vi.spyOn(Claude, 'killTreeNonBlocking').mockImplementation(proc => new Promise(resolve => killing.set(proc, resolve)));
    mocks.execFile.mockImplementation((_command, args: string[], _options, callback) => {
      const proc = child(43000 + tracked.length);
      if (args[1] === 'list') {
        queueMicrotask(() => { callback(null, names.map(name => `${name}: fixture - ✔ Connected`).join('\n'), ''); proc.emit('close', 0); });
      } else {
        active++; peak = Math.max(peak, active);
        const entry = { proc, name: args[2], done: false, finish: () => {
          if (entry.done) return;
          entry.done = true; active--;
          callback(null, `${entry.name}:\n  Scope: User config\n  Status: ✔ Connected\n  Type: stdio\n  Command: fixture`, '');
          proc.emit('close', 0);
        } };
        requests.push(entry);
      }
      return proc;
    });
    const closing = new AbortController();
    const first = getMcpServers('/fixture/a', undefined, closing.signal).catch(() => null);
    await flush(); expect(requests).toHaveLength(2);
    closing.abort();
    const reopened = getMcpServers('/fixture/b');
    await flush();
    expect(requests).toHaveLength(2);
    for (const entry of requests.slice(0, 2)) {
      entry.finish(); killing.get(entry.proc)!(); await flush();
      expect(active).toBeLessThanOrEqual(2);
    }
    while (requests.some(entry => !entry.done)) { requests.find(entry => !entry.done)!.finish(); await flush(); }
    expect(await first).toBeNull();
    expect((await reopened).servers).toHaveLength(3);
    expect(requests).toHaveLength(5);
    expect(peak).toBe(2);
  });

  it('uses managed cleanup for Windows shell:false through the pre-quoted cmd.exe line', async () => {
    const platform = process.platform;
    Object.defineProperty(process, 'platform', { value: 'win32', configurable: true });
    vi.useFakeTimers();
    try {
      vi.spyOn(Claude, 'which').mockResolvedValue('C:\\Program Files\\claude.cmd');
      const proc = child(44001);
      mocks.execFile.mockReturnValue(proc);
      const kill = vi.spyOn(Claude, 'killTreeNonBlocking').mockResolvedValue();
      const json = '{"command":"fixture & value"}';
      const result = Claude.exec(['mcp', 'add-json', 'example', json], { shell: false, timeout: 100 });
      const observed = result.catch(error => error);
      await flush();
      expect(mocks.execFile.mock.calls[0][1]).toEqual(['/d', '/v:off', '/s', '/c', buildCmdCommandLine('C:\\Program Files\\claude.cmd', ['mcp', 'add-json', 'example', json])]);
      expect(mocks.execFile.mock.calls[0][2]).toMatchObject({ shell: false, windowsVerbatimArguments: true, timeout: 0 });
      expect(tracked).toEqual([proc]);
      await vi.advanceTimersByTimeAsync(100);
      expect(kill).toHaveBeenCalledWith(proc);
      mocks.execFile.mock.calls[0][3](new Error('terminated'), Buffer.from('raw'), Buffer.alloc(0));
      expect(await observed).toMatchObject({ code: 'ETIMEDOUT', stdout: 'raw', stderr: '' });
    } finally { Object.defineProperty(process, 'platform', { value: platform, configurable: true }); }
  });

  // `mcp get`/`remove`/`logout` boot the user's MCP servers (docker containers
  // included) and so need the same straggler reclaim as every other exec. Only
  // `add-json`, which just writes config, was measured not to start any.
  it('reclaims MCP containers after Windows shell:false commands that can start servers, not after add-json', async () => {
    const platform = process.platform;
    Object.defineProperty(process, 'platform', { value: 'win32', configurable: true });
    try {
      vi.spyOn(Claude, 'which').mockResolvedValue('C:\\Program Files\\claude.cmd');
      mocks.execFile.mockImplementation((_command, _args, _options, callback) => {
        queueMicrotask(() => callback(null, Buffer.from('ok'), Buffer.alloc(0)));
        return child(44100 + tracked.length);
      });
      const reclaim = vi.mocked(attachMcpContainerReclaim);

      await Claude.exec(['mcp', 'get', 'aib spaced'], { shell: false });
      expect(reclaim).toHaveBeenCalledTimes(1);
      await Claude.exec(['mcp', 'add-json', 'example', '{}'], { shell: false });
      expect(reclaim).toHaveBeenCalledTimes(1);
      await Claude.exec(['mcp', 'logout', 'aib spaced'], { shell: false });
      await Claude.exec(['mcp', 'remove', 'aib spaced', '-s', 'user'], { shell: false });
      expect(reclaim).toHaveBeenCalledTimes(3);
    } finally { Object.defineProperty(process, 'platform', { value: platform, configurable: true }); }
  });
});
