import {
  type Announcement,
  type AnnouncementAction,
  type AnnouncementMedia,
  type AnnouncementStep,
  type AnnouncementTarget,
  type AnnouncementsResponse,
} from '../../shared';

/** Retained only for local schema compatibility. Remote delivery is absent. */
const SCHEMA_VERSION = 1;

/**
 * Validates only the structural shape of an action (id/label are strings,
 * type is a string, optional url/route/command are strings when present).
 * Deliberately does NOT check `type` against the known
 * `AnnouncementActionType` members — a newer server may add a new action type
 * as a backward-compatible extension, and this relay layer must not drop the
 * whole announcement just because it doesn't recognize one action's type
 * (original data preservation + forward-compat). The decision of "do I know how to render/run
 * this action" belongs to the webview (see `knownActions` in
 * `@ccg/announcement-core`'s `eligibility.ts`, vendored at
 * `webview/src/vendor/announcement-core`), not this backend relay.
 */
function isValidAction(value: unknown): value is AnnouncementAction {
  if (!value || typeof value !== 'object') return false;
  const action = value as Record<string, unknown>;
  if (typeof action.id !== 'string' || typeof action.label !== 'string') return false;
  if (typeof action.type !== 'string') return false;
  if (action.url !== undefined && typeof action.url !== 'string') return false;
  if (action.route !== undefined && typeof action.route !== 'string') return false;
  if (action.command !== undefined && typeof action.command !== 'string') return false;
  return true;
}

/**
 * Validates only the structural shape of a target (frequency is a string,
 * optional pluginVersion/showFrom/showUntil are strings when present).
 * Deliberately does NOT check `frequency` against the known
 * `AnnouncementFrequency` members, for the same forward-compat reason as
 * `isValidAction`'s `type` — the shared `isEligible` (in
 * `@ccg/announcement-core`) already falls back gracefully (treats any
 * non-ALWAYS value like UNTIL_DISMISSED) for a frequency it doesn't recognize.
 */
function isValidTarget(value: unknown): value is AnnouncementTarget {
  if (!value || typeof value !== 'object') return false;
  const target = value as Record<string, unknown>;
  if (typeof target.frequency !== 'string') return false;
  if (target.pluginVersion !== undefined && typeof target.pluginVersion !== 'string') return false;
  if (target.showFrom !== undefined && typeof target.showFrom !== 'string') return false;
  if (target.showUntil !== undefined && typeof target.showUntil !== 'string') return false;
  return true;
}

/**
 * Validates only the structural shape of a media object (type/url are strings,
 * optional alt is a string when present). Like `isValidAction`, this deliberately
 * does NOT check `type` against the known `AnnouncementMediaType` members — a
 * newer server may add a media kind as a backward-compatible extension, and this
 * relay layer must not drop the whole announcement over an unrecognized media
 * type (original data preservation + forward-compat). A well-typed string passes; the webview
 * renderer decides what it can actually display.
 */
function isValidMedia(value: unknown): value is AnnouncementMedia {
  if (!value || typeof value !== 'object') return false;
  const media = value as Record<string, unknown>;
  if (typeof media.type !== 'string') return false;
  if (typeof media.url !== 'string') return false;
  if (media.alt !== undefined && typeof media.alt !== 'string') return false;
  return true;
}

/**
 * Validates only the structural shape of a delivered step: optional `media` is a
 * valid media object, optional `title` is a string, and `body` — when present —
 * is a string. `body` is not hard-required here so a forward-compatible server
 * shape isn't dropped; the merge/render decision belongs to the webview.
 */
function isValidStep(value: unknown): value is AnnouncementStep {
  if (!value || typeof value !== 'object') return false;
  const step = value as Record<string, unknown>;
  if (step.media !== undefined && !isValidMedia(step.media)) return false;
  if (step.title !== undefined && typeof step.title !== 'string') return false;
  if (step.body !== undefined && typeof step.body !== 'string') return false;
  return true;
}

/**
 * Validates that `value` matches the `Announcement` shape (required fields
 * present, correct primitive types). Passing items are returned as-is (same
 * object reference) — per the "original data preservation" principle we never rebuild/rename
 * fields, only filter out structurally invalid entries.
 *
 * Individual enum members (`placements` entries, action `type`, target
 * `frequency`) are intentionally NOT checked against this client build's known
 * values — only that they are well-typed strings. This lets the server ship a
 * backward-compatible extension (e.g. a new placement or action type) without
 * this backend dropping the whole announcement for older, not-yet-updated
 * clients; unknown enum values are relayed through untouched and it's up to
 * the webview renderer to decide what it can actually show (see
 * `AnnouncementPlacement`'s natural no-op via `selectForPlacement`'s
 * `.includes(placement)`, and `knownActions` for action buttons).
 */
function isValidAnnouncement(value: unknown): value is Announcement {
  if (!value || typeof value !== 'object') return false;
  const item = value as Record<string, unknown>;
  if (typeof item.id !== 'string') return false;
  if (!Array.isArray(item.placements) || item.placements.length === 0) return false;
  if (!item.placements.every((p) => typeof p === 'string')) return false;
  if (typeof item.priority !== 'number') return false;
  if (typeof item.icon !== 'string') return false;
  if (item.imageUrl !== undefined && typeof item.imageUrl !== 'string') return false;
  if (item.media !== undefined && !isValidMedia(item.media)) return false;
  if (typeof item.title !== 'string') return false;
  if (typeof item.body !== 'string') return false;
  if (item.steps !== undefined && (!Array.isArray(item.steps) || !item.steps.every(isValidStep))) return false;
  if (typeof item.dismissible !== 'boolean') return false;
  if (!Array.isArray(item.actions) || !item.actions.every(isValidAction)) return false;
  if (!isValidTarget(item.target)) return false;
  return true;
}

const EMPTY_RESPONSE: AnnouncementsResponse = { schemaVersion: SCHEMA_VERSION, announcements: [] };

/**
 * Validates the raw fetch response body against the announcements contract.
 * Any mismatch (unknown schemaVersion, malformed envelope, invalid entries)
 * degrades gracefully to an empty list rather than throwing.
 */
export function validateResponse(data: unknown): AnnouncementsResponse {
  if (!data || typeof data !== 'object') return EMPTY_RESPONSE;
  const body = data as Record<string, unknown>;
  if (body.schemaVersion !== SCHEMA_VERSION) return EMPTY_RESPONSE;
  if (!Array.isArray(body.announcements)) return EMPTY_RESPONSE;
  return {
    schemaVersion: SCHEMA_VERSION,
    announcements: body.announcements.filter(isValidAnnouncement),
  };
}

/**
 * Fetches the current locale's announcement list from the remote delivery endpoint
 * (`AI_BRIDGE_ANNOUNCE_URL`), short-TTL cached per locale+pluginVersion. Returns an empty
 * list (never throws) when the user turned announcements off (profile.json
 * `announcementsEnabled`), the URL is unset, the request fails, or the response
 * doesn't validate. The request carries ONLY `locale` and `pluginVersion` — no
 * install id / uuid / any other PII (this is content delivery, not telemetry).
 */
export async function fetchAnnouncements(_workingDir?: string): Promise<AnnouncementsResponse> {
  return { schemaVersion: 1, announcements: [] };
}
