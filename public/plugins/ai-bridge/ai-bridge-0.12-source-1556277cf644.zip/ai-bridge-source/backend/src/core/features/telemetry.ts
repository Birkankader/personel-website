import { clientInfo, isJetBrainsMode } from '../../config/environment';

export interface TelemetryProperties { [key: string]: string | number | boolean }
export interface TelemetryOptions { requireConsent?: boolean }
let browserClient = '';
/** Kept only for local About information, never transmitted. */
export function setBrowserClient(client: string): void { browserClient = client; }
export function getRawClientInfo(): string { return isJetBrainsMode ? clientInfo : browserClient; }
/** Remote analytics are absent from this independent build. */
export async function flushTelemetry(): Promise<void> {}
export function trackEvent(_event: string, _properties: TelemetryProperties = {}, _options: TelemetryOptions = {}): void {}
export function trackActivity(_type: string): void {}
export function trackError(_error: Error, _context: TelemetryProperties = {}, _options: TelemetryOptions = {}): void {}
/** Preserve local diagnostics without a remote error-reporting transport. */
export function reportBackendError(error: Error, context: TelemetryProperties = {}): void {
  console.error('[node-backend]', error.message, context);
}
