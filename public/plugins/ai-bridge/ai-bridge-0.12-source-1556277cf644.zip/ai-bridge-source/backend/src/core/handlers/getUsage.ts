import { unsupportedServiceHandler } from './unsupportedServices';
interface UsageBucket { utilization: number; resets_at: string }
interface ExtraUsage { is_enabled: boolean; monthly_limit: number | null; used_credits: number | null; utilization: number | null }

export interface CcbUsageResponse {
  five_hour: UsageBucket | null;
  seven_day: UsageBucket | null;
  seven_day_oauth_apps: UsageBucket | null;
  seven_day_sonnet: UsageBucket | null;
  seven_day_opus: UsageBucket | null;
  seven_day_cowork: UsageBucket | null;
  iguana_necktie: UsageBucket | null;
  extra_usage: ExtraUsage | null;
}

type UsageErrorKind = 'ccb_missing' | 'npm_missing' | 'auth' | 'network' | 'unknown';

interface UsageErrorInfo {
  kind: UsageErrorKind;
  message: string;
}

export function classifyError(raw: string, code?: number | string): UsageErrorInfo {
  if (/npm[^a-z].*(?:command not found|not recognized)|(?:command not found|not recognized).*npm/i.test(raw)) {
    return { kind: 'npm_missing', message: 'Node.js / npm not found in PATH' };
  }

  // exit code 127 = the shell could not find the command we asked it to run (`ccb`).
  // This is the standard, locale-independent signal for a missing command: the shell's
  // "command not found" text is localized (e.g. Russian "команда не найдена") and cannot
  // be matched by an English regex, but the exit code is always 127. We additionally
  // require the `ccb` token so an unrelated failure inside the command is not misattributed.
  // The English text patterns remain as a fallback for paths where the exit code is
  // unavailable (e.g. npm's "could not determine executable to run"). (issue #114)
  //
  // Note: ENOENT is intentionally NOT treated as ccb_missing. execFile spawns the shell,
  // not ccb directly, so a missing ccb always surfaces as exit 127 — an ENOENT here means
  // the shell binary itself is absent, a different failure.
  const ccbMissingByCode = code === 127 && /\bccb\b/.test(raw);
  const ccbMissingByText = /could not determine executable to run/i.test(raw)
    || /command not found.*ccb|ccb.*not found|ccb.*not recognized/i.test(raw);
  if (ccbMissingByCode || ccbMissingByText) {
    return { kind: 'ccb_missing', message: 'The ccb CLI is not installed' };
  }

  const jsonMatch = raw.match(/\{[\s\S]*\}/);
  if (jsonMatch) {
    try {
      const parsed = JSON.parse(jsonMatch[0]);
      if (parsed.error?.message) {
        return { kind: 'auth', message: parsed.error.message };
      }
    } catch { /* not JSON, fall through */ }
  }

  if (/ENOTFOUND|ECONNREFUSED|ETIMEDOUT|getaddrinfo/i.test(raw)) {
    return { kind: 'network', message: 'Network error reaching Anthropic API' };
  }

  const cleaned = raw
    .split('\n')
    .filter((line) => !/^npm (warn|WARN)\b/.test(line))
    .join('\n')
    .trim();
  return { kind: 'unknown', message: cleaned || raw };
}

export function resetUsageCache(): void {}
export async function runCcbUsage(): Promise<CcbUsageResponse> { throw new Error('Optional quota polling is not supported by AI Bridge.'); }
export const getUsageHandler = unsupportedServiceHandler;
