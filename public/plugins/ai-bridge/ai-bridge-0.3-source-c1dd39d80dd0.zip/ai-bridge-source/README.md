# AI Bridge

Claude Code'u JetBrains IDE'nizde kullanın. Kod tabanını keşfedin, değişiklikleri planlayın ve önerilen düzenlemeleri IDE içinde inceleyin. Sohbetleri, kod bağlamını ve görevlerinizi aynı çalışma alanından yönetin.

Geliştirici ve yayıncı: **Birkan Kader**. Sürüm: **0.1**.

Ürün açıklaması: [Türkçe](docs/marketplaces/jetbrains/tr.md) · [English](docs/marketplaces/jetbrains/en.md).

## Özellikler

- Sekmelerin yanında kalıcı **+** düğmesi ve Türkçe arayüz.
- Düşük kaynak modu ve uzun sohbetlerde azaltılmış ekran güncellemeleri.
- Proje bazında görev kuyruğu, eşzamanlılık sınırı ve yerel CPU/RAM paneli.
- Konuşmalarda arama, yer imleri ve karar notları.
- Görev şablonları ve gönderim öncesi bağlam önizlemesi.
- Model menüsünden düşünme düzeyi seçimi; değişiklik sonraki mesajda uygulanır.
- Zamanlanmış mesajlar ve varsayılan olarak açık limit sonrası otomatik devam. Kaydedilmiş kapalı tercihler korunur.

## Kurulum

JetBrains **Settings / Preferences → Plugins → dişli → Manage Plugin Repositories…** üzerinden `https://birkankader.com/plugins/ai-bridge/updatePlugins.xml` adresini bir kez ekleyin. Eklentiyi bu depodan kurabilir veya mevcut eklenti kurulumunu **Update** ile güncelleyebilirsiniz. **Update Plugins Automatically** açıksa güncellemeler otomatik indirilip sonraki IDE yeniden başlatmasında uygulanır.

Diskten kurulum için [güncelleme deposundaki](https://birkankader.com/plugins/ai-bridge/release.json) `pluginFile` alanında belirtilen ZIP'i indirin ve **Install Plugin from Disk…** ile seçin. ZIP'i açmayın. Türkçe için eklenti içindeki **Settings → General → Language → Türkçe** seçin.

Paket ve arayüz adı **AI Bridge**, plugin ID `com.birkankader.ai-bridge`. AI Bridge 0.1 yeni bir eklenti olarak kurulur ve sürüm numaraları 0.1'den yeniden başlar. 0.39 ve önceki derlemeler farklı bir plugin ID kullandığı için yerinde güncellenmez: AI Bridge 0.1'i kurduktan sonra eski eklentiyi kaldırın.

Özel ayarlar `~/.ai-bridge` ve proje içindeki `.ai-bridge` altında saklanır. İlk açılışta önceki kurulumun ayarları, kayıtlı hesapları, harness sohbetleri, proje ayarları ve sohbet adları buraya bir kez kopyalanır; eski dosyalara dokunulmaz. Claude'un kendi hesap ve konuşma kayıtları kullanılmaya devam eder. Claude sağlayıcısının giriş ve kullanım koşulları geçerlidir.

Güncellemeler aynı plugin ID ile özel depodan dağıtılır. Yeni sürüm yayınlama komutu ve kurulum ayrıntıları: [dağıtım rehberi](distribution/README_TR.md).

## Kaynaktan derleme

JDK 21, Node.js ve package.json içindeki sabit pnpm sürümü gerekir. Komutları depo kökünde çalıştırın:

```sh
bash ./scripts/build.sh be-install
bash ./scripts/build.sh wv-install
bash ./scripts/build.sh be-lint
bash ./scripts/build.sh wv-lint
bash ./scripts/build.sh be-test --maxWorkers=2
bash ./scripts/build.sh wv-test --maxWorkers=2
bash ./scripts/build.sh test --max-workers=2
bash ./scripts/build.sh dist
bash ./scripts/build.sh verify-plugin
bash ./scripts/build.sh source-zip
```

## Lisans

GNU AGPL v3. [Lisans metni](LICENSE) ve [kaynak/telif bildirimleri](COMMUNITY_NOTICE.md) dağıtıma dahildir. Eşleşen kaynak kodu kurulum ZIP'iyle birlikte sunulur. Bu yazılım garanti verilmeden sağlanır.

Düşünme düzeyinin kullanımı ve doğrulama kapsamı: [EFFORT_VERIFICATION_TR.md](EFFORT_VERIFICATION_TR.md).

Otomatik devam düzeltmesi ve testleri: [AUTO_RESUME_FIX_TR.md](AUTO_RESUME_FIX_TR.md).

Windows başlangıç düzeltmeleri ve süre günlükleri: [WINDOWS_STARTUP_TR.md](WINDOWS_STARTUP_TR.md).

Windows ilk mesaj donması için inceleme ve düzeltmeler: [FIRST_SEND_FREEZE_TR.md](FIRST_SEND_FREEZE_TR.md).

## IDE compatibility

Distributable builds target IntelliJ IDEA 2023.1 (build 231) and Java 17. Kotlin API/language compatibility is pinned to 1.8 to match the minimum IDE runtime. Run `bash ./scripts/build.sh verify-plugin` for the configured compatibility matrix. Java 21 remains unnecessary for running this plugin on the 2023 IDE line.
