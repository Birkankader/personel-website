# Windows IntelliJ — ilk mesaj donması incelemesi

9 Eylül 2026. Kullanıcı bildirimi: Yeni sohbet açıp “selam” gönderince IntelliJ IDEA ve bilgisayar aşırı yavaşlıyor. Kullanıcının bildirdiği sürüm IntelliJ IDEA 2026.1; CPU göstergesinde AI Bridge için %88 yük görülüyor. Aynı proje/işlem terminalde sorun çıkarmıyor. Kullanıcı önceki Windows başlangıç paketini henüz denememişti.

**Kullanıcının Windows donmasının kesin nedeni ve bu paketin donmayı giderdiği henüz doğrulanmadı.** Bu çalışma eklentiye özgü, kod ve kontrollü testlerle doğrulanan yükleri azaltır. Gerçek Windows/JCEF çalıştırması veya kullanıcının CPU/RAM kaydı alınmadı.

## Uygulanan düzeltmeler

1. **Kapalı MCP panelinin ön yüklemesi.** ChatPage daha MCP paneli açılmadan sunucu listesini sorguluyordu. Canlı sohbet bulunmadığında fallback yolu bir `claude mcp list`, ardından N sunucu için N ayrı `claude mcp get` süreci başlatabiliyordu. Ön yükleme kaldırıldı; yönetim paneli açılınca sorgu yapılır. Detay sorguları tüm eşzamanlı listelerde ortak iki süreç sınırına alındı. Sunucuların sırası, hata davranışı ve panel özellikleri korunur. Açık panelin kuyruklu sorguları için RPC süresi beş dakikaya çıkarıldı. Kullanıcının MCP yapılandırması bilinmediği için bu yükün %88 CPU'nun kesin nedeni olduğu iddia edilmez.
2. **IntelliJ tam panel çizimleri.** OSR repaint köprüsü tüm WebSocket gönderimlerini, log kanalı dahil, yakalayıp her karede tam panel çizimi isteyebiliyordu. JCEF sorgu callback'i Swing boyut/görünürlük okumalarını EDT'ye geçmeden yapıyordu. Yeni ortak planlayıcı tüm istekleri EDT'ye aktarır, tek bekleyen iş tutar ve aralarında en az 250 ms bırakır. Son çizim isteği kaybolmaz. `/logs` çizim istemez; köprü yalnızca OSR tarayıcılarında kurulur. Pencere kapanınca bekleyen iş iptal edilir. Bu bir deadlock tespiti değildir: incelenen modern RemoteBrowser metotları asenkron RPC kullanır.
3. **Akışın loglarda çoğaltılması.** Backend her stdout parçasını tam metin olarak yazıyor, WebView Bridge de aynı CLI olayını yeniden JSON'a çevirip log kanalına gönderiyordu. Tam gövdelerin bu kopyaları kaldırıldı; olaylar arayüze değişmeden ulaşır. İstek türü/kimliği ve hatalar loglanmaya devam eder. Kontrollü yük testinde 100 büyük akış olayı önce 7.523.389 karakter ek tanı geçmişi oluşturuyordu; yeni yolda bu akış gövdeleri tanı geçmişine kopyalanmaz.
4. **Gürültülü CLI hata çıktısı.** Sınırsız stderr birikimi yerine son 16.384 karakter tutulur; tanı önizlemeleri saniyede en fazla bir kez ve sınırlı uzunlukta yazılır. “Session already in use” bilgisi metin bellekten çıksa bile korunur. Testte 10.000 parça tek aralıkta yalnızca bir kısa log üretir. Bu test gürültü davranışını ölçer; “selam” yanıtının bu kadar çıktı ürettiği iddia edilmez.
5. **Aynı oturumun eşzamanlı başlaması.** `ensureClaudeProcess` artık backend bağlantı yöneticisi ve oturum başına bekleyen başlatmayı paylaşır. Önceki kod kontrollü sekiz paralel çağrıda sekiz süreç başlatıyordu; yeni kod bir süreç başlatır. Sonraki farklı mod/düşünme tercihleri yeniden değerlendirilir; hata sonrası yeniden deneme çalışır. Normal arayüzdeki “selam” testinde ikinci başlatma görülmediği için bu yarış kullanıcının donmasının kanıtlanmış nedeni değildir.
6. **Devralınmış Bash başlangıcı.** Eklentinin kendi BASH_ENV yolunun tekrar devralınması kendini kaynaklama döngüsü oluşturabiliyordu. Uyarlayıcı tekrar uygulanınca aynı sonucu verir; script yeniden giriş ve eski wrapper döngülerini engeller, kullanıcının gerçek hook'unu korur. Normal temiz Windows başlatmasında uyarlayıcı yalnızca bir kez çağrılır; bu hata belirli devralınmış ortamlar içindir.

## Gerçek arayüzle kontrollü senaryo

Chrome/macOS üzerinde üretim WebView'i, ayrı geçici proje/kimlik dizini ve sahte CLI ile çalıştırıldı. Gerçek sağlayıcıya istek yapılmadı. “Selam” yalnızca bir kez gönderildi: 1 SEND_MESSAGE, 0 START_SESSION, 1 katalog sorgusu ve 1 sohbet süreci gözlendi. CLI altı saniye sessiz bırakıldı. Gönderimden sonra 4,5 saniyelik sessiz aralıkta yeni DOM değişikliği, uygulama logu veya uzun JavaScript görevi oluşmadı. Minimal `init → assistant → result` yanıtı beş DOM değişikliği ekledi; uzun görev oluşmadı. Bu senaryoda bağımsız WebView döngüsü üretilemedi; native JCEF dahil değildir.

İkinci testte katalog initialize yanıtı 6 saniye geciktirildi ve pencere açıldıktan yaklaşık 290 ms sonra “selam” gönderildi (katalog isteğinden 54 ms sonra). Yine 1 SEND_MESSAGE, 0 START_SESSION ve 1 sohbet süreci görüldü; sohbet katalogdan önce tamamlandı. Gönderim sonrası 50 ms üzeri JavaScript görevi oluşmadı. Sahte CLI içi ölçümde en fazla 3 yardımcı süreç çakıştı; toplam sürüm 1, auth 2, MCP 1, katalog 1 ve sohbet 1 yardımcı süreç görüldü. Bu işletim sistemi düzeyindeki tepe CPU/RAM ölçümü değildir; yardımcı süreçlerin gerçek Windows maliyeti ölçülmedi.

Son arayüz doğrulamasında yeni sohbet → “selam” → yanıt boyunca **GET_MCP_SERVERS = 0** kaldı; GET_CLI_CONFIG = 1 ve SEND_MESSAGE = 1 idi. Ardından gerçek composer'da `/mcp` yazılıp paletten “MCP Servers” seçildi. Modal açıldı, boş sunucu listesini gösterdi ve **GET_MCP_SERVERS = 1** oldu. Paletin kendi açık katalog yenilemesi beklenen şekilde çalıştı. Backend testinde 20 sunucu ve iki eşzamanlı panelden toplam 40 ayrıntı sorgusu, kontrollü hatalarla birlikte en fazla iki CLI ayrıntı süreciyle tamamlandı.

## Doğrulama

| Kontrol | Sonuç |
| --- | --- |
| Backend tam test paketi | 176 dosya; 2.005 başarılı, mevcut 8 atlanan test |
| WebView tam test paketi | 338 dosya; 3.347 başarılı |
| Native repaint/JCEF testleri | 14 başarılı |
| Backend ve WebView TypeScript | Başarılı |
| Diff kontrolü | Başarılı |

Yeni çizim planlayıcısı 10.000 eşzamanlı istek, tek bekleyen iş, hız sınırı, son çizim ve kapanışta iptal testlerinden geçti. Gerçek enjekte edilen JavaScript 20.000 gönderimle çalıştırıldı; gönderimler korunurken log kanalının çizim istemediği ve kendi kendine döngü oluşturmadığı doğrulandı. JCEF bulunmayan IDE'de sınıf yükleme testleri de geçti.

Üretim ZIP'i derlendi. Plugin Verifier, IC 242.26775.15 ve IU 262.8117.19 üzerinde **Compatible** sonucu verdi. Önceden mevcut iki experimental `requestOpenFile` uyarısı sürer; IC'de bulunmayan optional JCEF modülü o kontrolde kapsam dışıdır. IntelliJ IDEA 2026.1/Windows üzerinde çalışma veya CPU karşılaştırması yapılmadı.

ZIP CRC, paket kimliği/adı/yayıncısı/sürümü, gömülü lisanslar ve derlenen backend ile byte eşleşmesi doğrulandı. Yeni bundleRevision: `dad13b50ae41b268415a6647aeebe158a35aca27dea72728c263511a2a77c928`. Bu değer önceki 0.1 paketinden farklıdır; aynı sürüm numarasına rağmen yeni backend/arayüz kaynakları kullanılır.

Kurulum: `output/AI-Bridge-0.1.zip`. Eşleşen kaynak: `output/AI-Bridge-0.1-Source.zip`. SHA-256 değerleri `output/AI_BRIDGE_0.1_SHA256SUMS.txt` içindedir. Eski başlangıç paketi `output/archive/0.1-windows-startup` altında korunur. Diskten kurulumdan sonra IntelliJ'i yeniden başlatın.

## Windows'ta kalan doğrulama

Terminalde sorun olmaması eklentinin JCEF/çizim, tanı trafiği veya Windows süreç sarmalayıcısını öncelikli kılar; tek başına hangisinin sorumlu olduğunu kanıtlamaz. IntelliJ IDEA 2026.1 ve eklenti adı altında %88 CPU kullanıcı tarafından bildirildi. Bunun hangi alt süreç veya iş parçacığına ait olduğu ve RAM dağılımı henüz ölçülmedi. Antivirüs, Git Bash/PowerShell ve JCEF'nin gerçek maliyeti bu Mac'te ölçülemez. Paket kullanıcı IDE'sine kurulmadı ve Marketplace'e yayımlanmadı.

Süre günlükleri: önceki pakette eklenen `Backend startup`, `Chat startup`, `phase=orphan-sweep` ve `[loadCliConfig] probe finished`. Backend günlüğü kullanıcı dizinindeki `.ai-bridge/logs/server.log` dosyasındadır. Doğrulama çıktıları çalışma klasörü yanındaki `validation/windows-first-send-verification` ve `validation/windows-send-freeze` dizinlerindedir.
