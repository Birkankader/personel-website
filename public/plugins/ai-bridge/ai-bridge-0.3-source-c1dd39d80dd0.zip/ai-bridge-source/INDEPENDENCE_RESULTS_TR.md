# AI Bridge 0.31.1 — bağımsız dağıtım

Eklenti geliştiricisi ve yayıncısı **Birkan Kader**. 8 Eylül 2026.

## Ayrılan kimlikler

- Plugin ID: `com.birkankader.ai-bridge`.
- Kotlin namespace: `com.birkankader.aibridge`.
- JetBrains paket adı: `AI Bridge`; arayüz adı: `AI Bridge`. Paket adındaki ASCII tercihi JetBrains Plugin Verifier'ın karakter kısıtı içindir.
- Derleme/ZIP kökü: `ai-bridge`.
- Yerel veri ve proje ayarları: `.ai-bridge`.
- Native sekmeler, action/toolwindow/VFS/editor-state/widget kayıtları, çıkarılan dosyalar, WebSocket kimlik doğrulaması ve uygulamaya özel ortam değişkenleri AI Bridge alanına taşındı.
- Kaynak depo, eski uzak depoyu yalnızca `upstream` adıyla tutar. Yeni GitHub veya Marketplace kaydı oluşturulmadı; sahibin e-posta/web adresi uydurulmadı.

## Bağlantılar ve arayüz

Swttch sponsorluk/ödeme, telemetri, duyuru ve eklenti güncelleme servisleri kaldırıldı. Hakkında ekranı Birkan Kader'i gösterir; yardım ve gizlilik açıklamaları yereldir. Güncellemeler aynı bağımsız kimliğe sahip yeni AI Bridge ZIP'iyle diskten yapılır.

Swttch'e ait yardımcı paket artık kurulmaz veya güncellenmez. Buna bağlı sesli yazma ve uzak kullanım limiti servisleri bağımsız sürümde kullanılabilir gösterilmez. Resmi Claude hesabı/giriş, Claude CLI güncellemesi, yerel konuşma kullanım raporları, sohbet ve AI Bridge'in önceki yerel geliştirmeleri korunur. Kullanıcıya sahte sponsor durumu, oturum veya kullanım değeri verilmez. Otomatik devam, Claude’un bildirdiği sıfırlama zamanına 30 saniye ekleyerek normal `continue` isteği planlar; dış kota servisi kullanmaz. Sağlayıcı yeniden limit yanıtı verebilir. İptal/düzenleme ve erken tetiklenme yarışları önlenir; bağlantı koptuğunda onaylanmamış rezervasyonların yeniden teslim edilebildiği mevcut davranış korunur, tam bir kez gönderim garantisi verilmez.

İsteğe bağlı tarayıcı başlatıcısı da `ai-bridge` adı, ayrı veri dizini ve 19846 varsayılan portunu kullanır. Hazır bir uzak sürüm deposu tanımlı değildir; açıkça bir AI Bridge deposu yapılandırılmadıkça yükleyici/güncelleme komutları ağ isteği yapmaz. Bu çalışmada CLI kurulumu yapılmaz.

## Mevcut kurulum ve veriler

0.31.1, önceki Swttch veya aynı kimliği kullanan 0.31.0 paketinin üzerine güncelleme olarak kurulmaz; bağımsız bir eklentidir. Önceki eklentiyi kullanmayacaksanız Plugins ekranından devre dışı bırakın. Eski özel ayarlar otomatik kopyalanmaz veya silinmez. Claude'un kendi hesap ve ham JSONL konuşma verileri sağlayıcıya aittir ve korunur.

## Doğrulama

- Backend: **167 dosya, 1939 test geçti, 8 mevcut test atlandı**. Otomatik devam/scheduler değişikliklerinden sonra tam takım yeniden çalıştırıldı; ayrıca 34 odaklı zamanlama testi geçti.
- WebView: **334 dosya, 3264 test geçti**.
- Kotlin: **89 sınıf, 429 test geçti**, hata veya atlama yok.
- İsteğe bağlı CLI: **269 test geçti**, hata veya atlama yok. Yabancı süreç/port izolasyonu ve internetsiz önbellekli başlatma regresyonları dahil.
- Backend/WebView lint ve `git diff --check` temiz. Toplam **5901 geçen, 8 atlanan test**.
- `clean` sonrasında üretim derlemesi başarılı. ZIP/JAR kimliği, sürüm ve Birkan Kader yayıncısı doğrulandı. Eski Kotlin ad alanına ait dosya veya boş dizin kalmadı; gömülü backend güncel derlemeyle byte düzeyinde eşleşiyor. Çalışan JS/HTML varlıklarında kaldırılan Swttch servis adresleri bulunmuyor.
- Ağ erişimi kapalı izole backend testi: 11 eski servis isteği açık bir desteklenmiyor yanıtı verdi; harici istek sayısı sıfır. Sahte açık oturum veya kota oluşturulmadı, eski ayar ve Claude fixture dosyaları korundu.
- Gerçek tarayıcıda yerel backend ile Hakkında/gizlilik/sürüm ekranları, Birkan Kader ve 0.31.1 bilgileri, 4 mesajlık Claude JSONL fixture ve **+ ile yeni sekme** kontrol edildi. Eski özel ayar dosyasının SHA-256 değeri değişmedi. Gerçek sağlayıcı girişi/model çağrısı yapılmadı.
- JetBrains Plugin Verifier: **IC 2024.2.6 (`242.26775.15`) ve IU 2026.2 EAP (`262.8117.19`) uyumlu**. İki IDE'de de mevcut `requestOpenFile` çağrıları için 2 deneysel API uyarısı kaldı; bunlar gelecekte platform değişirse tekrar kontrol edilmelidir. IC paketinde opsiyonel JCEF bağımlılığı çözümlenmediği için bu sonuç JCEF'nin gerçek IDE içindeki çalışmasını kanıtlamaz.

Gerçek IDE'de CPU/RAM karşılaştırması veya kullanıcı IDE'sine kurulum bu ayrımın parçası değildir. Önceki performans çalışmasının ölçüm sınırları AI_BRIDGE_RESULTS_TR.md içinde açıklanır.

## Lisans ve kaynak

Bu bağımsız dağıtımın geliştirmeleri Birkan Kader'e aittir. Önceden yazılmış kaynakların yazarları, telif ve AGPL-3.0 metni korunur; ayrıntılar COMMUNITY_NOTICE.md ve LICENSE içindedir. Kaynak kökeni kaydı, eski ürüne ait bir hesap veya çalışma zamanı bağımlılığı değildir. Eşleşen kaynak ZIP, kurulum ZIP'iyle birlikte sunulur.
