# AI Bridge 0.1

Geliştirici/yayıncı: **Birkan Kader**. Güncellenme tarihi: 9 Eylül 2026.

AI Bridge; kalıcı yeni sekme düğmesi, Türkçe arayüz, düşük kaynak modu, görev/CPU/RAM paneli, arama, yer imleri, karar notları, görev şablonları, bağlam önizlemesi, zamanlanmış mesajlar ve otomatik devam içerir.

Model menüsündeki **Düşünme düzeyi** seçimi, modelin desteklediği seviyeleri gösterir. **Otomatik** seçeneği Claude'un varsayılanlarını kullanır. Tercih AI Bridge'in kendi proje ayarlarında saklanır ve açık yanıtı kesmeden sonraki mesajda uygulanır. Ayrıntılar ve doğrulama sınırları [EFFORT_VERIFICATION_TR.md](EFFORT_VERIFICATION_TR.md) içindedir.

**Limit sonrası otomatik devam** düğmesi artık ilk mesajdan önce de kullanılabilir. Seçim yeni sohbeti takip eder ve mevcut sohbet için yeniden yüklemede korunur. Kapatma bekleyen otomatik devamı iptal eder; başarısız gönderim rezervasyonu silmez. Ayrıntılar [AUTO_RESUME_FIX_TR.md](AUTO_RESUME_FIX_TR.md) içindedir.

**Windows başlangıcı:** Sekmeler aynı initialize sorgusunu paylaşır; kısa süreli katalog önbelleği kullanılır. Başlangıçtaki PowerShell taramaları birleştirildi, initialize temizliği backend’i bekletmeden yapılır ve Node doğrudan aranır. Ayrıntılar [WINDOWS_STARTUP_TR.md](WINDOWS_STARTUP_TR.md) içindedir.

**İlk mesaj yükü:** Kapalı MCP panelinin CLI ön yüklemesi kaldırıldı, açık panelin detay sorguları iki süreçle sınırlandırıldı. IntelliJ/JCEF tam panel çizimleri ortak kuyrukta sınırlandırıldı; log trafiği ekstra çizim başlatmaz. Akış verisinin günlüklerde tekrar kopyalanması azaltıldı, aynı oturumun paralel süreç başlatması ve devralınmış Bash başlangıç döngüsü engellendi. Gerçek Windows donmasının giderildiği henüz doğrulanmadı; kapsam [FIRST_SEND_FREEZE_TR.md](FIRST_SEND_FREEZE_TR.md) içindedir.

**Bağlam ve ardışık mesajlar:** Bağlam yüzdesi son ana model isteğinin giriş/önbellek tokenlarını tam model kapasitesiyle karşılaştırır. Dosya önizlemesi gönderilen yolları, olası sonraki dosya okumalarından ayırır. Yeni sohbette hızlı gönderimler aynı oturumu kullanır; başarısız gönderim sonrası seçili kod yeniden eklenir. CLI pipe hataları ve kapanmış süreçler için gönderim kontrolü güçlendirildi. Ayrıntılar ve doğrulama sınırları [CONTEXT_PROMPT_FIX_TR.md](CONTEXT_PROMPT_FIX_TR.md) içindedir.

**Kapatma sonrası kaynak kullanımı:** Kapatılmış sekmelerin süreçleri çıkana kadar izlenir; Windows temizleme komutları iki eşzamanlı işlemle sınırlanır. IDE kapanışı önce backend'e temizlik isteği gönderir. Geç gelen süreç/bağlantı başlangıçları ve kapanmış WebView'in yeniden bağlanması engellenir. Ayrıntılar ve gerçek Windows doğrulamasının sınırları [CLOSE_CPU_FIX_TR.md](CLOSE_CPU_FIX_TR.md) içindedir.

**İkinci tarama:** Parçalara bölünmüş CLI çıktısında Türkçe karakterlerin korunması, uzun satırların işlenmesi, sohbet geçişi/yeniden bağlanma, proje seçimi ve kapanışta kalan yardımcı işler yeniden incelendi. Güncel sonuçlar ve doğrulama sınırları [PERFORMANCE_RESCAN_TR.md](PERFORMANCE_RESCAN_TR.md) içindedir.

**Java analizini yeniden başlatan eklenti olayı:** Sohbet başlığı değişirken genel VFS dosya adı değişikliği bildirimi gönderiliyordu. IDEA 2026.1 bu olay üzerine tüm dosyaların analizini yeniden başlatıyordu; ilk arayüz yüklemesindeki başlık değişikliği de bu yolu çalıştırıyordu. Artık yalnız ilgili sekmenin sunumu yenilenir. Kapanmış veya taşınmış panellere ait eski bildirimler düşürülür. Java denetimleri ve analiz seviyeleri değiştirilmez. Kaynak düzeyindeki kanıt ve yeni paketin doğrulaması [INSPECTION_TRIGGER_FIX_TR.md](INSPECTION_TRIGGER_FIX_TR.md) içindedir.

Plugin ID: `com.birkankader.ai-bridge`. JetBrains paket adı karakter kısıtı nedeniyle **AI Bridge**, arayüz adı **AI Bridge**. Sürüm tüm bileşenlerde **0.1** olarak korunur.

Aynı sürümle güncellenmiş paket yeniden yüklendiğinde eski backend/arayüz dosyalarının kullanılmasını önlemek için kaynak önbelleği paket içeriğinin özetiyle ayrılır. Başka bir IDE'nin kullanabileceği eski önbellek dizinleri otomatik silinmez.

Ürün ekranları ve sürüm notları AI Bridge'e odaklanır. Devralınan kodun lisansı ve telif/kaynak bildirimleri `LICENSE` ve `COMMUNITY_NOTICE.md` içinde korunur; kaynak kodun sıfırdan yazıldığı iddia edilmez. Eşleşen kaynak ZIP kurulum ZIP'iyle birlikte sunulur.

Güncel test, üretim paketi ve IDE uyumluluk sonuçları [sekme olayı düzeltme raporunda](INSPECTION_TRIGGER_FIX_TR.md) kaydedilir. Kullanıcının IDE'sine kurulum veya Marketplace yayını yapılmadı.
