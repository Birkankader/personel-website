---
name: pr-checklist
description: >-
  Pre-PR review checklist for the claude-code-gui-jetbrains project. Verifies a
  change is ready to open a pull request against main — rebased onto the latest
  main, feature docs written for feature PRs, no marketplace-forbidden Internal/
  Deprecated JetBrains APIs, all three test layers passing, the project's core
  principles (CLI equivalence, original-data preservation, consistent naming)
  respected, and the lessons learned during the work recorded to memory.
  Use before opening or updating a PR. Trigger on: before opening a PR,
  pre-PR review, pre-contribution check, review my PR, pre-PR, is the PR ready?,
  open a PR, ready for PR, PR checklist, contribution check, PR öncesi kontrol.
---

> This document is written in English; if the user communicates in another language, read it and relay it translated into the user's language.

# pr-checklist — Review Before Opening a PR

Verifies, in order, the items a contributed change must pass before it is opened as a PR against `main`.
**[CONTRIBUTING.md](../../../CONTRIBUTING.md) is the single source for the body of the rules (why/what)**,
and this skill is the **procedure** that actually verifies those rules. See [CLAUDE.md](../../../CLAUDE.md) for the detailed rationale.

## Triggers

- When the user says things like "before opening a PR", "pre-PR review", "pre-contribution check", "review my PR", "is the PR ready?"
- Right before creating/updating a PR after finishing work on a branch

## Verification Procedure

Verify each item with actual commands and report pass/fail with evidence. For failed items, guide the user to fix them.

### 1. Rebase onto the Latest main (required)

A PR must be **rebased onto the latest commit of main**. Do not open a PR from an outdated base.

```bash
git fetch origin
git rebase origin/main
```

- If there are conflicts after the rebase, resolve them and run the 3-layer build/tests again.
- If the branch has already been pushed, point out that a force-push (`--force-with-lease`) is needed after the rebase.

### 2. Feature Docs for Feature PRs (required)

For a user-facing feature, write the feature document in English (`en.md`) in a `docs/features/NNN-feature_name/` folder,
and add one line to the `docs/features/CLAUDE.md` index. Follow that index document for the format.
Feature docs are English-only — do not add translated copies in other languages (e.g. `ko.md`).

```bash
ls docs/features/          # check the next number (NNN)
```

### 3. No Marketplace-Forbidden APIs (required)

JetBrains **Internal APIs** (`@ApiStatus.Internal`, classes inside `impl` packages) are **forbidden** —
the Marketplace Plugin Verifier flags them as errors and publication is rejected. Avoid **Deprecated APIs** too (they produce warnings).
If a native feature needs a risky API, work around it with reflection or a public alternative API.

```bash
# Static check (the same family of greps as the local precheck skill)
grep -rn "@ApiStatus.Internal\|StartupManager\|PluginManagerConfigurable" src/main/kotlin --include="*.kt"
```

### 3.5. Commit Subject of 72 Characters (required, on every commit)

**This item is enforced when committing, not right before the PR.** If you only discover it here, the commits have already been pushed,
so you have to rewrite the messages and force-push — and that rewrite has actually caused an incident before (the branch was reset onto
main and had to be restored from a backup). **Measuring before committing costs nothing.**

```bash
# Right before committing — measure only the subject
printf '%s' "<subject>" | wc -c

# Check commits that have already accumulated
git log origin/main..HEAD --format='%s' | awk '{ print length($0)" chars  "$0 }'
```

Locally, a `commit-msg` hook is installed that rejects the commit itself if the subject is 73 characters or longer
(`.git/hooks/commit-msg`, shared across all worktrees). **Hooks are not tracked, so a freshly cloned environment does not
have it** — in such an environment, check manually with the commands above. Hook installation:

```bash
ls .git/hooks/commit-msg 2>/dev/null || echo "No hook — if this is a fresh clone, create it yourself"
```

A subject usually gets too long because it **tries to fit two things into one line** (`A, and B`). In that case, do not shorten it —
**move the detail into the body or split the commit.**

### 4. 3-Layer Tests + lint + build Pass (required)

Unless stated otherwise, "tests" means **all 3 layers: WebView / Backend / Kotlin**.
All development follows TDD (test first → confirm it fails → implement).

```bash
bash ./scripts/build.sh wv-test
bash ./scripts/build.sh wv-lint
bash ./scripts/build.sh be-lint
bash ./scripts/build.sh full-build
```

### 5. Guaranteed Behavior Across OSes/Environments (Cross-Platform) (required)

Any code with even a slight chance of touching the OS must work safely on **all of Windows, macOS, and Linux**.
In particular, **Windows is not a single environment** — treat `cmd` / PowerShell / **WSL** / **WSL2** each as a separate shell,
and check any new external command against this all-environment checklist. Review from a pessimistic point of view.

- **Paths**: use `path.join()` instead of hardcoding `/`. Normalize case when comparing paths (Windows/APFS insensitive vs. Linux sensitive).
- **Shell commands**: avoid Unix-only commands (`which`, `chmod`, `kill`, POSIX pipes). **Avoiding shell tokenization** is an established pattern in this project.
- **Environment variables**: `HOME` (Unix) vs. `USERPROFILE`/`HOMEDIR` (Windows). Never use one on its own.
- **Line endings**: do not hardcode `\n`; account for Windows `\r\n`. Use `os.tmpdir()` for temporary directories, and watch out for executable extensions (`.sh` vs. `.cmd`/`.bat`).
- **Processes**: Unix signals (`SIGTERM`/`SIGKILL`) are not supported on Windows — branching is required.
- **WSL/WSL2**: watch out for **PATH asymmetry** when locating `claude`/`node`. Inherit `.bashrc` through a login shell (`bash -lic`) to obtain the PATH.

### 6. Adherence to the Project's Own Principles (required)

- **CLI equivalence & no dependency on the official SDK/internal protocols**: use official `claude` CLI commands as the baseline. Imitate only the UX of reference apps.
- **Original data preservation**: forward original structures such as JSONL entries to the WebView without editing or renaming them (range splitting is allowed).
- **Consistent naming**: the same verb for the same operation. IPC `type` uses the `MessageType` enum (no string literals).

### 7. PR Body / Commit Messages (required)

- Write the **PR body in English**. (Non-English bodies, e.g. Korean, are not allowed.)
- Commit messages are in English + conventional style (`fix:`, `feat:`, `refactor:`, `docs:`, `chore:` …). The 72-character limit on the first line is covered in **item 3.5** — if you first discover it here, it is already too late.
- The PR body clearly explains **what** was changed and **why**.
- If the change resolves an issue, **a closing keyword is required** — `Closes #N` / `Fixes #N`.
  A `(#N)` reference alone does not close the issue automatically. If it was left out before pushing, add it with `git commit --amend`.

### 7.1. Milestone Cross-Check (agents only)

> This item is **the maintainer's release-management procedure**. Assigning milestones requires write access to the repository,
> so external contributors cannot perform it and are not required to. The lookup/change commands are kept only in local operations docs.

If the PR resolves an issue, cross-check the PR against that issue's milestone.

- Confirm that **the issue number in the closing keyword matches the issue number recorded when the work was started**.
  If they differ, one of them is wrong, so report it to the user.
- If the resolved issue **has no milestone**, confirm whether to attach one now. Without a milestone, that issue is
  left out when the release notes are generated.
- If the attached milestone is **a version that has already been released, that is a wrong state.** Confirm whether to reassign it
  to the nearest milestone that has not been released yet. Whether it has been released is judged by **the release tag**, not by `state`.
- If the attached milestone **has not been released yet, leave it as it is even if it differs from the current patch.**
  It may have been deliberately deferred to the next minor, so do not change it on your own.

### 8. Record Lessons Learned to Memory (required, agents only)

> This item is **an agent's work discipline**. It is not a procedure required of external contributors, so
> it is not placed in CONTRIBUTING.md (the public contribution guide).

Before opening the PR, **summarize the points to remember and the lessons learned from this work and record them to memory.**
This item is repeated for every PR without exception.

**Why**: to avoid repeating the same investigation. In particular, "facts that can be used right away next time once checked"
(official schemas, API contracts, platform pitfalls, verification methods) have to be dug up again from scratch in the next session if they are not recorded.

**What to record** — record anything that falls under the following:
- **The basis for a judgment and how it was obtained**: what was used as the primary source and how it was retrieved (e.g. the URL of the original schema + the parsing command).
  In particular, **if you ran into an incorrect source of information, record that fact itself** — so you don't fall into the same trap next time.
- **Architecture decisions and their reasons**: why B and not A. Points where "why did we do it this way?" will come up later.
- **Pitfalls and counter-intuitive constraints**: circular dependencies, ordering that has to change because of a whitelist, platform-specific differences, etc.
- **What was left unresolved and its limits**: what could not be done and why, and under what conditions it becomes a problem.

**What not to record**: things that are immediately obvious from the code, git history, or CLAUDE.md (file structure, the code fixed
this time itself), and progress status that is meaningful only within this conversation.

**How to record**: if an existing memory covers the same topic, **update that file instead of creating a new one**
(to avoid duplication). Only when creating a new one, add one line to the `MEMORY.md` index.

## Reporting Results

Report each item in a PASS / FAIL table. If there is even one FAIL, advise not to open the PR and to fix it first.
If every item is PASS, finish with "Ready for PR".
