# PRD — JetBrains Claude Code GUI (Cursor-identical UX)

## 0. Purpose of this document

This document is the **Product Requirements Document (PRD)** for delivering, inside JetBrains IDEs, **an experience nearly identical to the UI/UX of Cursor's Claude Code extension**.

For any item that **is not clearly defined in this PRD or has several possible implementation choices**, the **behavior Cursor's Claude Code extension actually exhibits** is, as a rule, the primary reference.

* Principle: *When behavior, UX or structure conflict, priority is Cursor UX > JetBrains conventions*

---

## 1. Product goals

### 1.1 Primary goals (MVP)

* The **visual and interaction UX must be nearly identical** to Cursor's Claude Code extension
* The agent runtime must be **fully usable from inside the IDE**, without a terminal

### 1.2 Non-goals (out of scope for the first phase)

* UX improvements/differentiation relative to Cursor
* Active use of JetBrains-specific features (advanced diff UX, etc.)
* State synchronization across multiple IDEs

---

## 2. Core user scenarios

1. The user opens the Claude panel with a shortcut or from a menu
2. The user enters a request in the chat input
3. The agent outputs its response as a **stream**
4. When the agent proposes a file modification or command execution, the user chooses **Allow/Deny**
5. Proposed changes can be reviewed as a diff, then applied or reverted
6. Sessions are saved automatically and can be resumed at any time

---

## 3. Overall architecture overview

### 3.1 Layer separation principle

The product consists of the following three independent layers.

1. **IDE Plugin (Kotlin/JVM)**

* IDE API access and control
* WebView hosting and bridge
* Security/permission/file system integration

2. **WebView UI (JCEF, Web App)**

* Implements the same UI/UX as Cursor
* Chat, sessions, diff cards, input UX

3. **AI Bridge (separate process)**

* Runs agents such as Claude Code
* Stream parsing
* State machine (plan/execute/verify)

> Communication between layers and the separation of responsibilities are designed so that each layer can be replaced independently.

---

## 4. UI / UX requirements (Cursor-identical)

### 4.1 ToolWindow (main panel)

#### Composition

* Session list area
* Main conversation stream area
* Input composer at the bottom

#### Requirements

* All messages use **streaming rendering**
* Markdown + code block rendering
* Tool-call / Plan / Result are presented as card UI

> The concrete layout and component breakdown follow Cursor's screen composition.

---

### 4.2 Input composer

* Multi-line input
* Enter / Shift+Enter
* History navigation
* Slash command support (`/init`, `/review`, etc.)
* Context attachment UI (@file, selection)

---

### 4.3 Diff / change proposal UX

* When the agent proposes a file change:

    * Show a diff card inside the panel
    * Provide a per-file change summary
* The user can choose one of:

    * Open Diff (IDE diff viewer)
    * Apply
    * Reject

> The patch presentation and card UI follow Cursor's diff UX.

---

## 5. Context collection rules

### 5.1 Context types

* Selection
* Active File
* Open Files
* Explicit File (@file)

### 5.2 Priority

1. Explicit attachment (@file, drag)
2. Selection
3. Active file

> Whether context is injected automatically, and the scope-limiting policy, follow Cursor's behavior.

---

## 6. Permission and security policy

### 6.1 Permission types

* File write
* File delete
* Command execution
* Network access

### 6.2 UX principles

* Default: **user approval is always required**
* Approval requests are shown as Tool-call cards
* High-risk operations use IDE-native dialogs

> The permission memory (scope) policy uses the permission scopes provided by the Claude Code CLI as the primary reference.

---

## 7. Event / message protocol

### 7.1 Basic principles

* Event-driven
* Streaming-first
* Every request is traceable by request_id

> Event types and payload structures are designed to be compatible with the original structures streamed by the Claude Code CLI.

---

## 8. Session and state management

### 8.1 Sessions

* Per-project session storage
* Automatic saving
* Sessions can be resumed

### 8.2 State machine

* Idle
* Streaming
* Waiting Permission
* Has Diff
* Error

> State transition rules are based on the actual behavior of Cursor's Claude Code.

---

## 9. Diff / patch application policy

* Change proposals are managed per patch
* On Apply, changes are written to the IDE file system
* On Reject, changes are discarded
* Undo must be possible

> The patch format (unified diff vs file edits) follows the edit format proposed by the Claude Code CLI.

---

## 10. Technical constraints and decision principles

* The WebView uses JCEF
* Swing-based UI is not used (exception: permission dialogs)
* The agent runtime is separated into a process outside the IDE

---

## 11. Milestones

### M1 — Basic conversation

* ToolWindow + WebView
* Streaming responses

### M2 — Context

* Selection / file attachment
* Session saving

### M3 — Change proposals

* Diff cards
* Apply / Reject

### M4 — Agent completeness

* Permission flow
* Stop / Retry / Continue

---

## 12. Principle for undecided items (important)

The following items, which are not specified in this PRD:

* IPC mechanism
* Bridge internal structure
* WebView state management approach
* Error/recovery strategy

👉 are **decided using Cursor's actual behavior and the Claude Code CLI's official interface as the primary reference**.

---

## 13. Success criteria

* Users of Cursor's Claude Code can use it without any UX explanation
* The same tasks can be completed without using a terminal
* No IDE freezes/crashes while the agent is working

---

## 14. Future extensions (out of scope)

* Active use of JetBrains diff UX
* Multi-agent
* Remote runtime
* Team session sharing
