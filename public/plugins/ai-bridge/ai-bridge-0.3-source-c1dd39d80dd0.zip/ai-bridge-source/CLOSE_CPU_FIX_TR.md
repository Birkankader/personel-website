# Kapatma sonrası kaynak kullanımı — 0.1

9 Eylül 2026. İncelenen geri bildirim: eklenti kullanılıp kapatıldıktan sonra CPU kullanımının yükselmesi. Bildirilen ortam Windows, IntelliJ IDEA 2026.1. Kapatılanın sekme/panel mi, tüm IDE mi olduğu ve son paketin kurulu olup olmadığı henüz netleşmedi; iki kapanış yolu da incelendi.

Kullanıcının bilgisayarındaki CPU artışının kesin nedeni veya ne kadar azaldığı ölçülmedi. Aşağıdaki hatalar kodda ve kontrollü testlerde doğrulandı.

## Değişiklikler

- **Süreç sahipliği:** Kapatılan sekmenin veya backend'in oturum kayıtları silinse bile başlatılmış CLI süreçleri gerçek `close` olayına kadar takip edilir. Önceki kod kayıtları önce sildiğinden, kapanış beklemesi ve son çare temizliği bu süreçleri göremiyordu.
- **Görev kuyruğu:** Sekme kapandıktan sonra gelen süreç çıkışı, yalnızca o sürecin görev yuvasını serbest bırakır. Gecikmiş eski çıkış yeni görevi silemez. Backend kapanırken bekleyen görevler başlatılmaz.
- **Windows temizliği:** Olağan kapatma yolunda senkron `taskkill` yerine beklenebilir asenkron işlem kullanılır. Aynı süreç için yinelenen istekler birleşir; aynı anda en fazla iki temizleme komutu çalışır. Komutlar süreyle sınırlıdır, sırada beklerken çıkmış süreçlerin PID'leri tekrar hedeflenmez. JS `exit` kancası için senkron son çare temizliği korunur.
- **IDE kapanışı:** Windows'ta Java `Process.destroy()` doğrudan `TerminateProcess` kullanır; Node'un JS kapanış kodunu çalıştırması garanti değildir. IDE önce kimlik doğrulanan `/rpc` kanalından `SHUTDOWN_BACKEND` gönderir. Mesajın gönderilmesi ve backend'in kendi çıkışı ortak 3,5 saniyelik süreyi paylaşır; kontrol kanalı bu sırada açık tutulur. [OpenJDK Windows uygulaması](https://github.com/openjdk/jdk21u/blob/master/src/java.base/windows/native/libjava/ProcessImpl_md.c#L431)
- **Zorla kapatma koruması:** RPC kullanılamazsa veya süre dolarsa, Windows tarafı ana süreç hâlâ canlıyken yalnızca eklentinin sahip olduğu backend PID'sini `taskkill.exe /PID … /T /F` ile hedefler. Bu tek denemenin ek bekleme sınırı 1,5 saniyedir. Temiz RPC çıkışında çalışmaz; başarısız olursa mevcut doğrudan sonlandırma uygulanır. [Microsoft taskkill belgesi](https://learn.microsoft.com/en-us/windows-server/administration/windows-commands/taskkill)
- **Geç tamamlanan başlangıçlar:** Kapatma sırasında tamamlanan süreç veya RPC bağlantısı yeniden sahiplenilmez. İlgili coroutine, bağlantı ve yeniden bağlanma işleri iptal edilir. Boşta kapanış da aynı, yalnızca bir kez çalışan backend temizlik yolundan geçer.
- **WebView kapanışı:** Bağlantı beklemek için her isteğin açtığı 50 ms sorgulama zamanlayıcıları kaldırıldı. Kalıcı sayfa kapanışında bekleyen istekler, yeniden bağlanma zamanlayıcıları ve log aktarımı temizlenir. Eski socket olayları kapatılmış bağlantıyı yeniden açamaz.

Sekme bağlantısı kaybı için mevcut 30 saniyelik geri bağlanma süresi korunur. Son istemci çıktıktan sonraki backend boşta kapanış süresi 60 saniyedir; açık tutma ayarı bu davranışı etkiler. Bir paneli yalnızca gizlemek, tüm eklentiyi veya çalışan görevi kapatmakla aynı işlem değildir.

## Doğrulama

| Kontrol | Sonuç |
|---|---|
| Backend tam test paketi | 179 dosya; 2.026 başarılı, mevcut 8 atlanan |
| WebView tam test paketi | 342 dosya; 3.370 başarılı |
| Backend / WebView TypeScript kontrolleri | Başarılı |
| Gerçek POSIX süreç ağacı testleri | 6 başarılı |
| Gerçek backend ve RPC protokolü | İki aktif CLI + iki alt süreç kapandı; üçüncü kuyruk mesajı başlamadı |
| Yinelenen kapanış bildirimi | İki bildirim için tek `host-shutdown` günlüğü; backend kod 0 ile çıktı |
| Kanal sınırı | Olağan sohbet `/ws` isteği backend'i kapatmadı |
| Native kapanış / Windows komut testleri | 39 native ve 26 backend Windows sonlandırma testi başarılı |
| Üretim paketi / Plugin Verifier | Başarılı; IC 242.26775.15 ve IU 262.8117.19: Compatible |

İzole RPC koşusunda backend 11 ms'de çıktı; tüm dört alt süreç ve test portu temizlendi. Bir saniyelik takipte yeniden başlatma görülmedi. Bu süre Windows performans tahmini değildir. Kanıt: `../validation/close-lifecycle/rpc-shutdown/`.

Önce/sonra regresyonları kaydı erken silinen süreçlerin beklenmemesini, sekme kapanışından sonra görev yuvasının dolu kalmasını ve kapanan WebView'de zamanlayıcı/bağlantı kalmasını üretti. Yeni native testler geç gelen başlangıç, RPC mesajının gönderimini bekleme, temiz çıkış ve zaman aşımı senaryolarını kapsar.

Gerçek süreç testleri macOS üzerinde izole sahte CLI ile yapılır; gerçek Claude hesabına/sağlayıcısına istek gönderilmez. Windows sonlandırma komutları ve native süreç davranışı kontrollü taklitlerle sınanır. Bunlar Windows IntelliJ IDEA 2026.1 üzerinde CPU ölçümü yerine geçmez. RPC erişilemediğinde veya kapanış süresi dolduğunda zorla sonlandırma yolu devreye girer; bu yolun gerçek Windows süreç ağacındaki etkisi henüz ölçülmedi.

Verifier mevcut iki deneysel `FileEditorManager.requestOpenFile` kullanımı için uyarı verdi; uyumluluk hatası vermedi. `git diff --check` başarılı.

## Paket

Kurulum ZIP SHA-256: `04b23afa41d8f342f573db069da15f38881d37587cb9cec1632fc91ee43427dd`.

Paket içerik sürümü (`bundleRevision`): `ae2d7f3d42f48c240b5228c68adfdb149309fbc54e358a60a16af2a68afc08b7`. Sürüm/yayıncı: **0.1 / Birkan Kader**. Aynı sürüm yeniden kurulduğunda backend/arayüz önbelleği yeni içerik özetiyle ayrılır.

Kurulum: IntelliJ'de **Settings → Plugins → dişli → Install Plugin from Disk…** yolundan güncel `AI-Bridge-0.1.zip` seçilip IDE yeniden başlatılır. Eşleşen kaynak kod `AI-Bridge-0.1-Source.zip` içindedir.

Önceki bağlam/mesaj paketi `../output/archive/0.1-context-prompt/` altında korundu. Loglar `../validation/close-lifecycle/`, native ve hedefli Windows kontrolleri ayrıca `../validation/` altında bulunur. IDE'ye kurulum veya Marketplace yayını yapılmadı.
