# AI Bridge 0.1 — kendi kimliğine tam geçiş

16 Ekim 2026. Temel: 0.39 kaynağı ve 16 Ekim değişiklikleri (bkz. `HARNESS_AND_FEEDBACK_TR.md`).

## Ne değişti

AI Bridge artık önceki adın hiçbir izini taşımıyor. Sürüm numaraları 0.1'den yeniden başlıyor.

| | Önce (0.39) | Şimdi (0.1) |
|---|---|---|
| Plugin ID | eski ID | `com.birkankader.ai-bridge` |
| Kotlin paketi | eski paket | `com.birkankader.aibridge` |
| Paket dosyası | eski ad | `ai-bridge-0.1.zip`, kaynak `ai-bridge-0.1-source.zip` |
| Ayar dizini | eski dizin | `~/.ai-bridge`, proje içinde `.ai-bridge/` |
| Ortam değişkenleri | eski önek | `AI_BRIDGE_*` |
| Araç pencereleri, eylemler, durum çubuğu | eski önek | `AiBridge.*` |
| Sohbet sekmesi adresi | eski şema | `ai-bridge-chat://` |
| Kimlik doğrulama | eski adlar | `ai-bridge-auth` alt protokolü, `x-ai-bridge-token` başlığı |
| Arayüz çeviri ad alanı | eski ad | `aibridge` |
| Terminal başlatıcısı | eski komut | `ai-bridge` |
| Güncelleme deposu | eski klasör | `https://birkankader.com/plugins/ai-bridge/updatePlugins.xml` |

Değişiklik 398 dosyada mekanik bir yeniden adlandırma ve 167 dosya/klasör taşımasıdır. Eski ad kodda yalnız tek bir yerde kalır: `backend/src/core/features/legacy-data.ts`. Bu dosya önceki kurulumun verisini bulmak için eski dizin adını bilmek zorunda.

## Mevcut kullanıcılar

- **Yerinde güncelleme yok.** Plugin ID değiştiği için 0.39 ve önceki sürümler AI Bridge 0.1'e güncellenmez. Kullanıcı AI Bridge'i yeni depodan (veya ZIP'ten) kurmalı, ardından eski eklentiyi kaldırmalıdır. İkisi birlikte kurulu kalırsa iki ayrı panel, iki backend ve çakışan kısayollar olur.
- **Veri taşıma.** İlk açılışta backend, eski ayar dizininden `~/.ai-bridge` içinde henüz olmayan her şeyi bir kez kopyalar: ayarlar, kayıtlı hesaplar, harness sohbetleri, sabitlenmiş projeler, zamanlanmış mesajlar, notlar. Kopyalanmayanlar: günlükler, süreç kaydı (`cli-registry`; kopyalansa yeni backend eski eklentinin süreçlerini sahiplenirdi), önbellekler, `mcp/` (eski eklentinin dosyalarını gösterir), `bin/`, `runtimes/` ve kurulum başına üretilen `auth-secret`. İşlem bittiğinde `~/.ai-bridge/.legacy-data-imported` yazılır; silinen bir dosya sonraki açılışta geri gelmez. Eski dosyalara dokunulmaz.
- Proje içindeki eski ayar dosyası ve Claude oturum klasöründeki özel sohbet adları, ilk okunduklarında yeni adlarıyla kopyalanır.

## Doğrulama (Windows 11, bu makine)

| Kontrol | Sonuç |
|---|---|
| Backend / WebView TypeScript | temiz |
| Backend testleri | 196 dosya: 2.190 geçti, 38 atlandı, 9 başarısız. 9'unun hepsi değişmemiş temel kopyada da aynı şekilde başarısız (Windows ortamı: sembolik bağlantı, dosya izleyici zamanlaması, job-object önbelleği, okuma bütçesi). |
| Yeni veri taşıma testleri | 5/5 |
| WebView testleri | 358 dosya, 3.486 geçti |
| Kotlin testleri (JDK 17) | 99 dosya, 492 geçti, 7 atlandı. 16 Ekim Kotlin değişiklikleri ilk kez derlendi. |
| CLI (bats) | 269/269 |
| Güncelleme deposu testleri | 8/8 |
| Plugin Verifier 1.410 | IC 2023.1, Rider 2025.1.2, IntelliJ IDEA 2026.2.2: üçü de Compatible. 2023.1'de 0.34'ten beri bilinen tek deprecated kullanım (`com.intellij.util.Consumer`). |
| Paket içeriği | ID `com.birkankader.ai-bridge`, sürüm `0.1`, since-build 231. Eski adın tek geçişi taşıma sabitleri. |

Yeniden adlandırmada ASCII'ye dönüşen Türkçe karakterli test örnekleri, kapsam korunsun diye `Köprü` ile değiştirildi.

## Derleme notları (Windows)

- Gradle `jvmToolchain(17)` ister. Bu makinede JDK 17 yoktu; Eclipse Temurin 17.0.20.1 geçici bir klasöre indirilip (SHA-256 doğrulandı) `-Porg.gradle.java.installations.paths` ile verildi.
- Gradle'ın `pnpm` görevleri Windows'ta `pnpm` komutunu başlatamıyor (yalnız `pnpm.cmd` var). Backend ve WebView `scripts/build.sh` ile (`BUILD_ENV=production`) derlendi, Gradle bu görevler atlanarak çalıştırıldı.
- `verify-plugin` görev matrisi indirilemeyen 2026.2 EAP sürümünü içerdiği için Plugin Verifier CLI ile yerel IDE'lere karşı çalıştırıldı.

## Bilinen sınırlar

- Gerçek bir IDE içinde kurulup açılmadı; veri taşıma birim testleriyle ve gerçek dosya sistemiyle doğrulandı.
- macOS ve Linux'ta derlenmedi.
- Bu çalışmadaki eski tarihli notlar (`RELEASE_*`, `*_FIX_TR.md` vb.) da yeni adlarla güncellendi; geçmiş sürümleri anlatan cümleler artık AI Bridge adını kullanır.
