# Performans ve mesaj iletimi: ikinci tarama — 0.1

9 Eylül 2026. Kapsam: Windows başlangıcı ve ilk mesaj, kapatma sonrası CPU, bağlamın hızlı dolması ve ardışık mesajların kaybolması. Önceki kapanış düzeltmeleri başlangıç kabul edildi; süreç sahipliği, Kotlin/JCEF işleri, React sohbet geçişleri ve CLI çıktı okuyucusu yeniden incelendi.

Bu çalışma kullanıcının Windows IntelliJ IDEA 2026.1 ortamında CPU ölçümü değildir. Doğrulama macOS, kontrollü süreçler ve test doubles ile yapılır; gerçek Claude hesabına istek gönderilmez. Aynı 0.1 sürümü korunur.

## Yeni Windows kanıtı

Kullanıcı, önceki en son 0.1 ZIP'ini kurup IDE'yi yeniden başlattığını doğruladı. Yalnız eklentiyi açıp gönderilmemiş `selam` yazıldığında ekran görüntüsünde ana IntelliJ süreci %55,8 CPU / 3.974 MB, IntelliJ grubu %57,8 CPU, Node %0, iki Claude süreci %0,5 ve %0,9 gösteriyor. Makinenin toplamı %100; tamamı IntelliJ grubuna atfedilemez.

Bu görüntü, bu andaki yükün ağırlıkla ana IDE/JVM tarafında olduğunu gösterir. Mesaj iletimi veya CLI çıktı okuyucusu düzeltmeleri bu anlık yükün açıklaması olarak sunulmaz. Tuş başına native bildirim döngüsü saptanmadı; özel OSR yeniden çizim istekleri önceki kodda tek bekleyen iş ve 250 ms sınırı kullanıyor, boşta yedek tetikleme 2,5 saniyede bir. Bunların CPU payı gerçek thread/profil verisi olmadan belirlenemez. Ekrandaki sorunun giderildiği henüz doğrulanmadı.

Kullanıcının Activity Monitor değerleri: `progress` %255,4; `Plugin Java: psi.controlFlow` %160,2; `JobScheduler FJ pool` %92,1; `psi` %89; `JIT compiler` %86,7. Bu alt sistem toplamları Görev Yöneticisi yüzdeleriyle toplanmaz. Java PSI/kod analizi ve JVM derlemesi öne çıkıyor; analizi başlatan çağrı veya eklenti bu satırlardan belirlenemez.

Gönderim öncesi çağrılar kaynakta izlendi: chat dosyası yalnız özel `ClaudeCodeVirtualFile`/dosya tipini kullanıyor, Java dosyası olarak açılmıyor. Başlangıçtaki proje yolu ve geçmiş sorguları PSI taraması başlatmıyor; `@` araması Node tarafında ve düz `selam` ile çalışmıyor. Tek backend `REFRESH_FILES` göndericisi tamamlanan dosya düzenleme aracından geliyor. Seçim aktarımında PSI çözümleme, indeks veya analiz API'si yok. Bu negatif kaynak bulguları eklentinin etkisini kesin olarak dışlamaz.

**Açık teşhis adımı:** mevcut kurulu pakette Help → Diagnostic Tools → Start CPU Usage Profiling; paneli açıp `selam` yazma sırasında yaklaşık 20–30 saniye kayıt; Stop CPU Usage Profiling ile oluşan ZIP. CPU profilindeki gerçek çağrı yığını, Java analizinin hangi koddan tetiklendiğini gösterecek. Menü kullanılamayacak kadar donuyorsa thread dump gerekir. Bu profil henüz alınmadı. [Activity Monitor](https://www.jetbrains.com/help/idea/activity-monitor.html), [performans verisi toplama](https://intellij-support.jetbrains.com/hc/en-us/articles/207241235-Reporting-performance-problems).

## Yeni bulgular ve uygulama

- **Yardımcı süreçlerin kapanışı:** Sohbet CLI'larının yanı sıra yapılandırma, MCP, auth ve yol bulma için başlatılan Claude yardımcıları da backend sahipliğine kaydedilir. Kapanmış backend yeni yardımcı başlatamaz. Aynı anda ikinci login başladığında önceki login ağacı sonlandırılır.
- **İptal edilen MCP işleri:** İstek sahibinin bağlantısı kapanınca bekleyen liste/detay işleri iptal edilir. Windows timeout/iptalinde önce shell'i öldürmek yerine süreç ağacı temizliği başlatılır; işin eşzamanlılık yuvası sınırlandırılmış temizlik ve çıktı kapanışı beklenmeden bırakılmaz. Kontrollü hızlı kapat/aç testinde en fazla iki detay süreci doğrulandı. İşletim sistemi sonlandırmayı reddederse mutlak canlı süreç sınırı garanti edilmez.
- **Docker sahiplik çakışması:** Aynı backend'de örtüşen veya yapılandırması hâlâ okunmakta olan CLI pencereleri belirsiz kabul edilir. Başka oturuma ait olabilecek kapsayıcı silinmez ve gelecekte silmek için sahiplik kaydı oluşturulmaz. Tekil temizlik korunur. Belirsiz kapsayıcılar çalışmaya devam edebilir; başka backend/elle başlatılan aynı Docker komutları ve eski registry kayıtları için bu değişiklik kesin sahiplik kanıtı sağlamaz.
- **IDE seçim aktarımı:** Global editör dinleyicisi yalnız ilgili projeyi işler. Debounce ve ağ işleri proje servisinin ömrüne bağlandı; tek aktif gönderim ve yalnız en yeni bekleyen seçim tutulur. Başlangıç bitince tüketici tekrar kontrol edilir; kapanmış proje veya tüketicisi kalmamış panel için birikmiş işler gönderilmez. Aynı satırlardaki değişmiş metin artık yanlış dedup ile kaybolmaz. HTTP çağrısı kendi kısa timeout'una kadar sürebilir.
- **Retry düğmesi:** Backend yeniden başlatma/temizlik işi UI thread'inden I/O dispatcher'a taşındı. Hızlı tekrar tıklamalar tek işe birleşir; kapanmış panelde yeni retry başlamaz.
- **Sohbete dönüş ve yeniden bağlantı:** Yeni oluşturulan sohbet etiketi önceki kodda ömür boyu geçmiş yüklemesini atlatıyordu. A → B → A ve yeniden bağlantıda geçmiş ile backend aboneliği şimdi yeniden yüklenir; önceki sohbetin mesajları yanlış oturumda kalmaz. İlk gönderimin iyimser görünümü korunur.
- **Bağlantı hatası:** Üretimde bağlantı yokken sahte cevap yazan test zamanlayıcısı kaldırıldı. Reddedilen gönderim görünür hata ile sonlanır; geciken hata farklı bir sohbete uygulanmaz. Gönderim kabulünden önce composer'ı temizleyen mevcut davranış bu taramada değiştirilmedi.

Native `execFile` maxBuffer taşmasının işletim sistemi alt süreç davranışı bu değişikliğin kapsamı dışında kaldı; timeout ve AbortSignal yolları yönetilen temizliğe alındı.

## CLI çıktı akışı

`backend/src/core/claude-process.ts` her stdout parçasını tek başına UTF-8 metne çeviriyordu. Türkçe karakter veya emoji birden fazla parçaya bölündüğünde karakterler bozuluyordu. İki regresyon testi bunu önceki kodda üretti; yeni süreç başına okuyucu bu karakterleri ve bilinmeyen CLI alanlarını koruyor. Son satırın satır sonu olmadan kapanması da sınandı.

Aynı yol, tamamlanmamış uzun satırı her yeni parçada yeniden tarıyordu. `CliJsonlReader` sadece yeni parçayı tarar; satır tamamlandığında bir kez birleştirir. Satırlar veya CLI alanları boyut nedeniyle kesilmez. Bekleyen ham verinin belleği satırın gerçek boyutuyla büyüyebilir; bu değişiklik satır boyutunu sınırlayan bir filtre değildir. [Node StringDecoder belgesi](https://nodejs.org/api/string_decoder.html)

Yalnız satır ayırma ölçümü; 4 KiB parçalar, beş koşunun medyanı, macOS Node 26.8.1:

| Tek satır boyutu | Önce | Sonra |
|---|---:|---:|
| 512 KiB | 1,344 ms | 0,106 ms |
| 2 MiB | 36,193 ms | 0,440 ms |
| 4 MiB | 149,649 ms | 0,760 ms |

Her iki okuyucunun çıktısı birebir karşılaştırıldı. Bu ölçüm JSON işleme, arayüz çizimi veya Windows toplam CPU kullanımı için hızlanma iddiası değildir. Kanıt: `../validation/performance-rescan/stream-benchmark.json`.

## Kontroller

| Kontrol | Sonuç |
|---|---|
| Backend tam test paketi | 182 dosya; 2.043 başarılı, mevcut 8 atlanan |
| WebView tam test paketi | 343 dosya; 3.377 başarılı |
| Native seçim/Retry ve mevcut kapanış regresyonları | 57 başarılı |
| Backend/WebView TypeScript kontrolleri | Başarılı |
| Unicode akış regresyonu | Önce iki hata; sonra 5 dosyada 95 başarılı |
| Yardımcı sahipliği/MCP/login odaklı koşu | 9 dosyada 92 başarılı |
| Sohbet dönüşü/çevrimdışı/hata odaklı koşu | 136 başarılı; önceki kodda toplam 9 regresyon hatası |
| Üretim paketi ve Plugin Verifier | Başarılı; IC 242.26775.15 ve IU 262.8117.19: Compatible |

Odaklı JS test sayıları tam paketlerin alt kümesidir; toplam başarı sayısına ikinci kez eklenmez. Native seçim/Retry regresyonları önceki kodda 5 hata üretti. Testler gerçek Windows IntelliJ CPU ölçümü yerine geçmez; gerçek Claude sağlayıcısına istek gönderilmedi.

## Paket

Kurulum ZIP: `AI-Bridge-0.1.zip`; 8,707,146 bayt.

SHA-256: `20af3f6b513db11e769d7d1d7e63f627aa58111a1b7fad5143c6d06cec583e66`.

Paket içerik sürümü (`bundleRevision`): `8cc3430d387f010ffad30f01ceac49cb07a8ac3879fb97dbf6386c05c3a54083`.

Paket kimliği/adı/yayıncısı **com.birkankader.ai-bridge / AI Bridge / Birkan Kader**, sürüm **0.1** olarak kontrol edildi. ZIP CRC, gömülü backend/arayüz dosyalarının üretim çıktılarıyla birebir eşleşmesi ve içerik özeti doğrulandı. Lisans ve topluluk bildirimi korunuyor. Eşleşen kaynak ZIP ayrıca üretilir ve çalışma ağacına karşı dosya bazında doğrulanır; iki ZIP'in özetleri `../output/AI_BRIDGE_0.1_SHA256SUMS.txt` içindedir.

Plugin Verifier iki hedefte uyumluluk hatası vermedi. Önceden mevcut iki deneysel `FileEditorManager.requestOpenFile` kullanımı için uyarı sürüyor. Bu statik kontrol, Windows IntelliJ IDEA 2026.1'de CPU sorununun giderildiğini kanıtlamaz.

Güncelleme için Settings → Plugins → dişli → Install Plugin from Disk… ile kurulum ZIP'i seçilir ve IDE yeniden başlatılır. **Mevcut yüksek CPU teşhisi için yeniden kurulum gerekli değildir; önce şu anki kurulu paketten CPU profili alınabilir.**

Önceki paket `../output/archive/0.1-close-lifecycle/` altında korundu. Test ve ölçüm kayıtları `../validation/performance-rescan/` altındadır. Kullanıcının IDE'sine kurulum veya Marketplace yayını yapılmadı.
