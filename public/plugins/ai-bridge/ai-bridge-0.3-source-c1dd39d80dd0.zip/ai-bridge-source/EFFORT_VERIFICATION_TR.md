# Düşünme düzeyi — AI Bridge 0.1

## Kullanım

Mesaj kutusundaki **model adına** tıklayın; model menüsündeki **Düşünme düzeyi** bölümünden seçim yapın. Yalnızca seçili modelin CLI tarafından bildirilen seviyeleri gösterilir. Türkçe etiketler: Düşük, Orta, Yüksek, Çok yüksek ve En yüksek (`max`). Her modelin tüm seviyeleri desteklemesi beklenmez.

**Otomatik**, Claude'un ayarlarında/ortamında tanımlanan varsayılanları kullanır. Seçim mevcut proje için kaydedilir; proje yoksa genel AI Bridge ayarı kullanılır. Seviye değişiklikleri **sonraki mesajda uygulanır**, devam eden yanıtı kesmez. Kayıt başarısızsa kontrol hata gösterir.

## Düzeltilen aktarım

Önceki kontrol `effortLevel` değerini Claude ayar dosyasına yazıyordu. Kurulu Claude Code 2.1.220, `max` değerini `--effort` bayrağında kabul ederken kalıcı `effortLevel` şemasında kabul etmiyor. Ayrıca açık CLI sürecinin düşünme değeri bu dosya değişikliğinden sonra yenilenmiyordu.

AI Bridge tercihi artık kendi `reasoningEffort` ayarında tutulur. Açık bir seviye seçilirse CLI'ye `--effort` ve aynı değerde çocuk süreç ortam değişkeni iletilir. Bu, devralınan `CLAUDE_CODE_EFFORT_LEVEL` değerinin kullanıcı seçimini gölgelemesini önler. Otomatikte bu özel geçersiz kılma kaldırılır.

Sonraki mesaj sırasında uygulanacak ayar değişmişse mevcut sohbet `--resume` ile yeni CLI sürecinde devam eder; aynı ayarda süreç yeniden kullanılır. Görev şablonları da aynı tercihi kullanır. Proje ayarı bildirimleri başka projenin görünen düzeyini değiştirmemelidir.

## Doğrulama

- Kurulu **Claude Code 2.1.220**: `low`, `medium`, `high`, `xhigh`, `max` değerleri initialize-only kontrolünde uyarısız kabul edildi. CLI'nin kendi model listesi bu yetenekleri doğruladı; Haiku düşünme düzeyi yeteneği bildirmedi. Ağ, kimlik doğrulama ve model üretimi yapılmadı. Geçersiz değer için CLI'nin varsayılana döndüğünü söyleyen uyarısı da negatif kontrol olarak kaydedildi.
- Backend: **168 dosyada 1948 test geçti, 8 mevcut test atlandı**; lint temiz. Gerçek geçici ayar dosyaları ve gerçek mesaj/kuyruk/süreç yönetimi ile CLI çocuğu izole test nesnesi olarak kullanıldı. Açık `max`, ortam önceliği, aktif yanıtı kesmeme, sonraki tek mesajda `--resume`, aynı ayarda süreç kullanımı, Otomatik'e dönüş ve hata durumları kapsandı.
- WebView tam takım: **335 dosyada 3277 test geçti**; ek çoklu ayar geri alma kontrollerinde **23 test geçti**. Yeni kontrollerin proje/global kapsamı, Otomatik, Türkçe etiketler, desteklenmeyen model, kayıt hatası ve yinelenen seçim davranışı doğrulandı. Lint temiz.
- Native: **31/31 test geçti**. Aynı `0.1` sürümünün yeni içeriği farklı önbellek anahtarı kullanır; aynı içerik yeniden çıkarılmaz ve eski IDE kaynakları korunur. Paket özeti derleme sırasında üretilir, IDE arayüz iş parçacığında hesaplanmaz.
- Gerçek tarayıcı + yerel backend + kontrollü CLI fixture: **max → high → auto** seçimleri proje dosyasından CLI argv/env değerlerine kadar izlendi; aynı sohbetin sürdürülmesi, her gönderimde tek mesaj, yenileme sonrası kalıcılık ve farklı projenin genel `low` değerini koruması geçti. Sağlayıcının `effortLevel: medium` değeri değişmedi.
- Son gönderim kilidi: **3 dosyada 32 hedef test geçti**. Gerçek ChatInput/RichInput/SettingsProvider ile geciktirilmiş SAVE_SETTINGS sırasında Enter ve gönder düğmesi SEND üretmedi; ACK sonrası seçilen düzeyle tek mesaj gönderildi. Hata durumunda önceki düzey ve taslak korundu, görünür hata sunuldu. Son lint temiz.
- Nihai `0.1` üretim paketi başarıyla derlendi. Plugin Verifier, **IC 242.26775.15** ve **IU 262.8117.19** için **Compatible** sonucu verdi. Mevcut iki `requestOpenFile` deneysel API kullanımı uyarı olarak kalıyor; IC ortamında isteğe bağlı JCEF modülü doğrulanmadı. Bu kontrol gerçek IDE içinde çalıştırma testi değildir.
- Kurulum ZIP/JAR kimliği, yayıncı, sürüm, paketlenen backend, lisans bildirimleri ve içerik özeti kontrol edildi. JAR'daki tüm backend/arayüz kaynaklarından yeniden hesaplanan SHA-256, `bundleRevision` ile eşleşti. Son arayüz değişikliğinde sürüm `0.1` kalırken bu özet değişti; böylece eski `0.1` kaynak önbelleği yeni paket için kullanılamaz.

Gerçek sağlayıcıya ücretli/model isteği göndermek bu doğrulamanın parçası değildir. Bir modelin içeride ne kadar düşündüğünü ölçmüyoruz; ayarın desteklenmesi, kaydı ve doğru sürece aktarılması doğrulanır.

## Resmi kaynaklar

- [Model yapılandırması ve düşünme düzeyi](https://code.claude.com/docs/en/model-config)
- [effortLevel ayar başvurusu](https://code.claude.com/docs/en/settings-reference)
- [CLI ortam değişkenleri](https://code.claude.com/docs/en/env-vars)

Güncel belgeler 8 Eylül 2026'da Context7 üzerinden kontrol edildi. Kullanılabilir seçenekler bu belgeye sabitlenmez; çalışma anında CLI'nin model bilgileri kullanılır.
