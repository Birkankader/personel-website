# Swttch 0.30.1 performans ve topluluk sürümü

Başlangıç: 8 Eylül 2026. Kaynak: https://github.com/Swttch/swttch,
`v0.30.1`, commit `8c4264187610b6a1aace281d88e34d09ac28c4d7`.
Orijinal `../swttch-0.30.1.zip` ve açılmış paket korunur.

## İnceleme kapsamı

Kotlin/JetBrains kaynak yaşam döngüsü ve süreçler; Node.js eşzamanlılık,
dosya/ağ erişimi, önbellek, hata yönetimi ve veri yapıları; React çizim,
abonelik, zamanlayıcı, bellek ve günlükleme; derleme ve bağımlılıklar.
SQL/veritabanı optimizasyonu bu yerel dosya tabanlı mimariye uygulanmıyor.
Kod taramasıyla bulunan maliyetler gerçek kullanıcı makinesinde CPU profili
alınmış bulgular olarak sunulmaz.

## Öncelikli bulgular ve uygulama sırası

1. **Yüksek — boşta sürekli ekran ölçümü.** `webview/src/pages/ChatPage/index.tsx`
   her animation frame'de kaydırma geometrisini ölçüyor. Kaydırma, içerik/boyut
   değişimi ve görünürlük olaylarında tek frame planlanacak; geçmiş yükleme,
   alta kaydırma ve kullanıcı kaydırma niyeti korunacak.
2. **Yüksek — büyüyen çıktının tamamını yeniden okuma.**
   `backend/src/core/features/loadBackgroundTaskOutput.ts` yalnız son 200.000
   karakteri göndermek için tüm dosyayı okuyor. UTF-8 sınırlarını koruyan
   sınırlı kuyruk okuması uygulanacak; dosya erişim kontrolleri korunacak.
3. **Yüksek — etkisiz süreç zaman aşımı.** Kotlin shell/CLI/port sorgularında
   `readText()` çağrısı süreli `waitFor()` öncesinde bloklanabiliyor.
   Çıktısı ve toplam bekleme süresi sınırlı ortak süreç çalıştırıcısı
   uygulanacak; süreç ve okuyucu kaynakları her sonuçta kapatılacak.
4. **Orta — tekrarlanan oturum dosyası okumaları.** Oturum sıralama anahtarları
   için dosya kimliği, boyutu ve değişim zamanlarıyla doğrulanan sınırlı
   önbellek kullanılacak; eşzamanlı aynı okumalar birleştirilecek.
5. **Orta — günlük kaynak yaşam döngüsü.** WebView console interception,
   bağlantı kurulurken kapatma ve büyük geçmişte silme maliyeti düzeltilecek.
6. **Orta — yeniden denemede sahipsiz zamanlayıcı.** IDE sekme açma yeniden
   denemesi tool window yaşam döngüsüne bağlanacak.
7. **İşlev — yerel sponsor sınırları.** Zamanlanmış mesaj oluşturma/düzenleme
   ve limit sonrası otomatik devam bütün kullanıcılara açılacak. Sponsor
   hesabı, ödeme ve lisans durumu gerçek durumunu göstermeye devam edecek;
   dış servislerin kimlik doğrulaması değiştirilmeyecek.
8. **Yüksek — akışta geçmiş mesajların yeniden oluşturulması.**
   `webview/src/pages/ChatPage/mergeToolResults.ts` değişmeyen araç mesajları
   için de yeni nesneler üretiyor. Oturum bazlı, yalnız mevcut mesajları
   tutan önbellekle değişmeyen nesne referansları korunacak; sonuç/ilerleme
   değişiklikleri ve eski sayfa yükleme geçersizleştirmesi test edilecek.

## Doğrulama ve teslim

- Önce ilgili davranış testleri: boşta frame/cleanup, büyük dosya okuma,
  önbellek geçersizleştirme, takılan/gürültülü süreçler, sponsorsuz kullanım.
- Ardından backend ve webview TypeScript kontrolü ve tüm test paketleri;
  Kotlin testleri ve üretim plugin ZIP derlemesi.
- ZIP içinde sürüm ve kaynakların eşleşmesi, arşiv bütünlüğü ve mümkünse
  JetBrains Plugin Verifier kontrolü.
- Orijinal lisans/telif bildirimleri korunur. Değiştirilmiş sürüm ayrı bir
  sürüm numarası taşır ve eşleşen kaynaklarıyla teslim edilir. Marketplace'e
  yayınlamak veya kurulu IDE'yi değiştirmek bu çalışmanın parçası değildir.
- Ölçülen sonuçlar ve yapılamayan canlı IDE kontrolleri sonuç raporuna yazılır.
