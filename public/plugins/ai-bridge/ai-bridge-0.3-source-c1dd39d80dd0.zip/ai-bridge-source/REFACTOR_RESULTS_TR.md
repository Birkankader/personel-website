# Swttch Community 0.30.1.1 — sonuç raporu

8 Eylül 2026. Orijinal Swttch `v0.30.1` kaynakları üzerinde planlanan
performans ve yerel özellik erişimi refaktörü uygulandı.
Başlangıç commit'i: `8c4264187610b6a1aace281d88e34d09ac28c4d7`.
Plan: [REFACTOR_PLAN_TR.md](REFACTOR_PLAN_TR.md).

## Uygulanan değişiklikler

| Alan | Önce | Şimdi | Doğrulama |
|---|---|---|---|
| Boşta sohbet | Her animation frame'de geometri ölçümü ve state kontrolü | Kaydırma, boyut/içerik ve görünürlük olaylarında birleştirilmiş ölçüm | İlk ölçümden sonra kendiliğinden yeni frame yok; gizleme/dönüş/cleanup testleri |
| Uzun sohbet akışı | Geçmiş araç mesajları her güncellemede yeni nesne oluyor | Değişmeyen mesaj ve araç sonuçları aynı referansı koruyor | 1.000 geçmiş araç mesajının tamamı yeni mesaj eklenirken aynı kalıyor; değişen sonuç/ilerleme yenileniyor |
| Büyük görev çıktısı | Her dosya olayında dosyanın tamamı okunuyor | En fazla 600.006 bayt okunup son 200.000 UTF-16 kod birimi döndürülüyor | 8 MiB ve 1 GiB boyut senaryoları, Türkçe/CJK/emoji ve kısmi okumalar |
| Oturum sıralama | Tekrar aynı dosya kuyrukları okunuyor | 1.024 kayıtla sınırlı metadata önbelleği, eşzamanlı okumaların birleştirilmesi | Değişmeyen 101 sorguda 1 içerik okuması; her çağrıda dosya bilgisi kontrolü |
| Canlı görev çıktısı | Okumalar üst üste binebiliyor, sürekli yazı güncellemeyi erteleyebiliyor | Tek aktif okuma, bir bekleyen takip okuması, 200 ms olay birleştirmesi | Sürekli yazma, yavaş okuma, kapatma/yeniden açma ve sonradan oluşan dosya testleri |
| Günlükler | Boşta flush interval'i; `Array.shift`; bağlanan socket ve console cleanup eksikleri | Veri gelince flush; indeksle silme; doğru socket/console temizliği | Boşta interval yok; yeniden bağlanma ve bellek bütçesi testleri |
| IDE süreç sorguları | Bloklayan `readText()` zaman aşımı kontrolünü engelleyebiliyor | Ortak süre/çıktı sınırlı süreç çalıştırıcısı | Gerçek süreçlerde 8 test: dolu pipe, aşırı çıktı, timeout, child, erken parent exit, stdin ve exit code |
| IDE yeniden deneme | Sahipsiz `java.util.Timer` thread'i | Tool window yaşam döngüsüne bağlı platform `Alarm` | Kotlin testleri ve derleme |
| Sponsor özellikleri | Zamanlama/düzenleme/otomatik devam yerel sponsor kontrolüne bağlı | Bu yerel özellikler bütün kullanıcılara açık | Sponsorsuz ve sponsor servisi erişilemezken davranış testleri |

Önbellek dosya device/inode, boyut, mtime ve ctime bilgilerini kontrol eder.
Append, truncate, aynı boyut/mtime ile atomik değiştirme ve okuma sırasında
yazma senaryoları kapsandı. Orijinal CLI veri yapıları değiştirilmedi.

Günlük geçmişi yaklaşık 32 MiB bütçeyle yönetilir; metnin UTF-16 maliyeti ve
kayıt başına metadata hesaba katılır. Tek başına bütçeyi aşan en yeni kayıt
teşhis için korunur; bu bütçe mutlak JavaScript heap sınırı değildir.

## Doğrulama

- Backend: **170 dosyada 2.010 başarılı test**, mevcut 8 atlanan test.
- WebView: **347 dosyada 3.355 başarılı test**.
- Kotlin: **87 sınıfta 422 başarılı test**, hata/atlama yok.
- Toplam: **5.787 başarılı test**.
- Backend ve WebView TypeScript kontrolleri geçti.
- `git diff --check` ve build script sözdizimi kontrolü geçti.
- `bash ./scripts/build.sh dist` başarılı; üretim plugin ZIP'i oluştu.
- ZIP ve içindeki JAR bütünlük kontrolü geçti.
- Plugin adı **Swttch Community**, sürümü **0.30.1.1**.
- Orijinal plugin ID korundu: `com.github.yhk1038.claude-code-gui`.
- Paketlenmiş backend ve bütün WebView dosyaları güncel derleme çıktılarıyla
  bayt düzeyinde eşleşiyor; sürüm dosyaları da 0.30.1.1.
- Orijinal AGPL-3.0 lisansı ve değiştirilmiş sürüm bildirimi JAR'a eklendi.
- JetBrains Plugin Verifier: **IntelliJ IDEA Community 2024.2.6
  (IC-242.26775.15) ve IntelliJ IDEA Ultimate 2026.2 EAP
  (IU-262.8117.19) uyumlu**. `DiffTabService` ve `EditorTabHost` içindeki
  mevcut `requestOpenFile` çağrılarına ait iki deneysel API uyarısı var;
  bu dosyalar refaktörde değiştirilmedi. 2024.2.6 denetiminde ayrıca
  `com.intellij.modules.jcef` opsiyonel bağımlılığı çözümlenemiyor; eski
  sürümde JCEF platforma dahildir ve denetleyicinin sonucu yine uyumludur.

WebView testleri mock backend kullanır; bazı eski testler localhost'a başarısız
bağlantı girişimlerini loglar. Testlerin tamamı başarılıdır. Üretim derlemesinde
upstream Gradle API deprecation, eski Browserslist verisi ve 500 KB üstü chunk
uyarıları devam eder; bu çalışma bağımlılık sürümü yükseltmez.

## Teslim ve kullanım

- Plugin: `build/distributions/swttch-0.30.1.1.zip`.
- Kaynak: `dist/swttch-community-0.30.1.1-source.zip`.
- Kaynak paketi üretme: `bash ./scripts/build.sh source-zip`.
- Derleme/test komutları: [COMMUNITY_NOTICE.md](COMMUNITY_NOTICE.md).
- Ayrıntılı test/derleme logları çalışma alanının `../validation/` klasöründe.

Plugin ZIP'i IDE'nin **Install Plugin from Disk** seçeneğine verilir; kaynak
ZIP'i kurulum paketi değildir. Aynı plugin ID sayesinde mevcut sürümün yerine
kurulur. Orijinal `../swttch-0.30.1.zip` ve açılmış `../swttch/` korunmuştur.
Kurulu IDE'ye yükleme veya Marketplace'e yayınlama yapılmadı.

Gerçek IDE oturumunda önce/sonra CPU, RAM ve pil profili alınmadı. Yukarıdaki
ölçümler tekrarlanan işlem, okunan bayt ve nesne referansı testleridir; toplam
makine performansında yüzde iyileşme iddiası değildir. JCEF'nin canlı çizimi,
uzun sohbet sırasında gerçek kaydırma hissi ve macOS enerji tüketimi için
kullanıcının tipik oturumuyla son kontrol gerekir.

Gerçek sponsor hesabı, ödeme/cihaz yönetimi ve dış sağlayıcı kimlik doğrulaması
korunur. Erişime açılanlar eklentinin yerelde çalışan zamanlama ve otomatik
devam özellikleridir.
