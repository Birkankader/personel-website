# AI Bridge — uygulama planı

Önceki 0.30.1.1 performans ve topluluk erişimi değişiklikleri korunur.

1. Yeni sohbet: web başlığında kalıcı `+`, JetBrains araç penceresinin sekme çubuğunda `+`; açık sohbeti sıfırlamadan yeni sekme açma.
2. Adlandırma: görünen ad `AI Bridge`, sürüm `0.31.0`; JetBrains kayıt adı karakter kısıtı nedeniyle `AI Bridge`; mevcut kurulum ve ayarlarla devam için plugin kimliği korunur.
3. Düşük kaynak modu: görünmeyen sohbetlerde pahalı arayüz güncellemelerini durdurma; taslak, kaydırma ve çalışan görevleri koruma.
4. Uzun sohbet: ekran dışındaki mesaj bölümlerinin çizim ve React güncelleme maliyetini azaltma; metin seçimi, mesaj hedefleme ve eski sayfaları yükleme korunur.
5. Kaynak ve görev paneli: talep üzerine CPU/RAM ölçümü, aktif ve sıradaki görevler, iptal/durdurma, eşzamanlı görev sınırı.
6. Tam metin arama: konuşma içerikleri üzerinde sınırlı ve sayfalı arama, oturum ve mesaja doğrudan gitme.
7. Görev şablonları: proje bazında prompt, model, düşünme seviyesi ve dosya bağlamını kaydetme; göndermeden önce düzenlenebilir taslak olarak yükleme.
8. Bağlam önizlemesi: prompt ve eklerin boyut/tahmini token dökümü, ağır ekleri çıkarma, ayarlanabilir eşik uyarısı.
9. Yer imleri ve karar notları: ham JSONL kayıtlarını değiştirmeyen kalıcı yerel kayıtlar.
10. Türkçe: dil seçimi ve uygulama katalogları, yeni özelliklerin çevirileri.

Doğrulama: davranış regresyonları, TypeScript kontrolleri, Kotlin testleri, üretim ZIP ve kaynak ZIP; Plugin Verifier. Kaynak kazanımları gerçek ölçüm olmadan yüzde olarak raporlanmaz.
