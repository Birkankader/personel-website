# AI Bridge bağımsız eklenti planı — 0.31.1

1. Yayıncı/geliştirici Birkan Kader; yeni plugin ID `com.birkankader.ai-bridge`, Kotlin namespace `com.birkankader.aibridge` ve artifact `ai-bridge`.
2. Native action/toolwindow/VFS/state/widget kimlikleri, özel ortam değişkenleri ve WebSocket kimlik doğrulama protokolü AI Bridge'e ayrılır.
3. Özel global/proje verileri `.ai-bridge` altında; eski eklenti verileri silinmez/taşınmaz. Claude'un kendi hesabı ve ham JSONL kayıtları korunur.
4. Swttch'e ait sponsorluk/ödeme, telemetri, duyuru, yardımcı paket ve eklenti güncelleme bağlantıları kaldırılır. Gerçek Claude sağlayıcı oturumu ve CLI güncellemesi korunur.
5. Hakkında/gizlilik/yardım akışları bağımsız ve yerel hale getirilir. Yeni sahibi adına e-posta, web sitesi veya GitHub deposu uydurulmaz.
6. Upstream yazar/telif/lisans bildirimleri korunur. Kaynak Git remote'u `upstream` olarak adlandırılır; yayın yapılmaz.
7. Tür kontrolleri, davranış ve kimlik izolasyonu testleri, üretim ZIP metadata/bundle incelemesi ve iki IDE üzerinde Plugin Verifier ile doğrulanır. Eşleşen kaynak ZIP teslim edilir.
