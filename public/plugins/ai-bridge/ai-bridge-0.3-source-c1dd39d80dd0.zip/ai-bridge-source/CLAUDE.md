# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

A Claude Code GUI plugin for JetBrains IDEs. The goal is to provide the same UX as Cursor's Claude Code extension inside the JetBrains environment.

## ★ Core Principles — CLI Equivalence & Independence from Official Support (top priority, must not be violated)

This project exists because **the official JetBrains Claude Code plugin is cruder than the official Cursor extension and is not being updated, so we build a better one ourselves**. Therefore the following are **the baseline for every feature design**. (New contributors and agents must internalize these before working on any feature.)

1. **CLI equivalence**: "Anything an existing user can do in the CLI (`claude ...`) must also be possible in the GUI." When designing a feature, **first ask "Which command does a CLI user run to do this?"**, and make that official command the reference interface.

2. **Independence from official support**: **Do not depend on Claude's official SDK libraries or on undocumented internal protocols.** Depending on them creates a lock-in where "it works in the CLI, but only the GUI is blocked because of policy or a not-yet-released feature", and at that moment the reason this project exists collapses. If we were going to rely on official support, there would have been no reason to start this project in the first place.

3. **Imitate only the UX of reference products**: What we follow from reference products such as Cursor is **the screens and features (UX)**, not **the internal implementation means** used to build them. Example: even if Cursor uses the undocumented internal protocol `control_request{subtype:"mcp_status"}` to query MCP status, we implement that screen with the official `claude mcp list` command.

4. **Communication we control directly is our own asset**: Our direct control of claude over stdin/stdout (`control_request` interrupt/set_model etc., `backend/src/core/claude-process.ts`) is **not** a "dependency on the official SDK library" — **it is communication we implemented ourselves**. Improving its completeness is the right thing to do — but **do not depend on undocumented subtypes; use them only as auxiliary optimizations, and always guarantee the official CLI command fallback as the first priority**.

> Stability criterion: **the output contract of official commands that users run directly in the terminal** (e.g. the text output of `claude mcp list`) > **undocumented inter-program internal protocols**. Even if the latter looks more convenient because it is more "structured", the former takes precedence, both for stability and for our philosophy.

### Recorded Exceptions

A principle is a principle, not an inviolable law. It may be violated only in special cases that fall under one of the following, and in that case you must **obtain the user's direct decision and record the rationale for that decision in a document.**

- When it is unavoidable because there is no other alternative
- When the exception's approach yields an overwhelmingly greater benefit than the approach that keeps the principle (a human makes that judgment)
- When the exception's approach is the most fundamentally correct way to implement the feature, compared with the approach that keeps the principle

The procedure is described in [docs/principle-exceptions/README.md](./docs/principle-exceptions/README.md).

The exceptions recorded so far are:

- [Use the undocumented `control_request{subtype:"mcp_status"}` to query the MCP server list](./docs/principle-exceptions/363-mcp-status-control-request.md) — violates items 2 and 3 above. Adopted on the condition that the official `claude mcp list` path is always kept alive as a fallback ([#363](https://github.com/Swttch/swttch/issues/363))
- [Implement rewind and fork with CLI flags that are not listed in `--help`](./docs/principle-exceptions/356-rewind-and-fork-hidden-cli-flags.md) — violates item 2 above. There is no alternative, because `/rewind` does not support non-interactive mode. Since there is no fallback, if the flags disappear, do not try to revive the feature — hide the menu instead ([#356](https://github.com/Swttch/swttch/issues/356))

## Architecture

Consists of 3 layers:

1. **Node.js Backend (the only backend)** - Runs the Claude Code CLI, session/settings/file I/O, WebSocket server
2. **WebView UI** - Chat/session/diff card UI, a faithful implementation of the Cursor UX (communicates with Node.js over WebSocket)
3. **Bridge (per-environment adapter)** - BrowserBridge (browser) / KotlinBridge (JetBrains IDE native APIs)

## Implementation Criteria

When implementation options diverge, Cursor UX is the primary criterion. Priority: Cursor UX > JetBrains conventions

## Technical Constraints

- The WebView uses JCEF (Swing UI is forbidden, except for permission dialogs)
- The agent runtime is separated into a process outside the IDE
- Event-driven, streaming-first design

## Single-Backend Architecture

Regardless of the client's runtime environment, the WebView always communicates with the Node.js backend over WebSocket.

| Client environment | Bootstrap | Backend | Bridge |
|----------------|-----------|--------|--------|
| Browser | Vite dev server | Node.js WebSocket server | BrowserBridge (no-op, etc.) |
| JetBrains IDE | Kotlin spawns Node.js → localhost:PORT | Node.js WebSocket server | KotlinBridge (IDE API) |

**Both environments are environments where the real product runs.** The browser environment is not development-only; it is a standalone distribution target.

### Execution Mode Terms

| Term | Meaning |
|------|------|
| **JetBrains mode** | The IDE spawns the Node.js backend and connects through the JCEF WebView. Enabled by the `JETBRAINS_MODE=true` environment variable. |
| **Standalone mode** | The Node.js backend runs outside the IDE and is accessed from a regular browser. Applied automatically when `JETBRAINS_MODE` is not set. Two bootstrap paths: ① the Vite dev server for development, ② the `ccg` command (terminal launcher) on the user's machine. |

Distribution artifact names follow these terms as well — `claude-code-gui-standalone-v<ver>.tgz` is the backend + webview runtime for standalone mode. The JetBrains mode artifact is the marketplace zip (`swttch-<ver>.zip`, derived from `rootProject.name` in `settings.gradle.kts`).

> **Do not change the standalone tgz filename.** `claude-code-gui-standalone-v<ver>.tgz` is produced by `scripts/build.sh`, and `cli/lib/runtime.sh` downloads it from the release under the same name. The `ccg` already installed on users' machines has this name hardcoded, so renaming it breaks runtime downloads for existing users.

### Core Principles

- **Node.js is the only backend**: All business logic (sessions, settings, Claude CLI, file I/O) is handled in Node.js
- **Bridge is an ORM adapter**: Only features that must differ per environment (editor tabs, diff viewer, etc.) are abstracted behind the Bridge interface
- **Kotlin is an implementation that sits behind Node.js**: The WebView does not communicate with Kotlin directly. When Node.js needs an IDE-native feature, it calls the Bridge (Kotlin)

### ★ The Bridge Is the Only Two-Way Path Between Environment and Backend (must not be violated)

The Bridge is the mechanism that **mediates between the runtime environment and the Node backend by normalizing the formats of both sides**. As with MCP, the two sides do not know each other directly and talk only through the Bridge.

**Direction is not part of the Bridge's definition. Everything coming in and everything going out passes through the Bridge.**

| Direction | Rule |
|------|------|
| Environment → Backend | **The only path** by which the environment (JetBrains, etc.) delivers anything to the backend **is the Bridge** |
| Backend → Environment | **The only way** the backend controls the environment **is the Bridge** |

#### Every Bridge Implements the Same Capabilities

The capabilities declared in the `Bridge` interface must be **achieved by every implementation, without exception**. A `BrowserBridge` opting out with "there is no IDE, so we can't do this" is a violation of the principle. Finding **by what means that capability can be achieved** in that environment is the job of the Bridge implementation.

- JetBrains: **receives, translates, and forwards** what the IDE already knows (VFS events, etc.)
- Terminal (standalone): there is no host to mediate, so it **achieves the capability directly with the means available in that environment**

Do not misread the second case as "the Bridge does the work on its own". It fulfills the same contract in each environment's own way, and this is the mechanism that lets the backend **not need to know which environment it is attached to**.

> **Why this principle was created**: In #359, file change detection was wired directly into the JetBrains path only, and was not added to the Bridge interface. As a result, **the feature was entirely missing for standalone users**, and nobody noticed until it was reviewed in the browser. Had it been put on the interface, `BrowserBridge` could not have gotten away without implementing it — the interface is a mechanism that exposes missing pieces, and we did not use it.

**Only genuine no-ops stay no-ops.** Something like "open an editor tab", whose very concept exists only inside the IDE, is correctly a no-op in the browser. In contrast, **a capability that is meaningful in every environment, such as "knowing that a file changed", cannot be left as a no-op.** Deciding question: *"Does a user of that environment lose out if this capability is missing?"* If so, it is not a no-op — it is unimplemented.

### No Code Duplication

Since Node.js is the only backend, there is no need for dual implementations of business logic. Do not implement business logic in Kotlin.

## Original Data Preservation Principle

The original data structures produced by the Claude Code CLI (JSONL entries, session metadata, etc.) must **keep the structure of each entry, unedited, all the way to the WebView end**.

> **Why this principle was created**: The backend **repeatedly tended to edit what it forwarded down to only what was needed**, picking out the useful fields that Claude Code streams to us on the grounds that "the UI only needs this much right now". As a result, it later cost us effort to re-learn and trust the original structure. The core of this principle is therefore **"Do not edit data structures in the backend; send them to the frontend as they are."** It is enforced and will continue to be upheld.

### Rules

1. **No renaming of keys/values**: Do not rename original field names in intermediate layers. (e.g. `title` → ~~`firstPrompt`~~, `createdAt` → ~~`created`~~)
2. **No editing of entry structure**: The intermediate forwarding layer (the Node.js backend) must not edit the structure of individual entries or pick out fields and drop the rest. Edits that send only a subset of the original fields "because they aren't needed right now" are exactly what this principle targets.
3. **No information loss**: Do not remove fields from the forwarding path, even if the current UI does not use them. Preserve their potential for future use.
4. **Data type conversion is allowed**: Type mapping between languages (e.g. JSON → Kotlin data class → JSON) is allowed, but key names and structure must not change in the process.

### Exception for Range Splitting (Pagination / Views)

For performance, it is allowed to **send data in split ranges instead of all at once (pagination), or to send only the current conversation chain (active-chain filter)**. What this principle forbids is *editing or distorting the structure*, not *splitting the amount (range)*. However, all of the following must be satisfied.

1. **Per-entry structure stays intact**: Even when sent in parts, each entry that is forwarded keeps its original structure unedited (rules 1–4 above apply to individual entries as they are). Cutting a range is different from editing the inside of an entry.
2. **Guaranteed complete access with nothing missing**: Partial delivery means "not sent right now", not "can never be seen". When the frontend requests it, it must be able to receive the remaining range with nothing missing (e.g. the full history can be reached via "show earlier messages"; with pagination off, everything is loaded).
3. **Decision criterion**: "Leave the structure as it is, and deliver enough that everything is accessible with nothing missing" — then the compromise is justified. Conversely, "this field/entry isn't used, so strip it out of the structure entirely before sending" is still a violation.

### Rationale

- The project does not yet make full use of Claude Code's original data. If an intermediate layer edits the information, it later causes unnecessary cost to re-learn the original structure.
- **Looking at the data in any layer, you must be able to tell "what the Claude Code original looks like", and you must be able to trust that content.**

### Scope

| Layer | Role | Allowed | Not allowed |
|------|------|-------------|---------------|
| Node.js backend (dev-bridge) | Forward the original | Type conversion, serialization, range splitting (pagination) / narrowing to the current conversation view — provided entry structure is preserved + complete access is guaranteed | Field renaming, editing entry structure, omissions that make data inaccessible |
| WebView (React) | Final consumer | Filtering, sorting, processing for display | — |

## Consistent Naming Principle

Names that refer to the same purpose and the same action use **the same word** consistently, regardless of layer and language.

### Rules

1. **One word per action.** Use the same verb everywhere for the same operation — method names, IPC message types, variable names, RPC handler names, and so on. When reading along a pipeline, a change of word leads readers to mistake it for a different operation. (e.g. ~~`create()` → `NEW_SESSION`~~ → `create()` → `CREATE_SESSION`)
2. **Different words for different actions.** Operations with different meanings, such as "reset the session in the current tab" and "open a new editor tab", must not share the same name.
3. **Use clear verbs.** Use CRUD verbs (`create`, `get`, `update`, `delete`) or clear action verbs (`load`, `clear`, `open`, `stop`). Avoid ambiguous words such as `new` and `change`.

### IPC Message Types Use the `MessageType` Enum (Single Source)

Every IPC message `type` passed between webview↔backend (and Node↔Kotlin) uses the `MessageType` enum instead of plain string literals.

- **Where it is defined**: `webview/src/shared/message-type.ts` ↔ `backend/src/shared/message-type.ts` (mirrored directories, 1:1 sync required — see `shared/CLAUDE.md`). The webview imports from `@/shared`, the backend from `../shared` (adjusted to the path depth).
- **Member name = string value**: `MessageType.GET_ACCOUNT === 'GET_ACCOUNT'`. The wire format and the code read the same and can be grepped the same way. This is the mechanism that enforces the "one word per action" principle above at the IPC boundary.
- **Forbidden**: plain strings such as `send('GET_ACCOUNT')`. Always use `send(MessageType.GET_ACCOUNT)`.
- **When adding a new message type**: add a member to the enum and document **the meaning of each value in an English comment** (direction: inbound webview→backend / outbound backend→webview / Node↔Kotlin / logging channel). Apply the same change to both `shared` directories.
- **Scope**: everywhere a message `type` is used — `bridge.request`/`send`/`subscribe`/`waitFor`, backend routing `switch...case`, `connections.sendTo`/`broadcast`, JSON-RPC `method`, logging channels (`LOG_BATCH`), etc. However, sub-classifications inside the `payload` that are not the message envelope (`type`) (e.g. `CLI_ERROR` in a CLI_EVENT payload) are out of scope.

## User Data Directory (`~/.claude-code-gui`) — Do Not Rename

User data is stored in `~/.claude-code-gui` (can be overridden with the `CCG_HOME` environment variable). **This path stays as it is even after the product was rebranded to Swttch.**

It contains account credentials (`accounts.json`, `accounts/`, permission `600`), global settings (`settings.js`), sponsor licenses, scheduled messages, the CLI process registry, and the cloudflared installation (`bin/`). **These are not our files; they are the user's assets.**

- Do not move it to `~/.swttch` or the like because of the rebranding. If the path changes, every user loses their logins, settings, and sponsor licenses.
- It is a hidden directory that users don't notice, so there is nothing to gain from unifying the name. Confusion such as "where is this?" is resolved in the README and marketplace documentation.
- If it ever has to be moved, do not mix it into rebranding work — handle it in a **separate PR**. Even then, start not with a move but with **copying and then reading from both locations in parallel**, keep the old-path fallback across several versions, and if migration fails, keep working silently with the old path.
- `CCG_HOME` is a publicly documented contract in `cli/install.sh`. There may already be users who use a custom path.

For the same reason, **do not rename the `ccg` command name or the 29 `CCG_*` environment variables either.** `ccg` is a name users type themselves and register in their PATH, so renaming it makes the command disappear for users who already installed it. `CCG_*` is also a public contract, so do not touch it because of the rebranding.

## State Machine

Idle → Streaming → Waiting Permission → Has Diff → Error

## UI Term Definitions

| Term | Description |
|------|------|
| **Top bar** | The area element at the top of the chat screen that contains the new tab button and the session dropdown toggle button |
| **Session dropdown toggle button** | The dropdown toggle button on the left side of the top bar that shows the current session's title |
| **Session dropdown** | The dropdown menu that opens when the session dropdown toggle button is clicked |
| **New tab button** | The plus button on the right side of the top bar. When clicked, it opens a new Claude Code editor tab in the IDE |
| **Initialized session** | The state in which not even the first message has been started yet, so no session has been created |
| **Input banner** | The notice line that appears directly above the chat input (generic component `InputBanner`). Distinct from the top banner (`BannerArea`) at the very top of the screen. Composed of text on the left + actions on the right + an X close button at the far right. Reused for things like the telemetry consent notice |

## Build Commands

All builds are run through `bash ./scripts/build.sh <command>`. Do not compose `cd`, `pnpm`, or `./gradlew` commands directly.

> **Important**: Run `bash ./scripts/build.sh -h` to see the full list of commands.

### Main Commands

| Command | Purpose |
|------|------|
| `bash ./scripts/build.sh be-build` | Build the backend |
| `bash ./scripts/build.sh wv-build` | Build the webview |
| `bash ./scripts/build.sh build` | Build the plugin |
| `bash ./scripts/build.sh full-build` | Full build (be + wv + plugin) |
| `bash ./scripts/build.sh dist` | Build for distribution (be + wv + buildPlugin) |
| `bash ./scripts/build.sh run-ide` | Run the IDE for testing |
| `bash ./scripts/build.sh clear-cache` | Reset build caches/outputs |
| `bash ./scripts/build.sh wv-lint` | WebView TypeScript check |
| `bash ./scripts/build.sh wv-test` | WebView tests |
| `bash ./scripts/build.sh all` | Full build + run the IDE |

### Agent Behavior Guidelines

1. **When building/testing**: always use `bash ./scripts/build.sh`
2. **No `cd`**: the script handles paths internally with `pnpm -C` and `gradlew -p`
3. **When a new command is needed**: propose adding a case to `scripts/build.sh`
4. **Prefix every shell command with `bash`**: e.g. `bash ./scripts/build.sh build`, `bash -c "ls -la"`, etc.

## Local Skills

Project-local skills live in `.claude/skills/`. Prefer **project-local skills** over oh-my-claudecode skills.

> **Structure rule**: each skill must have the form `.claude/skills/<name>/SKILL.md` (folder + SKILL.md), and SKILL.md must have `name` and `description` YAML frontmatter at the top in order to be triggered automatically by natural-language requests. Flat `.claude/skills/<name>.md` files are not recognized as skills by Claude Code.

| Skill | File path | Trigger keywords |
|------|-----------|--------------|
| `/cc-gui-reporter` | `.claude/skills/cc-gui-reporter/SKILL.md` | "check marketplace", "check reviews/comments/replies", "unanswered", "unresolved bugs", "status", "report", "triage", "rapor", "durum" |
| `/deploy` | `.claude/skills/deploy/SKILL.md` | "deploy", "release", "publish", "publish to marketplace", "yayınla", "sürüm çıkar" |
| `/build` | `.claude/skills/build/SKILL.md` | "build", "compile", "derle" |
| `/precheck` | `.claude/skills/precheck/SKILL.md` | "precheck", "pre-deploy check", "pre-release review", "ön kontrol" |
| `/release-monitor` | `.claude/skills/release-monitor/SKILL.md` | "release monitoring", "release-monitor", "marketplace monitoring", "check approval", "sürüm takibi" |

Data collection for `/cc-gui-reporter` is handled by `./ignore/cc-gui-report.sh` (the user can run it directly; read-only. Not tracked by git — `ignore/` folder).

## JetBrains SDK API Usage Cautions

When publishing to the JetBrains Marketplace, the **Plugin Verifier** automatically validates API usage.

- Using a **Deprecated API** → warning
- Using an **Internal API** → error, publication may be rejected
- Be careful with classes that may be internal/deprecated, such as `EnvironmentUtil`
- Never use `@ApiStatus.Internal` or classes inside `impl` packages
- Before publishing, always build with `bash ./scripts/build.sh dist` and check the Plugin Verifier results

## JetBrains Marketplace Approval Guidelines (v1.3, 2026-03-31)

All of the criteria below must be met when publishing. Violations may delay or block approval.

### 1. Plugin Content

| Item | Requirement |
|------|---------|
| **Logo** | The default IntelliJ template logo is forbidden. Must not resemble JetBrains product logos. **40x40px SVG** required |
| **Name** | Must be unique. Max 30 characters. Only Latin letters/digits/symbols allowed. Must not include JetBrains product names such as "Plugin", "IntelliJ", "JetBrains". Starting with "A" or "." to manipulate search ranking is forbidden. Avoid using "Support" or "Integration" on their own |
| **Vendor** | Vendor website and email must be valid. Impersonation/false representation is forbidden |
| **Description** | English required (primary language). Correct formatting/spelling/grammar. Media must display correctly |
| **Change notes** | Placeholder text ("Add change notes here") is forbidden. Include only relevant information |
| **Links** | All external links must be valid. Only links related to the plugin/author are allowed |
| **Assets** | Infringing JetBrains brand assets is forbidden. Copyright/trademark infringement is forbidden |

### 2. Plugin Functionality

| Item | Requirement |
|------|---------|
| **Compatibility** | Compatible with at least 1 JetBrains product. Must be installable on the declared compatible products/versions |
| **Plugin Verifier** | Binary compatibility verification is required for every upload. **No Internal API usage violations** |
| **Security** | Must have no security vulnerabilities or privacy issues |
| **Performance** | Must not severely degrade JetBrains product performance |
| **No interference** | Modifying/hiding/intercepting/interfering with JetBrains product functionality (including licensing, subscriptions, trials, and upgrade flows) is forbidden |
| **Data collection** | **Explicit user consent is required** when processing personal/statistical/telemetry data. No data transmission while the plugin is disabled |
| **No search manipulation** | Manipulating search results or disrupting Marketplace functionality through metadata/marketing assets is forbidden |

### 3. Legal Requirements

- Agreement to the Developer Agreement is required
- A Developer EULA is required for every plugin
- Plugins under an open-source license **must link to the source code**
- **A Privacy Policy is required** when collecting personal information
- A trader/non-trader status declaration under EEA consumer protection law is required

### Agent Checklist (verify before publishing)

Before running a deployment (`/deploy`), check the following items:

- [ ] Logo: 40x40px SVG, not similar to JetBrains logos
- [ ] Name: 30 characters or fewer, no JetBrains product names
- [ ] Description: English first, no broken links/images
- [ ] Change notes: actual changes listed, not placeholders
- [ ] All external links valid
- [ ] Plugin Verifier passes (0 Internal API violations)
- [ ] Privacy Policy link present if personal information is collected
- [ ] Source code link present (open source)

## Logging System

See [logging.md](./logging.md).

## Work Plan

Before starting work, you must read `ignore/plan.md` and follow the agent instructions in it. When "the plan file" is mentioned in conversation, it means this file. If the user asks about the next task, answer first based on this plan file.
