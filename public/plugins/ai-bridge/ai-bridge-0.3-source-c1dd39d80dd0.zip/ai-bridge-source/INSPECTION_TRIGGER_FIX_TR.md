# Java denetimlerini yeniden başlatan sekme olayı — 0.1

9 Eylül 2026. Kullanıcının Windows IntelliJ IDEA 261.22158.277 CPU profili ve “AI Bridge açılış/kapanışında Java analizi tekrar çalışıyor” geri bildirimi üzerine eklentinin gönderdiği IDE olayları izlendi. **Java denetimleri açık kalır; inspection profili, dosya analiz seviyesi veya Power Save Mode değiştirilmez.**

## Doğrulanan tetikleyici

AI Bridge bir sohbet sekmesinin görünen adını değiştirmek için `VirtualFileManager.notifyPropertyChanged(..., PROP_NAME, ...)` çağırıyordu. Bu, yalnız etiket değişikliği yerine genel bir VFS dosya adı değişikliği olayı oluşturuyor.

IDEA'nın tam 261.22158.277 kaynak kodunda zincir:

```text
ClaudeCodeVirtualFile.setDisplayName
  → VirtualFileManagerImpl.notifyPropertyChanged
  → invokeLater + runWriteAction
  → VFS_CHANGES: VFilePropertyChangeEvent(PROP_NAME)
  → her projedeki DaemonListeners.fileRenamed
  → stopDaemonAndRestartAllFiles
  → DaemonCodeAnalyzerImpl.restart
  → FileStatusMap.markAllFilesDirty + stopProcess(true)
```

`DaemonListeners` yeniden başlatmayı sanal dosyanın geçerliliği veya PSI karşılığı kontrol edilmeden önce yapıyor. Bu nedenle sohbetin gerçek bir `.java` dosyası olmaması koruma sağlamıyor. Olay uygulama düzeyinden alt proje mesaj kanallarına yayılıyor. [VFS yayıncısı](https://github.com/JetBrains/intellij-community/blob/idea/261.22158.277/platform/core-impl/src/com/intellij/openapi/vfs/impl/VirtualFileManagerImpl.java), [analiz dinleyicisi](https://github.com/JetBrains/intellij-community/blob/idea/261.22158.277/platform/lang-impl/src/com/intellij/codeInsight/daemon/impl/DaemonListeners.java#L307), [tüm dosyaları yeniden işaretleme](https://github.com/JetBrains/intellij-community/blob/idea/261.22158.277/platform/lang-impl/src/com/intellij/codeInsight/daemon/impl/DaemonCodeAnalyzerImpl.java#L629).

**Gönderim öncesi somut olay:** Yerel sekmenin başlangıç adı `AI Bridge`, arayüzün yeni sohbet için verdiği `document.title` ise `AI Bridge`. Arayüz ilk kez yüklenirken bu iki ad arasındaki geçiş tek başına VFS olayını çıkarıyor; kullanıcı mesaj göndermemiş olabilir.

**Kapatma ile ilişki:** Eski VFS bildirimi `invokeLater` ile kuyruğa giriyordu. Sohbet sanal dosyasının `isValid()` değeri her zaman `true` olduğundan, sekme kapanmış olsa bile önceden kuyruğa girmiş başlık olayı çalışıp kalan Java dosyalarının analizini yeniden başlatabiliyordu.

Kullanıcının JFR kaydındaki ağır Java denetim zincirleri bu yeniden analiz etkisiyle uyumludur. Bu, eklentideki gerçek bir tetikleyicinin kaynak düzeyinde doğrulanmasıdır; düzeltilmiş paketin Windows CPU sonucu ayrıca ölçülmelidir.

## Uygulanan düzeltme

- Başlık modeli değişikliği artık VFS bildirimi üretmez. `ChatTabPresentation` yalnızca `FileEditorManager.updateFilePresentation(file)` ile ilgili sekmenin başlığını/simgesini yeniler. Bu public API 242 ve 261 kaynaklarında doğrulandı; kapalı editör dosyalarında işlem yapmaz.
- Başlık değişmediyse veya yalnız görünmeyen kırpılmış bölümü değiştiyse yeni sunum işi üretilmez. Kalıcı sekme URL'si ve tabId değişmez.
- Sohbet başlığı, sohbet geçişi, tool-window etiketi ve kullanıcının elle verdiği ad aynı sunum yolunu kullanır. Restore başlangıcı sessiz kalır.
- Başlık sunumu EDT üzerinde çalışır; proje kapanmışsa yapılmaz.

- Yerel başlık, yol ve akış bildirimleri EDT'ye taşınır. Teslim sırasında panel/proje yaşamı ve bildirimin hâlâ o panele ait olduğu tekrar kontrol edilir.
- Sekme taşınırken yeniden kullanılan tarayıcının bildirimleri yeni panele devredilir. Eski panelin geç kapanması yeni panelin bildirimlerini silemez; eski kuyruğu çalıştıramaz.
- Kapatılan panel kendi bildirimlerini hemen ayırır; tarayıcının taşıma için bekleme süresi dolmadan eski panel artık olay almaz. Tool-window başlık/yol güncellemesindeki ikinci kuyruk kaldırıldı.

[Public sunum API'si](https://github.com/JetBrains/intellij-community/blob/idea/261.22158.277/platform/analysis-api/src/com/intellij/openapi/fileEditor/FileEditorManager.java#L296).

## Doğrulama

Hedefli Kotlin paketi **102 test / 0 başarısız / 0 atlanan** ile geçti. Başlık sunumu, sanal dosya URL/claim, kalıcı sekme durumu, açılış kapısı, görünürlük, tarayıcı bırakma kuralları ve JCEF olmayan ortamda panel sınıfının yüklenmesi birlikte doğrulandı. Testler macOS üzerinde JDK 21 ile çalıştırıldı; Windows IDE oturumu veya Claude CLI çağrısı yapılmadı.

Bildirim sahipliği için eski kodda yeni panele geçiş testi başarısız oldu (6 test / 1 başarısız). Yeni sürümde 12 yaşam döngüsü testi; kapatma öncesi kuyruğa alınmış başlık, panel taşıma, eski panelin geç kapanması, projenin kapanması, iki ayrı bölme ve callback temizleme senaryolarını kapsar. Bu 12 test yukarıdaki 102 testin içindedir; ayrı bir toplam değildir.

Bu değişiklik yalnız Kotlin tarafına ve sürüm belgelerine aittir. Backend/WebView kaynakları önceki paketle aynıdır; bu turda önceki geniş JavaScript test toplamı tekrar çalıştırılmış gibi sunulmaz.

Üretim `dist` paketi oluşturuldu. JetBrains Plugin Verifier hem **IC-242.26775.15** hem **IU-262.8117.19** için **Compatible** sonucu verdi. İki mevcut `requestOpenFile` deneysel API kullanımı uyarısı devam eder; yeni başlık API'si için uyumsuzluk yok. Bu statik uyumluluk kontrolü, kullanıcının Windows IDEA 261 oturumunda performans ölçümü değildir. Tam 261 sürümündeki tetikleyici ve sunum API'si ayrıca JetBrains kaynak kodundan doğrulandı.

Eski kod üzerinde iki başlık regresyon testi başarısız oldu: gerçek başlık değişikliği ve restore başlığından varsayılan ada dönüş genel VFS servisine erişiyordu. Yeni testler başlangıçtaki gerçek `AI Bridge → AI Bridge` geçişini, yinelenen bildirimleri, kırpılmış adları, kapalı projeyi ve sekme adresinin korunmasını kapsar. Bu regresyon testleri kendi başına Windows CPU ölçümü değildir.

## Paket

- Kurulum: `../output/AI-Bridge-0.1.zip` — 8,711,536 bayt.
- SHA-256: `ed28a19336d0d94b0c4adaf5f5b6dd47f1eee657ca0af5bdb1ec0ad682c073f7`.
- Eşleşen kaynak: `../output/AI-Bridge-0.1-Source.zip`; kaynak ZIP özeti `../output/AI_BRIDGE_0.1_SHA256SUMS.txt` içinde bulunur.
- Plugin ID `com.birkankader.ai-bridge`, sürüm `0.1`, geliştirici/yayıncı `Birkan Kader`.
- Paket içindeki derlenmiş `ClaudeCodeVirtualFile` sınıfında `notifyPropertyChanged` yok; `ChatTabPresentation` sınıfında `updateFilePresentation` çağrısı var. Sürüm notları da yeni düzeltmeyi içeriyor.
- Backend/WebView `bundleRevision`: `8cc3430d387f010ffad30f01ceac49cb07a8ac3879fb97dbf6386c05c3a54083`. Yalnız yerel Kotlin kodu değiştiği için önceki paketle aynı; kurulum ZIP'inin SHA-256 değeri değişti.
- ZIP bütünlüğü, paket kimliği, lisans/bildirimler, derlenmiş sınıflar ve backend/arayüz dosyalarının çalışma alanıyla eşleşmesi doğrulandı.

**Windows kontrolü:** Bu ZIP'i yeniden kurup IntelliJ'i yeniden başlatın. Java dosyalarını açık ve denetimleri mevcut seviyelerinde tutarak AI Bridge açma, mesaj göndermeden yazma ve AI Bridge kapatma akışını karşılaştırın. Kaynak düzeyinde doğrulanan yeniden analiz tetikleyicisi kaldırıldı; gerçek makinedeki CPU düşüşü bu turda ölçülmedi.

Önceki paket `../output/archive/0.1-performance-rescan/` altında korundu. Kaynak/kanıt ve test kayıtları `../validation/inspection-trigger-fix/` altındadır. Kullanıcının IDE'sine kurulum veya Marketplace yayını yapılmadı.
