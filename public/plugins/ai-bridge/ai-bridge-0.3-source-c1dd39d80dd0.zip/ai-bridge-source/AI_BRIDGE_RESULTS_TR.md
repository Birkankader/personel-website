# AI Bridge 0.31.0

8 Eylül 2026. Swttch v0.30.1 kaynakları üzerine hazırlanan yerel, değiştirilmiş dağıtım. Önceki 0.30.1.1 performans refaktörü ve sponsorluk koşulu olmadan kullanılabilen zamanlanmış mesaj/otomatik devam özellikleri korunur.

## Kullanılabilir değişiklikler

- **Kalıcı +:** sohbet başlığında ve JetBrains araç penceresinin sekme çubuğunda. Yeni sekme açar; mevcut sohbeti sıfırlamaz. Eski menü düzeniyle çift düğme oluşmaz.
- **Ad:** arayüzde AI Bridge. JetBrains doğrulayıcısı kayıt adında `ş` kabul etmediği için Plugins listesindeki paket adı **AI Bridge**. Plugin kimliği korunur; mevcut kurulumun ayarları ve sohbetleriyle devam eder.
- **Düşük kaynak modu:** varsayılan açık. Görünmeyen panelde pahalı sohbet işlemleri ve göstergeler bekletilir; tekrar görünür olunca son durum gösterilir. Taslak, görev ve kaydırma durumu korunur.
- **Uzun sohbetler:** ekran dışındaki mesajların çizim ve React güncelleme maliyeti azaltılır. Mesaj hedefleme, seçim ve önceki mesajları yükleme davranışları korunur.
- **Kaynaklar ve görevler:** üst çubuktaki işlemci simgesi. Backend ve CLI süreçleri için CPU/RAM, bağlı sohbet sayısı, çalışan/sıradaki görevler ve tek görev durdurma/iptal. Panel açık ve görünürken ölçüm yapılır.
- **Görev sınırı:** varsayılan 2, ayarlanabilir 1–16 aktif Claude turu; fazlası sıraya alınır. Projelerin sınırları ayrı saklanır. Kuyruk 128 görevle sınırlıdır. İptal ve hemen yeniden gönderme, süreç kapanışı ve kuyruktaki kardeş görevleri koruma senaryoları testlidir.
- **Tam metin arama:** üst çubuktaki arama simgesi. Mevcut proje veya Claude profilindeki tüm projeler; mesaj/araç komutu/çıktı metninde arama, mesaja gitme ve devam sayfaları. Yalnızca istek üzerine çalışır; dosyalar ve dizinler sınırlı adımlarla okunur.
- **Görev şablonları:** mesaj kutusu altında. Proje bazında talimat, model, düşünme seviyesi ve dosya/klasör başvuruları kaydedilir. Seçilen şablon önce düzenlenebilir önizleme açar, açık yükleme eylemiyle mevcut taslağın yerine geçer; kendiliğinden gönderilmez. En fazla 50 şablon. Görseller şablona kaydedilmez.
- **Bağlam önizlemesi:** talimat/seçili metin ve eklerin yaklaşık boyutu, dosya/klasör ayrımı; ek çıkarma ve ayarlanabilir uyarı eşiği. Dosya içerikleri okunmadan boyut bilgisi alınır.
- **Yer imleri ve karar notları:** mesaj yanındaki yer imi simgesi ve arama panelindeki liste. Yerel ayrı dosyada saklanır; Claude'un ham JSONL kaydını değiştirmez.
- **Türkçe:** Ayarlar → Genel → Dil → Türkçe. Mevcut dil tercihi değiştirilmez; tüm uygulama çeviri katalogları tamamlandı. Claude CLI'nın kendi model açıklamaları gibi sağlayıcıdan gelen metinler kendi dilinde kalabilir.

## Doğrulamanın kapsamı

- Backend: 180 dosyada **2.071 test geçti**, 8 test mevcut koşulları nedeniyle atlandı.
- WebView: 356 dosyada **3.403 test geçti**; son arama arayüzü değişikliğinden sonra konuşma araçları ve dil eşliği için **57 odaklı test de geçti**.
- Kotlin: tam pakette **425 test geçti**; son iki adlandırma düzeltmesinden sonra ilgili **26 test tekrar geçti**.
- Backend ve WebView TypeScript kontrolleri geçti. `git diff --check` temiz.
- Üretim ZIP derlendi; ZIP bütünlüğü, plugin kimliği/adı/sürümü, paket içindeki backend ile derlenen backend'in eşliği ve WebView sürümü doğrulandı: **0.31.0**.
- JetBrains Plugin Verifier 1.410: **IC-242.26775.15 (2024.2.6)** ve **IU-262.8117.19 (2026.2 EAP)** üzerinde **Compatible**. İki mevcut `requestOpenFile` deneysel API uyarısı her iki sürümde sürüyor. IC tarafında isteğe bağlı JCEF modül bağımlılığı çözümlenemedi bildirimi var; doğrulayıcı yine uyumlu sonucunu verdi. Bu kontrol gerçek IDE/JCEF çalışma testi değildir.
- İlk paket doğrulamasında `ş` içeren kayıt adı ve kısa ilk açıklama satırı reddedildi. Paket kayıt adı ASCII'ye çevrildi, açıklama düzeltildi; yukarıdaki başarılı sonuç yeniden derlenen son pakete aittir.

Gerçek tarayıcıda izole yerel backend ve sentetik konuşma profili kullanıldı. Yeni sekme, aramadan mesaja dönüş, kalıcı yer imi/not, şablon kaydetme/düzenleyerek yükleme, bağlam önizlemesi ve 450 piksel dar panel görünümü kontrol edildi. Kullanıcının gerçek sohbetlerine/ayarlarına veya ücretli Claude çağrılarına dokunulmadı.

## Bilinen sınırlar

- Düşük kaynak modu, JCEF tarayıcısını veya mesaj DOM'unu bellekten tamamen kaldırmaz. İlk mesaj yükleme maliyeti sürer. Gerçek IDE üzerinde CPU/RAM karşılaştırma profili çıkarılmadığından yüzde hızlanma ya da bellek kazanımı iddiası yoktur.
- Görev sınırı bu projenin backend'indeki aktif turları kapsar; boşta tutulan CLI süreçlerini, diğer projeleri veya CLI içi alt görevleri kapsamaz. Çalışan görevi durdurmak önceden yapılmış dosya değişikliklerini geri almaz.
- Kaynak ölçümünde ilk CPU örneği için ikinci ölçüm gerekir. Windows'ta CLI süreç ağacı ölçümleri desteklenmediğinde kullanılamaz gösterilir; backend'in kendi ölçümleri kullanılabilir.
- Arama tam ifadeyi büyük/küçük harf ayrımı olmadan eşleştirir; semantik arama değildir. Çok büyük satırlar (8 MiB üzeri) atlanıp sayılır. En fazla 20.000 dosya keşfedilir. Aşırı araç kimliği biriktiren bir dosyada kalan bölüm de sınırlandırılır; kısmi sonuç ve atlanan kayıtlar UI'da bildirilir. Önbellek en fazla 512 dosya ve yaklaşık 8 MiB metin/metadata bütçesiyle tutulur. Devam imleçleri 5 dakika geçerli; sonuçlar yeniden arama ile yenilenir.
- Bağlam tahmini bayt/4 yaklaşımıdır. Klasör içerikleri, görseller, metindeki @başvuruları, sohbet geçmişi, sistem talimatları ve sonradan okunan dosyalar hesaba katılmaz. Kesin token, ücret veya tam bağlam penceresi hesabı değildir.
- Sponsorluk koşulu yerel özelliklerden kaldırılmıştır. Claude hesap doğrulaması, sağlayıcı abonelikleri ve kullanım ücretleri korunur.

## Kaynak ve kurulum

`COMMUNITY_NOTICE.md`, `LICENSE`, `AI_BRIDGE_PLAN_TR.md` ve ilgili kaynak ZIP birlikte sağlanır. Upstream yazarları/telif ve AGPL-3.0 korunur. Marketplace yayını veya kullanıcı IDE'sine kurulum yapılmaz.
