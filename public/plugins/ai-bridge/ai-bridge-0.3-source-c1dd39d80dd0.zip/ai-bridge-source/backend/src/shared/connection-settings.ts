export const CONNECTION_ENV_KEYS = ['ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL', 'ANTHROPIC_MODEL'] as const;
export type ConnectionEnvKey = typeof CONNECTION_ENV_KEYS[number];
export type ConnectionEnv = Record<ConnectionEnvKey, string>;
export type ConnectionTestCode = 'connected' | 'invalidUrl' | 'missingToken' | 'missingModel' |
  'unauthorized' | 'forbidden' | 'notFound' | 'modelError' | 'rateLimited' | 'serverError' |
  'redirect' | 'unexpectedResponse' | 'timeout' | 'tlsError' | 'unreachable';
export interface ConnectionTestResult {
  code: ConnectionTestCode;
  httpStatus?: number;
}
