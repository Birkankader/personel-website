export interface ContextFilePreview {
  path: string;
  bytes: number | null;
  /** Potential full-file read estimate; never add this to the outgoing prompt. */
  estimatedTokens: number | null;
  kind: 'file' | 'folder' | 'unavailable';
}

/** A deliberately approximate payload estimate, not a provider tokenizer. */
export function estimateTextTokens(text: string): number {
  return Math.ceil(new TextEncoder().encode(text).length / 4);
}
