export interface ConversationTarget {
  workingDir: string;
  sessionId: string;
  messageUuid: string;
}

export interface ConversationSearchResult extends ConversationTarget {
  sourceMessageUuid: string;
  title: string;
  role: string;
  timestamp?: string;
  snippet: string;
}

export interface ConversationSearchPage {
  results: ConversationSearchResult[];
  nextCursor: string | null;
  scannedFiles: number;
  totalFiles: number;
  skippedEntries: number;
  scopeTruncated: boolean;
}

export interface ConversationAnnotation extends ConversationTarget {
  bookmarked: boolean;
  note: string;
  updatedAt: string;
}

export interface ConversationAnnotationPage {
  annotations: ConversationAnnotation[];
  nextOffset: number | null;
}
