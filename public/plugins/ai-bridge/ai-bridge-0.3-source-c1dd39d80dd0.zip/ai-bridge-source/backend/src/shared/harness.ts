/**
 * Agent runtimes ("harnesses") a chat can run on.
 *
 * `claude` is the Claude Code CLI itself. The others are third-party agents that
 * speak the Agent Client Protocol (ACP) over stdio; the backend runs them through
 * its ACP bridge, which presents them to the rest of the plugin as a Claude-style
 * stream-json process. Each one is started with the official command its own
 * users would type in a terminal — nothing here depends on an SDK.
 *
 * Mirrored 1:1 between backend/src/shared and webview/src/shared.
 */
export const HARNESS_IDS = ['claude', 'opencode', 'deepseek'] as const;
export type HarnessId = typeof HARNESS_IDS[number];
export type AcpHarnessId = Exclude<HarnessId, 'claude'>;

export const DEFAULT_HARNESS: HarnessId = 'claude';

export function isHarnessId(value: unknown): value is HarnessId {
  return typeof value === 'string' && (HARNESS_IDS as readonly string[]).includes(value);
}

export function isAcpHarness(value: unknown): value is AcpHarnessId {
  return isHarnessId(value) && value !== 'claude';
}

/** Product names, shown as-is in every UI language. */
export const HARNESS_LABELS: Record<HarnessId, string> = {
  claude: 'Claude Code',
  opencode: 'OpenCode',
  deepseek: 'DeepSeek Harness',
};

/** The command that serves each harness over ACP stdio, as documented by its project. */
export const HARNESS_ACP_COMMANDS: Record<AcpHarnessId, readonly string[]> = {
  opencode: ['opencode', 'acp'],
  deepseek: ['dsh', '--profile', 'acp'],
};

/** Where users install each harness from, for "not found" guidance. */
export const HARNESS_INSTALL_HINTS: Record<AcpHarnessId, string> = {
  opencode: 'npm install -g @opencode/cli',
  deepseek: 'npm install -g @deepseek-ai/dsh',
};

/**
 * The npm package each harness ships as, built by its project from its GitHub
 * repository. AI Bridge installs this into its own data directory when the
 * harness is missing; it is also what the install hints above name.
 */
export const HARNESS_NPM_PACKAGES: Record<AcpHarnessId, string> = {
  opencode: '@opencode/cli',
  deepseek: '@deepseek-ai/dsh',
};

/**
 * Where a harness was found:
 * - `setting`: the location the user entered in Settings (`harnessPaths`)
 * - `env`: the `AI_BRIDGE_HARNESS_COMMAND` environment override
 * - `managed`: the copy AI Bridge installed under `~/.ai-bridge/harnesses`
 * - `path`: the command on PATH, as a terminal would run it
 */
export type HarnessSource = 'setting' | 'env' | 'managed' | 'path';

/** One row of the Connection page's harness list (GET_HARNESS_STATUS). */
export interface HarnessStatus {
  harness: HarnessId;
  installed: boolean;
  source?: HarnessSource;
  /** The executable, script or source folder that runs. */
  location?: string;
  /** First line of `<command> --version`. */
  version?: string;
  /** Why a configured location or the version probe failed. */
  error?: string;
  /** AI Bridge can install it with one click (HARNESS_NPM_PACKAGES). */
  installable: boolean;
}
