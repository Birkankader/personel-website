/**
 * Classification of the API failures the CLI reports, shared so the backend's
 * automatic recovery and the webview's rendering of the same failure can never
 * disagree about what is temporary.
 *
 * NOTE: This file is mirrored 1:1 in `webview/src/shared/api-failure.ts`.
 * Any edit here MUST be copied there (see `shared/CLAUDE.md`).
 */

/**
 * - `network`: the connection to the provider broke (socket closed, reset,
 *   timed out, stalled stream). Retried quickly.
 * - `server`: the provider answered with a 5xx / overloaded error. Retried
 *   with a longer backoff.
 * - `rate`: a 429 without a quota reset time. Retried after the provider's delay.
 * - `context`: the conversation no longer fits the model. Recovered by compaction.
 */
export type ApiFailureKind = 'network' | 'server' | 'rate' | 'context';

/**
 * The prompt sent to resume an interrupted turn, automatically by recovery or
 * from the error banner's retry action. It tells the model why the reply
 * stopped, so it continues instead of starting over.
 *
 * The exact text is also how the webview recognizes the message — live and
 * after a reload — and shows it as a slim notice instead of a user bubble.
 * Changing it orphans the recognition of messages already in transcripts, so
 * keep the old text in {@link AUTO_CONTINUE_PROMPTS} when it changes.
 */
export const AUTO_CONTINUE_PROMPT =
  'Continue from where you left off. (The previous response was interrupted by a temporary connection or API error.)';

/** Every text ever sent as {@link AUTO_CONTINUE_PROMPT}. */
export const AUTO_CONTINUE_PROMPTS: readonly string[] = [AUTO_CONTINUE_PROMPT];

export function isAutoContinuePrompt(text: string | null | undefined): boolean {
  return typeof text === 'string' && AUTO_CONTINUE_PROMPTS.includes(text.trim());
}

const CONTEXT_FAILURE =
  /maximum context|context.{0,30}(?:exceed|length|window|limit)|prompt.{0,20}too long|input.{0,20}too long|context_length_exceeded/i;

/**
 * Transport failures across CLI versions and runtimes: Bun's fetch ("The socket
 * connection was closed unexpectedly"), the CLI's own wording ("Connection
 * closed mid-response", "Connection to the API was lost (ECONNRESET)",
 * "Response stalled mid-stream"), the SDK's "Connection error." and Node/undici
 * codes for CLIs running on Node.
 */
const NETWORK_FAILURE = new RegExp([
  'socket connection was closed',
  'socket hang ?up',
  'connection (?:was )?(?:closed|lost|reset|refused|aborted|dropped)',
  'connection to the api was lost',
  'connection error',
  'closed (?:mid-response|while thinking)',
  'stalled (?:mid-stream|while thinking)',
  'stream idle timeout',
  'request timed out',
  'timed out',
  'fetch failed',
  'failed to fetch',
  'network (?:error|is unreachable|is down)',
  'other side closed',
  '\\bterminated\\b',
  'unable to connect to (?:the )?api',
  'ECONNRESET', 'ECONNREFUSED', 'ECONNABORTED', 'ETIMEDOUT', 'EPIPE', 'ENOTFOUND', 'EAI_AGAIN',
  'ENETUNREACH', 'ENETDOWN', 'EHOSTUNREACH', 'EHOSTDOWN',
  'ConnectionClosed', 'ConnectionRefused', 'FailedToOpenSocket', 'ERR_SOCKET_CLOSED',
  'UND_ERR_[A-Z_]+', 'StreamSuspended', 'ERR_PROXY_TUNNEL',
].join('|'), 'i');

/** Provider-side failures whose envelope carried no parseable status. */
const SERVER_FAILURE =
  /overloaded|server error|bad gateway|service unavailable|gateway time-?out|\b(?:500|502|503|504|529)\b/i;

/** Certificate and TLS trust problems do not fix themselves; retrying only delays the real advice. */
const TRUST_FAILURE = /certificate|\bSSL\b|\bTLS\b|self[- ]signed|CERT_|HOSTNAME_MISMATCH/i;

/** Error codes the CLI attaches to a synthetic API-error assistant message, or the API's own error types. */
const SERVER_CODES = new Set(['server_error', 'api_error', 'overloaded_error']);
const RATE_CODES = new Set(['rate_limit', 'rate_limit_error']);

/**
 * Classify one API failure from its text, the CLI's error code and the HTTP
 * status when known. Returns null for failures that must not be retried
 * automatically (authentication, billing, invalid requests, trust errors).
 *
 * The caller decides whether the text belongs to an API failure at all: quoted
 * errors in ordinary replies and failed tool results are never passed here.
 */
export function classifyApiFailure(text: string, code?: unknown, status?: number): ApiFailureKind | null {
  const knownStatus = typeof status === 'number' && Number.isFinite(status);
  if ((!knownStatus || status === 400 || status === 413) && CONTEXT_FAILURE.test(text)) return 'context';
  if (knownStatus && status >= 500 && status <= 599) return 'server';
  if ((knownStatus && status === 429) || RATE_CODES.has(String(code))) return 'rate';
  if (knownStatus && status === 408) return 'network';
  // A status says what the provider answered; only transport failures have none.
  if (knownStatus) return null;
  if (TRUST_FAILURE.test(text)) return null;
  if (NETWORK_FAILURE.test(text)) return 'network';
  if (SERVER_CODES.has(String(code)) || SERVER_FAILURE.test(text)) return 'server';
  return null;
}
