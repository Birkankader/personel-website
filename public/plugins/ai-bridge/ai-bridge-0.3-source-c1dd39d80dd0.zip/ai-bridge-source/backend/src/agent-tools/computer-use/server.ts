import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import { CallToolRequestSchema, ListToolsRequestSchema } from '@modelcontextprotocol/sdk/types.js';
import { createDriver, fitInside, MODIFIERS, parseKeyCombo, type Driver, type MouseButton } from './driver';

/**
 * Experimental computer use as a local stdio MCP server.
 *
 * The Claude CLI's own computer use is macOS-only and not available to the
 * harnesses at all, so this is ours: a plain MCP server any agent can load —
 * Claude through `--mcp-config`, an ACP harness through the session's
 * `mcpServers`. Every tool is an ordinary MCP tool, so the agent's usual
 * permission prompt applies to each action.
 *
 * Coordinates in and out are in the pixels of the last screenshot the model
 * received (scaled to fit 1280×800); the server converts them to the screen's.
 */
export const COMPUTER_USE_SERVER_NAME = 'ai-bridge-computer-use';

const MAX_WIDTH = 1280;
const MAX_HEIGHT = 800;
const MAX_TEXT = 5000;

type Args = Record<string, unknown>;

const point = (description: string) => ({
  type: 'object',
  properties: {
    x: { type: 'number', description: `${description} x, in screenshot pixels` },
    y: { type: 'number', description: `${description} y, in screenshot pixels` },
  },
});

const clickSchema = {
  type: 'object',
  properties: {
    x: { type: 'number', description: 'Target x in screenshot pixels. Omit to click where the cursor is.' },
    y: { type: 'number', description: 'Target y in screenshot pixels. Omit to click where the cursor is.' },
    modifiers: { type: 'string', description: 'Keys held during the click, e.g. "ctrl" or "ctrl+shift".' },
  },
};

export const TOOLS = [
  {
    name: 'screenshot',
    description: 'Capture the primary screen. Returns a PNG scaled to fit 1280x800; every other tool takes coordinates in this image\'s pixels.',
    inputSchema: { type: 'object', properties: {} },
  },
  { name: 'cursor_position', description: 'Report the mouse position in screenshot pixels.', inputSchema: { type: 'object', properties: {} } },
  { name: 'mouse_move', description: 'Move the mouse.', inputSchema: { ...point('Target'), required: ['x', 'y'] } },
  { name: 'left_click', description: 'Left-click, optionally after moving to (x, y).', inputSchema: clickSchema },
  { name: 'right_click', description: 'Right-click, optionally after moving to (x, y).', inputSchema: clickSchema },
  { name: 'middle_click', description: 'Middle-click, optionally after moving to (x, y).', inputSchema: clickSchema },
  { name: 'double_click', description: 'Double-click, optionally after moving to (x, y).', inputSchema: clickSchema },
  { name: 'triple_click', description: 'Triple-click (select a line), optionally after moving to (x, y).', inputSchema: clickSchema },
  {
    name: 'left_click_drag',
    description: 'Press the left button at (start_x, start_y), drag to (x, y) and release.',
    inputSchema: {
      type: 'object',
      properties: {
        start_x: { type: 'number' }, start_y: { type: 'number' }, x: { type: 'number' }, y: { type: 'number' },
      },
      required: ['start_x', 'start_y', 'x', 'y'],
    },
  },
  {
    name: 'scroll',
    description: 'Scroll the mouse wheel, optionally after moving to (x, y).',
    inputSchema: {
      type: 'object',
      properties: {
        x: { type: 'number' }, y: { type: 'number' },
        direction: { type: 'string', enum: ['up', 'down', 'left', 'right'] },
        amount: { type: 'number', description: 'Wheel notches, 1-20 (default 3).' },
      },
      required: ['direction'],
    },
  },
  {
    name: 'type',
    description: 'Type text into the focused window, as if from the keyboard.',
    inputSchema: { type: 'object', properties: { text: { type: 'string' } }, required: ['text'] },
  },
  {
    name: 'key',
    description: 'Press a key or combination, e.g. "enter", "ctrl+c", "alt+tab", "ctrl+shift+t".',
    inputSchema: { type: 'object', properties: { keys: { type: 'string' } }, required: ['keys'] },
  },
  {
    name: 'wait',
    description: 'Wait before the next action, e.g. for a window to open.',
    inputSchema: { type: 'object', properties: { seconds: { type: 'number', description: '0.1-30' } }, required: ['seconds'] },
  },
];

function num(value: unknown, name: string): number {
  if (typeof value !== 'number' || !Number.isFinite(value)) throw new Error(`${name} must be a number`);
  return value;
}

function optionalPoint(args: Args): { x: number; y: number } | null {
  if (args.x === undefined && args.y === undefined) return null;
  return { x: num(args.x, 'x'), y: num(args.y, 'y') };
}

const text = (value: string) => ({ content: [{ type: 'text', text: value }] });

/** Runs one tool. Exported for tests with a fake driver. */
export class ComputerUse {
  constructor(private readonly driver: Driver) {}

  /** Screenshot pixels → screen coordinates, against the current screen size. */
  private async toScreen(p: { x: number; y: number }): Promise<{ x: number; y: number }> {
    const screen = await this.driver.screenSize();
    const shot = fitInside(screen, MAX_WIDTH, MAX_HEIGHT);
    const x = Math.round(p.x * screen.width / shot.width);
    const y = Math.round(p.y * screen.height / shot.height);
    if (x < 0 || y < 0 || x >= screen.width || y >= screen.height) {
      throw new Error(`(${p.x}, ${p.y}) is outside the ${shot.width}x${shot.height} screenshot`);
    }
    return { x, y };
  }

  private async toShot(p: { x: number; y: number }): Promise<{ x: number; y: number }> {
    const screen = await this.driver.screenSize();
    const shot = fitInside(screen, MAX_WIDTH, MAX_HEIGHT);
    return { x: Math.round(p.x * shot.width / screen.width), y: Math.round(p.y * shot.height / screen.height) };
  }

  private async moveIfGiven(args: Args): Promise<void> {
    const target = optionalPoint(args);
    if (target) {
      const screen = await this.toScreen(target);
      await this.driver.moveMouse(screen.x, screen.y);
    }
  }

  private async click(args: Args, button: MouseButton, count: number) {
    const modifiers = typeof args.modifiers === 'string' && args.modifiers ? parseKeyCombo(args.modifiers) : [];
    const unknown = modifiers.filter(m => !MODIFIERS.has(m));
    if (unknown.length) throw new Error(`Not a modifier key: ${unknown.join(', ')}`);
    await this.moveIfGiven(args);
    await this.driver.click(button, count, modifiers);
    return text('Clicked.');
  }

  async call(name: string, args: Args): Promise<{ content: Array<Record<string, unknown>>; isError?: boolean }> {
    switch (name) {
      case 'screenshot': {
        const shot = await this.driver.screenshot(MAX_WIDTH, MAX_HEIGHT);
        return {
          content: [
            { type: 'image', data: shot.data, mimeType: 'image/png' },
            { type: 'text', text: `Screenshot ${shot.width}x${shot.height}. Use these pixel coordinates for the other tools.` },
          ],
        };
      }
      case 'cursor_position': {
        const p = await this.toShot(await this.driver.cursorPosition());
        return text(JSON.stringify(p));
      }
      case 'mouse_move': {
        const p = await this.toScreen({ x: num(args.x, 'x'), y: num(args.y, 'y') });
        await this.driver.moveMouse(p.x, p.y);
        return text('Moved.');
      }
      case 'left_click': return this.click(args, 'left', 1);
      case 'right_click': return this.click(args, 'right', 1);
      case 'middle_click': return this.click(args, 'middle', 1);
      case 'double_click': return this.click(args, 'left', 2);
      case 'triple_click': return this.click(args, 'left', 3);
      case 'left_click_drag': {
        const from = await this.toScreen({ x: num(args.start_x, 'start_x'), y: num(args.start_y, 'start_y') });
        const to = await this.toScreen({ x: num(args.x, 'x'), y: num(args.y, 'y') });
        await this.driver.moveMouse(from.x, from.y);
        await this.driver.mouseButton('left', true);
        try {
          await this.driver.moveMouse(Math.round((from.x + to.x) / 2), Math.round((from.y + to.y) / 2));
          await this.driver.moveMouse(to.x, to.y);
        } finally {
          await this.driver.mouseButton('left', false);
        }
        return text('Dragged.');
      }
      case 'scroll': {
        const amount = Math.min(20, Math.max(1, Math.round(typeof args.amount === 'number' ? args.amount : 3)));
        await this.moveIfGiven(args);
        const direction = String(args.direction);
        const dy = direction === 'down' ? amount : direction === 'up' ? -amount : 0;
        const dx = direction === 'right' ? amount : direction === 'left' ? -amount : 0;
        if (!dx && !dy) throw new Error('direction must be up, down, left or right');
        await this.driver.scroll(dx, dy);
        return text('Scrolled.');
      }
      case 'type': {
        if (typeof args.text !== 'string') throw new Error('text must be a string');
        if (args.text.length > MAX_TEXT) throw new Error(`text is limited to ${MAX_TEXT} characters per call`);
        await this.driver.typeText(args.text);
        return text('Typed.');
      }
      case 'key': {
        if (typeof args.keys !== 'string' || !args.keys.trim()) throw new Error('keys must be a key name such as "enter" or "ctrl+c"');
        await this.driver.pressKeys(parseKeyCombo(args.keys));
        return text('Pressed.');
      }
      case 'wait': {
        const seconds = Math.min(30, Math.max(0.1, num(args.seconds, 'seconds')));
        await new Promise(r => setTimeout(r, seconds * 1000));
        return text(`Waited ${seconds}s.`);
      }
      default:
        throw new Error(`Unknown tool: ${name}`);
    }
  }
}

export async function runComputerUseServer(): Promise<void> {
  const driver = await createDriver();
  const tools = new ComputerUse(driver);
  const server = new Server({ name: COMPUTER_USE_SERVER_NAME, version: '1.0.0' }, { capabilities: { tools: {} } });
  server.setRequestHandler(ListToolsRequestSchema, async () => ({ tools: TOOLS }));
  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    try {
      return await tools.call(request.params.name, (request.params.arguments ?? {}) as Args);
    } catch (error) {
      return { content: [{ type: 'text', text: error instanceof Error ? error.message : String(error) }], isError: true };
    }
  });
  const transport = new StdioServerTransport();
  const stop = () => { driver.close(); process.exit(0); };
  process.stdin.on('end', stop);
  process.on('SIGTERM', stop);
  await server.connect(transport);
}
