/**
 * agent-tools.mjs — helper processes the backend starts next to the chat.
 *
 *   node agent-tools.mjs acp-bridge --harness <id> [claude flags...]
 *       Runs a third-party agent over ACP while speaking the Claude CLI's
 *       stream-json protocol on stdio (see acp/bridge.ts).
 *
 *   node agent-tools.mjs computer-use-mcp
 *       A stdio MCP server exposing screenshot / mouse / keyboard tools
 *       (see computer-use/server.ts).
 *
 * Kept out of backend.mjs because each runs as its own child process, under the
 * same supervision (job object, process group) as the CLI it stands beside.
 */
import { AcpBridge } from './acp/bridge';
import { harnessAgentEnv, parseBridgeArgs } from './acp/translate';
import { HARNESS_ACP_COMMANDS, isAcpHarness } from '../shared';

function harnessCommand(harness: keyof typeof HARNESS_ACP_COMMANDS): readonly string[] {
  // An override for a harness installed off PATH, as a JSON array (`["C:/tools/opencode.exe","acp"]`).
  const override = process.env.AI_BRIDGE_HARNESS_COMMAND;
  if (override) {
    try {
      const parsed = JSON.parse(override) as unknown;
      if (Array.isArray(parsed) && parsed.length > 0 && parsed.every(p => typeof p === 'string')) return parsed as string[];
    } catch {
      process.stderr.write('[acp-bridge] ignoring malformed AI_BRIDGE_HARNESS_COMMAND\n');
    }
  }
  return HARNESS_ACP_COMMANDS[harness];
}

/**
 * MCP servers the backend asks us to hand the harness session, in ACP's
 * `McpServer` (stdio) shape. Today that is only the computer-use server.
 */
function sessionMcpServers(): unknown[] {
  const raw = process.env.AI_BRIDGE_COMPUTER_USE_MCP;
  if (!raw) return [];
  try {
    const server = JSON.parse(raw) as { name: string; command: string; args: string[] };
    return [{ name: server.name, command: server.command, args: server.args, env: [] }];
  } catch {
    process.stderr.write('[acp-bridge] ignoring malformed AI_BRIDGE_COMPUTER_USE_MCP\n');
    return [];
  }
}

async function main(): Promise<void> {
  const [tool, ...rest] = process.argv.slice(2);
  if (tool === 'acp-bridge') {
    const index = rest.indexOf('--harness');
    const harness = index >= 0 ? rest[index + 1] : undefined;
    if (!isAcpHarness(harness)) {
      process.stderr.write(`[acp-bridge] unknown harness: ${String(harness)}\n`);
      process.exit(2);
    }
    // This process exists only for the bridge, so the agent inherits it as-is.
    Object.assign(process.env, harnessAgentEnv(harness, process.env));
    new AcpBridge({
      harness,
      agentCommand: harnessCommand(harness),
      cwd: process.cwd(),
      args: parseBridgeArgs(rest, process.env),
      input: process.stdin,
      output: process.stdout,
      mcpServers: sessionMcpServers(),
    });
    return;
  }
  if (tool === 'computer-use-mcp') {
    const { runComputerUseServer } = await import('./computer-use/server');
    await runComputerUseServer();
    return;
  }
  process.stderr.write('usage: agent-tools.mjs <acp-bridge|computer-use-mcp> [...]\n');
  process.exit(2);
}

main().catch((error) => {
  process.stderr.write(`[agent-tools] ${error instanceof Error ? error.stack ?? error.message : String(error)}\n`);
  process.exit(1);
});
