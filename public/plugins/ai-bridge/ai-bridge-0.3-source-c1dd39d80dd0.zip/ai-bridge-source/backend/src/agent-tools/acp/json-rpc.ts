import { StringDecoder } from 'string_decoder';
import type { Readable, Writable } from 'stream';

/**
 * A minimal JSON-RPC 2.0 peer over newline-delimited stdio, which is the whole
 * transport the Agent Client Protocol defines. Hand-written on purpose: the
 * protocol is a public spec, and the bridge must not depend on any agent
 * vendor's SDK (CLAUDE.md principle 2).
 */
export interface RpcError {
  code: number;
  message: string;
  data?: unknown;
}

export class RpcRequestError extends Error {
  constructor(readonly error: RpcError) {
    super(error.message);
  }
}

type RequestHandler = (method: string, params: unknown) => Promise<unknown>;
type NotificationHandler = (method: string, params: unknown) => void;

export const METHOD_NOT_FOUND = -32601;

export class JsonRpcPeer {
  private nextId = 1;
  private readonly pending = new Map<number | string, { resolve: (v: unknown) => void; reject: (e: Error) => void }>();
  private readonly decoder = new StringDecoder('utf8');
  private buffer = '';
  private closed = false;

  constructor(
    input: Readable,
    private readonly output: Writable,
    private readonly onRequest: RequestHandler,
    private readonly onNotification: NotificationHandler,
    private readonly log: (message: string) => void = () => {},
  ) {
    input.on('data', (chunk: Buffer) => this.consume(this.decoder.write(chunk)));
    input.on('end', () => {
      this.consume(this.decoder.end() + '\n');
      this.close(new Error('The agent closed its output.'));
    });
  }

  request<T = unknown>(method: string, params: unknown): Promise<T> {
    if (this.closed) return Promise.reject(new Error('The agent is not running.'));
    const id = this.nextId++;
    return new Promise<T>((resolve, reject) => {
      this.pending.set(id, { resolve: resolve as (v: unknown) => void, reject });
      this.write({ jsonrpc: '2.0', id, method, params });
    });
  }

  notify(method: string, params: unknown): void {
    if (!this.closed) this.write({ jsonrpc: '2.0', method, params });
  }

  /** Reject everything still waiting, e.g. when the agent process exits. */
  close(reason: Error): void {
    if (this.closed) return;
    this.closed = true;
    for (const { reject } of this.pending.values()) reject(reason);
    this.pending.clear();
  }

  private write(message: Record<string, unknown>): void {
    try {
      this.output.write(JSON.stringify(message) + '\n');
    } catch (error) {
      this.log(`write failed: ${error instanceof Error ? error.message : String(error)}`);
    }
  }

  private consume(text: string): void {
    this.buffer += text;
    let newline: number;
    while ((newline = this.buffer.indexOf('\n')) >= 0) {
      const line = this.buffer.slice(0, newline).trim();
      this.buffer = this.buffer.slice(newline + 1);
      if (line) this.dispatch(line);
    }
  }

  private dispatch(line: string): void {
    let message: Record<string, unknown>;
    try {
      message = JSON.parse(line) as Record<string, unknown>;
    } catch {
      // Agents may print banners or logs on stdout; they are not protocol.
      this.log(`non-JSON agent output: ${line.slice(0, 200)}`);
      return;
    }
    const id = message.id as number | string | undefined;
    const method = message.method as string | undefined;
    if (method === undefined && id !== undefined) {
      const waiter = this.pending.get(id);
      if (!waiter) return;
      this.pending.delete(id);
      if (message.error) waiter.reject(new RpcRequestError(message.error as RpcError));
      else waiter.resolve(message.result);
      return;
    }
    if (!method) return;
    if (id === undefined) {
      try {
        this.onNotification(method, message.params);
      } catch (error) {
        this.log(`notification ${method} failed: ${error instanceof Error ? error.stack : String(error)}`);
      }
      return;
    }
    this.onRequest(method, message.params).then(
      (result) => this.write({ jsonrpc: '2.0', id, result: result ?? null }),
      (error: unknown) => {
        const rpc = error instanceof RpcRequestError
          ? error.error
          : { code: -32603, message: error instanceof Error ? error.message : String(error) };
        this.write({ jsonrpc: '2.0', id, error: rpc });
      },
    );
  }
}
