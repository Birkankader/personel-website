import { execFile } from 'child_process';
import { mkdtempSync, readFileSync, rmSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { fitInside, type Driver, type MouseButton, type Screenshot, type ScreenSize } from './driver';

function run(command: string, args: string[], input?: string): Promise<string> {
  return new Promise((resolve, reject) => {
    const child = execFile(command, args, { maxBuffer: 64 * 1024 * 1024, encoding: 'utf8' }, (error, stdout, stderr) => {
      if (error) {
        const missing = (error as NodeJS.ErrnoException).code === 'ENOENT';
        reject(new Error(missing ? `${command} is not installed` : (stderr || error.message).trim()));
      } else {
        resolve(stdout);
      }
    });
    if (input !== undefined) child.stdin?.end(input);
  });
}

function withTempDir<T>(work: (dir: string) => Promise<T>): Promise<T> {
  const dir = mkdtempSync(join(tmpdir(), 'ai-bridge-cu-'));
  return work(dir).finally(() => rmSync(dir, { recursive: true, force: true }));
}

// ─── macOS ───────────────────────────────────────────────────────────────────

/**
 * macOS: `screencapture` for pixels, JXA (osascript -l JavaScript) with the
 * CoreGraphics bridge for the mouse and System Events for the keyboard.
 * Coordinates are points, the unit CGEvent uses. Needs Screen Recording and
 * Accessibility permission for the app that launched the backend.
 */
const MAC_KEY_CODES: Record<string, number> = {
  enter: 36, tab: 48, space: 49, backspace: 51, escape: 53, delete: 117, home: 115, end: 119,
  pageup: 116, pagedown: 121, left: 123, right: 124, down: 125, up: 126,
  f1: 122, f2: 120, f3: 99, f4: 118, f5: 96, f6: 97, f7: 98, f8: 100, f9: 101, f10: 109, f11: 103, f12: 111,
};
const MAC_MODIFIERS: Record<string, string> = { ctrl: 'control down', shift: 'shift down', alt: 'option down', meta: 'command down' };

export class MacDriver implements Driver {
  private jxa(script: string): Promise<string> {
    return run('osascript', ['-l', 'JavaScript', '-e', script]);
  }

  async screenSize(): Promise<ScreenSize> {
    const out = await this.jxa(`ObjC.import('AppKit'); var f = $.NSScreen.mainScreen.frame; JSON.stringify({w: f.size.width, h: f.size.height})`);
    const size = JSON.parse(out) as { w: number; h: number };
    return { width: Math.round(size.w), height: Math.round(size.h) };
  }

  async screenshot(maxWidth: number, maxHeight: number): Promise<Screenshot> {
    const target = fitInside(await this.screenSize(), maxWidth, maxHeight);
    return withTempDir(async (dir) => {
      const raw = join(dir, 'raw.png');
      const scaled = join(dir, 'scaled.png');
      await run('screencapture', ['-x', '-m', '-t', 'png', raw]);
      await run('sips', ['-z', String(target.height), String(target.width), raw, '--out', scaled]);
      return { data: readFileSync(scaled).toString('base64'), ...target };
    });
  }

  async cursorPosition(): Promise<{ x: number; y: number }> {
    const out = await this.jxa(`ObjC.import('CoreGraphics'); var p = $.CGEventGetLocation($.CGEventCreate(null)); JSON.stringify({x: p.x, y: p.y})`);
    const p = JSON.parse(out) as { x: number; y: number };
    return { x: Math.round(p.x), y: Math.round(p.y) };
  }

  private async mouseEvent(type: string, button: string, clickState = 1): Promise<void> {
    await this.jxa(`ObjC.import('CoreGraphics');
      var p = $.CGEventGetLocation($.CGEventCreate(null));
      var e = $.CGEventCreateMouseEvent(null, $.${type}, p, $.${button});
      $.CGEventSetIntegerValueField(e, $.kCGMouseEventClickState, ${clickState});
      $.CGEventPost($.kCGHIDEventTap, e);`);
  }

  async moveMouse(x: number, y: number): Promise<void> {
    await this.jxa(`ObjC.import('CoreGraphics');
      $.CGEventPost($.kCGHIDEventTap, $.CGEventCreateMouseEvent(null, $.kCGEventMouseMoved, $.CGPointMake(${x}, ${y}), $.kCGMouseButtonLeft));`);
  }

  async click(button: MouseButton, count: number, modifiers: string[]): Promise<void> {
    if (modifiers.length > 0) throw new Error('Modifier clicks are not supported on macOS yet.');
    for (let i = 1; i <= count; i++) {
      await this.mouseButton(button, true, i);
      await this.mouseButton(button, false, i);
    }
  }

  async mouseButton(button: MouseButton, down: boolean, clickState = 1): Promise<void> {
    const names = {
      left: ['kCGEventLeftMouseDown', 'kCGEventLeftMouseUp', 'kCGMouseButtonLeft'],
      right: ['kCGEventRightMouseDown', 'kCGEventRightMouseUp', 'kCGMouseButtonRight'],
      middle: ['kCGEventOtherMouseDown', 'kCGEventOtherMouseUp', 'kCGMouseButtonCenter'],
    }[button];
    await this.mouseEvent(down ? names[0] : names[1], names[2], clickState);
  }

  async scroll(dx: number, dy: number): Promise<void> {
    await this.jxa(`ObjC.import('CoreGraphics');
      $.CGEventPost($.kCGHIDEventTap, $.CGEventCreateScrollWheelEvent(null, $.kCGScrollEventUnitLine, 2, ${-dy}, ${-dx}));`);
  }

  async typeText(text: string): Promise<void> {
    await this.jxa(`Application('System Events').keystroke(${JSON.stringify(text)})`);
  }

  async pressKeys(keys: string[]): Promise<void> {
    const using = keys.filter(k => MAC_MODIFIERS[k]).map(k => MAC_MODIFIERS[k]);
    const main = keys.filter(k => !MAC_MODIFIERS[k]);
    if (main.length !== 1) throw new Error('Press one key, optionally with modifiers (e.g. cmd+c).');
    const key = main[0];
    const opts = using.length ? `, {using: ${JSON.stringify(using)}}` : '';
    const code = MAC_KEY_CODES[key];
    if (code !== undefined) await this.jxa(`Application('System Events').keyCode(${code}${opts})`);
    else if (key.length === 1) await this.jxa(`Application('System Events').keystroke(${JSON.stringify(key)}${opts})`);
    else throw new Error(`Unknown key: ${key}`);
  }

  close(): void {}
}

// ─── Linux ───────────────────────────────────────────────────────────────────

/**
 * Linux (X11): xdotool for input, and the first screenshot tool found among
 * ImageMagick's `import`, `gnome-screenshot` and `grim` (Wayland). Scaling uses
 * ImageMagick when present; without it the screenshot is sent at full size.
 */
const XDOTOOL_KEYS: Record<string, string> = {
  enter: 'Return', tab: 'Tab', escape: 'Escape', backspace: 'BackSpace', delete: 'Delete', space: 'space',
  up: 'Up', down: 'Down', left: 'Left', right: 'Right', home: 'Home', end: 'End', pageup: 'Prior', pagedown: 'Next',
  insert: 'Insert', ctrl: 'ctrl', shift: 'shift', alt: 'alt', meta: 'super',
};

export class LinuxDriver implements Driver {
  async screenSize(): Promise<ScreenSize> {
    const [w, h] = (await run('xdotool', ['getdisplaygeometry'])).trim().split(/\s+/).map(Number);
    return { width: w, height: h };
  }

  async screenshot(maxWidth: number, maxHeight: number): Promise<Screenshot> {
    const screen = await this.screenSize();
    const target = fitInside(screen, maxWidth, maxHeight);
    return withTempDir(async (dir) => {
      const raw = join(dir, 'raw.png');
      const attempts: Array<[string, string[]]> = [
        ['import', ['-window', 'root', raw]],
        ['gnome-screenshot', ['-f', raw]],
        ['grim', [raw]],
      ];
      let captured = false;
      for (const [command, args] of attempts) {
        try { await run(command, args); captured = true; break; } catch { /* next tool */ }
      }
      if (!captured) throw new Error('No screenshot tool found. Install ImageMagick (import), gnome-screenshot or grim.');
      try {
        const scaled = join(dir, 'scaled.png');
        await run('convert', [raw, '-resize', `${target.width}x${target.height}!`, scaled]);
        return { data: readFileSync(scaled).toString('base64'), ...target };
      } catch {
        return { data: readFileSync(raw).toString('base64'), ...screen };
      }
    });
  }

  async cursorPosition(): Promise<{ x: number; y: number }> {
    const out = await run('xdotool', ['getmouselocation', '--shell']);
    const x = Number(/X=(\d+)/.exec(out)?.[1]);
    const y = Number(/Y=(\d+)/.exec(out)?.[1]);
    return { x, y };
  }

  async moveMouse(x: number, y: number): Promise<void> {
    await run('xdotool', ['mousemove', String(x), String(y)]);
  }

  async click(button: MouseButton, count: number, modifiers: string[]): Promise<void> {
    const mods = modifiers.map(m => XDOTOOL_KEYS[m] ?? m);
    for (const m of mods) await run('xdotool', ['keydown', m]);
    try {
      await run('xdotool', ['click', '--repeat', String(count), String({ left: 1, middle: 2, right: 3 }[button])]);
    } finally {
      for (const m of mods.reverse()) await run('xdotool', ['keyup', m]);
    }
  }

  async mouseButton(button: MouseButton, down: boolean): Promise<void> {
    await run('xdotool', [down ? 'mousedown' : 'mouseup', String({ left: 1, middle: 2, right: 3 }[button])]);
  }

  async scroll(dx: number, dy: number): Promise<void> {
    if (dy) await run('xdotool', ['click', '--repeat', String(Math.abs(dy)), dy > 0 ? '5' : '4']);
    if (dx) await run('xdotool', ['click', '--repeat', String(Math.abs(dx)), dx > 0 ? '7' : '6']);
  }

  async typeText(text: string): Promise<void> {
    await run('xdotool', ['type', '--delay', '5', '--', text]);
  }

  async pressKeys(keys: string[]): Promise<void> {
    await run('xdotool', ['key', '--', keys.map(k => XDOTOOL_KEYS[k] ?? k).join('+')]);
  }

  close(): void {}
}
