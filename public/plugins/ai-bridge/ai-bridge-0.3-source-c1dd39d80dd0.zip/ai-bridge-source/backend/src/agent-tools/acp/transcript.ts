import { appendFileSync, existsSync, mkdirSync, readFileSync } from 'fs';
import { dirname, join } from 'path';
import { randomUUID } from 'crypto';
import {
  getHarnessSessionsPath,
  HARNESS_META_TYPE,
  parseHarnessMeta,
  type HarnessSessionMeta,
} from '../../core/features/harness-sessions';
import type { AcpHarnessId } from '../../shared';

/**
 * The bridge's record of one conversation, appended entry by entry in the
 * Claude CLI's transcript shape (`type`, `uuid`, `parentUuid`, `message`, ...),
 * which is what the session list and history loader already read. Every entry
 * the chat saw live is the entry written here, so a reload shows the same thing.
 */
export class HarnessTranscript {
  readonly file: string;
  private lastUuid: string | null = null;
  private meta: HarnessSessionMeta | null = null;

  constructor(
    readonly harness: AcpHarnessId,
    readonly sessionId: string,
    readonly cwd: string,
    private readonly disabled = false,
  ) {
    this.file = join(getHarnessSessionsPath(cwd), `${sessionId}.jsonl`);
    if (!disabled && existsSync(this.file)) {
      const text = readFileSync(this.file, 'utf8');
      this.meta = parseHarnessMeta(text);
      this.lastUuid = lastConversationUuid(text);
    }
  }

  get exists(): boolean {
    return this.meta !== null;
  }

  get agentSessionId(): string | undefined {
    return this.meta?.agentSessionId;
  }

  /** Record which harness session backs this conversation (first use, or after it had to be replaced). */
  recordAgentSession(agentSessionId: string): void {
    if (this.meta?.agentSessionId === agentSessionId) return;
    this.meta = {
      type: HARNESS_META_TYPE,
      harness: this.harness,
      agentSessionId,
      sessionId: this.sessionId,
      cwd: this.cwd,
      timestamp: new Date().toISOString(),
    };
    this.append(this.meta as unknown as Record<string, unknown>);
  }

  /**
   * Append a conversation entry, chaining it to the previous one. Returns the
   * entry as written so the live event can carry the same uuid and timestamp.
   */
  record(entry: Record<string, unknown>): Record<string, unknown> {
    const uuid = typeof entry.uuid === 'string' ? entry.uuid : randomUUID();
    const full = {
      parentUuid: this.lastUuid,
      isSidechain: false,
      userType: 'external',
      cwd: this.cwd,
      sessionId: this.sessionId,
      harness: this.harness,
      ...entry,
      uuid,
      timestamp: typeof entry.timestamp === 'string' ? entry.timestamp : new Date().toISOString(),
    };
    this.lastUuid = uuid;
    this.append(full);
    return full;
  }

  private append(entry: Record<string, unknown>): void {
    if (this.disabled) return;
    try {
      mkdirSync(dirname(this.file), { recursive: true });
      appendFileSync(this.file, JSON.stringify(entry) + '\n', 'utf8');
    } catch (error) {
      // History is a convenience; a full disk must not stop the conversation.
      process.stderr.write(`[acp-bridge] could not write transcript: ${error instanceof Error ? error.message : String(error)}\n`);
    }
  }
}

function lastConversationUuid(text: string): string | null {
  const lines = text.split('\n');
  for (let i = lines.length - 1; i >= 0; i--) {
    const line = lines[i].trim();
    if (!line) continue;
    try {
      const entry = JSON.parse(line) as Record<string, unknown>;
      if ((entry.type === 'user' || entry.type === 'assistant') && typeof entry.uuid === 'string') return entry.uuid;
    } catch {
      // torn line
    }
  }
  return null;
}
