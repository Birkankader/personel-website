import { spawn, type ChildProcess } from 'child_process';
import { StringDecoder } from 'string_decoder';
import { MODIFIERS, type Driver, type MouseButton, type Screenshot, type ScreenSize } from './driver';

/**
 * Windows: one long-lived PowerShell that compiles a small user32 interop once
 * and then runs commands sent on stdin, one JSON line each. Spawning a shell per
 * action would cost a second or more every time (Add-Type compiles C#).
 *
 * The process is made DPI-aware before anything else, so screen sizes and
 * cursor coordinates are physical pixels on scaled displays as well.
 */
const INTEROP = String.raw`
using System;
using System.IO;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

public static class AiBridgeInput {
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X; public int Y; }
  [StructLayout(LayoutKind.Sequential)] public struct MOUSEINPUT { public int dx; public int dy; public uint mouseData; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
  [StructLayout(LayoutKind.Sequential)] public struct KEYBDINPUT { public ushort wVk; public ushort wScan; public uint dwFlags; public uint time; public IntPtr dwExtraInfo; }
  [StructLayout(LayoutKind.Explicit)] public struct InputUnion { [FieldOffset(0)] public MOUSEINPUT mi; [FieldOffset(0)] public KEYBDINPUT ki; }
  [StructLayout(LayoutKind.Sequential)] public struct INPUT { public uint type; public InputUnion u; }

  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  [DllImport("user32.dll")] public static extern bool SetCursorPos(int x, int y);
  [DllImport("user32.dll")] public static extern bool GetCursorPos(out POINT p);
  [DllImport("user32.dll")] public static extern int GetSystemMetrics(int index);
  [DllImport("user32.dll", SetLastError = true)] static extern uint SendInput(uint count, INPUT[] inputs, int size);

  static void Send(INPUT input) { SendInput(1, new INPUT[] { input }, Marshal.SizeOf(typeof(INPUT))); }

  public static void Mouse(uint flags, int data) {
    INPUT i = new INPUT(); i.type = 0; i.u.mi.dwFlags = flags; i.u.mi.mouseData = unchecked((uint)data); Send(i);
  }

  public static void Key(ushort vk, bool up, bool extended) {
    INPUT i = new INPUT(); i.type = 1; i.u.ki.wVk = vk;
    i.u.ki.dwFlags = (up ? 2u : 0u) | (extended ? 1u : 0u); Send(i);
  }

  public static void Text(string text) {
    foreach (char c in text) {
      if (c == '\n') { Key(0x0D, false, false); Key(0x0D, true, false); continue; }
      if (c == '\r') continue;
      INPUT down = new INPUT(); down.type = 1; down.u.ki.wScan = c; down.u.ki.dwFlags = 4; Send(down);
      INPUT up = new INPUT(); up.type = 1; up.u.ki.wScan = c; up.u.ki.dwFlags = 6; Send(up);
    }
  }

  public static string Capture(int width, int height) {
    int sw = GetSystemMetrics(0), sh = GetSystemMetrics(1);
    using (Bitmap full = new Bitmap(sw, sh, PixelFormat.Format32bppArgb)) {
      using (Graphics g = Graphics.FromImage(full)) { g.CopyFromScreen(0, 0, 0, 0, new Size(sw, sh)); }
      using (Bitmap scaled = new Bitmap(width, height, PixelFormat.Format24bppRgb)) {
        using (Graphics g = Graphics.FromImage(scaled)) {
          g.InterpolationMode = InterpolationMode.HighQualityBicubic;
          g.DrawImage(full, 0, 0, width, height);
        }
        using (MemoryStream ms = new MemoryStream()) { scaled.Save(ms, ImageFormat.Png); return Convert.ToBase64String(ms.ToArray()); }
      }
    }
  }
}
`;

const LOOP = String.raw`
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Drawing
Add-Type -ReferencedAssemblies System.Drawing -TypeDefinition $env:AI_BRIDGE_CU_INTEROP
[void][AiBridgeInput]::SetProcessDPIAware()
[Console]::Out.WriteLine('{"ready":true}')
while ($true) {
  $line = [Console]::In.ReadLine()
  if ($line -eq $null) { break }
  $c = $line | ConvertFrom-Json
  $r = @{ id = $c.id }
  try {
    switch ($c.op) {
      'size' { $r.width = [AiBridgeInput]::GetSystemMetrics(0); $r.height = [AiBridgeInput]::GetSystemMetrics(1) }
      'capture' { $r.data = [AiBridgeInput]::Capture([int]$c.width, [int]$c.height) }
      'cursor' { $p = New-Object AiBridgeInput+POINT; [void][AiBridgeInput]::GetCursorPos([ref]$p); $r.x = $p.X; $r.y = $p.Y }
      'move' { [void][AiBridgeInput]::SetCursorPos([int]$c.x, [int]$c.y) }
      'mouse' { [AiBridgeInput]::Mouse([uint32]$c.flags, [int]$c.data) }
      'key' { [AiBridgeInput]::Key([uint16]$c.vk, [bool]$c.up, [bool]$c.extended) }
      'text' { [AiBridgeInput]::Text([string]$c.text) }
    }
  } catch { $r.error = $_.Exception.Message }
  [Console]::Out.WriteLine(($r | ConvertTo-Json -Compress))
}
`;

const VK: Record<string, number> = {
  enter: 0x0d, tab: 0x09, escape: 0x1b, backspace: 0x08, delete: 0x2e, space: 0x20, insert: 0x2d,
  up: 0x26, down: 0x28, left: 0x25, right: 0x27, home: 0x24, end: 0x23, pageup: 0x21, pagedown: 0x22,
  ctrl: 0x11, shift: 0x10, alt: 0x12, meta: 0x5b, capslock: 0x14, printscreen: 0x2c, menu: 0x5d,
  minus: 0xbd, '-': 0xbd, equal: 0xbb, '=': 0xbb, comma: 0xbc, ',': 0xbc, period: 0xbe, '.': 0xbe,
  slash: 0xbf, '/': 0xbf, semicolon: 0xba, ';': 0xba, quote: 0xde, "'": 0xde, bracketleft: 0xdb, '[': 0xdb,
  bracketright: 0xdd, ']': 0xdd, backslash: 0xdc, '\\': 0xdc, grave: 0xc0, '`': 0xc0,
};
const EXTENDED = new Set([0x26, 0x28, 0x25, 0x27, 0x24, 0x23, 0x21, 0x22, 0x2d, 0x2e]);

export function virtualKey(name: string): number | undefined {
  if (VK[name] !== undefined) return VK[name];
  if (/^[a-z]$/.test(name)) return name.toUpperCase().charCodeAt(0);
  if (/^[0-9]$/.test(name)) return name.charCodeAt(0);
  const f = /^f([1-9]|1[0-9]|2[0-4])$/.exec(name);
  if (f) return 0x6f + Number(f[1]);
  return undefined;
}

const BUTTON_FLAGS: Record<MouseButton, [number, number]> = { left: [0x2, 0x4], right: [0x8, 0x10], middle: [0x20, 0x40] };

export class WindowsDriver implements Driver {
  private readonly ps: ChildProcess;
  private readonly waiting = new Map<number, { resolve: (v: Record<string, unknown>) => void; reject: (e: Error) => void }>();
  private nextId = 1;
  private readonly ready: Promise<void>;

  constructor() {
    // The loop goes in as -EncodedCommand so stdin carries nothing but commands.
    const encoded = Buffer.from(LOOP, 'utf16le').toString('base64');
    this.ps = spawn('powershell.exe', ['-NoProfile', '-NonInteractive', '-ExecutionPolicy', 'Bypass', '-EncodedCommand', encoded], {
      stdio: ['pipe', 'pipe', 'pipe'],
      windowsHide: true,
      env: { ...process.env, AI_BRIDGE_CU_INTEROP: INTEROP },
    });
    const decoder = new StringDecoder('utf8');
    let buffer = '';
    let markReady: () => void = () => {};
    let failReady: (e: Error) => void = () => {};
    this.ready = new Promise((resolve, reject) => { markReady = resolve; failReady = reject; });
    this.ps.stdout!.on('data', (chunk: Buffer) => {
      buffer += decoder.write(chunk);
      let i: number;
      while ((i = buffer.indexOf('\n')) >= 0) {
        const line = buffer.slice(0, i).trim();
        buffer = buffer.slice(i + 1);
        if (!line.startsWith('{')) continue;
        const message = JSON.parse(line) as Record<string, unknown>;
        if (message.ready) { markReady(); continue; }
        const waiter = this.waiting.get(message.id as number);
        if (!waiter) continue;
        this.waiting.delete(message.id as number);
        if (typeof message.error === 'string') waiter.reject(new Error(message.error));
        else waiter.resolve(message);
      }
    });
    let stderr = '';
    this.ps.stderr!.on('data', (chunk: Buffer) => { stderr = (stderr + chunk.toString()).slice(-2000); });
    this.ps.on('exit', () => {
      const error = new Error(`The input helper stopped${stderr ? `: ${stderr.trim()}` : ''}`);
      failReady(error);
      for (const waiter of this.waiting.values()) waiter.reject(error);
      this.waiting.clear();
    });
  }

  private async call(op: string, args: Record<string, unknown> = {}): Promise<Record<string, unknown>> {
    await this.ready;
    const id = this.nextId++;
    return new Promise((resolve, reject) => {
      this.waiting.set(id, { resolve, reject });
      this.ps.stdin!.write(JSON.stringify({ id, op, ...args }) + '\n');
    });
  }

  async screenSize(): Promise<ScreenSize> {
    const r = await this.call('size');
    return { width: Number(r.width), height: Number(r.height) };
  }

  async screenshot(maxWidth: number, maxHeight: number): Promise<Screenshot> {
    const { fitInside } = await import('./driver');
    const target = fitInside(await this.screenSize(), maxWidth, maxHeight);
    const r = await this.call('capture', { width: target.width, height: target.height });
    return { data: String(r.data), ...target };
  }

  async cursorPosition(): Promise<{ x: number; y: number }> {
    const r = await this.call('cursor');
    return { x: Number(r.x), y: Number(r.y) };
  }

  async moveMouse(x: number, y: number): Promise<void> {
    await this.call('move', { x, y });
  }

  async click(button: MouseButton, count: number, modifiers: string[]): Promise<void> {
    const held = modifiers.map(m => virtualKey(m)).filter((vk): vk is number => vk !== undefined);
    for (const vk of held) await this.call('key', { vk, up: false, extended: false });
    try {
      for (let i = 0; i < count; i++) {
        await this.mouseButton(button, true);
        await this.mouseButton(button, false);
      }
    } finally {
      for (const vk of held.reverse()) await this.call('key', { vk, up: true, extended: false });
    }
  }

  async mouseButton(button: MouseButton, down: boolean): Promise<void> {
    await this.call('mouse', { flags: BUTTON_FLAGS[button][down ? 0 : 1], data: 0 });
  }

  async scroll(dx: number, dy: number): Promise<void> {
    // WHEEL_DELTA (120) per notch; positive wheel data scrolls up / right.
    if (dy) await this.call('mouse', { flags: 0x800, data: -dy * 120 });
    if (dx) await this.call('mouse', { flags: 0x1000, data: dx * 120 });
  }

  async typeText(text: string): Promise<void> {
    await this.call('text', { text });
  }

  async pressKeys(keys: string[]): Promise<void> {
    const codes = keys.map(k => {
      const vk = virtualKey(k);
      if (vk === undefined) throw new Error(`Unknown key: ${k}`);
      return vk;
    });
    for (const vk of codes) await this.call('key', { vk, up: false, extended: EXTENDED.has(vk) });
    for (const vk of [...codes].reverse()) await this.call('key', { vk, up: true, extended: EXTENDED.has(vk) });
  }

  close(): void {
    try { this.ps.stdin?.end(); } catch { /* gone */ }
    try { this.ps.kill(); } catch { /* gone */ }
  }
}

export { MODIFIERS };
