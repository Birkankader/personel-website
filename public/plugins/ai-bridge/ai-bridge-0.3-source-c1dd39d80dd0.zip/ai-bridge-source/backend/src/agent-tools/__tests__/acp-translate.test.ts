import { join, resolve } from 'path';
import { describe, expect, it } from 'vitest';
import {
  harnessAgentEnv,
  parseBridgeArgs,
  pickEffortValue,
  pickModeValue,
  planToTodos,
  sameJson,
  toAcpPrompt,
  toClaudeTool,
  toolResultText,
  type ConfigOption,
} from '../acp/translate';

const effort = (values: string[]): ConfigOption => ({
  id: 'effort', category: 'thought_level', options: values.map(value => ({ value, name: value })),
});

describe('parseBridgeArgs', () => {
  it('reads the Claude flags the backend passes', () => {
    expect(parseBridgeArgs([
      '-p', '--output-format', 'stream-json', '--resume', 'abc', '--permission-mode', 'plan',
      '--model', 'm', '--effort', 'high', '--settings', 'x.json',
    ])).toEqual({ sessionId: 'abc', resume: true, noPersistence: false, permissionMode: 'plan', model: 'm', effort: 'high' });
  });

  it('takes the model from the environment, where Windows cannot mangle it', () => {
    expect(parseBridgeArgs(['--session-id', 's'], { AI_BRIDGE_HARNESS_MODEL: '["p","m"]' }).model).toBe('["p","m"]');
  });
});

describe('pickEffortValue', () => {
  it('uses an exact match and leaves auto to the harness', () => {
    expect(pickEffortValue('xhigh', effort(['low', 'xhigh']))).toBe('xhigh');
    expect(pickEffortValue('auto', effort(['low']))).toBeUndefined();
  });

  it('rounds to the nearest level, upward on a tie, and never to off', () => {
    expect(pickEffortValue('medium', effort(['off', 'low', 'high', 'max']))).toBe('high');
    expect(pickEffortValue('xhigh', effort(['off', 'low', 'high', 'max']))).toBe('max');
    expect(pickEffortValue('low', effort(['off', 'high']))).toBe('high');
  });
});

describe('pickModeValue', () => {
  const modes: ConfigOption = { id: 'mode', category: 'mode', currentValue: 'build', options: [{ value: 'build' }, { value: 'plan' }] };
  it('selects plan and returns to the base mode afterwards', () => {
    expect(pickModeValue('plan', modes, 'build')).toBe('plan');
    expect(pickModeValue('default', { ...modes, currentValue: 'plan' }, 'build')).toBe('build');
    expect(pickModeValue('default', modes, 'build')).toBeUndefined();
  });
});

describe('toClaudeTool', () => {
  const cwd = resolve('/', 'work');
  it('maps the exact correspondences', () => {
    expect(toClaudeTool({ toolCallId: '1', kind: 'read', rawInput: { path: 'a.txt' } }, cwd))
      .toEqual({ name: 'Read', input: { file_path: join(cwd, 'a.txt') } });
    expect(toClaudeTool({ toolCallId: '1', kind: 'execute', rawInput: { command: 'ls', description: 'list' } }, cwd))
      .toEqual({ name: 'Bash', input: { command: 'ls', description: 'list' } });
    expect(toClaudeTool({ toolCallId: '1', kind: 'edit', rawInput: { filePath: 'b.ts', oldString: 'x', newString: 'y' } }, cwd))
      .toEqual({ name: 'Edit', input: { file_path: join(cwd, 'b.ts'), old_string: 'x', new_string: 'y' } });
    expect(toClaudeTool({
      toolCallId: '1', kind: 'edit', locations: [{ path: join(cwd, 'c.ts') }],
      content: [{ type: 'diff', path: join(cwd, 'c.ts'), oldText: null, newText: 'new' }],
    }, cwd)).toEqual({ name: 'Write', input: { file_path: join(cwd, 'c.ts'), content: 'new' } });
  });

  it('keeps anything else under the harness own name and arguments', () => {
    expect(toClaudeTool({ toolCallId: '1', name: 'webfetch', kind: 'other', rawInput: { q: 1 } }, cwd))
      .toEqual({ name: 'webfetch', input: { q: 1 } });
  });
});

describe('toolResultText', () => {
  it('joins text content and falls back to raw output', () => {
    expect(toolResultText({
      toolCallId: '1', content: [{ type: 'content', content: { type: 'text', text: 'a' } }, { type: 'diff', path: 'p' }],
    })).toBe('a\nUpdated p');
    expect(toolResultText({ toolCallId: '1', rawOutput: { output: 'out' } })).toBe('out');
    expect(toolResultText({ toolCallId: '1', status: 'failed' })).toBe('The tool failed.');
  });
});

describe('toAcpPrompt', () => {
  const image = { type: 'image', source: { type: 'base64', media_type: 'image/png', data: 'AAA' } };
  it('converts text and images, and says so when images cannot be sent', () => {
    expect(toAcpPrompt([{ type: 'text', text: 'hi' }, image], true))
      .toEqual([{ type: 'text', text: 'hi' }, { type: 'image', mimeType: 'image/png', data: 'AAA' }]);
    const without = toAcpPrompt([image], false);
    expect(without).toHaveLength(1);
    expect(without[0]).toMatchObject({ type: 'text' });
  });
});

describe('planToTodos / sameJson', () => {
  it('maps plan entries to TodoWrite todos', () => {
    expect(planToTodos([{ content: 'a', status: 'in_progress', priority: 'high' }, { content: 'b', status: 'weird' }]))
      .toEqual([{ content: 'a', status: 'in_progress', activeForm: 'a' }, { content: 'b', status: 'pending', activeForm: 'b' }]);
  });

  it('compares JSON regardless of key order', () => {
    expect(sameJson({ a: 1, b: [1, { c: 2 }] }, { b: [1, { c: 2 }], a: 1 })).toBe(true);
    expect(sameJson({ a: 1 }, { a: 2 })).toBe(false);
  });
});

describe('harnessAgentEnv', () => {
  it('makes OpenCode ask before anything but read-only tools', () => {
    const env = harnessAgentEnv('opencode', {});
    const config = JSON.parse(env.OPENCODE_CONFIG_CONTENT!);
    expect(config.permission['*']).toBe('ask');
    expect(config.permission.read).toBe('allow');
    expect(config.permission.bash).toBeUndefined();
  });

  it("keeps the user's own inline config and rules", () => {
    const env = harnessAgentEnv('opencode', {
      OPENCODE_CONFIG_CONTENT: JSON.stringify({ model: 'x/y', permission: { bash: { 'git *': 'allow' }, read: 'ask' } }),
    });
    const config = JSON.parse(env.OPENCODE_CONFIG_CONTENT!);
    expect(config.model).toBe('x/y');
    expect(config.permission).toEqual({
      '*': 'ask', read: 'ask', glob: 'allow', grep: 'allow', list: 'allow', todoread: 'allow', todowrite: 'allow',
      bash: { 'git *': 'allow' },
    });
  });

  it('leaves a blanket rule, unreadable config and other harnesses alone', () => {
    expect(harnessAgentEnv('opencode', { OPENCODE_CONFIG_CONTENT: '{"permission":"allow"}' })).toEqual({});
    expect(harnessAgentEnv('opencode', { OPENCODE_CONFIG_CONTENT: 'not json' })).toEqual({});
    expect(harnessAgentEnv('deepseek', {})).toEqual({});
  });
});
