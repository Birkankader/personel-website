import { createWriteStream, WriteStream } from 'fs';
import { mkdir, stat, readdir, unlink, rename } from 'fs/promises';
import { join } from 'path';
import { homedir } from 'os';

const DEFAULT_LOG_DIR = join(homedir(), '.ai-bridge', 'logs');
const MAX_FILE_SIZE = 50 * 1024 * 1024; // 50MB
const MAX_TOTAL_SIZE = 2 * 1024 * 1024 * 1024; // 2GB

export class FileLogger {
  private readonly logDir: string;
  private stream: WriteStream | null = null;
  private currentSize: number = 0;
  private isRotating: boolean = false;
  private rotationBuffer: string[] = [];

  constructor(logDir: string = DEFAULT_LOG_DIR) {
    this.logDir = logDir;
  }

  async init(): Promise<void> {
    await mkdir(this.logDir, { recursive: true });

    const logFilePath = join(this.logDir, 'server.log');
    this.stream = createWriteStream(logFilePath, { flags: 'a' });

    try {
      const fileStat = await stat(logFilePath);
      this.currentSize = fileStat.size;
    } catch {
      // If the file does not exist, start the size at 0
      this.currentSize = 0;
    }
  }

  write(line: string): void {
    if (this.isRotating) {
      this.rotationBuffer.push(line);
      return;
    }

    if (!this.stream) {
      return;
    }

    this.stream.write(line);
    this.currentSize += Buffer.byteLength(line, 'utf8');
    this.checkRotation();
  }

  private checkRotation(): void {
    if (this.currentSize > MAX_FILE_SIZE) {
      this.rotate().catch((err) => {
        console.error('[FileLogger] Rotation failed:', err);
      });
    }
  }

  private async rotate(): Promise<void> {
    if (!this.stream) {
      return;
    }

    this.isRotating = true;

    // Wait for the current stream to finish (register the finish listener before calling end() so the event is not missed)
    const oldStream = this.stream;
    this.stream = null;
    await new Promise<void>((resolve) => {
      oldStream.on('finish', resolve);
      oldStream.end();
    });

    // Rename server.log → server-{timestamp}.log
    const timestamp = new Date().toISOString().replace(/[:.]/g, '');
    const oldLogPath = join(this.logDir, 'server.log');
    const archivedLogPath = join(this.logDir, `server-${timestamp}.log`);

    try {
      await rename(oldLogPath, archivedLogPath);
    } catch (err) {
      console.error('[FileLogger] Failed to rename log file:', err);
    }

    // Open a new server.log stream
    const newLogPath = join(this.logDir, 'server.log');
    this.stream = createWriteStream(newLogPath, { flags: 'a' });
    this.currentSize = 0;

    // Flush the buffered lines to the new stream
    const buffered = this.rotationBuffer.slice();
    this.rotationBuffer = [];
    this.isRotating = false;

    for (const line of buffered) {
      this.stream.write(line);
      this.currentSize += Buffer.byteLength(line, 'utf8');
    }

    // Enforce the size cap
    try {
      await this.enforceCapLimit();
    } catch (err) {
      console.error('[FileLogger] Failed to enforce size cap:', err);
    }
  }

  private async enforceCapLimit(): Promise<void> {
    const entries = await readdir(this.logDir);
    const archiveNames = entries.filter((name) => /^server-.+\.log$/.test(name));

    // Collect the size and name of each archive file
    const archives: Array<{ name: string; size: number }> = [];
    for (const name of archiveNames) {
      try {
        const fileStat = await stat(join(this.logDir, name));
        archives.push({ name, size: fileStat.size });
      } catch {
        // Skip if stat fails
      }
    }

    // Sort by name, ascending (the timestamp is part of the name, so older files come first)
    archives.sort((a, b) => a.name.localeCompare(b.name));

    let totalSize = archives.reduce((sum, f) => sum + f.size, 0);

    for (const archive of archives) {
      if (totalSize <= MAX_TOTAL_SIZE) {
        break;
      }
      try {
        await unlink(join(this.logDir, archive.name));
        totalSize -= archive.size;
      } catch (err) {
        console.error(`[FileLogger] Failed to delete archive (${archive.name}):`, err);
      }
    }
  }

  close(): Promise<void> {
    return new Promise<void>((resolve) => {
      if (!this.stream) {
        resolve();
        return;
      }
      this.stream.on('finish', resolve);
      this.stream.end();
    });
  }
}
