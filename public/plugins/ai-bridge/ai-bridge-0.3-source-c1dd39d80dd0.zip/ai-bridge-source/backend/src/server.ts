import { startWebSocketServer, type BridgeMap } from './ws/ws-server';
import { BrowserBridge } from './bridge/browser-bridge';
import { JetBrainsBridge } from './bridge/jetbrains-bridge';
import { handleMessage } from './core/handlers/index';
import { initSettingsWatcher, stopSettingsWatcher } from './core/features/settings-watcher';
import { trackEvent, reportBackendError } from './core/features/telemetry';
import { restoreTunnelState } from './core/features/tunnel-manager';
import { tunnelPairing } from './core/features/tunnel-pairing';
import { restoreSleepGuardState } from './core/features/sleep-guard';
import { registerAutoResumeHook } from './core/features/auto-resume';
import { resetLegacyAutoResumeDefault } from './core/features/settings-migration';
import { importLegacyDataDir } from './core/features/legacy-data';
import { isJetBrainsMode, serverPort, serverHost, webviewDir } from './config/environment';
import { parseResolveDiffParams, resolveDiffReview } from './core/features/resolveDiff';
import { refreshReviewAgainstDisk } from './core/features/refreshReview';
import { peekPreview } from './core/features/diffPreview';
import { carryEditAcrossRefresh } from './core/features/carryEditAcrossRefresh';
import { refreshOutcomeNotice } from './core/features/refreshOutcomeNotice';
import { initLogger, getLogger } from './logging';
import { LogWebSocketServer } from './logging/log-ws';
import { Claude } from './core/claude';
import { sweepOrphanCliProcesses } from './core/cli-registry';
import { removeContainersById } from './core/mcp-container-reclaimer';
import { startParentWatchdog, resolveWatchedPid } from './core/parent-watchdog';
import { startHostLivenessWatchdog } from './core/host-liveness';
import { createLifecycleJournal } from './logging/lifecycle-journal';
import { ClientEnv, MessageType } from './shared';
import type { NativeDropEntry } from './core/types';
import { drainMcpContainerReclaims } from './core/mcp-container-reclaimer';

/**
 * JetBrains mode: detected via the JETBRAINS_MODE=true environment variable
 * - Kotlin sets this environment variable when it spawns Node.js
 * - WEBVIEW_DIR: path to the WebView static files (passed by Kotlin after extracting them)
 * - Node.js prints PORT:{n}\n as the first line of stdout (read by Kotlin)
 * - The IDE connects to the /rpc WebSocket path and talks JSON-RPC
 * - stderr carries log output
 *
 * Browser (standalone) mode: the default
 * - Uses a fixed port (19846) (overridable with the PORT environment variable)
 * - Uses BrowserBridge (the Vite dev server serves the static files)
 *
 * Bootstrap order:
 * 1. Create JetBrainsBridge (waits for the WebSocket RPC client)
 * 2. Start the WebSocket server (acquire the port)
 * 3. Print PORT:{port}\n to stdout (read by Kotlin)
 * 4. Kotlin connects to the /rpc WebSocket → JSON-RPC channel established
 * 5. Kotlin loads http://localhost:{port} in JCEF → /ws WebSocket connection
 */

const GRACEFUL_RECLAIM_MS = 2_500;

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function startServerWithoutReclaim(
  bridges: BridgeMap,
  logWs?: LogWebSocketServer,
): Promise<Awaited<ReturnType<typeof startWebSocketServer>>> {
  try {
    return await startWebSocketServer(serverPort, serverHost, bridges, handleMessage, webviewDir, logWs);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'EADDRINUSE') {
      throw new Error(`Port ${serverPort} is already in use. Choose a different PORT for AI Bridge; the existing process was left running.`);
    }
    throw error;
  }
}

/**
 * Validate NATIVE_DROP `params.entries` arriving over JSON-RPC. Kotlin builds
 * each entry as `{ path: string; type: "file" | "folder" }`, but the value lands
 * here as `unknown`, so we narrow it explicitly. Malformed elements are dropped
 * (not coerced) so a single bad path can't poison the stash.
 */
function parseNativeDropEntries(raw: unknown): NativeDropEntry[] {
  if (!Array.isArray(raw)) return [];
  const result: NativeDropEntry[] = [];
  for (const item of raw) {
    if (!item || typeof item !== 'object') continue;
    const candidate = item as { path?: unknown; type?: unknown };
    if (typeof candidate.path !== 'string' || !candidate.path) continue;
    const type = candidate.type === 'folder' ? 'folder' : 'file';
    result.push({ path: candidate.path, type });
  }
  return result;
}

async function main() {
  // Survive parent process (Kotlin/JVM) shutdown.
  // When JVM exits, stdin/stdout/stderr pipes break. Without these handlers,
  // any console.error() call would crash the process with EPIPE.
  process.on('SIGPIPE', () => {}); // Ignore SIGPIPE signal
  process.stdout.on('error', () => {}); // Ignore stdout EPIPE
  process.stderr.on('error', () => {}); // Ignore stderr EPIPE

  // No temp-dir cleanup on exit. The JetBrains plugin extracts webview/backend
  // resources into a version-scoped dir shared across backend generations and prunes
  // stale versions at extraction time (issue #149). Deleting on exit here would let an
  // old generation remove the dir a new one is actively serving → blank `Not found`.

  // 0. Bring over the previous installation's data before the logger creates ~/.ai-bridge.
  importLegacyDataDir();

  // 1. Initialize the logger immediately (so bootstrap logs are written to the file too)
  const logger = initLogger();
  await logger.init();
  logger.interceptConsole();

  // Lifecycle journal: opened here so a start is recorded even if the boot below throws.
  // The pid is resolved now rather than at watchdog-arm time so the start line names the
  // same host the shutdown line will, whether or not the watchdog ends up arming.
  const journal = createLifecycleJournal();
  const watchedHostPid = resolveWatchedPid();

  // AI Bridge starts without upstream account discovery, analytics or migration of
  // the user's Claude configuration. Plugin preferences are read lazily.

  // The top-level (process-global) half of the backend error boundary. Errors raised outside
  // the handler flow (e.g. an unhandled throw in an async callback) also converge on the single
  // reportBackendError entry point. It only reports and logs; the process keeps its existing
  // survival style — no forced exit, no rethrow.
  process.on('uncaughtException', (err) => {
    console.error('[node-backend]', 'uncaughtException:', err);
    reportBackendError(err, { layer: 'process', hook: 'uncaughtException' });
  });
  process.on('unhandledRejection', (reason) => {
    const err = reason instanceof Error ? reason : new Error(String(reason));
    console.error('[node-backend]', 'unhandledRejection:', err);
    reportBackendError(err, { layer: 'process', hook: 'unhandledRejection' });
  });

  // Sends the app-start (active) event only for users who consented (ACCEPTED). trackEvent
  // attaches the common fields (os/version/settings, etc.) automatically. Without consent it is a no-op internally.
  trackEvent('app_started');

  // Before the first GET_SETTINGS: turn back on an auto-resume that only a
  // pre-0.31 build's default switched off (once; see the function).
  await resetLegacyAutoResumeDefault();

  // Load CLI path from settings before any handler can spawn claude
  await Claude.refresh();

  // Orphan sweep: a backend that died hard (SIGKILL bypasses every
  // JS-level guard from the process-group hard-binding) leaves its CLI children running
  // headless. The registry written at spawn time lets this fresh backend find
  // and kill them before it starts serving.
  // Kill CLIs a previous backend left behind, then remove the MCP containers
  // those CLIs were holding. A backend killed outright never ran its own reclaim,
  // and by now nothing else can tell which containers were theirs — the ids come
  // from the registry entries the sweep just retired (#363).
  const orphanSweepStarted = performance.now();
  const { mcpContainers } = await sweepOrphanCliProcesses();
  console.error('[startup]', `phase=orphan-sweep elapsedMs=${Math.round(performance.now() - orphanSweepStarted)}`);
  await removeContainersById(mcpContainers);

  const bridges: BridgeMap = {
    [ClientEnv.BROWSER]: new BrowserBridge(),
    [ClientEnv.JETBRAINS]: new JetBrainsBridge(),
  };

  // 2. Create the LogWebSocketServer
  const logWs = new LogWebSocketServer((entries) => {
    logger.handleWebViewLogs(entries);
  });

  // 3. Start the server (passing logWs)
  const { port, close, connections } = await startServerWithoutReclaim(bridges, logWs);
  Claude.configureProcessLifecycle({
    trackProcess: proc => connections.trackSessionProcess(proc),
    isShuttingDown: () => connections.isShuttingDown(),
  });

  // Register the AUTO_RESUME pre-send gate on the scheduled-message engine once,
  // now that the ConnectionManager (needed to broadcast poll progress) exists.
  // The engine's per-session timers are restored on session connect; this only
  // installs the quota-check hook the engine calls before delivering a reservation.
  registerAutoResumeHook(connections);

  // Last-resort orphan guard: tie CLI lifetime to backend lifetime. Every soft
  // cleanup path (grace timers, shutdownAll) needs a LIVE backend; this hook
  // covers every death that still runs 'exit' hooks (process.exit, fatal
  // main().catch, handled signals). uncaughtException/unhandledRejection above
  // deliberately do NOT exit (survival style), so they reach this hook only if
  // the process really dies. A hard SIGKILL bypasses JS entirely — that residual
  // gap is narrowed by the graceful port reclaim (startServerWithoutReclaim) and,
  // later, orphan detection at startup.
  process.on('exit', () => {
    const killed = connections.killAllSessionProcesses('SIGKILL');
    if (killed > 0) {
      console.error('[node-backend]', `Exit sweep: SIGKILLed ${killed} CLI process tree(s)`);
    }
  });

  // Stash native drop paths on drag-enter; the webview will flush them on its drop event.
  // The page's HTML5 `dataTransfer` doesn't expose absolute paths (browser security), so
  // Kotlin sends the paths it received from CefDragHandler over /rpc, and we hold them
  // against the panelId until the webview confirms the actual drop via NATIVE_DROP_FLUSH.
  // That ensures attach happens on release — not on hover — while still using the real
  // OS file paths.
  // Kotlin (IDE plugin) error boundary → Node. The plugin's top-level catch forwards
  // exceptions here as a CLIENT_ERROR JSON-RPC notification; we converge them at the
  // single backend reporting point with origin:'kotlin'. Kotlin holds no telemetry
  // logic (single-backend principle) — it is only the transport that hands the error
  // to Node. Fire-and-forget; never throws back into the RPC reader.
  (bridges[ClientEnv.JETBRAINS] as JetBrainsBridge).onNotification('CLIENT_ERROR', (_method, params) => {
    const message = typeof params.message === 'string' && params.message.length > 0
      ? params.message
      : 'Unknown Kotlin error';
    const error = new Error(message);
    if (typeof params.stack === 'string' && params.stack.length > 0) {
      error.stack = params.stack;
    }
    const context: Record<string, string> = { origin: 'kotlin', layer: 'plugin' };
    if (typeof params.where === 'string' && params.where.length > 0) {
      context.where = params.where;
    }
    reportBackendError(error, context);
  });

  (bridges[ClientEnv.JETBRAINS] as JetBrainsBridge).onNotification('NATIVE_DROP', (_method, params) => {
    const panelId = typeof params.panelId === 'string' ? params.panelId : '';
    const entries = parseNativeDropEntries(params.entries);
    if (!panelId || entries.length === 0) return;
    const stashed = connections.setNativeDropStash(panelId, entries);
    if (!stashed) {
      console.error('[node-backend]', `[NATIVE_DROP] stash failed — no connection for panelId=${panelId}`);
    }
  });

  // "Rename Session..." on a chat tab's IDE context menu. Kotlin does not rename
  // anything itself (a Swing popup over JCEF takes no input — see
  // RenameChatTabAction), so it names the tab and the tab's own webview prompts.
  // Not stashed when the panel is absent, unlike NATIVE_DROP: this is a menu
  // click on a tab the user is looking at, so a missing connection means the
  // panel died rather than that it has yet to connect — replaying later would
  // pop a dialog nobody asked for.
  (bridges[ClientEnv.JETBRAINS] as JetBrainsBridge).onNotification(MessageType.TAB_RENAME_REQUESTED, (_method, params) => {
    const panelId = typeof params.panelId === 'string' ? params.panelId : '';
    if (!panelId) return;
    const connectionId = connections.getConnectionIdByPanelId(panelId);
    if (!connectionId) {
      console.error('[node-backend]', `[TAB_RENAME_REQUESTED] no connection for panelId=${panelId}`);
      return;
    }
    // currentName travels with the request because only the IDE knows it: once a
    // tab carries a name of its own, the webview's document.title is still the
    // conversation's and would seed the field with the wrong value.
    const currentName = typeof params.currentName === 'string' ? params.currentName : '';
    connections.sendTo(connectionId, MessageType.TAB_RENAME_REQUESTED, { currentName });
  });

  // Parent-death watchdog — installed after `shutdown` is defined (below), since
  // its callback calls it. See the comment at that call site for the rule.

  // Idle-shutdown gate ("keep backend running"). Kotlin pushes the
  // desired state on every /rpc (re)connect and on user toggle; a `false` push
  // with zero /ws connections arms the idle timer immediately (see
  // ConnectionManager.setKeepAlive), which also closes the pre-existing
  // prewarm leak where a backend that never received a /ws client lived forever.
  (bridges[ClientEnv.JETBRAINS] as JetBrainsBridge).onNotification(MessageType.SET_KEEP_ALIVE, (_method, params) => {
    connections.setKeepAlive(params.enabled === true);
  });

  // The IDE's diff viewer reporting which hunks of a pending edit the user kept
  // (#109). Answering happens there because that is where the change is legible;
  // the backend turns the selection into the CLI's control_response.
  const jetbrainsBridge = bridges[ClientEnv.JETBRAINS] as JetBrainsBridge;
  jetbrainsBridge.onNotification(MessageType.RESOLVE_DIFF, (_method, params) => {
    const parsed = parseResolveDiffParams(params);
    if (!parsed) {
      console.error('[node-backend]', 'RESOLVE_DIFF ignored: malformed params');
      return;
    }
    // Logged like the webview's own handler does. Without it the two answering
    // paths are indistinguishable in the log, and "the IDE never sent it" reads
    // the same as "the backend dropped it".
    console.error(
      '[node-backend]',
      `Received: RESOLVE_DIFF from the IDE (session=${parsed.sessionId}, edited=${parsed.editedContent !== undefined})`,
    );
    // A notification has nobody to answer, so failures are logged here rather
    // than propagating into the RPC layer that delivered it.
    void resolveDiffReview(connections, parsed, jetbrainsBridge).catch((err) => {
      console.error('[node-backend]', 'RESOLVE_DIFF from the IDE failed:', err);
    });
  });

  /*
   * The IDE asking to rebuild a review its own diff is drawing (#359).
   *
   * A notification rather than a request because Kotlin can only notify — so
   * the rebuilt change goes back the other way, as REDRAW_REVIEW. The webview's
   * equivalent is a plain request/response; this is the same exchange split in
   * two because of what the RPC channel allows.
   */
  jetbrainsBridge.onNotification(MessageType.REFRESH_DIFF_PREVIEW, (_method, params) => {
    const toolUseId = typeof params?.toolUseId === 'string' ? params.toolUseId : undefined;
    if (!toolUseId) {
      console.error('[node-backend]', 'REFRESH_DIFF_PREVIEW from the IDE ignored: no toolUseId');
      return;
    }
    // What the reviewer has on the proposed side, sent because it exists only
    // in their diff. Absent when they never typed, or when the IDE could not
    // read it back.
    const editedProposal =
      typeof params?.editedProposal === 'string' ? params.editedProposal : undefined;
    // Read before the rebuild replaces it: the merge needs the proposal the
    // typing was made against, not the one about to take its place.
    const proposalBeforeRefresh = peekPreview(toolUseId)?.newContent;
    void refreshReviewAgainstDisk(toolUseId)
      .then((outcome) => {
        console.error('[node-backend]', `IDE refresh for ${toolUseId}: ${outcome.status}`);
        /*
         * Carry the reviewer's typing across, the same way the built-in surface
         * does (#359).
         *
         * A refresh restates the ORIGINAL side; typing lives on the PROPOSED
         * one. Different axes, so unless both changed the same line there is
         * nothing to choose between — and replacing the proposed side wholesale
         * threw the typing away with nothing said about it.
         *
         * Only meaningful when there is a rebuild to carry it onto; the other
         * outcomes leave the diff as it is, typing included.
         */
        let mergedProposal = '';
        if (outcome.status === 'refreshed') {
          const carried = carryEditAcrossRefresh(
            proposalBeforeRefresh,
            editedProposal,
            outcome.preview.newContent,
          );
          mergedProposal = carried.newContent;
          if (carried.conflicts.length > 0) {
            console.error(
              '[node-backend]',
              `IDE refresh for ${toolUseId}: kept the rebuilt proposal on line(s) ` +
                `${carried.conflicts.join(', ')}, where both sides had changed it`,
            );
          }
        }
        const notice = refreshOutcomeNotice(outcome, mergedProposal);
        if (notice.kind === 'redraw') {
          return jetbrainsBridge.redrawReview({
            toolUseId,
            filePath: notice.filePath,
            oldContent: notice.oldContent,
            newContent: notice.newContent,
          });
        }
        if (notice.kind === 'banner') {
          const preview = peekPreview(toolUseId);
          if (!preview) return;
          return jetbrainsBridge.notifyReviewBaseChanged({
            toolUseId,
            filePath: preview.filePath,
            reason: notice.reason,
            // The disk change is what made it unrebuildable, so it is over the
            // proposal by definition.
            overlapsAccepted: true,
            // Nothing was refused just now; this is the refresh answering.
            blockedApproval: false,
          });
        }
        return;
      })
      .catch((err) => {
        console.error('[node-backend]', 'IDE refresh failed:', err);
      });
  });

  // The IDE reporting a save, so a review of that file can be told its base has
  // moved before the user approves against content that is no longer there
  // (#359). Sent for every save; whether any review cared is decided here.
  jetbrainsBridge.onNotification(MessageType.FILE_SAVED, (_method, params) => {
    const filePath = typeof params?.filePath === 'string' ? params.filePath : undefined;
    if (!filePath) {
      console.error('[node-backend]', 'FILE_SAVED ignored: no filePath');
      return;
    }
    // Handed to the bridge, not acted on here. The IDE reporting a save is one
    // environment's way of meeting `watchFile`; whoever asked to watch that file
    // is told by the bridge, so the backend never learns which host it is on.
    jetbrainsBridge.reportFileSaved(filePath);
  });

  // 4. Give the logger a reference to LogWS
  logger.setLogWs(logWs);

  // Print PORT as the first line of stdout. The wrapper (JetBrains plugin or ccg standalone
  // launcher) reads it and starts the follow-up connections. Even if the user runs
  // `node backend.mjs` directly, it is just one line of noise with no side effects.
  process.stdout.write(`PORT:${port}\n`);

  console.error(
    '[node-backend]',
    `Server started on ${serverHost}:${port}`,
    `(mode: ${isJetBrainsMode ? 'JetBrains' : 'browser'})`,
    webviewDir ? `(webviewDir: ${webviewDir})` : '',
  );

  // The start line the later shutdown line pairs with. Several backends write to this one
  // file, so each event carries the pid and port that identify which one it was about.
  journal.record('start', {
    pid: process.pid,
    mode: isJetBrainsMode ? 'JetBrains' : 'browser',
    port,
    hostPid: watchedHostPid,
    webviewDir,
  });

  // Seed the launcher-provided INITIAL LOCAL pairing code. The launcher (Kotlin
  // plugin / ccg CLI) owns the stable auth token and, on each launch, mints a
  // single-use pairing code that it (a) passes here via AI_BRIDGE_INITIAL_PAIR_CODE and
  // (b) embeds as `?pair=` in the local webview URL. Seeding it lets the local
  // webview redeem it at /pair for the token on first load — the token is thus
  // NEVER placed in any URL. Guarded on presence; the code value is NEVER logged.
  const initialPairCode = process.env.AI_BRIDGE_INITIAL_PAIR_CODE?.trim();
  if (initialPairCode) {
    tunnelPairing.seedCode(initialPairCode);
    console.error('[node-backend]', 'Seeded initial local pairing code');
  }

  // Restore tunnel/sleep state from previous session
  restoreTunnelState();
  restoreSleepGuardState().catch(() => {});

  // Start watching all settings files for external changes
  const settingsWatcher = initSettingsWatcher((event, data) => {
    console.error('[node-backend]', `Broadcasting ${event} event`);
    connections.broadcastToAll(event, data);
  });
  settingsWatcher.startGlobalWatchers();

  let shuttingDown = false;
  async function shutdown(signal: string) {
    if (shuttingDown) return;
    shuttingDown = true;
    // Written before any teardown runs. Whatever the reason turns out to be, the line
    // that names it has to survive the exit that follows, and it carries the evidence the
    // verdict was made on rather than the verdict alone: knowing a backend stopped for
    // "parent-death" says nothing, while knowing a host was still attached when it did
    // says the verdict was wrong.
    journal.record('shutdown', {
      reason: signal,
      pid: process.pid,
      uptimeSec: Math.round(process.uptime()),
      hostPid: watchedHostPid,
      hostAttached: jetbrainsBridge.isConnected(),
      wsClients: connections.getConnectionCount(),
    });
    console.error('[node-backend]', `${signal} received, shutting down...`);
    stopSettingsWatcher();
    connections.shutdownAll();
    close();

    // Let the signalled CLIs actually exit, then let the reclaims their deaths
    // triggered finish, before this process exits out from under them. The order
    // matters: a reclaim only starts from a CLI's `close`, so draining first
    // drains nothing and the containers the last live session held are stranded
    // (#363, observed when the IDE went away and took the backend with it).
    //
    // Both waits are bounded — shutdown must not hang on a CLI that will not die,
    // and anything missed here is still caught by the next backend's orphan sweep.
    await connections.awaitSessionProcessExits(3_000);
    await drainMcpContainerReclaims();

    // Wait for the log stream to flush (up to 5 seconds)
    const timeoutPromise = new Promise<void>((resolve) => setTimeout(resolve, 5000));
    await Promise.race([getLogger().close(), timeoutPromise]);

    process.exit(0);
  }

  connections.setIdleShutdownHandler(() => { void shutdown('idle'); });
  // Java Process.destroy is not a portable SIGTERM. The native host requests
  // cleanup over its authenticated control channel before forceful fallback.
  jetbrainsBridge.onNotification(MessageType.SHUTDOWN_BACKEND, () => {
    void shutdown('host-shutdown');
  });

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
  // SIGHUP (terminal window closed): MANDATORY now that chat CLIs run in their own
  // process groups — they no longer receive the terminal's SIGHUP alongside the
  // backend (pre-fix they died with us for free). Without
  // this handler the process-group isolation itself would mint a new orphan class.
  process.on('SIGHUP', () => shutdown('SIGHUP'));

  // Parent-death watchdog: when the process that spawned this backend dies, the
  // backend exits — in every mode, regardless of any browser/tunnel client.
  //
  // The host owns the lifetime. Whoever started the backend is the only party
  // that can stop it, so once they are gone a surviving backend is an orphan
  // nobody launched and nobody can reach: after the IDE window closes there is
  // no UI left to shut it down with. That orphan is what forced reporters of
  // #308 to reboot Windows — it kept holding the files a newly installed
  // version needed, and closing the IDE did not clear it.
  //
  // JetBrains used to be the exception here: on IDE death the backend stayed up
  // and only restored the idle-shutdown regime, so a remote client could keep
  // working past the IDE. That exception is withdrawn. Outliving its host is
  // worth less than being reliably stoppable, and it applies all the more once
  // sessions can be shared with someone else — the machine's owner must not need
  // a guest to disconnect before their own backend will stop.
  //
  // SIGHUP is still the clean path for a terminal host; this watchdog is the
  // backup for what SIGHUP misses (host SIGKILLed, or a reparent that delivers
  // no signal), detected within one poll interval.
  startParentWatchdog(() => shutdown('parent-death'), {
    // An IDE holding its /rpc socket open is proof the host is running, and it outranks
    // whatever the pid probe infers. Standalone hosts have no such socket, so this reads
    // false there and the pid verdict stands unchanged.
    isHostAttached: () => jetbrainsBridge.isConnected(),
    onVerdictRejected: (pid) =>
      journal.record('pid-verdict-rejected', { hostPid: pid, hostAttached: true }),
  });

  // The same rule for an IDE host, enforced over its /rpc socket instead of its pid.
  //
  // The pid poller above can only speak when it can see the host's pid, and an IDE host
  // is exactly where that assumption breaks: under WSL2 the IDE lives in Windows' pid
  // namespace while this backend lives inside the distro, so there is no pid here to
  // probe (#384). The /rpc socket has no such gap — the IDE holds it open for its whole
  // life and the kernel closes it when the IDE dies, however it dies and whatever sits
  // between the two processes.
  //
  // This is not an exception to the rule stated above; it is that rule reaching the one
  // host the pid probe cannot. A terminal host opens no /rpc socket and is untouched.
  const hostLiveness = startHostLivenessWatchdog(() => shutdown('host-rpc-lost'));
  let lastHostCount = -1;
  jetbrainsBridge.setHostCountListener((count) => {
    hostLiveness.report(count);
    // Every change is journalled, not just the last one. A reconnect loop looks identical
    // to a single disconnect if only the final state is kept, and telling the two apart is
    // the whole question when someone reports the chat dropping over and over.
    if (count !== lastHostCount) {
      journal.record(count > 0 ? 'host-attached' : 'host-detached', { hosts: count });
      lastHostCount = count;
    }
  });
}

main().catch((err) => {
  console.error('[node-backend]', 'Fatal error:', err);
  process.exit(1);
});
