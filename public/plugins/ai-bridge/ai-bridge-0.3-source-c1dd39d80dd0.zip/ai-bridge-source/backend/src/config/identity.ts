/** Stable independent identity for readiness probes and local process ownership. */
export const APP_ID = 'com.birkankader.ai-bridge';
export const APP_NAME = 'AI Bridge';
export const APP_VENDOR = 'Birkan Kader';
