import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { markSessionAsSpawned } from '../claude-process';
import { MessageType } from '../../shared';
import { loadAndSendSession } from './loadAndSendSession';

export async function loadSessionHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const workingDir = message.payload?.workingDir as string | undefined;
  const sessionId = message.payload?.sessionId as string;

  if (!workingDir) {
    connections.sendTo(connectionId, MessageType.ERROR, {
      requestId: message.requestId,
      error: 'workingDir is required',
    });
    return;
  }

  if (sessionId) {
    // Loading an existing session → mark it so the next spawn uses --resume
    markSessionAsSpawned(sessionId);
    connections.subscribe(connectionId, sessionId, workingDir);
    
    const beforeUuid = message.payload?.beforeUuid as string | undefined;
    const limit = message.payload?.limit as number | undefined;
    const isOlderPage = message.type === MessageType.LOAD_OLDER_MESSAGES;

    await loadAndSendSession(connectionId, connections, workingDir, sessionId, {
      beforeUuid,
      limit,
      isOlderPage,
    });
  }
  connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId });
}
