import { spawn } from 'node:child_process';
import { win32 } from 'node:path';
import { CONNECTION_ENV_KEYS, type ConnectionEnv, type ConnectionEnvKey } from '../../shared/connection-settings';

// Only the fixed script goes in argv. Values travel as base64 UTF-8 JSON over
// stdin, never through cmd.exe, PowerShell interpolation, logs or a temp file.
const SCRIPT = `
$ErrorActionPreference = 'Stop'
[Console]::OutputEncoding = New-Object System.Text.UTF8Encoding($false)
try {
  $request = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String([Console]::In.ReadToEnd())) | ConvertFrom-Json
  $keys = @('ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL', 'ANTHROPIC_MODEL')
  if ($null -ne $request.key) {
    if ($keys -cnotcontains $request.key) { throw 'Invalid key' }
    [Environment]::SetEnvironmentVariable($request.key, [string]$request.value, 'User')
  }
  $values = @{}; $machine = @{}
  foreach ($key in $keys) {
    $values[$key] = [Environment]::GetEnvironmentVariable($key, 'User')
    $machine[$key] = [Environment]::GetEnvironmentVariable($key, 'Machine')
  }
  @{ values = $values; machine = $machine } | ConvertTo-Json -Compress
} catch { [Console]::Error.Write('Windows user environment operation failed.'); exit 1 }
`;

interface Snapshot {
  values: Record<ConnectionEnvKey, string | null>;
  machine: Record<ConnectionEnvKey, string | null>;
}

function run(request: { key?: ConnectionEnvKey; value?: string }): Promise<Snapshot> {
  return new Promise((resolve, reject) => {
    const executable = win32.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'WindowsPowerShell', 'v1.0', 'powershell.exe');
    const child = spawn(executable, ['-NoLogo', '-NoProfile', '-NonInteractive', '-EncodedCommand', Buffer.from(SCRIPT, 'utf16le').toString('base64')], {
      shell: false, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'],
    });
    let output = '';
    let settled = false;
    const fail = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      child.kill();
      reject(new Error('Windows user environment operation failed.'));
    };
    const timer = setTimeout(fail, 15_000);
    child.on('error', fail);
    child.stdin.on('error', fail);
    child.stderr.resume(); // Never expose PowerShell diagnostics that might contain a value.
    child.stdout.setEncoding('utf8');
    child.stdout.on('data', chunk => {
      output += chunk;
      if (output.length > 512_000) fail();
    });
    child.on('close', code => {
      if (settled) return;
      if (code !== 0) return fail();
      try {
        const parsed = JSON.parse(output.replace(/^\uFEFF/, '').trim()) as Snapshot;
        for (const group of [parsed.values, parsed.machine]) {
          for (const key of CONNECTION_ENV_KEYS) {
            if (!group || (group[key] !== null && typeof group[key] !== 'string')) throw new Error();
          }
        }
        settled = true;
        clearTimeout(timer);
        resolve(parsed);
      } catch { fail(); }
    });
    child.stdin.end(Buffer.from(JSON.stringify(request), 'utf8').toString('base64'));
  });
}

let queue: Promise<unknown> = Promise.resolve();
const managedKeys = new Set<ConnectionEnvKey>();
function transact(request: { key?: ConnectionEnvKey; value?: string }): Promise<ConnectionEnv> {
  const next = queue.then(async () => {
    const snapshot = await run(request);
    if (request.key) managedKeys.add(request.key);
    for (const key of CONNECTION_ENV_KEYS) {
      if (snapshot.values[key] !== null) managedKeys.add(key);
      if (!managedKeys.has(key)) continue; // Preserve intentionally inherited process-only values.
      const value = snapshot.values[key] ?? snapshot.machine[key];
      if (value === null) delete process.env[key];
      else process.env[key] = value;
    }
    return Object.fromEntries(CONNECTION_ENV_KEYS.map(key => [key, snapshot.values[key] ?? ''])) as ConnectionEnv;
  });
  queue = next.catch(() => {});
  return next;
}

export async function getWindowsUserEnv() {
  if (process.platform !== 'win32') return { supported: false as const };
  return { supported: true as const, values: await transact({}) };
}

export async function saveWindowsUserEnv(key: unknown, value: unknown): Promise<void> {
  if (process.platform !== 'win32') throw new Error('Windows is required.');
  if (!CONNECTION_ENV_KEYS.includes(key as ConnectionEnvKey) || typeof value !== 'string' || value.length > 32760 || /[\0\r\n]/.test(value)) {
    throw new Error('Invalid environment variable.');
  }
  await transact({ key: key as ConnectionEnvKey, value });
}

/** Refresh once at backend startup/settings reload; saving also updates this
 * backend immediately. Running CLI processes keep their launch environment. */
export async function refreshWindowsUserEnv(): Promise<void> {
  if (process.platform !== 'win32') return;
  try { await transact({}); }
  catch { console.error('[node-backend] Could not refresh Windows user environment.'); }
}
