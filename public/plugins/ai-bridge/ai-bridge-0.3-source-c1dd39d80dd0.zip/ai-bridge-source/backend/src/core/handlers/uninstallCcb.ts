import { unsupportedServiceHandler } from './unsupportedServices';

export const uninstallCcbHandler = unsupportedServiceHandler;
