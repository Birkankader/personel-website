import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { mkdtemp, mkdir, writeFile, rm } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import type { ConnectionManager } from '../../../ws/connection-manager';
import { MessageType } from '../../../shared';
import { conversationSearch } from '../../features/conversation-search';
import { conversationToolsHandler } from '../conversationTools';

describe('conversation search cancellation handler', () => {
  let directory: string;
  const owner = 'cancel-paused-handler';
  beforeEach(async () => {
    directory = await mkdtemp(join(tmpdir(), 'swttch-search-handler-'));
    const project = join(directory, 'projects', '-work');
    await mkdir(project, { recursive: true });
    await writeFile(join(project, 'large.jsonl'), 'x'.repeat(2 * 1024 * 1024));
    vi.stubEnv('CLAUDE_CONFIG_DIR', directory);
  });
  afterEach(async () => {
    conversationSearch.cancel(owner); vi.unstubAllEnvs();
    await rm(directory, { recursive: true, force: true });
  });

  it('cancels a retained cursor after its page response has removed the active request', async () => {
    const sendTo = vi.fn();
    const connections = { sendTo } as unknown as ConnectionManager;
    await conversationToolsHandler(owner, { type: MessageType.SEARCH_CONVERSATIONS, timestamp: 0, requestId: 'initial', payload: { searchId: 'search-a', query: 'needle', workingDir: '/work' } }, connections);
    const page = sendTo.mock.calls.find((call) => call[2].requestId === 'initial')![2];
    expect(page.nextCursor).toEqual(expect.any(String));
    await conversationToolsHandler(owner, { type: MessageType.CANCEL_CONVERSATION_SEARCH, timestamp: 0, requestId: 'cancel', payload: { searchId: 'search-a' } }, connections);
    await conversationToolsHandler(owner, { type: MessageType.SEARCH_CONVERSATIONS, timestamp: 0, requestId: 'resume', payload: { searchId: 'search-b', query: 'needle', workingDir: '/work', cursor: page.nextCursor } }, connections);
    expect(sendTo).toHaveBeenCalledWith(owner, MessageType.ERROR, expect.objectContaining({ requestId: 'resume', error: 'Search expired; start again' }));
  });
});
