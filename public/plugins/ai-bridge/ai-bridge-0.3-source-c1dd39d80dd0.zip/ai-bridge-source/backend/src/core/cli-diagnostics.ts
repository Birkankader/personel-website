const MAX_TAIL_CHARS = 16 * 1024;
const PREVIEW_CHARS = 600;
const LOG_INTERVAL_MS = 1000;

/** Diagnostic output must not grow with a noisy CLI or compete with its stream. */
export class CliDiagnostics {
  private tail = '';
  private lastPreviewAt = -Infinity;
  private suppressed = 0;
  private conflict = false;

  get stderr(): string { return this.tail; }
  get sessionAlreadyInUse(): boolean { return this.conflict; }

  stderrChunk(text: string, now = performance.now()): string | null {
    // Keep the conflict signal even if later noise evicts its error text; the
    // overlap also recognizes a message split across two stderr pipe chunks.
    this.conflict ||= (this.tail.slice(-32) + text).includes('already in use');
    this.tail = (this.tail + text.slice(-MAX_TAIL_CHARS)).slice(-MAX_TAIL_CHARS);
    return this.preview(text, now);
  }

  preview(text: string, now = performance.now()): string | null {
    if (now - this.lastPreviewAt < LOG_INTERVAL_MS) {
      this.suppressed++;
      return null;
    }
    this.lastPreviewAt = now;
    const skipped = this.suppressed ? ` [${this.suppressed} diagnostic chunks suppressed]` : '';
    this.suppressed = 0;
    return text.slice(0, PREVIEW_CHARS) + (text.length > PREVIEW_CHARS ? ' [truncated]' : '') + skipped;
  }
}
