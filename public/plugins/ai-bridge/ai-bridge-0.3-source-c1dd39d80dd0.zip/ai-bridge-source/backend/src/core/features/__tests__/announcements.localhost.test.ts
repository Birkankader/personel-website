import { afterEach, expect, it, vi } from 'vitest';
import { fetchAnnouncements } from '../announcements';
afterEach(() => { vi.unstubAllEnvs(); vi.unstubAllGlobals(); });
it('does not enable upstream announcements via an inherited local endpoint override', async () => {
  vi.stubEnv('CCG_ANNOUNCE_URL', 'http://localhost:9988');
  vi.stubEnv('AI_BRIDGE_ANNOUNCE_URL', 'http://localhost:9988');
  const network = vi.fn(); vi.stubGlobal('fetch', network);
  expect((await fetchAnnouncements()).announcements).toEqual([]);
  expect(network).not.toHaveBeenCalled();
});
