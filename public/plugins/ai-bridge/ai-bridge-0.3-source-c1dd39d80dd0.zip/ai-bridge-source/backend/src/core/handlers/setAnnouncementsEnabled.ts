import { unsupportedServiceHandler } from './unsupportedServices';

export const setAnnouncementsEnabledHandler = unsupportedServiceHandler;
