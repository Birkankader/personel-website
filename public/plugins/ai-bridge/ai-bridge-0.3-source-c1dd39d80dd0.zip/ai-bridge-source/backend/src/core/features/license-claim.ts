/** The independent build never discovers or activates an upstream license. */
export const CLAIM_RETRY_INTERVAL_MS = 60 * 60 * 1000;
export interface ClaimOptions { throttled: boolean }
export function resetClaimThrottle(): void {}
export async function claimSponsorByInstall(_options: ClaimOptions): Promise<boolean> { return false; }
