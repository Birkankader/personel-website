import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { MessageType } from '../../../shared';
import { SettingsFileWatcher } from '../settings-watcher';

const calls = vi.hoisted(() => ({
  watchers: [] as { dir: string; callback: (event: string, filename: string) => void; close: ReturnType<typeof vi.fn> }[],
}));
vi.mock('fs', () => ({
  existsSync: () => true,
  watch: vi.fn((dir: string, callback: (event: string, filename: string) => void) => {
    const close = vi.fn(); calls.watchers.push({ dir, callback, close }); return { close };
  }),
}));
vi.mock('os', () => ({ homedir: () => '/test-home' }));
vi.mock('../settings', () => ({
  readMergedSettings: vi.fn(async (project?: string) => ({
    settings: { reasoningEffort: project ? 'high' : 'low' }, overrides: project ? ['reasoningEffort'] : [],
  })),
}));
vi.mock('../claude-settings', () => ({ readMergedClaudeSettings: vi.fn(async () => ({ settings: {}, overrides: [] })) }));

describe('settings watcher scope and lifetime', () => {
  let watcher: SettingsFileWatcher;
  const notify = vi.fn((_event: string, _data: unknown) => {});
  beforeEach(() => {
    vi.useFakeTimers(); calls.watchers.length = 0; notify.mockClear();
    vi.stubEnv('CLAUDE_CONFIG_DIR', '/provider');
    watcher = new SettingsFileWatcher(notify);
  });
  afterEach(() => { watcher.stopAll(); vi.useRealTimers(); vi.unstubAllEnvs(); });

  it('tags project merged snapshots while global updates remain unscoped for each client to refetch', async () => {
    watcher.startGlobalWatchers();
    watcher.registerProject('/project-a');
    calls.watchers.find((w) => w.dir === '/project-a/.ai-bridge')!.callback('change', 'settings.json');
    await vi.advanceTimersByTimeAsync(300);
    expect(notify).toHaveBeenLastCalledWith(MessageType.SETTINGS_CHANGED, {
      workingDir: '/project-a', settings: { reasoningEffort: 'high' }, overrides: ['reasoningEffort'],
    });
    calls.watchers.find((w) => w.dir === '/test-home/.ai-bridge')!.callback('change', 'settings.js');
    await vi.advanceTimersByTimeAsync(300);
    expect(notify).toHaveBeenLastCalledWith(MessageType.SETTINGS_CHANGED, {
      settings: { reasoningEffort: 'low' }, overrides: [],
    });
  });

  it('keeps a shared project watcher until its last reference closes and cancels pending notifications', async () => {
    watcher.registerProject('/project-a'); watcher.registerProject('/project-a');
    expect(calls.watchers).toHaveLength(3);
    watcher.unregisterProject('/project-a');
    expect(calls.watchers.every((w) => w.close.mock.calls.length === 0)).toBe(true);
    calls.watchers[2].callback('change', 'settings.json');
    watcher.unregisterProject('/project-a');
    await vi.advanceTimersByTimeAsync(300);
    expect(calls.watchers.every((w) => w.close.mock.calls.length === 1)).toBe(true);
    expect(notify).not.toHaveBeenCalled();
    expect(vi.getTimerCount()).toBe(0);
  });
});
