import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { markSessionAsSpawned } from '../claude-process';
import { Claude } from '../claude';
import { MessageType } from '../../shared';
import { loadAndSendSession } from './loadAndSendSession';

export async function reclaimSessionHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const sessionId = message.payload?.sessionId as string;
  const workingDir = message.payload?.workingDir as string | undefined;
  const limit = message.payload?.limit as number | undefined;

  if (!sessionId) {
    connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId });
    return;
  }

  if (!workingDir) {
    connections.sendTo(connectionId, MessageType.ERROR, {
      requestId: message.requestId,
      error: 'workingDir is required',
    });
    return;
  }

  console.error('[node-backend]', `Reclaiming session: ${sessionId}`);

  // 1. Kill the internal process
  const session = connections.getSession(sessionId);
  if (session?.process) {
    console.error('[node-backend]', `Killing internal process for session ${sessionId}`);
    Claude.killTree(session.process);
    connections.setProcess(sessionId, null);
    await new Promise(resolve => setTimeout(resolve, 500));
  }

  // 2. Mark the session so the next spawn uses --resume
  markSessionAsSpawned(sessionId);

  // 3. Load & send the session messages
  // Forward the pagination limit so a reclaim honors the user's "Paginate chat
  // history" setting exactly like the initial load (loadSessionHandler).
  connections.subscribe(connectionId, sessionId);
  await loadAndSendSession(connectionId, connections, workingDir, sessionId, { limit });

  console.error('[node-backend]', `Session ${sessionId} reclaimed successfully`);
  connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId });
}
