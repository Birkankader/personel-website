import { readFile } from 'fs/promises';
import { createHash } from 'crypto';
import { homedir } from 'os';
import { join } from 'path';
import type { ConnectionManager } from '../../ws/connection-manager';
import { MessageType } from '../../shared';
import { updateJsonFile } from './atomic-json';
import { TaskLimiter } from './task-limiter';

const settingsPath = () => {
  // Native launchers pass the owning project, since their cwd is the extracted
  // backend directory. Standalone instances use their launch directory.
  const scope = process.env.AI_BRIDGE_RUNTIME_SCOPE || process.cwd();
  const key = createHash('sha256').update(scope).digest('hex');
  return join(homedir(), '.ai-bridge', 'task-limits', `${key}.json`);
};
const managers = new WeakMap<ConnectionManager, { limiter: TaskLimiter; ready: Promise<void>; settingsFile: string }>();

export function runtimeTasks(connections: ConnectionManager) {
  let manager = managers.get(connections);
  if (manager) return manager;
  const settingsFile = settingsPath();
  const limiter = new TaskLimiter(2, (snapshot) => connections.broadcastToAll(MessageType.TASK_QUEUE_CHANGED, { ...snapshot }));
  const ready = readFile(settingsFile, 'utf8').then((raw) => {
    const limit = (JSON.parse(raw) as { limit?: number }).limit;
    if (Number.isInteger(limit) && limit! >= 1 && limit! <= 16) limiter.setLimit(limit!);
  }).catch(() => {});
  manager = { limiter, ready, settingsFile };
  managers.set(connections, manager);
  return manager;
}

export async function setTaskConcurrency(connections: ConnectionManager, limit: number): Promise<void> {
  if (!Number.isInteger(limit) || limit < 1 || limit > 16) throw new Error('Concurrent tasks must be between 1 and 16.');
  const manager = runtimeTasks(connections);
  await manager.ready;
  const result = await updateJsonFile(manager.settingsFile, (current) => ({ ...current, limit }));
  if (result.status === 'error') throw new Error(result.error);
  manager.limiter.setLimit(limit);
}
