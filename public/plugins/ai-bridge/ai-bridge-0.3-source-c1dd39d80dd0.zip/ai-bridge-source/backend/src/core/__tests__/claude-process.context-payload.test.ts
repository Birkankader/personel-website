import { EventEmitter } from 'node:events';
import { Writable } from 'node:stream';
import { describe, expect, it, vi } from 'vitest';
import type { ConnectionManager } from '../../ws/connection-manager';
import { sendMessageToProcess } from '../claude-process';

vi.mock('../features/runtime-tasks', () => ({ runtimeTasks: () => ({ limiter: { setProcess: vi.fn(), taskForProcess: vi.fn() } }) }));
vi.mock('../features/telemetry', () => ({ reportBackendError: vi.fn() }));

function fixture() {
  const lines: string[] = [];
  const process = Object.assign(new EventEmitter(), {
    pid: 99101, exitCode: null, signalCode: null,
    stdin: new Writable({ write(chunk, _encoding, done) { lines.push(chunk.toString()); done(); } }),
  });
  const connections = { getSession: () => ({ process }), setStreaming: vi.fn() } as unknown as ConnectionManager;
  return { lines, connections, process };
}

describe('outbound prompt context', () => {
  it('writes each of three prompts once without replaying history or system text', async () => {
    const { lines, connections, process } = fixture();
    try {
      for (const content of ['selam', 'ikinci', 'üçüncü']) {
        expect(await sendMessageToProcess(connections, 'same-session', content)).toBe(true);
      }
      expect(lines.map(line => JSON.parse(line))).toEqual(['selam', 'ikinci', 'üçüncü'].map(content => ({ type: 'user', message: { role: 'user', content } })));
      expect(lines.map(line => Buffer.byteLength(JSON.parse(line).message.content))).toEqual([5, 6, 10]);
    } finally { process.stdin.destroy(); }
  });

  it('sends explicit file and folder paths once and does not carry them into later prompts', async () => {
    const { lines, connections, process } = fixture();
    try {
      expect(await sendMessageToProcess(connections, 'same-session', 'selam', [
        { type: 'file', fileName: 'large.ts', absolutePath: 'C:\\project\\large.ts' },
        { type: 'folder', folderName: 'src', absolutePath: 'C:\\project\\src\\' },
      ])).toBe(true);
      expect(await sendMessageToProcess(connections, 'same-session', 'ikinci')).toBe(true);
      const outgoing = lines.map(line => JSON.parse(line).message.content);
      expect(outgoing).toEqual(['C:\\project\\large.ts\nC:\\project\\src\\\n\nselam', 'ikinci']);
      expect(Buffer.byteLength(outgoing[0])).toBeLessThan(60);
    } finally { process.stdin.destroy(); }
  });

  it('includes one explicit image only on its own send', async () => {
    const { lines, connections, process } = fixture();
    try {
      const image = { type: 'image' as const, fileName: 'example.png', mimeType: 'image/png', base64: 'ZmFrZQ==' };
      expect(await sendMessageToProcess(connections, 'same-session', 'image', [image])).toBe(true);
      expect(await sendMessageToProcess(connections, 'same-session', 'next')).toBe(true);
      expect(JSON.parse(lines[0]).message.content).toEqual([
        { type: 'text', text: 'image' },
        { type: 'image', source: { type: 'base64', media_type: 'image/png', data: 'ZmFrZQ==' } },
      ]);
      expect(JSON.parse(lines[1]).message.content).toBe('next');
    } finally { process.stdin.destroy(); }
  });
});
