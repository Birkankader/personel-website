import { unsupportedServiceHandler } from './unsupportedServices';

export const installCcbHandler = unsupportedServiceHandler;
