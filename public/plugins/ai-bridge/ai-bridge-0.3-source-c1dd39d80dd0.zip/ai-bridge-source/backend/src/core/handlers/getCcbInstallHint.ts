import { unsupportedServiceHandler } from './unsupportedServices';

export const getCcbInstallHintHandler = unsupportedServiceHandler;
