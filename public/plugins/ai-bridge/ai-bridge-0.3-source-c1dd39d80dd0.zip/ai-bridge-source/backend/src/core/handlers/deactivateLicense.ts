import { unsupportedServiceHandler } from './unsupportedServices';

export const deactivateLicenseHandler = unsupportedServiceHandler;
