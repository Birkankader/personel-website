import { execFile } from 'child_process';

export type WindowsProcessSnapshot = Map<number, string | null>;

/** One bounded, asynchronous CIM scan for a startup sweep, rather than one
 * PowerShell startup per registry entry. Command lines stay in memory only. */
export function readWindowsProcessSnapshot(): Promise<WindowsProcessSnapshot | null> {
  return new Promise((resolve) => {
    try {
      execFile('powershell.exe', [
        '-NoProfile', '-NonInteractive', '-Command',
        '[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false); ' +
        'Get-CimInstance Win32_Process | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress',
      ], { encoding: 'utf8', windowsHide: true, timeout: 5000, maxBuffer: 8 * 1024 * 1024 }, (error, stdout) => {
        if (error) { resolve(null); return; }
        try {
          const data: unknown = JSON.parse(stdout.replace(/^\uFEFF/, '').trim());
          if (!data || typeof data !== 'object') { resolve(null); return; }
          const rows: unknown[] = Array.isArray(data) ? data : [data];
          const snapshot: WindowsProcessSnapshot = new Map();
          for (const row of rows) {
            if (!row || typeof row !== 'object') { resolve(null); return; }
            const { ProcessId: pid, CommandLine: command } = row as Record<string, unknown>;
            if (typeof pid !== 'number' || !Number.isInteger(pid) || pid < 0 ||
                (command !== null && typeof command !== 'string')) { resolve(null); return; }
            snapshot.set(pid, typeof command === 'string' && command.length > 0 ? command : null);
          }
          resolve(snapshot);
        } catch { resolve(null); }
      });
    } catch {
      resolve(null);
    }
  });
}

export function windowsSessionProcessIds(snapshot: WindowsProcessSnapshot, sessionId: string): number[] {
  if (!/^[A-Za-z0-9._-]+$/.test(sessionId)) return [];
  return [...snapshot].filter(([pid, command]) => pid > 1 && pid !== process.pid &&
    command?.includes(sessionId) && !command.includes('Get-CimInstance')).map(([pid]) => pid);
}

/** Await tree termination without stopping the backend's event loop. */
export function terminateWindowsTree(pid: number): Promise<boolean> {
  if (!Number.isInteger(pid) || pid <= 1 || pid === process.pid) return Promise.resolve(false);
  return new Promise((resolve) => {
    try {
      execFile('taskkill', ['/F', '/T', '/PID', String(pid)],
        { windowsHide: true, timeout: 5000 }, (error) => {
          if (!error) { resolve(true); return; }
          try { process.kill(pid, 0); resolve(false); } catch (probeError) {
            // Access denied does not prove that the writer exited. Only the
            // explicit no-such-process result permits clearing its registry.
            resolve((probeError as NodeJS.ErrnoException).code === 'ESRCH');
          }
        });
    } catch {
      resolve(false);
    }
  });
}
