import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { randomUUID } from 'crypto';
import { AutoResumeStatusPhase, MessageType, ScheduledMessageKind, type ScheduledMessage } from '../../shared';
import {
  scheduleMessage,
  cancelSchedule,
  editScheduledMessage,
  settleScheduledDelivery,
} from '../features/scheduled-messages';
import { readSchedulesForSession } from '../features/scheduled-messages-store';

/**
 * Handlers for the scheduled-message ("send later") engine:
 *   SCHEDULE_MESSAGE          → create a reservation for a session
 *   CANCEL_SCHEDULED_MESSAGE  → cancel a reservation by id
 *   GET_SCHEDULED_MESSAGES    → list a session's reservations (ACK)
 *
 * ACK/requestId conventions follow the other request handlers (e.g. getUsage.ts).
 */

/** SCHEDULE_MESSAGE: persist + arm a reservation, then ACK with the created reservation. */
export async function scheduleMessageHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const payload = message.payload as
    | { sessionId?: string; sendAt?: string; message?: string; kind?: ScheduledMessageKind }
    | undefined;
  const sessionId = payload?.sessionId;
  const sendAt = payload?.sendAt;
  const messageText = payload?.message;
  const kind = payload?.kind ?? ScheduledMessageKind.AUTO_RESUME;

  if (!sessionId || !sendAt || !messageText) {
    connections.sendTo(connectionId, MessageType.ERROR, {
      requestId: message.requestId,
      error: 'sessionId, sendAt and message are required',
    });
    return;
  }

  // Record which tab set the reservation (read from the server-side client
  // record, not the payload, so it always reflects the actual requesting tab).
  // Delivery prefers this tab; undefined for standalone/browser tabs with no
  // panelId, in which case delivery falls back by session/focus.
  const panelId = connections.getClient(connectionId)?.panelId ?? undefined;

  const reservation: ScheduledMessage = {
    id: randomUUID(),
    sessionId,
    sendAt,
    message: messageText,
    kind,
    createdAt: new Date().toISOString(),
    panelId,
  };

  await scheduleMessage(reservation, connections);

  connections.sendTo(connectionId, MessageType.ACK, {
    requestId: message.requestId,
    scheduledMessage: reservation,
  });
}

/** CANCEL_SCHEDULED_MESSAGE: clear a reservation's timer + remove it, then ACK. */
export async function cancelScheduledMessageHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const payload = message.payload as { sessionId?: string; id?: string } | undefined;
  const sessionId = payload?.sessionId;
  const id = payload?.id;

  if (!sessionId || !id) {
    connections.sendTo(connectionId, MessageType.ERROR, {
      requestId: message.requestId,
      error: 'sessionId and id are required',
    });
    return;
  }

  await cancelSchedule(sessionId, id, connections);

  connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId });
}

/**
 * UPDATE_SCHEDULED_MESSAGE: edit a reservation in place (message and/or sendAt)
 * by id, then ACK. A missing id/session errors; an unknown id is a no-op
 * (still ACKed) since the list may have changed under the editor.
 */
export async function updateScheduledMessageHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const payload = message.payload as
    | { sessionId?: string; id?: string; message?: string; sendAt?: string }
    | undefined;
  const sessionId = payload?.sessionId;
  const id = payload?.id;

  if (!sessionId || !id) {
    connections.sendTo(connectionId, MessageType.ERROR, {
      requestId: message.requestId,
      error: 'sessionId and id are required',
    });
    return;
  }

  await editScheduledMessage(
    sessionId,
    id,
    { message: payload?.message, sendAt: payload?.sendAt },
    connections,
  );

  connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId });
}

/**
 * SCHEDULED_MESSAGE_DELIVERED: the selected webview reports normal send-path
 * admission. Only successful admission removes the reservation. A rejected
 * admission releases the recipient claim for a later attach, without starting
 * an automatic retry loop. Missing `delivered` retains legacy success semantics.
 */
export async function scheduledMessageDeliveredHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const payload = message.payload as { sessionId?: string; id?: string; delivered?: boolean } | undefined;
  const sessionId = payload?.sessionId;
  const id = payload?.id;
  if (!sessionId || !id) return;

  const delivered = payload?.delivered !== false;
  const reservation = await settleScheduledDelivery(sessionId, id, connectionId, delivered, connections);
  if (!delivered && reservation?.kind === ScheduledMessageKind.AUTO_RESUME) {
    connections.broadcastToSession(sessionId, MessageType.AUTO_RESUME_STATUS, {
      sessionId,
      scheduleId: id,
      phase: AutoResumeStatusPhase.FAILED,
      attempt: 1,
      error: 'The scheduled message could not be sent.',
      errorKind: 'unknown',
    });
  }
}

/** GET_SCHEDULED_MESSAGES: return a session's current reservation list (ACK). */
export async function getScheduledMessagesHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const payload = message.payload as { sessionId?: string } | undefined;
  const sessionId = payload?.sessionId;

  if (!sessionId) {
    connections.sendTo(connectionId, MessageType.ERROR, {
      requestId: message.requestId,
      error: 'sessionId is required',
    });
    return;
  }

  const schedules = await readSchedulesForSession(sessionId);

  connections.sendTo(connectionId, MessageType.ACK, {
    requestId: message.requestId,
    schedules,
  });
}
