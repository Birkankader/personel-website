import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { MessageType } from '../../../shared';
import type { ConnectionManager } from '../../../ws/connection-manager';
import type { Bridge } from '../../../bridge/bridge-interface';

vi.mock('../../claude', () => ({ Claude: {
  command: 'claude',
  env: { PATH: '/fixture/bin' },
  which: vi.fn().mockResolvedValue('/fixture/bin/claude'),
  exec: vi.fn(),
  applyConfigDir: vi.fn(),
} }));
vi.mock('../../features/loadCliConfig', () => ({ loadCliConfig: vi.fn().mockResolvedValue(null) }));
vi.mock('../../features/telemetry', () => ({ getRawClientInfo: vi.fn() }));
vi.mock('../../features/settings', () => ({ readMergedSettings: vi.fn().mockResolvedValue({ settings: { harness: 'opencode' } }) }));

import { Claude } from '../../claude';
import { getCliVersion } from '../getVersion';
import { getCliConfigHandler } from '../getCliConfig';
import { loadCliConfig } from '../../features/loadCliConfig';

describe('startup probe sharing', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(Claude.exec).mockReset();
    vi.mocked(Claude.applyConfigDir).mockReset();
  });
  afterEach(() => { vi.unstubAllEnvs(); });

  it('shares concurrent version reads without caching a completed version across updates', async () => {
    let finish!: (value: { stdout: string; stderr: string }) => void;
    vi.mocked(Claude.exec).mockReturnValueOnce(new Promise((resolve) => { finish = resolve; }));
    const requests = Array.from({ length: 8 }, () => getCliVersion());
    expect(Claude.exec).toHaveBeenCalledTimes(1);
    expect(Claude.which).toHaveBeenCalledTimes(1);
    finish({ stdout: '2.1.220 (Claude Code)', stderr: '' });
    expect(await Promise.all(requests)).toEqual(Array(8).fill('2.1.220'));
    vi.mocked(Claude.exec).mockResolvedValueOnce({ stdout: '2.1.221 (Claude Code)', stderr: '' });
    expect(await getCliVersion()).toBe('2.1.221');
    expect(Claude.exec).toHaveBeenCalledTimes(2);
  });

  it('does not share probes between CLI profiles and retries after failure', async () => {
    vi.mocked(Claude.exec).mockRejectedValueOnce(new Error('missing'))
      .mockResolvedValueOnce({ stdout: '2.1.221', stderr: '' });
    vi.stubEnv('CLAUDE_CONFIG_DIR', '/fixture/a');
    const a = getCliVersion();
    vi.stubEnv('CLAUDE_CONFIG_DIR', '/fixture/b');
    const b = getCliVersion();
    expect(await a).toBeNull();
    expect(await b).toBe('2.1.221');
    vi.mocked(Claude.exec).mockResolvedValueOnce({ stdout: '2.1.222', stderr: '' });
    expect(await getCliVersion()).toBe('2.1.222');
    expect(Claude.exec).toHaveBeenCalledTimes(3);
  });

  it('projects the requested CLI context before reading cached or fresh config', async () => {
    let finishProjection!: () => void;
    vi.mocked(Claude.applyConfigDir).mockReturnValueOnce(new Promise((resolve) => { finishProjection = resolve; }));
    const sendTo = vi.fn();
    const request = getCliConfigHandler('connection', {
      type: MessageType.GET_CLI_CONFIG,
      payload: { workingDir: 'C:\\Projects\\Köprü', refresh: true },
      timestamp: 0,
      requestId: 'request',
    }, { sendTo } as unknown as ConnectionManager, {} as Bridge);
    expect(Claude.applyConfigDir).toHaveBeenCalledWith('C:\\Projects\\Köprü');
    expect(loadCliConfig).not.toHaveBeenCalled();
    finishProjection();
    await request;
    // The catalogue follows the harness new chats will run on.
    expect(loadCliConfig).toHaveBeenCalledWith('C:\\Projects\\Köprü', { refresh: true, harness: 'opencode' });
    expect(sendTo).toHaveBeenCalledWith('connection', MessageType.ACK, {
      requestId: 'request', status: 'ok', controlResponse: null,
    });
  });
});
