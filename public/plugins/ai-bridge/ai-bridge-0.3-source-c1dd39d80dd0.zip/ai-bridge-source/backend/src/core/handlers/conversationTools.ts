import type { ConnectionManager } from '../../ws/connection-manager';
import type { IPCMessage } from '../types';
import { MessageType } from '../../shared';
import type { ConversationTarget } from '../../shared/conversation-tools';
import { conversationSearch } from '../features/conversation-search';
import { conversationAnnotations } from '../features/conversation-annotations';

const active = new Map<string, { id: string; controller: AbortController }>();

export async function conversationToolsHandler(connectionId: string, message: IPCMessage, connections: ConnectionManager): Promise<void> {
  const payload = message.payload ?? {};
  const ack = (value: object) => connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId, ...value });
  try {
    if (message.type === MessageType.CANCEL_CONVERSATION_SEARCH) {
      const current = active.get(connectionId);
      if (current && current.id === payload.searchId) current.controller.abort();
      if (typeof payload.searchId === 'string') conversationSearch.cancel(connectionId, payload.searchId);
      ack({});
    } else if (message.type === MessageType.SEARCH_CONVERSATIONS) {
      if (typeof payload.searchId !== 'string' || typeof payload.query !== 'string' || typeof payload.workingDir !== 'string') throw new Error('Search request is missing its query or directory');
      active.get(connectionId)?.controller.abort();
      const controller = new AbortController();
      const record = { id: payload.searchId, controller };
      active.set(connectionId, record);
      try {
        ack(await conversationSearch.search({
          owner: connectionId, query: payload.query, workingDir: payload.workingDir,
          allProjects: payload.allProjects === true, cursor: typeof payload.cursor === 'string' ? payload.cursor : undefined,
          limit: typeof payload.limit === 'number' ? payload.limit : undefined, signal: controller.signal, cancellationId: payload.searchId,
        }));
      } finally { if (active.get(connectionId) === record) active.delete(connectionId); }
    } else if (message.type === MessageType.GET_CONVERSATION_ANNOTATIONS) {
      ack(await conversationAnnotations.list({
        workingDir: typeof payload.workingDir === 'string' ? payload.workingDir : undefined,
        sessionId: typeof payload.sessionId === 'string' ? payload.sessionId : undefined,
        messageUuid: typeof payload.messageUuid === 'string' ? payload.messageUuid : undefined,
        offset: typeof payload.offset === 'number' ? payload.offset : undefined,
        limit: typeof payload.limit === 'number' ? payload.limit : undefined,
      }));
    } else if (message.type === MessageType.SAVE_CONVERSATION_ANNOTATION) {
      const annotation = await conversationAnnotations.save(payload as unknown as ConversationTarget & { note: string; bookmarked: boolean });
      ack({ annotation });
    }
  } catch (error) {
    connections.sendTo(connectionId, MessageType.ERROR, { requestId: message.requestId,
      error: error instanceof Error ? error.message : 'Conversation tools failed' });
  }
}
