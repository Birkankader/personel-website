import { expect, it, vi } from 'vitest';
import { TaskLimiter } from '../task-limiter';
const flush = async () => { for (let i = 0; i < 10; i++) await Promise.resolve(); };
const steer = () => ({ validate: vi.fn(), write: vi.fn(async () => true), accepted: vi.fn() });
async function setup() {
  const limiter = new TaskLimiter(1);
  const owner = limiter.enqueueUser('a', '/a', () => true, vi.fn(), 'a');
  await flush(); limiter.setProcess('a', 42);
  const action = steer();
  const normal = vi.fn(() => true);
  const queued = limiter.enqueueUser('a', '/a', normal, vi.fn(), 'b', action);
  return { limiter, owner, queued, action, normal };
}
it('claims once across views, keeps the active slot and waits for a matching CLI replay', async () => {
  const { limiter, owner, queued, action, normal } = await setup();
  await limiter.steerQueued(queued.id);
  await expect(limiter.steerQueued(queued.id)).rejects.toThrow('already');
  expect(action.write).toHaveBeenCalledExactlyOnceWith(queued.id);
  expect(action.accepted).not.toHaveBeenCalled();
  expect(normal).not.toHaveBeenCalled();
  expect(limiter.cancelQueued(queued.id)).toBe(false);
  expect(limiter.acceptSteering('a', 99, queued.id)).toBe(false);
  expect(limiter.acceptSteering('b', 42, queued.id)).toBe(false);
  expect(limiter.acceptSteering('a', 42, queued.id)).toBe(true);
  expect(action.accepted).toHaveBeenCalledOnce();
  expect(limiter.get(queued.id)).toBeUndefined();
  expect(limiter.get(owner.id)?.state).toBe('running');
  expect(limiter.holdForSteering('a')).toBe(false);
});
it('holds a late steer across the first result and never coalesces already written input', async () => {
  const { limiter, queued, action } = await setup();
  await limiter.steerQueued(queued.id);
  const c = limiter.enqueueUser('a', '/a', vi.fn(() => true), vi.fn(), 'c');
  const d = limiter.enqueueUser('a', '/a', vi.fn(() => true), vi.fn(), 'd');
  expect(limiter.get(c.id)?.state).toBe('queued'); expect(limiter.get(queued.id)?.steering).toBe(true);
  expect(limiter.holdForSteering('a')).toBe(true);
  expect(limiter.get(d.id)?.state).toBe('queued');
  limiter.acceptSteering('a', 42, queued.id);
  expect(action.accepted).toHaveBeenCalledOnce();
  limiter.release('a'); await flush();
  expect(limiter.get(c.id)?.state).toBe('running');
  limiter.release('a'); await flush();
  expect(limiter.get(d.id)?.state).toBe('running');
});
it('keeps the message queued if validation rejects recovery or commands', async () => {
  const { limiter, queued, action } = await setup();
  action.validate.mockImplementation(() => { throw new Error('Recovering'); });
  await expect(limiter.steerQueued(queued.id)).rejects.toThrow('Recovering');
  expect(action.write).not.toHaveBeenCalled();
  expect(limiter.get(queued.id)?.steering).toBeUndefined();
  expect(limiter.hasPendingSteering('a')).toBe(false);
});
it('cannot steer a globally queued task with no running turn in its session', async () => {
  const { limiter } = await setup();
  const action = steer();
  const other = limiter.enqueueUser('other', '/other', () => true, vi.fn(), 'other', action);
  await expect(limiter.steerQueued(other.id)).rejects.toThrow('running');
  expect(action.write).not.toHaveBeenCalled();
});
it('does not retry an ambiguous write failure or strand the slot after an early result', async () => {
  const { limiter, owner, queued, action, normal } = await setup();
  let reject!: (reason: Error) => void;
  action.write.mockImplementation(() => new Promise((_resolve, fail) => { reject = fail; }));
  const pending = limiter.steerQueued(queued.id);
  expect(limiter.holdForSteering('a')).toBe(true);
  reject(new Error('Broken pipe'));
  await expect(pending).rejects.toThrow('Broken pipe');
  expect(limiter.get(owner.id)).toBeUndefined(); expect(limiter.get(queued.id)).toBeUndefined();
  expect(normal).not.toHaveBeenCalled(); expect(action.accepted).not.toHaveBeenCalled();
});
it('removes unconsumed steering on process close and suppresses admission after Stop', async () => {
  const { limiter, queued, action } = await setup();
  await limiter.steerQueued(queued.id);
  limiter.cancelSession('a');
  expect(limiter.hasPendingSteering('a')).toBe(true);
  expect(limiter.holdForSteering('a')).toBe(false);
  limiter.acceptSteering('a', 42, queued.id);
  expect(action.accepted).not.toHaveBeenCalled();
  limiter.release('a', 'cancelled');
  expect(limiter.snapshot().tasks).toEqual([]);
});
it('fails unconsumed input on unexpected exit without sending it again', async () => {
  const { limiter, queued, action, normal } = await setup();
  await limiter.steerQueued(queued.id);
  limiter.release('a', 'failed'); await flush();
  expect(limiter.snapshot().tasks).toEqual([]);
  expect(action.accepted).not.toHaveBeenCalled(); expect(normal).not.toHaveBeenCalled();
});
