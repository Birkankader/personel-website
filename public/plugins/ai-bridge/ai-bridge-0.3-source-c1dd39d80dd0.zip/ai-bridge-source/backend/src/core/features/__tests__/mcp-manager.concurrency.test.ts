import { beforeEach, describe, expect, it, vi } from 'vitest';
import { Claude } from '../../claude';
import { getMcpServers } from '../mcp-manager';
import { McpServerStatus } from '../../../shared';
import { ConnectionManager } from '../../../ws/connection-manager';
import { getMcpServersHandler } from '../../handlers/getMcpServersHandler';
import { MessageType } from '../../../shared';
import type { Bridge } from '../../../bridge/bridge-interface';
import type { WebSocket } from 'ws';

const state = vi.hoisted(() => ({ config: {} as Record<string, unknown> }));
vi.mock('../../claude', () => ({ Claude: { exec: vi.fn() } }));
vi.mock('../mcp-config-files', async original => ({
  ...await original<typeof import('../mcp-config-files')>(),
  readClaudeJson: vi.fn(async () => state.config),
  readProjectMcpJson: vi.fn(async () => null),
  claudeJsonDisplayPath: () => '/fixture/.claude.json',
}));
vi.mock('../env-sources', () => ({ buildMcpEnvSource: vi.fn(async () => ({})) }));
vi.mock('../runtime-tasks', () => ({ runtimeTasks: () => ({ limiter: { shutdown: vi.fn() } }) }));

const names = Array.from({ length: 20 }, (_, index) => `server-${String(index).padStart(2, '0')}`);
type Completion = { name: string; resolve: () => void; reject: () => void };
let pending: Map<string, Completion>;
let active: number;
let peak: number;
let started: string[];

const flush = async () => { for (let turn = 0; turn < 15; turn++) await Promise.resolve(); };

beforeEach(() => {
  vi.clearAllMocks();
  active = 0; peak = 0; started = [];
  pending = new Map();
  state.config = { mcpServers: Object.fromEntries(names.map(name => [name, {
    command: 'fixture-command', args: ['--name', name], env: { USER_VALUE: `value-${name}` },
  }])) };
  vi.mocked(Claude.exec).mockImplementation((args, options) => {
    if (args[1] === 'list') return Promise.resolve({
      stdout: [...names].reverse().map(name => `${name}: fixture-command - ✔ Connected`).join('\n'), stderr: '',
    });
    expect(args.slice(0, 2)).toEqual(['mcp', 'get']);
    const name = args[2];
    const key = `${String(options?.cwd)}/${name}`;
    started.push(key); active++; peak = Math.max(peak, active);
    return new Promise((resolve, reject) => {
      const finish = () => { pending.delete(key); active--; };
      pending.set(key, {
        name,
        resolve: () => {
          finish();
          resolve({ stdout: [
            `${name}:`, '  Scope: User config (available in all your projects)',
            `  Status: ${Number(name.slice(-2)) % 4 === 0 ? '✘ Failed to connect' : '✔ Connected'}`,
            '  Type: stdio', '  Command: fixture-command', `  Args: --name ${name}`, '',
          ].join('\n'), stderr: '' });
        },
        reject: () => { finish(); reject(new Error('controlled CLI failure')); },
      });
    });
  });
});

async function drain(total: number, rejectNames = new Set<string>()) {
  for (let completed = 0; completed < total; completed++) {
    await flush();
    expect(pending.size).toBeGreaterThan(0);
    expect(pending.size).toBeLessThanOrEqual(2);
    // Complete the newest admitted child first to exercise out-of-order work.
    const next = [...pending.values()].at(-1)!;
    if (rejectNames.has(next.name)) next.reject();
    else next.resolve();
  }
  await flush();
  expect(active).toBe(0);
}

describe('MCP fallback detail process limit', () => {
  it('visits all 20 servers with at most two child processes and preserves statuses/config/order', async () => {
    const result = getMcpServers('/fixture/project');
    await flush();
    expect(pending.size).toBe(2);
    await drain(20);
    const { servers } = await result;
    expect(peak).toBe(2);
    expect(started).toHaveLength(20);
    expect(servers.map(server => server.name)).toEqual(names);
    for (const server of servers) {
      expect(server.config).toEqual((state.config.mcpServers as Record<string, unknown>)[server.name]);
      const failed = Number(server.name.slice(-2)) % 4 === 0;
      expect(server.status).toBe(failed ? McpServerStatus.FAILED : McpServerStatus.CONNECTED);
      expect(server.error).toBe(failed ? 'Failed to connect' : null);
      expect(server.tools).toBeUndefined();
    }
  });

  it('releases failed slots, keeps the existing failure policy, and shares the cap between simultaneous panels', async () => {
    const failures = new Set(['server-02', 'server-09', 'server-17']);
    const first = getMcpServers('/fixture/a');
    const second = getMcpServers('/fixture/b');
    await drain(40, failures);
    const results = await Promise.all([first, second]);
    expect(peak).toBe(2);
    expect(started).toHaveLength(40);
    for (const result of results) {
      expect(result.servers.map(server => server.name)).toEqual(names.filter(name => !failures.has(name)));
    }
  });

  it.each(['disconnect', 'shutdown'])('does not start queued probes after requester %s', async (reason) => {
    const connections = new ConnectionManager(true);
    const id = connections.addConnection({ send: vi.fn(), close: vi.fn(), readyState: 1 } as unknown as WebSocket);
    const request = getMcpServersHandler(id, { type: MessageType.GET_MCP_SERVERS, requestId: 'mcp', timestamp: 0,
      payload: { workingDir: '/fixture/closing' } }, connections, {} as Bridge);
    await flush();
    expect(started).toHaveLength(2);
    if (reason === 'disconnect') connections.removeConnection(id);
    else connections.shutdownAll();
    const first = [...pending.values()];
    for (const task of first) task.resolve();
    await flush();
    const startedAfterClose = started.length;
    // Drain fixture work even when the baseline violates cancellation, so no
    // shared queue state leaks into the next test.
    while (pending.size) { [...pending.values()][0].resolve(); await flush(); }
    await request;
    expect(startedAfterClose).toBe(2);
    expect(started).toHaveLength(2);
  });
});
