import { EventEmitter } from 'node:events';
import { PassThrough } from 'node:stream';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';

const { spawn } = vi.hoisted(() => ({ spawn: vi.fn() }));
vi.mock('node:child_process', () => ({ spawn }));
const keys = ['ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL', 'ANTHROPIC_MODEL'];
let registry: Record<string, string | null>;
let machine: Record<string, string | null>;
let request: Record<string, string>;
let fail = false;
let children: Array<EventEmitter & { kill: ReturnType<typeof vi.fn> }>;
const platformDescriptor = Object.getOwnPropertyDescriptor(process, 'platform')!;
const original = Object.fromEntries(keys.map(key => [key, process.env[key]]));

beforeEach(() => {
  vi.resetModules(); spawn.mockReset();
  Object.defineProperty(process, 'platform', { value: 'win32', configurable: true });
  registry = { ANTHROPIC_AUTH_TOKEN: 'existing-secret', ANTHROPIC_BASE_URL: 'https://office.example', ANTHROPIC_MODEL: 'model', OTHER_ENV: 'preserve-me' };
  machine = Object.fromEntries(keys.map(key => [key, null])); children = []; fail = false;
  spawn.mockImplementation(() => {
    const child = Object.assign(new EventEmitter(), { stdout: new PassThrough(), stderr: new PassThrough(), stdin: new PassThrough(), kill: vi.fn() });
    children.push(child);
    let input = '';
    child.stdin.on('data', chunk => { input += chunk.toString(); });
    child.stdin.on('finish', () => queueMicrotask(() => {
      request = JSON.parse(Buffer.from(input, 'base64').toString('utf8'));
      if (fail) { child.stderr.write('secret diagnostics'); child.emit('close', 1); return; }
      if (request.key) registry[request.key] = request.value || null;
      child.stdout.write(JSON.stringify({ values: Object.fromEntries(keys.map(key => [key, registry[key]])), machine }));
      child.emit('close', 0);
    }));
    return child;
  });
});
afterEach(() => {
  vi.restoreAllMocks();
  Object.defineProperty(process, 'platform', platformDescriptor);
  for (const key of keys) { if (original[key] === undefined) delete process.env[key]; else process.env[key] = original[key]; }
});

describe('Windows User Env transport', () => {
  it('reads existing user values and updates the environment inherited by new CLI children', async () => {
    const { getWindowsUserEnv } = await import('../windows-user-env');
    expect(await getWindowsUserEnv()).toMatchObject({ supported: true, values: { ANTHROPIC_AUTH_TOKEN: 'existing-secret' } });
    expect(process.env.ANTHROPIC_BASE_URL).toBe('https://office.example');
  });
  it('writes only the requested key and preserves Unicode, quotes, percent and shell syntax through stdin', async () => {
    const { saveWindowsUserEnv } = await import('../windows-user-env');
    const value = 'fixture ç %PATH% "quoted" $() ` & |';
    await saveWindowsUserEnv('ANTHROPIC_AUTH_TOKEN', value);
    expect(request).toEqual({ key: 'ANTHROPIC_AUTH_TOKEN', value });
    expect(registry.OTHER_ENV).toBe('preserve-me');
    expect(registry.ANTHROPIC_BASE_URL).toBe('https://office.example');
    expect(process.env.ANTHROPIC_AUTH_TOKEN).toBe(value);
    const [command, args, options] = spawn.mock.calls[0];
    expect(command).toMatch(/WindowsPowerShell.*powershell\.exe$/);
    expect(args.join(' ')).not.toContain(value);
    expect(options).toMatchObject({ shell: false, windowsHide: true });
    const script = Buffer.from(args.at(-1), 'base64').toString('utf16le');
    expect(script).toContain("SetEnvironmentVariable($request.key, [string]$request.value, 'User')");
    expect(script).not.toContain(value);
  });
  it('clears a user value without resurrecting the stale parent value, falling back only to Machine', async () => {
    const { saveWindowsUserEnv } = await import('../windows-user-env');
    process.env.ANTHROPIC_AUTH_TOKEN = 'stale-parent';
    await saveWindowsUserEnv('ANTHROPIC_AUTH_TOKEN', '');
    expect(process.env.ANTHROPIC_AUTH_TOKEN).toBeUndefined();
    machine.ANTHROPIC_MODEL = 'machine-model';
    await saveWindowsUserEnv('ANTHROPIC_MODEL', '');
    expect(process.env.ANTHROPIC_MODEL).toBe('machine-model');
    expect(registry.ANTHROPIC_MODEL).toBeNull();
  });
  it.each([['PATH', 'bad'], ['ANTHROPIC_AUTH_TOKEN', 'with\nnewline'], ['ANTHROPIC_MODEL', 'x'.repeat(32761)]])('rejects invalid input %s before launching a helper', async (key, value) => {
    const { saveWindowsUserEnv } = await import('../windows-user-env');
    await expect(saveWindowsUserEnv(key, value)).rejects.toThrow('Invalid environment variable');
    expect(spawn).not.toHaveBeenCalled();
  });
  it('does not expose native errors and continues accepting saves after a failure', async () => {
    const { saveWindowsUserEnv } = await import('../windows-user-env');
    fail = true;
    await expect(saveWindowsUserEnv('ANTHROPIC_MODEL', 'new')).rejects.toThrow('Windows user environment operation failed.');
    expect(children[0].kill).toHaveBeenCalled();
    fail = false;
    await saveWindowsUserEnv('ANTHROPIC_MODEL', 'retry');
    expect(registry.ANTHROPIC_MODEL).toBe('retry');
  });
  it('serializes saves so the last edit wins', async () => {
    const { saveWindowsUserEnv } = await import('../windows-user-env');
    await Promise.all([saveWindowsUserEnv('ANTHROPIC_MODEL', 'first'), saveWindowsUserEnv('ANTHROPIC_MODEL', 'last')]);
    expect(registry.ANTHROPIC_MODEL).toBe('last');
  });
  it('does not read or mutate a different ENV store on non-Windows hosts', async () => {
    Object.defineProperty(process, 'platform', { value: 'darwin', configurable: true });
    const { getWindowsUserEnv, saveWindowsUserEnv } = await import('../windows-user-env');
    expect(await getWindowsUserEnv()).toEqual({ supported: false });
    await expect(saveWindowsUserEnv('ANTHROPIC_MODEL', 'no')).rejects.toThrow('Windows is required');
    expect(spawn).not.toHaveBeenCalled();
  });
});
