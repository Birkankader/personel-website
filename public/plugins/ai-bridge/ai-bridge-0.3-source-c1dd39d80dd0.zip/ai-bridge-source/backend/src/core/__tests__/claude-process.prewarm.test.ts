import { EventEmitter } from 'events';
import type { ChildProcess } from 'child_process';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { Bridge } from '../../bridge/bridge-interface';
import { ConnectionManager } from '../../ws/connection-manager';
import { MessageType } from '../../shared';
import { TaskLimiter } from '../features/task-limiter';
import { ensureClaudeProcess, prewarmClaudeProcess, PREWARM_IDLE_TIMEOUT_MS, sendMessageToProcess } from '../claude-process';
import { prewarmSessionHandler } from '../handlers/prewarmSession';
import { Claude } from '../claude';

const state = vi.hoisted(() => ({ manager: null as unknown }));
vi.mock('../features/runtime-tasks', () => ({ runtimeTasks: () => state.manager }));
vi.mock('../claude', () => ({ Claude: { command: 'claude', applyConfigDir: vi.fn(async () => {}), spawnAuthed: vi.fn(), killTree: vi.fn() } }));
vi.mock('../features/settings', () => ({ readMergedSettings: vi.fn(async () => ({ settings: {} })) }));
vi.mock('../features/claude-settings', () => ({ readMergedClaudeSettings: vi.fn(async () => ({ settings: {} })) }));
vi.mock('../features/scheduled-messages', () => ({ restoreSchedulesForSession: vi.fn(async () => {}) }));
vi.mock('../features/lastRecordedSend', () => ({ readLastRecordedSend: vi.fn(async () => null) }));
vi.mock('../cli-registry', () => ({ findLiveCliForSession: vi.fn(() => null), registerCliProcess: vi.fn(), unregisterCliProcess: vi.fn() }));
vi.mock('../features/workflow-tracker', () => ({ WorkflowProgressTracker: { create: () => ({ handleEvent: vi.fn(), stopSession: vi.fn() }) } }));
vi.mock('../features/telemetry', () => ({ reportBackendError: vi.fn() }));
vi.mock('../features/auth-diagnosis', () => ({ diagnoseAuthError: vi.fn(async () => {}) }));

function fakeProcess(pid: number) {
  return Object.assign(new EventEmitter(), {
    pid, exitCode: null as number | null, signalCode: null,
    stdout: new EventEmitter(), stderr: new EventEmitter(),
    stdin: Object.assign(new EventEmitter(), { writable: true, write: vi.fn((_text: string, callback?: (error?: Error | null) => void) => { callback?.(); return true; }) }),
  });
}
type FakeProcess = ReturnType<typeof fakeProcess>;
const bridge = {} as Bridge;
let counter = 0;
let launches: { proc: FakeProcess; args: string[] }[];
let limiter: TaskLimiter;
let connections: ConnectionManager;
let session: string;
let spawnFails: boolean;

beforeEach(() => {
  vi.clearAllMocks();
  launches = [];
  spawnFails = false;
  limiter = new TaskLimiter(1);
  state.manager = { limiter, ready: Promise.resolve() };
  connections = new ConnectionManager(true);
  vi.spyOn(connections, 'broadcastToSession');
  vi.spyOn(connections, 'sendTo');
  session = `prewarm-${++counter}`;
  vi.mocked(Claude.spawnAuthed).mockImplementation(async args => {
    const proc = fakeProcess(44000 + launches.length);
    launches.push({ proc, args });
    setImmediate(() => spawnFails ? proc.emit('error', new Error('spawn claude ENOENT')) : proc.emit('spawn'));
    return proc as unknown as ChildProcess;
  });
  vi.mocked(Claude.killTree).mockImplementation(child => {
    const proc = child as unknown as FakeProcess;
    proc.exitCode = 0;
    proc.emit('close', 0);
  });
});
afterEach(() => {
  vi.useRealTimers();
  limiter.shutdown();
  for (const { proc } of launches) {
    if (proc.exitCode === null) { proc.exitCode = 0; proc.emit('close', 0); }
  }
});

const prewarm = (inputMode?: string) => prewarmClaudeProcess(connections, 'client', '/project', session, inputMode, bridge);
const broadcasts = (type: MessageType) => vi.mocked(connections.broadcastToSession).mock.calls.filter(([, sent]) => sent === type);
function exit(proc: FakeProcess, code: number, stderr = '') {
  if (stderr) proc.stderr.emit('data', Buffer.from(stderr));
  proc.exitCode = code;
  proc.emit('close', code);
}

describe('prewarming a session CLI while the user types', () => {
  it('starts a new session under its own id and the send reuses it without a second launch', async () => {
    expect(await prewarm('plan')).toBe(true);
    expect(launches).toHaveLength(1);
    expect(launches[0].args).toEqual(expect.arrayContaining(['--session-id', session, '--permission-mode', 'plan']));
    expect(connections.getSession(session)?.subscribers.has('client')).toBe(true);
    await ensureClaudeProcess(connections, 'client', '/project', session, 'plan', bridge, undefined, true);
    expect(launches).toHaveLength(1);
    expect(await sendMessageToProcess(connections, session, 'hello')).toBe(true);
    expect(launches[0].proc.stdin.write).toHaveBeenCalledOnce();
  });

  it('does nothing when a CLI is alive or starting, or when a queued task will start one', async () => {
    await prewarm();
    expect(await prewarm()).toBe(false);
    const other = `${session}-other`;
    const starting = ensureClaudeProcess(connections, 'client', '/project', other, undefined, bridge);
    expect(await prewarmClaudeProcess(connections, 'client', '/project', other, undefined, bridge)).toBe(false);
    await starting;
    const queued = `${session}-queued`;
    limiter.enqueueUser(queued, '/project', async () => new Promise<boolean>(() => {}), () => {}, 'message-1');
    expect(await prewarmClaudeProcess(connections, 'client', '/project', queued, undefined, bridge)).toBe(false);
    expect(launches).toHaveLength(2);
  });

  it('claims the id again when the drafted settings change before the first message', async () => {
    await prewarm('plan');
    await ensureClaudeProcess(connections, 'client', '/project', session, 'bypass', bridge, undefined, true);
    expect(launches).toHaveLength(2);
    expect(launches[1].args).toEqual(expect.arrayContaining(['--session-id', session, '--permission-mode', 'bypassPermissions']));
    expect(launches[1].args).not.toContain('--resume');
  });

  it('reports nothing when the CLI cannot start; the handler only acknowledges', async () => {
    spawnFails = true;
    await prewarmSessionHandler('client', {
      type: MessageType.PREWARM_SESSION, requestId: 'r1', timestamp: Date.now(),
      payload: { sessionId: session, workingDir: '/project' },
    }, connections, bridge);
    expect(connections.sendTo).toHaveBeenCalledWith('client', MessageType.ACK, { requestId: 'r1' });
    expect(broadcasts(MessageType.SERVICE_ERROR)).toEqual([]);
    expect(broadcasts(MessageType.STREAM_END)).toEqual([]);
    // The send that follows starts the CLI itself and reports the failure.
    await expect(ensureClaudeProcess(connections, 'client', '/project', session, undefined, bridge)).rejects.toThrow('ENOENT');
    expect(broadcasts(MessageType.SERVICE_ERROR)).toHaveLength(1);
  });

  it('keeps an idle prewarmed CLI exit silent, but reports one that had received a message', async () => {
    await prewarm();
    exit(launches[0].proc, 1, 'Error: settings are invalid');
    expect(broadcasts(MessageType.SERVICE_ERROR)).toEqual([]);
    expect(connections.getSession(session)?.process).toBeNull();
    await prewarm();
    await sendMessageToProcess(connections, session, 'hello');
    exit(launches[1].proc, 1, 'Error: settings are invalid');
    expect(broadcasts(MessageType.SERVICE_ERROR)).toEqual([[session, MessageType.SERVICE_ERROR, expect.objectContaining({ type: MessageType.CLI_EXIT_ERROR })]]);
  });

  it('closes a prewarmed CLI that never receives a message, and keeps one that did', async () => {
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout'] });
    const ready = prewarm();
    await vi.waitFor(() => expect(launches).toHaveLength(1));
    await ready;
    vi.advanceTimersByTime(PREWARM_IDLE_TIMEOUT_MS);
    expect(Claude.killTree).toHaveBeenCalledWith(launches[0].proc);
    expect(connections.getSession(session)?.process).toBeNull();

    const used = prewarm();
    await vi.waitFor(() => expect(launches).toHaveLength(2));
    await used;
    await sendMessageToProcess(connections, session, 'hello');
    vi.advanceTimersByTime(PREWARM_IDLE_TIMEOUT_MS * 2);
    expect(Claude.killTree).toHaveBeenCalledTimes(1);
    expect(connections.getSession(session)?.process).toBe(launches[1].proc);
  });
});
