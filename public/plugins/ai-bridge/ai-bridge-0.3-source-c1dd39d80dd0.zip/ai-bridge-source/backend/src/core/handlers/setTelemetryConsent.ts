import { unsupportedServiceHandler } from './unsupportedServices';

export const setTelemetryConsentHandler = unsupportedServiceHandler;
