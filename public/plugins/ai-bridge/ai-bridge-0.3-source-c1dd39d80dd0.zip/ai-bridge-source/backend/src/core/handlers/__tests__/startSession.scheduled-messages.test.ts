import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { ConnectionManager } from '../../../ws/connection-manager';
import type { Bridge } from '../../../bridge/bridge-interface';
import { AutoResumeStatusPhase, MessageType, ScheduledMessageKind, type ScheduledMessage } from '../../../shared';
import { ensureClaudeProcess } from '../../claude-process';
import { startSessionHandler } from '../startSession';
import { scheduledMessageDeliveredHandler } from '../scheduleMessage';
import {
  cancelSchedule,
  resetSchedulerForTest,
  restoreSchedulesForSession,
  scheduleMessage,
} from '../../features/scheduled-messages';
import { registerAutoResumeHook } from '../../features/auto-resume';

const fixtures = vi.hoisted(() => ({ schedules: new Map<string, ScheduledMessage[]>() }));
vi.mock('../../claude-process', () => ({ ensureClaudeProcess: vi.fn(async () => {}) }));
// Keep the real timer/delivery engine, replacing only disk I/O and the CLI.
vi.mock('../../features/scheduled-messages-store', () => ({
  addSchedule: async (msg: ScheduledMessage) => {
    fixtures.schedules.set(msg.sessionId, [...(fixtures.schedules.get(msg.sessionId) ?? []), msg]);
  },
  readSchedulesForSession: async (sessionId: string) => fixtures.schedules.get(sessionId) ?? [],
  removeSchedule: async (sessionId: string, id: string) => {
    fixtures.schedules.set(sessionId, (fixtures.schedules.get(sessionId) ?? []).filter(msg => msg.id !== id));
  },
  removeSchedulesForSession: async (sessionId: string) => { fixtures.schedules.delete(sessionId); },
  updateSchedule: vi.fn(),
}));

const bridge = {} as Bridge;
const request = {
  type: MessageType.START_SESSION,
  timestamp: Date.now(),
  requestId: 'attach-request',
  payload: { sessionId: 'session-a', workingDir: '/project' },
};

function connectionFixture() {
  const clients = new Set(['old-tab', 'new-tab']);
  let subscribed = 'old-tab';
  const connections = {
    subscribe: vi.fn((connectionId: string) => { subscribed = connectionId; }),
    getClient: vi.fn((connectionId: string) => clients.has(connectionId) ? {} : undefined),
    pickScheduledDeliveryTarget: vi.fn(() => ({ connectionId: subscribed, needsSessionSwitch: false })),
    sendTo: vi.fn(),
    broadcastToSession: vi.fn(),
  };
  return { clients, connections, manager: connections as unknown as ConnectionManager };
}

function reservation(): ScheduledMessage {
  return {
    id: 'auto-resume', sessionId: 'session-a', kind: ScheduledMessageKind.AUTO_RESUME,
    sendAt: new Date(Date.now() - 1000).toISOString(),
    createdAt: new Date(Date.now() - 5000).toISOString(), message: 'continue',
  };
}

describe('START_SESSION restores due scheduled messages on attach', () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.mocked(ensureClaudeProcess).mockReset().mockResolvedValue(undefined);
    fixtures.schedules.clear();
    resetSchedulerForTest();
  });
  afterEach(() => {
    resetSchedulerForTest();
    vi.useRealTimers();
  });

  it('redelivers an unacknowledged retry to a reconnected tab while its CLI is reused', async () => {
    const { clients, connections, manager } = connectionFixture();
    registerAutoResumeHook(manager);
    const msg = reservation();
    await scheduleMessage(msg, manager);
    await vi.advanceTimersByTimeAsync(0);
    expect(connections.sendTo).toHaveBeenCalledWith('old-tab', MessageType.DELIVER_SCHEDULED_MESSAGE,
      expect.objectContaining({ id: msg.id, sessionId: msg.sessionId, message: 'continue' }));

    // The socket disappeared before SEND_MESSAGE admission/ACK, but the CLI
    // remains alive: ensureClaudeProcess reuses it without spawning/restoring.
    clients.delete('old-tab');
    connections.sendTo.mockClear();
    await startSessionHandler('new-tab', request, manager, bridge);
    await vi.advanceTimersByTimeAsync(0);
    expect(ensureClaudeProcess).toHaveBeenCalledOnce();
    expect(connections.sendTo).toHaveBeenCalledWith('new-tab', MessageType.DELIVER_SCHEDULED_MESSAGE,
      expect.objectContaining({ id: msg.id, sessionId: msg.sessionId, message: 'continue' }));
    expect(fixtures.schedules.get(msg.sessionId)).toEqual([msg]);

    // Repeated attach before the recipient ACK must not submit a second copy.
    await startSessionHandler('new-tab', request, manager, bridge);
    await vi.advanceTimersByTimeAsync(0);
    expect(connections.sendTo.mock.calls.filter(([, type]) => type === MessageType.DELIVER_SCHEDULED_MESSAGE)).toHaveLength(1);

    await cancelSchedule(msg.sessionId, msg.id, manager);
    await startSessionHandler('new-tab', request, manager, bridge);
    await vi.advanceTimersByTimeAsync(0);
    expect(connections.sendTo.mock.calls.filter(([, type]) => type === MessageType.DELIVER_SCHEDULED_MESSAGE)).toHaveLength(1);
  });

  it('does not duplicate delivery when a fresh CLI spawn has already restored the timer', async () => {
    const { connections, manager } = connectionFixture();
    const msg = reservation();
    fixtures.schedules.set(msg.sessionId, [msg]);
    vi.mocked(ensureClaudeProcess).mockImplementationOnce(async () => {
      await restoreSchedulesForSession(msg.sessionId, manager);
    });

    await startSessionHandler('new-tab', request, manager, bridge);
    await vi.advanceTimersByTimeAsync(0);
    expect(connections.sendTo.mock.calls.filter(([, type]) => type === MessageType.DELIVER_SCHEDULED_MESSAGE)).toHaveLength(1);
  });

  it('does not resume a reservation when session startup fails', async () => {
    const { connections, manager } = connectionFixture();
    const msg = reservation();
    fixtures.schedules.set(msg.sessionId, [msg]);
    vi.mocked(ensureClaudeProcess).mockRejectedValueOnce(new Error('CLI unavailable'));

    await startSessionHandler('new-tab', request, manager, bridge);
    await vi.advanceTimersByTimeAsync(0);
    expect(connections.sendTo).not.toHaveBeenCalledWith(expect.anything(), MessageType.DELIVER_SCHEDULED_MESSAGE,
      expect.anything());
    expect(fixtures.schedules.get(msg.sessionId)).toEqual([msg]);
  });

  it('keeps a rejected admission, reports failure, and retries only on a later attach', async () => {
    const { connections, manager } = connectionFixture();
    const msg = reservation();
    await scheduleMessage(msg, manager);
    await vi.advanceTimersByTimeAsync(0);
    connections.sendTo.mockClear();

    await scheduledMessageDeliveredHandler('old-tab', {
      type: MessageType.SCHEDULED_MESSAGE_DELIVERED,
      timestamp: Date.now(),
      payload: { id: msg.id, sessionId: msg.sessionId, delivered: false },
    }, manager, bridge);
    expect(fixtures.schedules.get(msg.sessionId)).toEqual([msg]);
    expect(connections.broadcastToSession).toHaveBeenCalledWith(msg.sessionId, MessageType.AUTO_RESUME_STATUS,
      expect.objectContaining({ scheduleId: msg.id, phase: AutoResumeStatusPhase.FAILED }));
    await vi.advanceTimersByTimeAsync(60_000);
    expect(connections.sendTo).not.toHaveBeenCalled();

    // Same socket can retry after explicit re-entry; no disconnect is needed.
    await startSessionHandler('old-tab', request, manager, bridge);
    await vi.advanceTimersByTimeAsync(0);
    expect(connections.sendTo.mock.calls.filter(([, type]) => type === MessageType.DELIVER_SCHEDULED_MESSAGE)).toHaveLength(1);
    await scheduledMessageDeliveredHandler('old-tab', {
      type: MessageType.SCHEDULED_MESSAGE_DELIVERED,
      timestamp: Date.now(),
      payload: { id: msg.id, sessionId: msg.sessionId, delivered: true },
    }, manager, bridge);
    expect(fixtures.schedules.get(msg.sessionId)).toEqual([]);
  });

  it.each([true, false])('ignores a different tab attempting to settle a delivery with delivered=%s', async (delivered) => {
    const { connections, manager } = connectionFixture();
    const msg = reservation();
    await scheduleMessage(msg, manager);
    await vi.advanceTimersByTimeAsync(0);
    connections.sendTo.mockClear();
    connections.broadcastToSession.mockClear();

    await scheduledMessageDeliveredHandler('new-tab', {
      type: MessageType.SCHEDULED_MESSAGE_DELIVERED,
      timestamp: Date.now(),
      payload: { id: msg.id, sessionId: msg.sessionId, delivered },
    }, manager, bridge);
    expect(fixtures.schedules.get(msg.sessionId)).toEqual([msg]);
    expect(connections.broadcastToSession).not.toHaveBeenCalled();
    await startSessionHandler('old-tab', request, manager, bridge);
    await vi.advanceTimersByTimeAsync(0);
    expect(connections.sendTo).not.toHaveBeenCalledWith(expect.anything(), MessageType.DELIVER_SCHEDULED_MESSAGE,
      expect.anything());
  });

  it('ignores a recipient acknowledgement for a different session', async () => {
    const { connections, manager } = connectionFixture();
    const msg = reservation();
    await scheduleMessage(msg, manager);
    await vi.advanceTimersByTimeAsync(0);
    connections.broadcastToSession.mockClear();

    await scheduledMessageDeliveredHandler('old-tab', {
      type: MessageType.SCHEDULED_MESSAGE_DELIVERED,
      timestamp: Date.now(),
      payload: { id: msg.id, sessionId: 'another-session', delivered: false },
    }, manager, bridge);
    expect(fixtures.schedules.get(msg.sessionId)).toEqual([msg]);
    expect(connections.broadcastToSession).not.toHaveBeenCalled();
    // The matching legacy acknowledgement remains accepted.
    await scheduledMessageDeliveredHandler('old-tab', {
      type: MessageType.SCHEDULED_MESSAGE_DELIVERED,
      timestamp: Date.now(),
      payload: { id: msg.id, sessionId: msg.sessionId },
    }, manager, bridge);
    expect(fixtures.schedules.get(msg.sessionId)).toEqual([]);
  });

  it('does not emit auto-resume status for a rejected ordinary scheduled message', async () => {
    const { connections, manager } = connectionFixture();
    const msg = { ...reservation(), kind: ScheduledMessageKind.USER_SCHEDULED };
    await scheduleMessage(msg, manager);
    await vi.advanceTimersByTimeAsync(0);
    connections.broadcastToSession.mockClear();

    await scheduledMessageDeliveredHandler('old-tab', {
      type: MessageType.SCHEDULED_MESSAGE_DELIVERED,
      timestamp: Date.now(),
      payload: { id: msg.id, sessionId: msg.sessionId, delivered: false },
    }, manager, bridge);
    expect(fixtures.schedules.get(msg.sessionId)).toEqual([msg]);
    expect(connections.broadcastToSession).not.toHaveBeenCalled();
  });
});
