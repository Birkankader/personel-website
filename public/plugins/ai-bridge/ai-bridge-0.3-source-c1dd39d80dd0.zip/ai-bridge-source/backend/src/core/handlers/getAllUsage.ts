import { unsupportedServiceHandler } from './unsupportedServices';
export function resetAllUsageCache(): void {}
export const getAllUsageHandler = unsupportedServiceHandler;
