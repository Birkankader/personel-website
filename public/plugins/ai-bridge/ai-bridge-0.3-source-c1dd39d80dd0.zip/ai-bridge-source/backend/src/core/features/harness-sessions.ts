import { existsSync } from 'fs';
import { open, readFile } from 'fs/promises';
import { homedir } from 'os';
import { join, sep } from 'path';
import { getProjectSessionsPath, normalizeProjectPath } from './getProjectSessionsPath';
import { isWslUncPath, toWslPath } from '../wsl-path';
import { DEFAULT_HARNESS, isHarnessId, type HarnessId, type AcpHarnessId } from '../../shared';

/**
 * Where conversations run on a third-party harness (OpenCode, DeepSeek Harness)
 * are kept.
 *
 * Those agents keep their own history in their own stores, which no Claude
 * command reads and which differ per harness. So the ACP bridge records each
 * conversation here as well, one JSONL per session, written in the same entry
 * shape the Claude CLI uses for its transcripts. That is what lets the session
 * list, history loading and search treat both kinds alike.
 *
 * It is a separate tree under the plugin's own data directory and never inside
 * CLAUDE_CONFIG_DIR: these files are ours, not Claude's, and nothing of Claude's
 * is edited or imitated in its own directory.
 */
export function getHarnessSessionsRoot(): string {
  return join(homedir(), '.ai-bridge', 'harness-sessions');
}

/** The per-project directory, named exactly as the Claude projects directory is. */
export function getHarnessSessionsPath(workingDir: string): string {
  // Same WSL conversion as getProjectSessionsPath, so one project maps to one name.
  const dir =
    process.platform === 'linux' && isWslUncPath(workingDir)
      ? toWslPath(workingDir) ?? workingDir
      : workingDir;
  return join(getHarnessSessionsRoot(), normalizeProjectPath(dir));
}

/** First entry of every harness transcript, re-appended when the agent's own session changes. */
export const HARNESS_META_TYPE = 'harness-session';

export interface HarnessSessionMeta {
  type: typeof HARNESS_META_TYPE;
  harness: AcpHarnessId;
  /** The session id the harness itself assigned (`session/new`), used to resume it. */
  agentSessionId?: string;
  sessionId: string;
  cwd: string;
  timestamp: string;
}

/** The last meta entry in a transcript's text, or null when it has none. */
export function parseHarnessMeta(text: string): HarnessSessionMeta | null {
  let meta: HarnessSessionMeta | null = null;
  for (const line of text.split('\n')) {
    if (!line.includes(HARNESS_META_TYPE)) continue;
    try {
      const entry = JSON.parse(line) as Record<string, unknown>;
      if (entry.type === HARNESS_META_TYPE && isHarnessId(entry.harness) && entry.harness !== 'claude') {
        meta = entry as unknown as HarnessSessionMeta;
      }
    } catch {
      // A torn last line is expected while the bridge is writing; skip it.
    }
  }
  return meta;
}

/** How much of a transcript's head is read for its harness; the meta entry is its first line. */
const META_HEAD_BYTES = 16 * 1024;

/**
 * The harness a transcript in the harness tree was recorded on, read from its
 * head only, so listing a page of sessions does not read whole transcripts.
 * A transcript without a meta entry counts as OpenCode, as in resolveSessionFile.
 */
export async function readHarnessOfTranscript(file: string): Promise<AcpHarnessId> {
  try {
    const handle = await open(file, 'r');
    try {
      const buffer = Buffer.alloc(META_HEAD_BYTES);
      const { bytesRead } = await handle.read(buffer, 0, buffer.length, 0);
      return parseHarnessMeta(buffer.subarray(0, bytesRead).toString('utf8'))?.harness ?? 'opencode';
    } finally {
      await handle.close();
    }
  } catch {
    return 'opencode';
  }
}

/** True for a sessions directory inside the harness tree rather than Claude's. */
export function isHarnessSessionsPath(sessionsPath: string): boolean {
  const root = getHarnessSessionsRoot();
  return sessionsPath === root || sessionsPath.startsWith(root + sep);
}

export async function readHarnessMeta(file: string): Promise<HarnessSessionMeta | null> {
  try {
    return parseHarnessMeta(await readFile(file, 'utf8'));
  } catch {
    return null;
  }
}

export interface ResolvedSessionFile {
  /** Directory holding the transcript (also where per-directory side files live). */
  dir: string;
  file: string;
  harness: HarnessId;
  exists: boolean;
}

/**
 * Find a session's transcript, whichever runtime wrote it.
 *
 * Claude's directory is checked first, because that is where nearly every
 * session lives and its CLI owns those ids. A session found in neither place is
 * reported at the Claude path, which keeps every caller's "not found" behaviour
 * exactly what it was before harnesses existed.
 */
export async function resolveSessionFile(workingDir: string, sessionId: string): Promise<ResolvedSessionFile> {
  const claudeDir = await getProjectSessionsPath(workingDir);
  const claudeFile = join(claudeDir, `${sessionId}.jsonl`);
  if (existsSync(claudeFile)) return { dir: claudeDir, file: claudeFile, harness: 'claude', exists: true };

  const harnessDir = getHarnessSessionsPath(workingDir);
  const harnessFile = join(harnessDir, `${sessionId}.jsonl`);
  if (existsSync(harnessFile)) {
    const meta = await readHarnessMeta(harnessFile);
    return { dir: harnessDir, file: harnessFile, harness: meta?.harness ?? 'opencode', exists: true };
  }
  return { dir: claudeDir, file: claudeFile, harness: 'claude', exists: false };
}

/**
 * The harness a session runs on: the one that recorded it, or for a session
 * with no transcript yet, the user's chosen harness. A conversation never moves
 * between runtimes mid-way — neither side could read the other's context.
 */
export async function resolveSessionHarness(
  workingDir: string,
  sessionId: string,
  preferred: unknown,
): Promise<HarnessId> {
  const resolved = await resolveSessionFile(workingDir, sessionId);
  if (resolved.exists) return resolved.harness;
  return isHarnessId(preferred) ? preferred : DEFAULT_HARNESS;
}
