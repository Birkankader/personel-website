import { connectionSettingsHandler } from './connectionSettings';
import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { ClientEnv, MessageType } from '../../shared';
import { Claude } from '../claude';
import { sendMessageHandler } from './sendMessage';
import { runtimeResourcesHandler } from './runtimeResources';
import { stopGenerationHandler } from './stopGeneration';
import { stopSessionHandler } from './stopSession';
import { sendControlRequestHandler } from './sendControlRequest';
import { startSessionHandler } from './startSession';
import { prewarmSessionHandler } from './prewarmSession';
import { sessionChangeHandler } from './sessionChange';
import { toolResponseHandler } from './toolResponse';
import { getSessionsHandler } from './getSessions';
import { loadSessionHandler } from './loadSession';
import { loadPromptHistoryHandler } from './loadPromptHistory';
import { deleteSessionHandler } from './deleteSession';
import { rewindCodeHandler } from './rewindCode';
import { forkSessionHandler } from './forkSession';
import { renameSessionHandler } from './renameSession';
import { getAgentTranscriptHandler } from './getAgentTranscript';
import { watchBackgroundTaskOutputHandler, unwatchBackgroundTaskOutputHandler } from './watchBackgroundTaskOutput';
import { getSettingsHandler } from './getSettings';
import { previewContextHandler } from './previewContext';
import { saveSettingsHandler } from './saveSettings';
import { getClaudeConfigDirHandler } from './getClaudeConfigDir';
import { saveClaudeConfigDirHandler } from './saveClaudeConfigDir';
import { getTelemetryConsentHandler } from './getTelemetryConsent';
import { setTelemetryConsentHandler } from './setTelemetryConsent';
import { getVoicePromptHandler } from './getVoicePrompt';
import { setVoicePromptHandler } from './setVoicePrompt';
import { getAnnouncementsHandler } from './getAnnouncements';
import { dismissAnnouncementHandler } from './dismissAnnouncement';
import { getAnnouncementsEnabledHandler } from './getAnnouncementsEnabled';
import { setAnnouncementsEnabledHandler } from './setAnnouncementsEnabled';
import { getRunnerBestScoreHandler, setRunnerBestScoreHandler } from './runnerBestScore';
import { getSponsorUrlHandler } from './getSponsorUrl';
import { conversationToolsHandler } from './conversationTools';
import { verifyLicenseHandler } from './verifyLicense';
import { getSponsorStatusHandler } from './getSponsorStatus';
import { deactivateLicenseHandler } from './deactivateLicense';
import { checkSponsorHandler } from './checkSponsor';
import {
  getSponsorDevicesHandler,
  removeSponsorDeviceHandler,
  getSponsorInvoicesHandler,
  cancelSponsorSubscriptionHandler,
} from './sponsorAccount';
import { getProjectsHandler } from './getProjects';
import { setProjectFavoriteHandler } from './projectFavorite';
import { deleteProjectHandler } from './deleteProject';
import { setProjectMetaHandler } from './projectMeta';
import { getUsageHandler } from './getUsage';
import { getUsageReportHandler } from './getUsageReport';
import { getAllUsageHandler } from './getAllUsage';
import { openFileHandler } from './openFile';
import { openDiffHandler } from './openDiff';
import { openDiffTabHandler } from './openDiffTab';
import { getDiffPreviewHandler } from './getDiffPreview';
import { resolveDiffHandler } from './resolveDiff';
import { refreshDiffPreviewHandler } from './refreshDiffPreview';
import { applyDiffHandler } from './applyDiff';
import { rejectDiffHandler } from './rejectDiff';
import { createSessionHandler } from './createSession';
import { openNewTabHandler } from './openNewTab';
import { openSessionHandler } from './openSession';
import { setTabNameHandler } from './setTabName';
import { openSettingsHandler } from './openSettings';
import { restartBackendHandler } from './restartBackend';
import { openTerminalHandler } from './openTerminal';
import { openDevToolsHandler } from './openDevTools';
import { getVersionHandler } from './getVersion';
import { getCliUpdateInfoHandler } from './getCliUpdateInfo';
import { updateCliHandler } from './updateCli';
import { installCcbHandler } from './installCcb';
import { uninstallCcbHandler } from './uninstallCcb';
import {
  startDictationHandler,
  sendDictationAudioHandler,
  stopDictationHandler,
  getDictationAvailabilityHandler,
  getExtendKitInfoHandler,
} from './dictation';
import { getCcbInstallHintHandler } from './getCcbInstallHint';
import { getAccountHandler } from './getAccount';
import { getAccountsHandler } from './getAccounts';
import { saveAccountHandler } from './saveAccount';
import { switchAccountHandler } from './switchAccount';
import { verifyAccountSwitchHandler } from './verifyAccountSwitch';
import { deleteAccountHandler } from './deleteAccount';
import { updateAccountPoolsHandler } from './updateAccountPools';
import { updateAccountOrderHandler } from './updateAccountOrder';
import { reclaimSessionHandler } from './reclaimSession';
import {
  scheduleMessageHandler,
  cancelScheduledMessageHandler,
  updateScheduledMessageHandler,
  getScheduledMessagesHandler,
  scheduledMessageDeliveredHandler,
} from './scheduleMessage';
import { loginHandler } from './login';
import { submitLoginCodeHandler } from './submitLoginCode';
import { openUrlHandler } from './openUrl';
import { getAvailableTerminalsHandler } from './getAvailableTerminals';
import { getAvailableEditorsHandler } from './getAvailableEditors';
import { getDetectedCliPathHandler } from './getDetectedCliPath';
import { getDetectedNodePathHandler } from './getDetectedNodePath';
import { pickFilesHandler } from './pickFiles';
import { nativeDropFlushHandler } from './nativeDropFlush';
import { getPluginUpdatesHandler } from './getPluginUpdates';
import { updatePluginHandler } from './updatePlugin';
import { getClaudeSettingsHandler } from './getClaudeSettings';
import { saveClaudeSettingsHandler } from './saveClaudeSettings';
import { setModelHandler } from './setModel';
import { setPermissionModeHandler } from './setPermissionMode';
import { probeFableAvailabilityHandler } from './probeFableAvailability';
import { getWorkingDirHandler } from './getWorkingDir';
import { getIdeRootHandler } from './getIdeRoot';
import { tunnelStartHandler } from './tunnelStart';
import { tunnelStopHandler } from './tunnelStop';
import { getTunnelStatusHandler } from './getTunnelStatus';
import { getTunnelPrereqsHandler } from './getTunnelPrereqs';
import { issueTunnelPairingHandler } from './issueTunnelPairing';
import { issueLocalPairingHandler } from './issueLocalPairing';
import { installCloudflaredHandler } from './installCloudflared';
import { getHarnessStatusHandler } from './getHarnessStatus';
import { installHarnessHandler } from './installHarness';
import { sleepGuardEnableHandler } from './sleepGuardEnable';
import { sleepGuardDisableHandler } from './sleepGuardDisable';
import { listProjectFilesHandler } from './listProjectFiles';
import { getCliConfigHandler } from './getCliConfig';
import { openFolderDialogHandler } from './openFolderDialog';
import { findBackgroundTaskOutputPathHandler } from './findBackgroundTaskOutputPathHandler';
import { listSystemSoundsHandler } from './listSystemSounds';
import { playSystemSoundHandler } from './playSystemSound';
import { clientInfoHandler } from './clientInfo';
import { clientErrorHandler } from './clientError';
import { panelFocusedHandler } from './panelFocused';
import { getMcpServersHandler } from './getMcpServersHandler';
import { getMcpServerToolsHandler } from './getMcpServerToolsHandler';
import {
  reconnectMcpServerHandler,
  authenticateMcpServerHandler,
  clearMcpServerAuthHandler,
  setMcpServerEnabledHandler,
  submitMcpOauthCallbackUrlHandler,
  addMcpServerHandler,
  removeMcpServerHandler,
  searchMcpRegistryHandler,
} from './mcpActionsHandler';
import { isUnsupportedService, unsupportedServiceHandler } from './unsupportedServices';

export async function handleMessage(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  bridge: Bridge,
  bridges: Record<ClientEnv, Bridge>,
): Promise<void> {
  console.error('[node-backend]', `Received: ${message.type}`);
  if (isUnsupportedService(message.type)) {
    await unsupportedServiceHandler(connectionId, message, connections);
    return;
  }

  // Project the active context's CLAUDE_CONFIG_DIR onto process.env up front, so every
  // handler that reads Claude data (sessions, projects) or spawns a child (claude/ccb)
  // resolves the right profile for this workingDir. Messages without a workingDir leave
  // the current context untouched — the project picker (getProjects) sets global itself,
  // and usage/account intentionally keep whatever context is already active. (#123)
  const ctxWorkingDir = (message.payload as { workingDir?: string } | undefined)?.workingDir;
  if (ctxWorkingDir) await Claude.applyConfigDir(ctxWorkingDir);

  switch (message.type) {
    case MessageType.GET_WINDOWS_USER_ENV:
    case MessageType.SAVE_WINDOWS_USER_ENV:
    case MessageType.TEST_CONNECTION:
      await connectionSettingsHandler(connectionId, message, connections);
      break;
    case MessageType.GET_RUNTIME_RESOURCES:
    case MessageType.GET_RUNTIME_TASKS:
    case MessageType.SET_TASK_CONCURRENCY:
    case MessageType.STEER_QUEUED_TASK:
    case MessageType.REORDER_QUEUED_TASKS:
    case MessageType.MERGE_QUEUED_TASKS:
    case MessageType.CANCEL_QUEUED_TASK:
    case MessageType.STOP_RUNTIME_TASK:
      await runtimeResourcesHandler(connectionId, message, connections);
      break;
    case MessageType.SEND_MESSAGE:
      await sendMessageHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.STOP_GENERATION:
      stopGenerationHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.STOP_SESSION:
      stopSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.START_SESSION:
      await startSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.PREWARM_SESSION:
      await prewarmSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SESSION_CHANGE:
      sessionChangeHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.TOOL_RESPONSE:
      await toolResponseHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SEND_CONTROL_REQUEST:
      await sendControlRequestHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_SESSIONS:
      await getSessionsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.LOAD_SESSION:
    case MessageType.LOAD_OLDER_MESSAGES:
      await loadSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.LOAD_PROMPT_HISTORY:
      await loadPromptHistoryHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.DELETE_SESSION:
      await deleteSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.REWIND_CODE:
      await rewindCodeHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.FORK_SESSION:
      await forkSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.RENAME_SESSION:
      await renameSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_AGENT_TRANSCRIPT:
      await getAgentTranscriptHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.WATCH_BACKGROUND_TASK_OUTPUT:
      watchBackgroundTaskOutputHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.UNWATCH_BACKGROUND_TASK_OUTPUT:
      unwatchBackgroundTaskOutputHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_SETTINGS:
      await getSettingsHandler(connectionId, message, connections, bridge, bridges);
      break;
    case MessageType.PREVIEW_CONTEXT:
      await previewContextHandler(connectionId, message, connections);
      break;
    case MessageType.SAVE_SETTINGS:
      await saveSettingsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_CLAUDE_CONFIG_DIR:
      await getClaudeConfigDirHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SAVE_CLAUDE_CONFIG_DIR:
      await saveClaudeConfigDirHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_TELEMETRY_CONSENT:
      await getTelemetryConsentHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_TELEMETRY_CONSENT:
      await setTelemetryConsentHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_ANNOUNCEMENTS:
      await getAnnouncementsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.DISMISS_ANNOUNCEMENT:
      await dismissAnnouncementHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_ANNOUNCEMENTS_ENABLED:
      await getAnnouncementsEnabledHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_ANNOUNCEMENTS_ENABLED:
      await setAnnouncementsEnabledHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_RUNNER_BEST_SCORE:
      await getRunnerBestScoreHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_RUNNER_BEST_SCORE:
      await setRunnerBestScoreHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SEARCH_CONVERSATIONS:
    case MessageType.CANCEL_CONVERSATION_SEARCH:
    case MessageType.GET_CONVERSATION_ANNOTATIONS:
    case MessageType.SAVE_CONVERSATION_ANNOTATION:
      await conversationToolsHandler(connectionId, message, connections);
      break;
    case MessageType.GET_SPONSOR_URL:
      await getSponsorUrlHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_SPONSOR_STATUS:
      await getSponsorStatusHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.VERIFY_LICENSE:
      await verifyLicenseHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.DEACTIVATE_LICENSE:
      await deactivateLicenseHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.CHECK_SPONSOR:
      await checkSponsorHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_SPONSOR_DEVICES:
      await getSponsorDevicesHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.REMOVE_SPONSOR_DEVICE:
      await removeSponsorDeviceHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_SPONSOR_INVOICES:
      await getSponsorInvoicesHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.CANCEL_SPONSOR_SUBSCRIPTION:
      await cancelSponsorSubscriptionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_PROJECTS:
      await getProjectsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_PROJECT_FAVORITE:
      await setProjectFavoriteHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.DELETE_PROJECT:
      await deleteProjectHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_PROJECT_META:
      await setProjectMetaHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_USAGE:
      await getUsageHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_USAGE_REPORT:
      await getUsageReportHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_ALL_USAGE:
      await getAllUsageHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_FILE:
      await openFileHandler(connectionId, message, connections, bridge, bridges);
      break;
    case MessageType.OPEN_DIFF:
      await openDiffHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_DIFF_TAB:
      await openDiffTabHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_DIFF_PREVIEW:
      await getDiffPreviewHandler(connectionId, message, connections);
      break;
    case MessageType.RESOLVE_DIFF:
      await resolveDiffHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.REFRESH_DIFF_PREVIEW:
      await refreshDiffPreviewHandler(connectionId, message, connections);
      break;
    case MessageType.APPLY_DIFF:
      await applyDiffHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.REJECT_DIFF:
      await rejectDiffHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.CREATE_SESSION:
      await createSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_NEW_TAB:
      await openNewTabHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_SESSION:
      await openSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_TAB_NAME:
      await setTabNameHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_SETTINGS:
      await openSettingsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.RESTART_BACKEND:
      restartBackendHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_TERMINAL:
      await openTerminalHandler(connectionId, message, connections, bridge);
      break;

    case MessageType.OPEN_DEV_TOOLS:
      await openDevToolsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_VERSION:
      await getVersionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_CLI_UPDATE_INFO:
      await getCliUpdateInfoHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.UPDATE_CLI:
      await updateCliHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.UNINSTALL_CCB:
      await uninstallCcbHandler(connectionId, message, connections, bridge);
      break;

    case MessageType.INSTALL_CCB:
      await installCcbHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_CCB_INSTALL_HINT:
      await getCcbInstallHintHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.START_DICTATION:
      await startDictationHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SEND_DICTATION_AUDIO:
      await sendDictationAudioHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.STOP_DICTATION:
      await stopDictationHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_DICTATION_AVAILABILITY:
      await getDictationAvailabilityHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_EXTEND_KIT_INFO:
      await getExtendKitInfoHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_VOICE_PROMPT:
      await getVoicePromptHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_VOICE_PROMPT:
      await setVoicePromptHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_ACCOUNT:
      await getAccountHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_ACCOUNTS:
      await getAccountsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SAVE_ACCOUNT:
      await saveAccountHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SWITCH_ACCOUNT:
      await switchAccountHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.VERIFY_ACCOUNT_SWITCH:
      await verifyAccountSwitchHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.DELETE_ACCOUNT:
      await deleteAccountHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.UPDATE_ACCOUNT_POOLS:
      await updateAccountPoolsHandler(connectionId, message, connections, bridge);
      break;

    case MessageType.UPDATE_ACCOUNT_ORDER:
      await updateAccountOrderHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.RECLAIM_SESSION:
      await reclaimSessionHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SCHEDULE_MESSAGE:
      await scheduleMessageHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.CANCEL_SCHEDULED_MESSAGE:
      await cancelScheduledMessageHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.UPDATE_SCHEDULED_MESSAGE:
      await updateScheduledMessageHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_SCHEDULED_MESSAGES:
      await getScheduledMessagesHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SCHEDULED_MESSAGE_DELIVERED:
      await scheduledMessageDeliveredHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.LOGIN:
      await loginHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SUBMIT_LOGIN_CODE:
      submitLoginCodeHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_URL:
      await openUrlHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_AVAILABLE_TERMINALS:
      await getAvailableTerminalsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_AVAILABLE_EDITORS:
      await getAvailableEditorsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_DETECTED_CLI_PATH:
      await getDetectedCliPathHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_DETECTED_NODE_PATH:
      await getDetectedNodePathHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.PICK_FILES:
      await pickFilesHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.NATIVE_DROP_FLUSH:
      await nativeDropFlushHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_PLUGIN_UPDATES:
      await getPluginUpdatesHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.UPDATE_PLUGIN:
      await updatePluginHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_CLAUDE_SETTINGS:
      await getClaudeSettingsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SAVE_CLAUDE_SETTINGS:
      await saveClaudeSettingsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_MODEL:
      setModelHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_PERMISSION_MODE:
      setPermissionModeHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.PROBE_FABLE_AVAILABILITY:
      void probeFableAvailabilityHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_WORKING_DIR:
      getWorkingDirHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_IDE_ROOT:
      await getIdeRootHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.TUNNEL_START:
      await tunnelStartHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.TUNNEL_STOP:
      await tunnelStopHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_TUNNEL_STATUS:
      await getTunnelStatusHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_TUNNEL_PREREQS:
      await getTunnelPrereqsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.ISSUE_TUNNEL_PAIRING:
      await issueTunnelPairingHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.ISSUE_LOCAL_PAIRING:
      await issueLocalPairingHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.INSTALL_CLOUDFLARED:
      await installCloudflaredHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_HARNESS_STATUS:
      await getHarnessStatusHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.INSTALL_HARNESS:
      await installHarnessHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SLEEP_GUARD_ENABLE:
      await sleepGuardEnableHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SLEEP_GUARD_DISABLE:
      await sleepGuardDisableHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.LIST_PROJECT_FILES:
      await listProjectFilesHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_CLI_CONFIG:
      await getCliConfigHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.OPEN_FOLDER_DIALOG:
      await openFolderDialogHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.FIND_BG_TASK_OUTPUT_PATH:
      await findBackgroundTaskOutputPathHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.LIST_SYSTEM_SOUNDS:
      await listSystemSoundsHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.PLAY_SYSTEM_SOUND:
      await playSystemSoundHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.CLIENT_INFO:
      clientInfoHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.CLIENT_ERROR:
      clientErrorHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.PANEL_FOCUSED:
      panelFocusedHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_MCP_SERVERS:
      await getMcpServersHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.RECONNECT_MCP_SERVER:
      await reconnectMcpServerHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.AUTHENTICATE_MCP_SERVER:
      await authenticateMcpServerHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.CLEAR_MCP_SERVER_AUTH:
      await clearMcpServerAuthHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SET_MCP_SERVER_ENABLED:
      await setMcpServerEnabledHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SUBMIT_MCP_OAUTH_CALLBACK_URL:
      await submitMcpOauthCallbackUrlHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.ADD_MCP_SERVER:
      await addMcpServerHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.REMOVE_MCP_SERVER:
      await removeMcpServerHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.SEARCH_MCP_REGISTRY:
      await searchMcpRegistryHandler(connectionId, message, connections, bridge);
      break;
    case MessageType.GET_MCP_SERVER_TOOLS:
      await getMcpServerToolsHandler(connectionId, message, connections, bridge);
      break;
    default:
      console.error('[node-backend]', `Unknown message type: ${message.type}`);
  }
}
