import type { ConnectionEnv, ConnectionTestResult } from '../../shared/connection-settings';

export function connectionEndpoint(baseUrl: string): URL | null {
  try {
    const url = new URL(baseUrl.trim());
    if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) return null;
    // Same base-URL contract as Claude: /v1/messages is appended, preserving
    // gateway path prefixes. A pasted /v1 or endpoint is not silently rewritten.
    url.pathname = url.pathname.replace(/\/+$/, '') + '/v1/messages';
    return url;
  } catch { return null; }
}

export async function testConnection(values: ConnectionEnv): Promise<ConnectionTestResult> {
  const url = connectionEndpoint(values.ANTHROPIC_BASE_URL);
  if (!url) return { code: 'invalidUrl' };
  if (!values.ANTHROPIC_AUTH_TOKEN.trim() || /[\r\n\0]/.test(values.ANTHROPIC_AUTH_TOKEN)) return { code: 'missingToken' };
  if (!values.ANTHROPIC_MODEL.trim()) return { code: 'missingModel' };
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), 12_000);
  try {
    const response = await fetch(url, {
      method: 'POST', redirect: 'manual', signal: controller.signal,
      headers: { Authorization: `Bearer ${values.ANTHROPIC_AUTH_TOKEN}`, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
      body: JSON.stringify({ model: values.ANTHROPIC_MODEL, max_tokens: 1, messages: [{ role: 'user', content: '.' }] }),
    });
    const httpStatus = response.status;
    const statusCode = httpStatus >= 300 && httpStatus < 400 ? 'redirect'
      : httpStatus === 401 ? 'unauthorized' : httpStatus === 403 ? 'forbidden'
      : httpStatus === 404 ? 'notFound' : httpStatus === 400 || httpStatus === 422 ? 'modelError'
      : httpStatus === 429 ? 'rateLimited' : httpStatus >= 500 ? 'serverError'
      : !response.ok ? 'unexpectedResponse' : undefined;
    if (statusCode) {
      await response.body?.cancel();
      return { code: statusCode, httpStatus };
    }
    // A generic 200/HTML landing page is not proof of an Anthropic connection.
    // Bound the body and never return server-controlled text (it may echo auth).
    const reader = response.body?.getReader();
    if (!reader) return { code: 'unexpectedResponse', httpStatus };
    let body = '';
    let bytes = 0;
    const decoder = new TextDecoder();
    for (;;) {
      const chunk = await reader.read();
      if (chunk.done) break;
      bytes += chunk.value.length;
      if (bytes > 64_000) { await reader.cancel(); return { code: 'unexpectedResponse', httpStatus }; }
      body += decoder.decode(chunk.value, { stream: true });
    }
    try {
      const message = JSON.parse(body + decoder.decode());
      return { code: message?.type === 'message' && message?.role === 'assistant' && Array.isArray(message?.content) ? 'connected' : 'unexpectedResponse', httpStatus };
    } catch { return { code: 'unexpectedResponse', httpStatus }; }
  } catch (error) {
    const cause = error as { code?: string; cause?: { code?: string } };
    const code = cause.cause?.code ?? cause.code ?? '';
    return { code: controller.signal.aborted ? 'timeout' : /CERT|TLS|SSL|SELF_SIGNED|UNABLE_TO_VERIFY/.test(code) ? 'tlsError' : 'unreachable' };
  } finally { clearTimeout(timer); }
}
