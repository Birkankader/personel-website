import { afterEach, describe, expect, it, vi } from 'vitest';
import { mkdtemp, readFile, rm } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import type { ConnectionManager } from '../../../ws/connection-manager';
import { runtimeTasks, setTaskConcurrency } from '../runtime-tasks';

const state = vi.hoisted(() => ({ home: '' }));
vi.mock('os', async (original) => ({ ...await original<typeof import('os')>(), homedir: () => state.home }));

describe('backend-scoped task settings', () => {
  afterEach(async () => { vi.unstubAllEnvs(); if (state.home) await rm(state.home, { recursive: true, force: true }); });
  const connection = () => ({ broadcastToAll: vi.fn() }) as unknown as ConnectionManager;

  it('keeps two project backends independent and restores each limit after restart', async () => {
    state.home = await mkdtemp(join(tmpdir(), 'runtime-task-settings-'));
    vi.stubEnv('AI_BRIDGE_RUNTIME_SCOPE', '/projects/a');
    const a = connection(); const first = runtimeTasks(a); await first.ready;
    vi.stubEnv('AI_BRIDGE_RUNTIME_SCOPE', '/projects/b');
    const b = connection(); const second = runtimeTasks(b); await second.ready;
    // A keeps its startup scope even though the process env has since changed.
    await Promise.all([setTaskConcurrency(a, 1), setTaskConcurrency(b, 4)]);
    expect(first.limiter.snapshot().limit).toBe(1);
    expect(second.limiter.snapshot().limit).toBe(4);
    expect(first.settingsFile).not.toBe(second.settingsFile);
    expect(JSON.parse(await readFile(first.settingsFile, 'utf8'))).toEqual({ limit: 1 });
    vi.stubEnv('AI_BRIDGE_RUNTIME_SCOPE', '/projects/a');
    const restartedA = runtimeTasks(connection()); await restartedA.ready;
    vi.stubEnv('AI_BRIDGE_RUNTIME_SCOPE', '/projects/b');
    const restartedB = runtimeTasks(connection()); await restartedB.ready;
    expect(restartedA.limiter.snapshot().limit).toBe(1);
    expect(restartedB.limiter.snapshot().limit).toBe(4);
  });
});
