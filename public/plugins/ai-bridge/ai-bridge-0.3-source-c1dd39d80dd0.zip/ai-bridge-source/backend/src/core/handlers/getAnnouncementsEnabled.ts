import { unsupportedServiceHandler } from './unsupportedServices';

export const getAnnouncementsEnabledHandler = unsupportedServiceHandler;
