import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { getRunnerBestScore, setRunnerBestScore } from '../features/profile';
import { MessageType } from '../../shared';

/** Returns the runner game (easter egg) best score (0 if there is no record). */
export async function getRunnerBestScoreHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const best = await getRunnerBestScore();
  connections.sendTo(connectionId, MessageType.ACK, {
    requestId: message.requestId,
    status: 'ok',
    best,
  });
}

/**
 * Records the score of a finished round. Only updates when it beats the existing best,
 * and returns the current best score whether or not it was updated.
 */
export async function setRunnerBestScoreHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const { score } = (message.payload ?? {}) as { score?: unknown };
  const best = await setRunnerBestScore(typeof score === 'number' ? score : 0);
  connections.sendTo(connectionId, MessageType.ACK, {
    requestId: message.requestId,
    status: 'ok',
    best,
  });
}
