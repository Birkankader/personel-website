import { unsupportedServiceHandler } from './unsupportedServices';

export const getSponsorStatusHandler = unsupportedServiceHandler;
