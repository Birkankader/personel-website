import { EventEmitter } from 'events';
import type { ChildProcess } from 'child_process';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
const mocks = vi.hoisted(() => ({ execFile: vi.fn(), recordCliContainers: vi.fn(), collectMcpServerConfigs: vi.fn() }));
vi.mock('child_process', () => ({ execFile: mocks.execFile }));
vi.mock('util', () => ({
  // Match execFile's custom promisify result, including both output streams.
  promisify: (fn: (...args: unknown[]) => unknown) => (...args: unknown[]) => new Promise((resolve, reject) => {
    fn(...args, (error: Error | null, stdout: string, stderr: string) => error ? reject(error) : resolve({ stdout, stderr }));
  }),
}));
vi.mock('../augmented-path', () => ({ augmentedEnv: () => ({}) }));
vi.mock('../cli-registry', () => ({ recordCliContainers: mocks.recordCliContainers }));
vi.mock('../features/mcp-config-files', () => ({ collectMcpServerConfigs: mocks.collectMcpServerConfigs }));
import { attachMcpContainerReclaim, drainMcpContainerReclaims, reclaimContainers, snapshotContainers } from '../mcp-container-reclaimer';

const servers = [{ image: 'fixture/mcp', command: 'serve' }];
const config = [{ command: 'docker', args: ['run', '-i', '--rm', 'fixture/mcp', 'serve'] }];
const flush = async () => { for (let n = 0; n < 30; n++) await Promise.resolve(); };
let containers: Set<string>;
let removed: string[];
let children: ChildProcess[];
beforeEach(() => {
  vi.clearAllMocks(); containers = new Set(); removed = []; children = [];
  mocks.collectMcpServerConfigs.mockResolvedValue(config);
  mocks.execFile.mockImplementation((_command, args: string[], _options, callback) => {
    let stdout = '';
    if (args[0] === 'ps') stdout = [...containers].join('\n');
    else if (args[0] === 'inspect') stdout = 'fixture/mcp\tserve';
    else if (args[0] === 'rm') { removed.push(args[2]); containers.delete(args[2]); }
    else throw new Error('Unexpected fixture command');
    queueMicrotask(() => callback(null, stdout, ''));
  });
});
afterEach(async () => {
  for (const child of children) { Object.defineProperty(child, 'exitCode', { value: 0 }); child.emit('close', 0); }
  await flush(); await drainMcpContainerReclaims(); vi.useRealTimers();
});

describe('Docker MCP cleanup ownership windows', () => {
  it('does not remove containers of another live CLI with an overlapping identical server window', async () => {
    const first = await snapshotContainers(servers);
    containers.add('container-a');
    const second = await snapshotContainers(servers);
    containers.add('container-b');
    const firstRemoved = await reclaimContainers(first);
    const secondRemoved = await reclaimContainers(second);
    expect(firstRemoved).toEqual([]);
    expect(secondRemoved).toEqual([]);
    expect(removed).toEqual([]);
    expect([...containers]).toEqual(['container-a', 'container-b']);
  });

  it('retains cleanup for an isolated CLI and releases its completed window', async () => {
    const first = await snapshotContainers(servers);
    containers.add('container-a');
    expect(await reclaimContainers(first)).toEqual(['container-a']);
    const second = await snapshotContainers(servers);
    containers.add('container-b');
    expect(await reclaimContainers(second)).toEqual(['container-b']);
  });

  it('does not persist ambiguous IDs for destructive cleanup on the next backend start', async () => {
    vi.useFakeTimers({ toFake: ['setTimeout', 'clearTimeout'] });
    const child = (pid: number) => Object.assign(new EventEmitter(), { pid, exitCode: null, signalCode: null }) as ChildProcess;
    children = [child(42001), child(42002)];
    attachMcpContainerReclaim(children[0], '/fixture'); await flush();
    containers.add('container-a');
    attachMcpContainerReclaim(children[1], '/fixture'); await flush();
    containers.add('container-b');
    await vi.advanceTimersByTimeAsync(4000); await flush();
    expect(mocks.recordCliContainers).not.toHaveBeenCalled();
  });

  it('treats a still-loading configuration as an unknown overlapping owner', async () => {
    let finishConfig!: (value: typeof config) => void;
    mocks.collectMcpServerConfigs.mockImplementationOnce(() => new Promise(resolve => { finishConfig = resolve; }));
    const child = (pid: number) => Object.assign(new EventEmitter(), { pid, exitCode: null, signalCode: null }) as ChildProcess;
    children = [child(42101), child(42102)];
    attachMcpContainerReclaim(children[0], '/fixture');
    attachMcpContainerReclaim(children[1], '/fixture'); await flush();
    containers.add('container-a'); containers.add('container-b');
    Object.defineProperty(children[1], 'exitCode', { value: 0 }); children[1].emit('close', 0);
    await flush();
    finishConfig(config); await flush();
    expect(removed).toEqual([]);
  });
});
