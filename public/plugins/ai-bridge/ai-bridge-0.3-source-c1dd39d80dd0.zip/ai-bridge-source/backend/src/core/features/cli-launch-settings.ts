import { mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import type { ChildProcess } from 'node:child_process';

const SETTINGS_PATH_ENV = 'AI_BRIDGE_CLI_SETTINGS_FILE';

/** Settings layered over the user's own for one chat launch (`claude --settings`). */
export type CliLaunchSettings = { env: Record<string, string> } & Record<string, unknown>;

/** Commits made through AI Bridge carry no Co-Authored-By trailer. This is the
 * CLI's own `attribution` setting; a choice already written in the user's
 * Claude settings (`attribution`, or the older `includeCoAuthoredBy`) wins. */
export function commitAttribution(claudeSettings: Record<string, unknown>): Partial<CliLaunchSettings> {
  const attribution = claudeSettings.attribution;
  const chosen = 'includeCoAuthoredBy' in claudeSettings || attribution === false
    || (typeof attribution === 'object' && attribution !== null && ('commit' in attribution || 'commitTrailers' in attribution));
  return chosen ? {} : { attribution: { commit: '' } };
}

/** Windows chat launches pass through cmd.exe, which consumes inline JSON's
 * quotes. Keep the JSON in a private file and pass only its path. Expanding a
 * quoted environment variable also keeps spaces/metacharacters in TEMP out of
 * the command string assembled by the Job Object wrapper and shell fallback. */
export async function createCliLaunchSettings(settings: CliLaunchSettings, platform = process.platform) {
  const directory = await mkdtemp(join(tmpdir(), 'ai-bridge-cli-settings-'));
  const file = join(directory, 'settings.json');
  const cleanup = () => rm(directory, { recursive: true, force: true });
  try {
    await writeFile(file, JSON.stringify(settings), { encoding: 'utf8', mode: 0o600, flag: 'wx' });
  } catch (error) {
    await cleanup();
    throw error;
  }
  return {
    file,
    args: ['--settings', platform === 'win32' ? `"%${SETTINGS_PATH_ENV}%"` : file],
    env: platform === 'win32' ? { [SETTINGS_PATH_ENV]: file } : {},
    cleanup,
  };
}

/** Retain settings until the process exits: the CLI can read them after spawn
 * and reload them during a session. Failed launches release their file too. */
export async function spawnWithCliLaunchSettings(
  launch: CliLaunchSettings,
  spawn: (settings: Awaited<ReturnType<typeof createCliLaunchSettings>>) => Promise<ChildProcess>,
): Promise<ChildProcess> {
  const settings = await createCliLaunchSettings(launch);
  try {
    const child = await spawn(settings);
    const cleanup = () => { void settings.cleanup().catch(error => console.error('[node-backend] CLI settings cleanup failed:', error)); };
    child.once('close', cleanup);
    child.once('error', cleanup);
    return child;
  } catch (error) {
    await settings.cleanup().catch(cleanupError => console.error('[node-backend] CLI settings cleanup failed:', cleanupError));
    throw error;
  }
}
