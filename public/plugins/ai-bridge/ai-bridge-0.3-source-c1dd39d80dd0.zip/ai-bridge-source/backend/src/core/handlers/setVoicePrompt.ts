import { unsupportedServiceHandler } from './unsupportedServices';

export const setVoicePromptHandler = unsupportedServiceHandler;
