import { homedir } from 'os';
import { gzipSync } from 'zlib';
import { readMergedSettings } from './settings';
import { readMergedClaudeSettings } from './claude-settings';

// Settings snapshot to attach to telemetry. Combines the scattered settings (app settings.js +
// Claude settings) and serializes the **whole object** as JSON (no key filtering — the goal is
// reproduction). Personal data mixed into paths (home directory username, etc.) is replaced
// with '~' in every string.
//
// Rybbit properties are limited to 2048 characters, so large settings do not fit. Settings are
// therefore compressed with gzip+base64 and split into chunks in Rybbit's feature_flags (whose
// values are also limited to 2048) as { settings_0, settings_1, ... } (effectively unlimited).
// This borrows the feature_flags slot (we do not use Rybbit's feature flag feature); once we
// have our own api+Postgres, settings will move there.
//
// Decoding for reproduction (sort and join settings_* → base64 → gunzip → JSON) is done by the
// agent, not by the user (see the parent CLAUDE.md / memory).

// Chunk size with headroom under the feature_flags value limit (2048).
const SETTINGS_CHUNK_SIZE = 1900;

/** Replaces the home directory in a path string with '~' (prefix match). undefined if not a string. */
export function sanitizePath(value: unknown): string | undefined {
  if (typeof value !== 'string' || value.length === 0) return undefined;
  const home = homedir();
  return value.startsWith(home) ? `~${value.slice(home.length)}` : value;
}

// settings is Record<string, unknown>, so values are unknown (same as the existing settings.ts).
// Recursively replaces only the home path in every string value with '~', preserving the structure.
function sanitizeDeep(value: unknown): unknown {
  if (typeof value === 'string') {
    const home = homedir();
    return home.length > 0 ? value.split(home).join('~') : value;
  }
  if (Array.isArray(value)) {
    return value.map(sanitizeDeep);
  }
  if (value !== null && typeof value === 'object') {
    const out: Record<string, unknown> = {};
    for (const [key, v] of Object.entries(value)) {
      out[key] = sanitizeDeep(v);
    }
    return out;
  }
  return value;
}

export interface SettingsSnapshot {
  /** Compressed settings split into chunks that fit the feature_flags value limit (2048). { settings_0, settings_1, ... } */
  settingsChunks: Record<string, string>;
  /** Terminal setting value (home replaced). undefined if unset. */
  terminal: string | undefined;
}

/**
 * Combines app + Claude settings into a snapshot (settings chunks + terminal).
 * NOTE: currently unused on the telemetry send path (sending settings is on hold due to Rybbit limits).
 * To be reused when settings move to our own api+Postgres (memory: ccg-telemetry-settings).
 */
export async function buildSettingsSnapshot(): Promise<SettingsSnapshot> {
  const app = (await readMergedSettings()).settings;
  const claude = (await readMergedClaudeSettings()).settings;
  const merged = { ...app, ...claude };
  const json = JSON.stringify(sanitizeDeep(merged));
  const compressed = gzipSync(Buffer.from(json, 'utf-8')).toString('base64');

  const settingsChunks: Record<string, string> = {};
  for (let i = 0; i * SETTINGS_CHUNK_SIZE < compressed.length; i++) {
    settingsChunks[`settings_${i}`] = compressed.slice(
      i * SETTINGS_CHUNK_SIZE,
      (i + 1) * SETTINGS_CHUNK_SIZE,
    );
  }

  return { settingsChunks, terminal: sanitizePath(app.terminalApp) };
}
