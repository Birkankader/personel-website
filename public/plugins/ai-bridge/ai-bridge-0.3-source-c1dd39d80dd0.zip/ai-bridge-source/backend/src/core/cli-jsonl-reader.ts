import { StringDecoder } from 'node:string_decoder';

/** Process-local UTF-8 framing; scan each chunk once and assemble only complete lines. */
export class CliJsonlReader {
  private readonly decoder = new StringDecoder('utf8');
  private fragments: string[] = [];

  write(chunk: Buffer): string[] {
    return this.consume(this.decoder.write(chunk));
  }

  end(): string[] {
    const lines = this.consume(this.decoder.end());
    if (this.fragments.length > 0) lines.push(this.fragments.join(''));
    this.fragments = [];
    return lines;
  }

  private consume(text: string): string[] {
    // Splitting the previous partial line again for every chunk makes large
    // tool outputs quadratic. Keep the pieces until their newline arrives.
    const lines = text.split('\n');
    const tail = lines.pop()!;
    if (lines.length > 0 && this.fragments.length > 0) {
      this.fragments.push(lines[0]);
      lines[0] = this.fragments.join('');
      this.fragments = [];
    }
    if (tail) this.fragments.push(tail);
    return lines;
  }
}
