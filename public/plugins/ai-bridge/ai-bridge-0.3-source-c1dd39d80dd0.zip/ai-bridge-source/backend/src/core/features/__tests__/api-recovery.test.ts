import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { ApiRecovery, MAX_TRANSIENT_ATTEMPTS, readApiFailure } from '../api-recovery';
import { ContextBudget, contextLimitFromError, estimatePromptTokens } from '../context-budget';
import { AUTO_CONTINUE_PROMPT } from '../../../shared';

vi.mock('../atomic-json', () => ({ updateJsonFile: vi.fn(async () => ({ status: 'ok' })) }));
const contextError = "API Error:400 This model's maximum context length is 126000 tokens. However, you requested 32000 output tokens and your prompt contains at lease 101011 input tokens, for a total of at least 133011 tokens. Please reduce the length of the input prompt or the number of requested output tokens. (parameter=input_token, value=101011)";
const api = (text: string, extra = {}) => ({ type: 'assistant', is_api_error_message: true, message: { content: [{ type: 'text', text }] }, ...extra });
const result = (is_error = false) => ({ type: 'result', is_error });

describe('API failure recognition', () => {
  it('extracts the actual provider limit, not input tokens or requested total', () => {
    expect(contextLimitFromError(contextError)).toBe(126000);
    expect(contextLimitFromError(contextError.replace('126000', '126,000'))).toBe(126000);
    expect(readApiFailure(api(contextError))?.kind).toBe('context');
  });
  it('recognizes both metadata spellings, result errors and stderr envelopes', () => {
    expect(readApiFailure({ ...api('API Error:500 internal server error'), is_api_error_message: undefined, isApiErrorMessage: true })?.kind).toBe('server');
    expect(readApiFailure({ ...result(true), errors: ['API Error:500 internal server error'] })?.kind).toBe('server');
    expect(readApiFailure({ type: 'error', error: contextError })?.kind).toBe('context');
  });
  it('does not retry quoted errors, tool failures, subagent failures, auth, invalid requests or scheduled quota resets', () => {
    for (const event of [
      { ...api(contextError), is_api_error_message: false },
      { type: 'user', message: { content: [{ type: 'tool_result', is_error: true, content: contextError }] } },
      api(contextError, { parent_tool_use_id: 'child' }),
      api('API Error:401 unauthorized'), api('API Error:403 forbidden'), api('API Error:400 invalid tool schema'),
      api("You've hit your limit · resets 3am", { error: 'rate_limit' }),
    ]) expect(readApiFailure(event)).toBeNull();
  });
  it('backs off rate limits and respects provider retry-after', () => {
    expect(readApiFailure(api('API Error:429 too many requests'))?.retryMs).toBe(60000);
    expect(readApiFailure(api('API Error:429 retry-after: 120'))?.retryMs).toBe(120000);
    expect(readApiFailure(api('API Error:503 unavailable', { headers: { 'retry-after': '90' } }))?.retryMs).toBe(90000);
  });
  it('recognizes dropped connections across CLI versions and runtimes as network failures', () => {
    for (const [text, error] of [
      // Bun's fetch, as reported by the native CLI on several office machines.
      ['API Error: The socket connection was closed unexpectedly. For more information, pass `verbose: true` in the second argument to fetch()', 'unknown'],
      ['API Error: Connection closed mid-response. The response above may be incomplete.', 'server_error'],
      ['API Error: Connection closed while thinking, before producing a response. Try again.', 'server_error'],
      ['API Error: Response stalled mid-stream. The response above may be incomplete.', 'server_error'],
      ['API Error: Connection to the API was lost (ECONNRESET). This is usually temporary — try again.', 'server_error'],
      ['API Error: Connection error.', 'server_error'],
      ['API Error: Request timed out.', 'unknown'],
      ['API Error: terminated', 'unknown'],
    ] as const) {
      expect(readApiFailure(api(text, { error }))).toMatchObject({ kind: 'network', retryMs: 2000 });
    }
    // A CLI that dies on a transport failure reports it only on stderr.
    expect(readApiFailure({ type: 'error', error: 'TypeError: fetch failed' })?.kind).toBe('network');
    expect(readApiFailure({ type: 'error', error: 'Error: read ECONNRESET' })?.kind).toBe('network');
  });
  it('reads a failed result by its API error, not by the reply text it carries', () => {
    expect(readApiFailure({ type: 'result', is_error: true, result: 'API Error: Connection error.' })?.kind).toBe('network');
    expect(readApiFailure({ type: 'result', subtype: 'error_max_turns', is_error: true,
      result: 'The dev server refused the connection (ECONNREFUSED); start it with npm run dev.' })).toBeNull();
  });
  it('classifies provider failures without a status and leaves trust errors to the user', () => {
    expect(readApiFailure(api('API Error: Server error mid-response. The response above may be incomplete.', { error: 'server_error' }))?.kind).toBe('server');
    expect(readApiFailure(api('API Error: Repeated 529 Overloaded errors', { error: 'unknown' }))?.kind).toBe('server');
    expect(readApiFailure(api('Unable to connect to API: Self-signed certificate detected. Check your proxy or corporate SSL certificates', { error: 'unknown' }))).toBeNull();
    expect(readApiFailure(api('API Error: 401 {"type":"error","error":{"type":"authentication_error"}}', { error: 'authentication_failed' }))).toBeNull();
    expect(readApiFailure(api('Credit balance is too low', { error: 'billing_error' }))).toBeNull();
  });
});

describe('model context budget', () => {
  it('combines cached and uncached input, reserves output and learns a smaller gateway limit', () => {
    const budget = new ContextBudget({}, {}, 'gateway-model');
    budget.observe({ type: 'assistant', message: { usage: { input_tokens: 1000, cache_read_input_tokens: 90000, cache_creation_input_tokens: 10011, output_tokens: 100 } } });
    budget.observe({ type: 'result', modelUsage: { 'gateway-model': { contextWindow: 200000, maxOutputTokens: 32000, inputTokens: 9000000 } } });
    budget.learnError(contextError);
    expect(budget.view()).toEqual({ model: 'gateway-model', totalTokens: 101011, contextWindow: 126000, maxOutputTokens: 12600, compactAt: 94500 });
    expect(budget.shouldCompact()).toBe(true);
    expect(budget.launchEnv()).toMatchObject({ CLAUDE_CODE_AUTO_COMPACT_WINDOW: '126000', CLAUDE_AUTOCOMPACT_PCT_OVERRIDE: '75', CLAUDE_CODE_MAX_OUTPUT_TOKENS: '12600' });
    budget.observe({ type: 'result', modelUsage: { 'gateway-model': { contextWindow: 1000000 } } });
    expect(budget.window).toBe(126000);
  });
  it('supports small contexts below the CLI 100K window floor with a lower percentage', () => {
    const budget = new ContextBudget({ env: { CLAUDE_CODE_MAX_CONTEXT_TOKENS: '32000', CLAUDE_CODE_MAX_OUTPUT_TOKENS: '2000' } }, {});
    expect(budget.compactAt).toBe(22000);
    expect(budget.launchEnv()).toMatchObject({ CLAUDE_CODE_AUTO_COMPACT_WINDOW: '100000', CLAUDE_AUTOCOMPACT_PCT_OVERRIDE: '22', CLAUDE_CODE_MAX_OUTPUT_TOKENS: '2000' });
  });
  it('keeps unknown capacity unknown, protects custom gateways and does not guess from multi-model totals', () => {
    const budget = new ContextBudget({ env: { ANTHROPIC_BASE_URL: 'https://gateway.example' } }, {}, 'custom');
    budget.observe({ type: 'result', modelUsage: { a: { contextWindow: 200000 }, b: { contextWindow: 1000000 } } });
    expect(budget.window).toBe(0);
    expect(budget.launchEnv()).toMatchObject({ CLAUDE_CODE_AUTO_COMPACT_WINDOW: '100000', CLAUDE_CODE_MAX_OUTPUT_TOKENS: '8192' });
    budget.observe({ type: 'result', modelUsage: { custom: { contextWindow: 1000000, maxOutputTokens: 128000 } } });
    expect(budget.launchEnv()).toMatchObject({ CLAUDE_CODE_AUTO_COMPACT_WINDOW: '100000', CLAUDE_CODE_MAX_OUTPUT_TOKENS: '8192', CLAUDE_AUTOCOMPACT_PCT_OVERRIDE: '75' });
  });

  it('does not restart a native CLI just because its model capability metadata arrived', () => {
    const budget = new ContextBudget({}, {}, 'claude-opus');
    const before = budget.launchEnv();
    budget.observe({ type: 'result', modelUsage: { 'claude-opus': { contextWindow: 200000, maxOutputTokens: 128000 } } });
    expect(budget.launchEnv()).toEqual(before);
  });
  it('ignores subagents and synthetic usage, clears stale usage after compact and model switches', () => {
    const budget = new ContextBudget({}, {}, 'a');
    const usage = { type: 'assistant', message: { model: 'a', usage: { input_tokens: 99999 } } };
    budget.observe(usage);
    budget.observe({ ...usage, is_api_error_message: true, message: { model: '<synthetic>', usage: { input_tokens: 0 } } });
    budget.observe({ ...usage, parent_tool_use_id: 'child', message: { model: 'b', usage: { input_tokens: 1 } } });
    expect(budget.inputTokens).toBe(99999);
    budget.observe({ type: 'system', subtype: 'compact_boundary', compact_metadata: { pre_tokens: 99999 } });
    expect(budget.hasUsage).toBe(false);
    budget.observe(usage);
    budget.setModel('b');
    expect(budget.hasUsage).toBe(false);
    expect(budget.window).toBe(0);
  });
  it('counts file paths and image allowance without treating base64 as text', () => {
    expect(estimatePromptTokens('iş', [{ type: 'image' }, { type: 'file', absolutePath: '/a' }])).toBe(4103);
  });
});

describe('bounded automatic recovery', () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => vi.useRealTimers());
  function fixture() {
    const deps = { send: vi.fn(async () => {}), status: vi.fn(), failed: vi.fn(), valid: vi.fn(() => true) };
    const budget = new ContextBudget({}, {}, 'custom');
    const recovery = new ApiRecovery(budget, deps);
    recovery.begin({ content: 'finish the current task' });
    const finish = (event: Record<string, unknown>) => { recovery.observe(event); return recovery.result(event); };
    return { recovery, budget, deps, finish };
  }
  it('waits for a terminal result, then resumes, compacts on repeat failure and continues only after compact boundary', async () => {
    const { recovery, deps, finish } = fixture();
    recovery.observe(api(contextError));
    await vi.advanceTimersByTimeAsync(10000);
    expect(deps.send).not.toHaveBeenCalled();
    expect(finish(result(true))).toBe(true);
    await vi.advanceTimersByTimeAsync(2000);
    expect(deps.send).toHaveBeenLastCalledWith({ content: 'continue' });
    recovery.observe(api(contextError));
    expect(finish(result(true))).toBe(true);
    await vi.advanceTimersByTimeAsync(4000);
    expect(deps.send).toHaveBeenLastCalledWith({ content: '/compact' });
    recovery.observe({ type: 'system', subtype: 'compact_boundary' });
    expect(deps.send).toHaveBeenCalledTimes(2);
    expect(finish(result())).toBe(true);
    await vi.advanceTimersByTimeAsync(0);
    expect(deps.send).toHaveBeenLastCalledWith({ content: 'continue' });
    expect(finish(result())).toBe(false);
    await vi.runAllTimersAsync();
    expect(deps.send).toHaveBeenCalledTimes(3);
  });
  it('stops after failed compact, or after a failed post-compact continue, without looping', async () => {
    for (const compactSuccess of [false, true]) {
      const { recovery, deps, finish } = fixture();
      for (let i = 0; i < 2; i++) {
        recovery.observe(api(contextError));
        finish(result(true));
        await vi.runAllTimersAsync();
      }
      if (compactSuccess) {
        recovery.observe({ type: 'system', subtype: 'compact_boundary' });
        finish(result());
        await vi.runAllTimersAsync();
      }
      recovery.observe(api(contextError));
      expect(finish(result(true))).toBe(false);
      await vi.runAllTimersAsync();
      expect(deps.send).toHaveBeenCalledTimes(compactSuccess ? 3 : 2);
      expect(deps.failed).toHaveBeenCalledOnce();
      expect(deps.failed.mock.calls[0]).toHaveLength(2);
      expect(deps.failed.mock.calls[0][1]).toBeUndefined();
    }
  });
  it('retries a dropped connection with growing delays and the continuation prompt, then stops with its kind', async () => {
    const { recovery, deps, finish } = fixture();
    const socket = () => api('API Error: The socket connection was closed unexpectedly. For more information, pass `verbose: true` in the second argument to fetch()', { error: 'unknown' });
    const delays: number[] = [];
    for (let attempt = 1; attempt <= MAX_TRANSIENT_ATTEMPTS.network; attempt++) {
      recovery.observe(socket());
      const before = Date.now();
      expect(finish(result(true))).toBe(true);
      expect(deps.status).toHaveBeenLastCalledWith(expect.objectContaining({ phase: 'waiting', kind: 'network', attempt, maxAttempts: 8 }));
      const retryAt = (deps.status.mock.lastCall?.[0] as { retryAt: number }).retryAt;
      delays.push(retryAt - before);
      await vi.advanceTimersByTimeAsync(retryAt - before);
      expect(deps.send).toHaveBeenCalledTimes(attempt);
      expect(deps.send).toHaveBeenLastCalledWith({ content: AUTO_CONTINUE_PROMPT });
      expect(deps.status).toHaveBeenLastCalledWith(expect.objectContaining({ phase: 'continuing', kind: 'network', attempt }));
    }
    expect(delays).toEqual([2000, 4000, 8000, 16000, 30000, 30000, 30000, 30000]);
    recovery.observe(socket());
    expect(finish(result(true))).toBe(false);
    expect(deps.failed).toHaveBeenCalledOnce();
    expect(deps.failed.mock.calls[0][1]).toBe('network');
    expect(deps.status).toHaveBeenLastCalledWith(expect.objectContaining({ phase: 'failed', kind: 'network' }));
    await vi.runAllTimersAsync();
    expect(deps.send).toHaveBeenCalledTimes(8);
  });
  it('ends recovery when the continuation succeeds and never compacts for a temporary failure', async () => {
    const { recovery, deps, finish } = fixture();
    recovery.observe(api('API Error: Connection closed mid-response. The response above may be incomplete.', { error: 'server_error' }));
    expect(finish(result(true))).toBe(true);
    await vi.advanceTimersByTimeAsync(2000);
    recovery.observe(api('API Error:503 service unavailable'));
    expect(finish(result(true))).toBe(true);
    await vi.advanceTimersByTimeAsync(5000);
    expect(deps.send.mock.calls.map(call => (call as unknown[])[0])).toEqual([{ content: AUTO_CONTINUE_PROMPT }, { content: AUTO_CONTINUE_PROMPT }]);
    recovery.observe({ type: 'assistant', message: { content: [{ type: 'text', text: 'done' }] } });
    expect(finish(result())).toBe(false);
    expect(deps.status).toHaveBeenLastCalledWith(expect.objectContaining({ phase: 'idle' }));
    expect(deps.failed).not.toHaveBeenCalled();
    await vi.runAllTimersAsync();
    expect(deps.send).toHaveBeenCalledTimes(2);
  });
  it('bounds server errors and rate limits separately with provider-sized delays', async () => {
    const { recovery, deps, finish } = fixture();
    const waits: number[] = [];
    const fail = async (event: Record<string, unknown>) => {
      recovery.observe(event);
      const before = Date.now();
      const held = finish(result(true));
      if (held) {
        const retryAt = (deps.status.mock.lastCall?.[0] as { retryAt: number }).retryAt;
        waits.push(retryAt - before);
        await vi.advanceTimersByTimeAsync(retryAt - before);
      }
      return held;
    };
    for (let i = 0; i < MAX_TRANSIENT_ATTEMPTS.server; i++) expect(await fail(api('API Error:500 internal server error'))).toBe(true);
    expect(waits).toEqual([5000, 10000, 20000, 40000, 60000, 60000]);
    // A different temporary kind keeps its own budget.
    expect(await fail(api('API Error:429 too many requests'))).toBe(true);
    expect(waits.at(-1)).toBe(60000);
    expect(await fail(api('API Error:500 internal server error'))).toBe(false);
    expect(deps.failed.mock.calls[0][1]).toBe('server');
  });
  it('retries a compaction interrupted by a dropped connection without losing the held message', async () => {
    const { budget, recovery, finish, deps } = fixture();
    budget.observe({ type: 'result', modelUsage: { custom: { contextWindow: 126000 } } });
    budget.observe({ type: 'assistant', message: { usage: { input_tokens: 85000 } } });
    const prompt = { content: 'a'.repeat(1100), attachments: [{ type: 'image' as const, fileName: 'a.png', mimeType: 'image/png', base64: 'AAAA' }] };
    expect(recovery.begin(prompt)).toEqual({ content: '/compact' });
    recovery.observe(api('API Error: Connection error.', { error: 'server_error' }));
    expect(finish(result(true))).toBe(true);
    await vi.advanceTimersByTimeAsync(2000);
    expect(deps.send).toHaveBeenLastCalledWith({ content: '/compact' });
    recovery.observe({ type: 'system', subtype: 'compact_boundary' });
    expect(finish(result())).toBe(true);
    await vi.runAllTimersAsync();
    expect(deps.send).toHaveBeenLastCalledWith({ ...prompt, echo: false });
  });
  it('does not treat an unconfirmed compact result as successful', async () => {
    const { recovery, deps, finish } = fixture();
    for (let i = 0; i < 2; i++) { recovery.observe(api(contextError)); finish(result(true)); await vi.runAllTimersAsync(); }
    expect(finish(result())).toBe(false);
    expect(deps.failed).toHaveBeenCalledOnce();
  });
  it('cancels backoff on Stop and ignores events from a detached session', async () => {
    const { recovery, deps, finish } = fixture();
    recovery.observe(api('API Error:500 internal server error'));
    finish(result(true));
    recovery.cancel();
    await vi.runAllTimersAsync();
    expect(deps.send).not.toHaveBeenCalled();
    recovery.begin({ content: 'new request' });
    recovery.observe(api(contextError));
    deps.valid.mockReturnValue(false);
    expect(finish(result(true))).toBe(false);
    expect(vi.getTimerCount()).toBe(0);
  });
  it('leaves manual slash commands alone and does not repeat errors already recovered by the CLI', () => {
    const { recovery, finish, deps } = fixture();
    recovery.observe(api('API Error:500 internal server error'));
    recovery.observe({ type: 'assistant', message: { content: [{ type: 'text', text: 'done' }] } });
    expect(finish(result())).toBe(false);
    recovery.begin({ content: '/compact' });
    recovery.observe(api(contextError));
    expect(finish(result(true))).toBe(false);
    expect(deps.send).not.toHaveBeenCalled();
  });
  it('proactively compacts at the budget threshold and continues once', async () => {
    const { budget, recovery, finish, deps } = fixture();
    budget.observe({ type: 'result', modelUsage: { custom: { contextWindow: 126000, maxOutputTokens: 32000 } } });
    recovery.observe({ type: 'assistant', message: { usage: { input_tokens: 87000 } } });
    expect(finish(result())).toBe(true);
    await vi.runAllTimersAsync();
    expect(deps.send).toHaveBeenLastCalledWith({ content: '/compact' });
    recovery.observe({ type: 'system', subtype: 'compact_boundary' });
    finish(result());
    await vi.runAllTimersAsync();
    expect(deps.send).toHaveBeenLastCalledWith({ content: 'continue' });
    expect(finish(result())).toBe(false);
  });
  it('preflights the next message, retaining its attachments and exact text through compaction', async () => {
    const { budget, recovery, finish, deps } = fixture();
    budget.observe({ type: 'result', modelUsage: { custom: { contextWindow: 126000 } } });
    budget.observe({ type: 'assistant', message: { usage: { input_tokens: 85000 } } });
    const prompt = { content: 'a'.repeat(1100), attachments: [{ type: 'image' as const, fileName: 'a.png', mimeType: 'image/png', base64: 'AAAA' }] };
    expect(recovery.begin(prompt)).toEqual({ content: '/compact' });
    recovery.observe({ type: 'system', subtype: 'compact_boundary' });
    finish(result());
    await vi.runAllTimersAsync();
    expect(deps.send).toHaveBeenCalledWith({ ...prompt, echo: false });
  });
  it('rejects a single oversized message without dropping its content or silently sending it', () => {
    const { recovery, budget } = fixture();
    budget.learnError(contextError);
    expect(() => recovery.begin({ content: 'x'.repeat(126000) })).toThrow('Shorten it');
  });
});
