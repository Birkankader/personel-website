export interface LicenseVerifyResult {
  valid: boolean;
  status?: string;
  /** Which paid tier this key grants, as reported by www. */
  tier?: string;
  /** Billing cadence ("monthly" | "yearly"); absent until a subscription resolves it. */
  interval?: string;
  /** List price of the plan, so the UI can say "$5/mo" without another call. */
  price?: SponsorPrice;
  /** Whether a recurring payment exists that could be cancelled. */
  cancellable?: boolean;
  error?: string;
}

/** What a sponsor pays, as reported by www. */
export interface SponsorPrice {
  /** Whole units of the currency (e.g. 5 for $5). */
  amount: number;
  /** ISO 4217 code, e.g. "USD". */
  currency: string;
}

/** One machine this license is active on, as shown in the sponsor's device list. */
export interface SponsorDevice {
  /** Install id (profile.uuid) — also how a device is identified for removal. */
  telemetryId: string | null;
  /** Claude account seen on that install, when known. */
  claudeEmail: string | null;
  /** Human-readable machine label, e.g. "MacBook Pro · macOS". */
  deviceName: string | null;
  /** ISO 8601 — when the key was last seen active there. */
  activatedAt: string | null;
  /**
   * Whether this row is the machine the user is looking at right now. Resolved
   * backend-side by comparing against this install's id, so the webview can
   * label "this device" without the install id ever being handed to it.
   */
  isCurrent: boolean;
}

/** One payment behind the license, with its provider-hosted receipt. */
export interface SponsorInvoice {
  id: string;
  paidAt: string | null;
  /** Amount in the smallest currency unit (e.g. cents). */
  total: number | null;
  currency: string | null;
  status: string | null;
  receiptUrl: string | null;
}

/** Locally persisted sponsor license — a verified key and its last-known status. */
export interface StoredLicense {
  licenseKey: string;
  /** Last status reported by www (e.g. "active"); null if unknown. */
  status: string | null;
  /** When this key was last verified (ISO 8601). */
  verifiedAt: string;
  /** Paid tier, cached from the last verification so the UI can show it offline. */
  tier?: string | null;
  /** Billing cadence ("monthly" | "yearly"), cached alongside the tier. */
  interval?: string | null;
  /** Plan price, cached so the screen renders offline. */
  price?: SponsorPrice | null;
  /** Whether a recurring payment exists that could be cancelled. */
  cancellable?: boolean | null;
}

/** Sponsor entitlement derived from local storage — what the UI toggles on. */
export interface SponsorStatus {
  isSponsor: boolean;
  licenseKey?: string;
  status?: string;
  tier?: string;
  interval?: string;
  price?: SponsorPrice;
  cancellable?: boolean;
  deactivatedAt?: string;
}

export const SERVICE_DISABLED = 'Sponsorship and billing are not supported by AI Bridge.';
export async function verifyLicenseRemote(_key: string): Promise<LicenseVerifyResult> { return { valid: false, status: 'unsupported', error: SERVICE_DISABLED }; }
export async function findSponsorByInstall(_uid: string): Promise<string | null> { return null; }
export async function reportActivation(_key: string): Promise<void> {}
export async function readLicense(): Promise<StoredLicense | null> { return null; }
export async function saveLicense(_license: StoredLicense): Promise<void> { throw new Error(SERVICE_DISABLED); }
export async function deactivateLicense(): Promise<void> { throw new Error(SERVICE_DISABLED); }
export async function wasDeactivatedHere(): Promise<boolean> { return false; }
export async function readDeactivatedAt(): Promise<string | null> { return null; }
export async function clearDeactivation(): Promise<void> {}
export async function getSponsorStatus(): Promise<SponsorStatus> { return { isSponsor: false, status: 'unsupported', cancellable: false }; }
export async function listSponsorDevices(): Promise<SponsorDevice[]> { return []; }
export async function removeSponsorDevice(_id: string): Promise<boolean> { return false; }
export async function listSponsorInvoices(): Promise<SponsorInvoice[]> { return []; }
export async function cancelSponsorSubscription(): Promise<boolean> { return false; }
