import type { ConnectionManager } from '../../ws/connection-manager';
import {
  MessageType,
  ScheduledMessageKind,
  AutoResumeStatusPhase,
  type ScheduledMessage,
} from '../../shared';
import { registerHook, type ScheduleHook } from './scheduled-messages';

/** A reported-reset timed retry is a normal send attempt, not a quota check. */
export interface AutoResumeStatus {
  sessionId: string;
  scheduleId: string;
  phase: AutoResumeStatusPhase;
  attempt: number;
  error?: string;
  errorKind?: 'unknown';
}

export interface AutoResumeHookDeps {
  broadcast: (status: AutoResumeStatus) => void;
}

/**
 * The scheduler waits until sendAt (the provider-reported reset plus the UI's
 * safety margin), then delivers one normal continue through the existing tab
 * send/ACK path. No usage service is consulted and no quota availability is
 * claimed. If the limit remains, Claude returns its normal limit response.
 */
export function createAutoResumeHook(deps: AutoResumeHookDeps): ScheduleHook {
  return async (msg: ScheduledMessage) => {
    try {
      if (!Number.isFinite(Date.parse(msg.sendAt))) {
        throw new Error('Invalid automatic resume time');
      }
      deps.broadcast({
        sessionId: msg.sessionId,
        scheduleId: msg.id,
        phase: AutoResumeStatusPhase.PROCEEDING,
        attempt: 1,
      });
      return { proceed: true };
    } catch (err) {
      const error = err instanceof Error ? err.message : String(err);
      deps.broadcast({
        sessionId: msg.sessionId,
        scheduleId: msg.id,
        phase: AutoResumeStatusPhase.FAILED,
        attempt: 1,
        error,
        errorKind: 'unknown',
      });
      return { proceed: false, done: true, error };
    }
  };
}

/** Install the local timed retry at startup; this never starts a polling loop. */
export function registerAutoResumeHook(connections: ConnectionManager): void {
  registerHook(
    ScheduledMessageKind.AUTO_RESUME,
    createAutoResumeHook({
      broadcast: (status) => {
        connections.broadcastToSession(status.sessionId, MessageType.AUTO_RESUME_STATUS, { ...status });
      },
    }),
  );
}
