import { mkdir, readFile, readdir, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { ContextBudget } from '../context-budget';

const state = vi.hoisted(() => ({ home: `/tmp/ai-bridge-context-${Date.now()}-${Math.random().toString(36).slice(2)}` }));
vi.mock('node:os', async original => ({ ...await original<typeof import('node:os')>(), homedir: () => state.home }));
vi.mock('../getProjectSessionsPath', () => ({ getProjectSessionsPath: async () => join(state.home, 'sessions') }));
const error = "API Error:400 This model's maximum context length is 126000 tokens. Your prompt contains at least 101011 input tokens.";
const settings = { env: { ANTHROPIC_BASE_URL: 'https://gateway.example', ANTHROPIC_API_KEY: 'DO-NOT-PERSIST' } };
afterEach(async () => { await rm(state.home, { recursive: true, force: true }); });

describe('context limits across restarts', () => {
  it('persists only numeric model limits under hashed scope, and isolates models and gateways', async () => {
    const budget = new ContextBudget(settings, {}, 'custom-model');
    budget.learnError(error);
    const cacheDir = join(state.home, '.ai-bridge', 'context-limits');
    let raw = '';
    await vi.waitFor(async () => {
      const files = (await readdir(cacheDir)).filter(name => name.endsWith('.json'));
      expect(files).toHaveLength(1);
      raw = await readFile(join(cacheDir, files[0]), 'utf8');
      expect(raw).toContain('126000');
    });
    expect(raw).not.toContain('DO-NOT-PERSIST');
    expect(raw).not.toContain('custom-model');
    expect(raw).not.toContain('gateway.example');
    const restored = new ContextBudget(settings, {}, 'custom-model');
    await restored.load();
    expect(restored.window).toBe(126000);
    const anotherModel = new ContextBudget(settings, {}, 'another-model');
    await anotherModel.load();
    expect(anotherModel.window).toBe(0);
    const anotherGateway = new ContextBudget({ env: { ANTHROPIC_BASE_URL: 'https://other.example' } }, {}, 'custom-model');
    await anotherGateway.load();
    expect(anotherGateway.window).toBe(0);
  });

  it('restores last main-agent usage from a transcript while preserving the original file', async () => {
    const folder = join(state.home, 'sessions');
    await mkdir(folder, { recursive: true });
    const transcript = [
      { type: 'assistant', message: { model: 'custom-model', usage: { input_tokens: 1000, cache_read_input_tokens: 90000, output_tokens: 300 } } },
      { type: 'assistant', isSidechain: true, message: { model: 'small-model', usage: { input_tokens: 5 } } },
      { type: 'assistant', isApiErrorMessage: true, message: { model: '<synthetic>', content: [{ type: 'text', text: error }], usage: { input_tokens: 0 } } },
    ].map(row => JSON.stringify(row)).join('\n') + '\n';
    const file = join(folder, 'session.jsonl');
    await writeFile(file, transcript);
    const budget = new ContextBudget(settings, {});
    await budget.load('session', '/project');
    expect(budget.model).toBe('custom-model');
    expect(budget.inputTokens).toBe(101011);
    expect(budget.window).toBe(126000);
    expect(budget.shouldCompact()).toBe(true);
    expect(await readFile(file, 'utf8')).toBe(transcript);
    // Wait for the learned limit's asynchronous atomic write before fixture cleanup.
    await vi.waitFor(async () => expect((await readdir(join(state.home, '.ai-bridge', 'context-limits'))).some(f => f.endsWith('.json'))).toBe(true));
  });

  it('does not reuse pre-compact token counts or treat model output capability as a reservation', async () => {
    const folder = join(state.home, 'sessions');
    await mkdir(folder, { recursive: true });
    await writeFile(join(folder, 'compacted.jsonl'), [
      { type: 'assistant', message: { model: 'model', usage: { input_tokens: 190000 } } },
      { type: 'system', subtype: 'compact_boundary', compactMetadata: { preTokens: 190000 } },
    ].map(row => JSON.stringify(row)).join('\n') + '\n');
    const budget = new ContextBudget({}, {});
    await budget.load('compacted', '/project');
    expect(budget.hasUsage).toBe(false);
    budget.observe({ type: 'result', modelUsage: { model: { contextWindow: 200000, maxOutputTokens: 128000 } } });
    expect(budget.maxOutput).toBe(32000);
  });
});
