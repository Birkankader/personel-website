import { createServer, type Server } from 'node:http';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { connectionEndpoint, testConnection } from '../test-connection';

const env = { ANTHROPIC_BASE_URL: '', ANTHROPIC_AUTH_TOKEN: 'fixture-only-token', ANTHROPIC_MODEL: 'office-model' };
let server: Server;
beforeEach(() => { server = createServer(); });
afterEach(async () => { vi.unstubAllGlobals(); vi.useRealTimers(); server.closeAllConnections(); if (server.listening) await new Promise<void>(resolve => server.close(() => resolve())); });
async function listen() {
  await new Promise<void>(resolve => server.listen(0, '127.0.0.1', resolve));
  const address = server.address() as { port: number };
  return `http://127.0.0.1:${address.port}/gateway`;
}
describe('connection test', () => {
  it('uses the exact gateway prefix, Bearer token and model with a one-token Messages request', async () => {
    const received: Record<string, unknown> = {};
    server.on('request', async (req, res) => {
      received.path = req.url; received.auth = req.headers.authorization; received.version = req.headers['anthropic-version'];
      const chunks = []; for await (const chunk of req) chunks.push(chunk);
      received.body = JSON.parse(Buffer.concat(chunks).toString());
      res.end(JSON.stringify({ type: 'message', role: 'assistant', content: [{ type: 'text', text: 'Hi' }] }));
    });
    expect(await testConnection({ ...env, ANTHROPIC_BASE_URL: await listen() + '/' })).toEqual({ code: 'connected', httpStatus: 200 });
    expect(received).toEqual({ path: '/gateway/v1/messages', auth: 'Bearer fixture-only-token', version: '2023-06-01', body: { model: 'office-model', max_tokens: 1, messages: [{ role: 'user', content: '.' }] } });
  });
  it.each([[401, 'unauthorized'], [403, 'forbidden'], [404, 'notFound'], [400, 'modelError'], [422, 'modelError'], [429, 'rateLimited'], [503, 'serverError'], [302, 'redirect']])('classifies HTTP %s without returning server secrets', async (status, code) => {
    server.on('request', (_req, res) => { res.writeHead(status as number, { Location: 'http://should-never-be-contacted.invalid' }); res.end(env.ANTHROPIC_AUTH_TOKEN); });
    expect(await testConnection({ ...env, ANTHROPIC_BASE_URL: await listen() })).toEqual({ code, httpStatus: status });
  });
  it.each(['<html>Login</html>', '{}', '{"type":"message","role":"user","content":[]}', 'x'.repeat(65_000)])('rejects successful non-API/oversized responses (%#)', async body => {
    server.on('request', (_req, res) => res.end(body));
    expect((await testConnection({ ...env, ANTHROPIC_BASE_URL: await listen() })).code).toBe('unexpectedResponse');
  });
  it.each(['file:///private/file', 'https://user:password@example.com', 'https://example.com/?token=secret', 'https://example.com/#x', 'not a url'])('rejects invalid base URL %s', url => {
    expect(connectionEndpoint(url)).toBeNull();
  });
  it('does not silently correct /v1 and tests the same endpoint Claude would use', () => {
    expect(connectionEndpoint('https://example.com/v1')?.pathname).toBe('/v1/v1/messages');
  });
  it('validates missing credentials/model before calling the network', async () => {
    const fetcher = vi.fn(); vi.stubGlobal('fetch', fetcher);
    expect((await testConnection({ ...env, ANTHROPIC_BASE_URL: 'https://example.com', ANTHROPIC_AUTH_TOKEN: '' })).code).toBe('missingToken');
    expect((await testConnection({ ...env, ANTHROPIC_BASE_URL: 'https://example.com', ANTHROPIC_MODEL: '' })).code).toBe('missingModel');
    expect(fetcher).not.toHaveBeenCalled();
  });
  it('bounds a hanging connection and distinguishes TLS failures', async () => {
    vi.useFakeTimers();
    vi.stubGlobal('fetch', vi.fn((_url, options) => new Promise((_resolve, reject) => options.signal.addEventListener('abort', () => reject(new Error('aborted'))))));
    const pending = testConnection({ ...env, ANTHROPIC_BASE_URL: 'https://example.com' });
    await vi.advanceTimersByTimeAsync(12_000);
    expect(await pending).toEqual({ code: 'timeout' });
    vi.stubGlobal('fetch', vi.fn().mockRejectedValue({ cause: { code: 'DEPTH_ZERO_SELF_SIGNED_CERT' } }));
    expect((await testConnection({ ...env, ANTHROPIC_BASE_URL: 'https://example.com' })).code).toBe('tlsError');
  });
});
