import { describe, it, expect, vi, beforeEach } from 'vitest';

// The migration moves settings keys between the two stores so each key ends up
// where the official Claude Code schema says it belongs. We mock both settings
// modules so the tests assert the orchestration (copy → delete, idempotency,
// defensive failure) without touching the filesystem.
vi.mock('../claude-settings', () => ({
  readClaudeSettings: vi.fn(),
  saveClaudeSetting: vi.fn(),
}));

vi.mock('../settings', () => ({
  readSettingsFile: vi.fn(),
  saveSettingToFile: vi.fn(),
}));

import { readClaudeSettings, saveClaudeSetting } from '../claude-settings';
import { readSettingsFile, saveSettingToFile } from '../settings';
import {
  migrateSettingsToCorrectStore,
  MIGRATED_GUI_KEYS,
  RECLAIMED_NATIVE_KEYS,
  RENAMED_TO_NATIVE_KEYS,
  CONFIG_DIR_ENV_KEY,
  LEGACY_SHOW_DIFF_IN_IDE_KEY,
  DIFF_SURFACE_KEY,
  AUTO_RESUME_RESET_KEY,
  resetLegacyAutoResumeDefault,
} from '../settings-migration';
import { DiffSurface } from '../../../shared';

const mockReadClaudeSettings = vi.mocked(readClaudeSettings);
const mockSaveClaudeSetting = vi.mocked(saveClaudeSetting);
const mockReadSettingsFile = vi.mocked(readSettingsFile);
const mockSaveSettingToFile = vi.mocked(saveSettingToFile);

describe('migrateSettingsToCorrectStore', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockSaveSettingToFile.mockResolvedValue({ status: 'ok' });
    mockSaveClaudeSetting.mockResolvedValue({ status: 'ok' });
    mockReadClaudeSettings.mockResolvedValue({});
    mockReadSettingsFile.mockResolvedValue({});
  });

  describe('key sets', () => {
    it('lists the GUI-only keys that must leave the native file', () => {
      // Verified absent from the official schema (schemastore claude-code-settings).
      expect([...MIGRATED_GUI_KEYS].sort()).toEqual(
        [
          'autoResumeOnLimit',
          'focusInputOnEditorContext',
          'uiLanguage',
          'useCtrlEnterToSend',
        ].sort(),
      );
    });

    it('lists the official-schema keys that must return to the native file', () => {
      expect([...RECLAIMED_NATIVE_KEYS].sort()).toEqual(['env', 'language', 'ultracode'].sort());
    });

    // #377: `ultracode` is a key the CLI itself reads from the settings file, so
    // treating it as GUI-only made the migration delete a value the user had set
    // from the terminal on every backend startup.
    it('never treats ultracode as a GUI-only key, so it is not deleted from native', () => {
      expect(MIGRATED_GUI_KEYS).not.toContain('ultracode');
    });

    it('maps the renamed app key onto its official native key name', () => {
      expect(RENAMED_TO_NATIVE_KEYS).toEqual({
        respectGitignoreForContext: 'respectGitignore',
      });
    });
  });

  describe('native → app (GUI-only keys)', () => {
    it('adopts each present GUI key into app settings', async () => {
      mockReadClaudeSettings.mockResolvedValue({
        uiLanguage: 'korean',
        useCtrlEnterToSend: true,
        // native keys that must be left alone:
        model: 'claude-opus-4-6',
        permissions: { defaultMode: 'auto' },
      });

      await migrateSettingsToCorrectStore();

      expect(mockSaveSettingToFile).toHaveBeenCalledWith('uiLanguage', 'korean');
      expect(mockSaveSettingToFile).toHaveBeenCalledWith('useCtrlEnterToSend', true);
    });

    // The native settings file belongs to the user, and a key sitting in it may
    // have been put there by them or by another tool. Adopting the value is our
    // business; deleting someone else's line out of their file is not.
    it('never deletes anything from the native file', async () => {
      mockReadClaudeSettings.mockResolvedValue({
        uiLanguage: 'korean',
        useCtrlEnterToSend: true,
        focusInputOnEditorContext: false,
        autoResumeOnLimit: false,
      });

      await migrateSettingsToCorrectStore();

      for (const key of MIGRATED_GUI_KEYS) {
        expect(mockSaveClaudeSetting).not.toHaveBeenCalledWith(key, null);
      }
    });

    it('adopts falsy values too (false / empty are still values)', async () => {
      mockReadClaudeSettings.mockResolvedValue({
        uiLanguage: 'english',
        useCtrlEnterToSend: false,
        focusInputOnEditorContext: false,
        autoResumeOnLimit: false,
      });

      await migrateSettingsToCorrectStore();

      expect(mockSaveSettingToFile).toHaveBeenCalledWith('useCtrlEnterToSend', false);
      expect(mockSaveSettingToFile).toHaveBeenCalledWith('focusInputOnEditorContext', false);
      expect(mockSaveSettingToFile).toHaveBeenCalledWith('autoResumeOnLimit', false);
    });

    // Because the native copy is left behind, this runs on every startup. It must
    // therefore not undo what the user has since chosen in the GUI.
    it('does not overwrite an app value the user has already set', async () => {
      mockReadClaudeSettings.mockResolvedValue({ uiLanguage: 'korean' });
      mockReadSettingsFile.mockResolvedValue({ uiLanguage: 'english' });

      await migrateSettingsToCorrectStore();

      expect(mockSaveSettingToFile).not.toHaveBeenCalledWith('uiLanguage', 'korean');
    });

    it('still adopts when the app value is explicitly unset', async () => {
      mockReadClaudeSettings.mockResolvedValue({ uiLanguage: 'korean' });
      mockReadSettingsFile.mockResolvedValue({ uiLanguage: null });

      await migrateSettingsToCorrectStore();

      expect(mockSaveSettingToFile).toHaveBeenCalledWith('uiLanguage', 'korean');
    });

    // #377: a user who set `ultracode` in ~/.claude/settings.json from the
    // terminal used to lose it the next time the backend booted.
    it('leaves a natively-set ultracode alone', async () => {
      mockReadClaudeSettings.mockResolvedValue({ ultracode: true });

      await migrateSettingsToCorrectStore();

      expect(mockSaveClaudeSetting).not.toHaveBeenCalledWith('ultracode', null);
      expect(mockSaveSettingToFile).not.toHaveBeenCalledWith('ultracode', true);
    });

    it('keeps the native key when the app-settings copy fails', async () => {
      mockReadClaudeSettings.mockResolvedValue({ uiLanguage: 'korean' });
      mockSaveSettingToFile.mockResolvedValue({ status: 'error', error: 'disk full' });

      await migrateSettingsToCorrectStore();

      expect(mockSaveSettingToFile).toHaveBeenCalledWith('uiLanguage', 'korean');
      expect(mockSaveClaudeSetting).not.toHaveBeenCalledWith('uiLanguage', null);
    });
  });

  describe('app → native (official-schema keys)', () => {
    it('copies language back to the native file then clears it from app settings', async () => {
      mockReadSettingsFile.mockResolvedValue({ language: 'korean' });

      await migrateSettingsToCorrectStore();

      expect(mockSaveClaudeSetting).toHaveBeenCalledWith('language', 'korean');
      expect(mockSaveSettingToFile).toHaveBeenCalledWith('language', null);
    });

    it('does NOT clear the app value when the native copy fails', async () => {
      mockReadSettingsFile.mockResolvedValue({ language: 'korean' });
      mockSaveClaudeSetting.mockResolvedValue({ status: 'error', error: 'read-only fs' });

      await migrateSettingsToCorrectStore();

      expect(mockSaveClaudeSetting).toHaveBeenCalledWith('language', 'korean');
      expect(mockSaveSettingToFile).not.toHaveBeenCalledWith('language', null);
    });

    it('skips a null app value — an unset key is not a value to migrate', async () => {
      mockReadSettingsFile.mockResolvedValue({ language: null });

      await migrateSettingsToCorrectStore();

      expect(mockSaveClaudeSetting).not.toHaveBeenCalledWith('language', null);
      expect(mockSaveClaudeSetting).not.toHaveBeenCalledWith('language', expect.anything());
    });

    // #377: users who engaged the slider's top notch before this fix have the
    // flag sitting in the app settings, where the CLI never sees it. Carry it
    // over so the setting they already chose starts working.
    it('carries an app-side ultracode over to the native file', async () => {
      mockReadSettingsFile.mockResolvedValue({ ultracode: true });

      await migrateSettingsToCorrectStore();

      expect(mockSaveClaudeSetting).toHaveBeenCalledWith('ultracode', true);
      expect(mockSaveSettingToFile).toHaveBeenCalledWith('ultracode', null);
    });
  });

  describe('env: CLAUDE_CONFIG_DIR stays behind', () => {
    it('moves other env vars to native but keeps CLAUDE_CONFIG_DIR in app settings', async () => {
      mockReadSettingsFile.mockResolvedValue({
        env: {
          [CONFIG_DIR_ENV_KEY]: '/custom/.claude',
          ANTHROPIC_MODEL: 'claude-opus-4-6',
        },
      });

      await migrateSettingsToCorrectStore();

      // Only the non-config-dir vars go native.
      expect(mockSaveClaudeSetting).toHaveBeenCalledWith('env', {
        ANTHROPIC_MODEL: 'claude-opus-4-6',
      });
      // CLAUDE_CONFIG_DIR must remain in app settings: it decides WHERE the
      // native file lives, so storing it inside that file is circular.
      expect(mockSaveSettingToFile).toHaveBeenCalledWith('env', {
        [CONFIG_DIR_ENV_KEY]: '/custom/.claude',
      });
    });

    it('leaves app env untouched when it only holds CLAUDE_CONFIG_DIR', async () => {
      mockReadSettingsFile.mockResolvedValue({
        env: { [CONFIG_DIR_ENV_KEY]: '/custom/.claude' },
      });

      await migrateSettingsToCorrectStore();

      expect(mockSaveClaudeSetting).not.toHaveBeenCalledWith('env', expect.anything());
      expect(mockSaveSettingToFile).not.toHaveBeenCalledWith('env', expect.anything());
    });

    it('merges into existing native env rather than replacing it', async () => {
      mockReadClaudeSettings.mockResolvedValue({ env: { EXISTING: 'keep-me' } });
      mockReadSettingsFile.mockResolvedValue({ env: { ANTHROPIC_MODEL: 'claude-opus-4-6' } });

      await migrateSettingsToCorrectStore();

      expect(mockSaveClaudeSetting).toHaveBeenCalledWith('env', {
        EXISTING: 'keep-me',
        ANTHROPIC_MODEL: 'claude-opus-4-6',
      });
    });

    it('does not let the app value clobber an existing native var of the same name', async () => {
      mockReadClaudeSettings.mockResolvedValue({ env: { ANTHROPIC_MODEL: 'native-wins' } });
      mockReadSettingsFile.mockResolvedValue({ env: { ANTHROPIC_MODEL: 'app-value' } });

      await migrateSettingsToCorrectStore();

      expect(mockSaveClaudeSetting).toHaveBeenCalledWith('env', {
        ANTHROPIC_MODEL: 'native-wins',
      });
    });
  });

  describe('rename + move (respectGitignoreForContext → respectGitignore)', () => {
    it('carries the app value over to the official native key and clears the old one', async () => {
      mockReadSettingsFile.mockResolvedValue({ respectGitignoreForContext: true });

      await migrateSettingsToCorrectStore();

      expect(mockSaveClaudeSetting).toHaveBeenCalledWith('respectGitignore', true);
      expect(mockSaveSettingToFile).toHaveBeenCalledWith('respectGitignoreForContext', null);
    });

    it('also reclaims the stale misnamed key if it is still sitting in the native file', async () => {
      // Shipped versions wrote respectGitignoreForContext straight into the native
      // file — a key the CLI never reads. Clean it up while carrying its value.
      mockReadClaudeSettings.mockResolvedValue({ respectGitignoreForContext: true });

      await migrateSettingsToCorrectStore();

      expect(mockSaveClaudeSetting).toHaveBeenCalledWith('respectGitignore', true);
      expect(mockSaveClaudeSetting).toHaveBeenCalledWith('respectGitignoreForContext', null);
    });

    it('never overwrites an existing official value with the legacy one', async () => {
      mockReadClaudeSettings.mockResolvedValue({ respectGitignore: false });
      mockReadSettingsFile.mockResolvedValue({ respectGitignoreForContext: true });

      await migrateSettingsToCorrectStore();

      expect(mockSaveClaudeSetting).not.toHaveBeenCalledWith('respectGitignore', true);
      // The legacy app key is still cleared — its value simply loses.
      expect(mockSaveSettingToFile).toHaveBeenCalledWith('respectGitignoreForContext', null);
    });
  });

  describe('idempotency and safety', () => {
    it('is a no-op when both stores are already correct', async () => {
      mockReadClaudeSettings.mockResolvedValue({
        model: 'claude-opus-4-6',
        language: 'korean',
        permissions: { defaultMode: 'auto' },
      });
      mockReadSettingsFile.mockResolvedValue({ theme: 'dark', fontSize: 13 });

      await migrateSettingsToCorrectStore();

      expect(mockSaveSettingToFile).not.toHaveBeenCalled();
      expect(mockSaveClaudeSetting).not.toHaveBeenCalled();
    });

    it('resolves without throwing when reading native settings fails (non-fatal)', async () => {
      mockReadClaudeSettings.mockRejectedValue(new Error('read failed'));

      await expect(migrateSettingsToCorrectStore()).resolves.toBeUndefined();
    });

    it('resolves without throwing when reading app settings fails (non-fatal)', async () => {
      mockReadSettingsFile.mockRejectedValue(new Error('read failed'));

      await expect(migrateSettingsToCorrectStore()).resolves.toBeUndefined();
    });
  });

  // `showDiffInIde` asked whether the IDE may show the diff; `diffSurface` names
  // which surface draws it. Both keys are ours and both live in the app settings,
  // so this migration never touches the native file.
  describe('showDiffInIde → diffSurface', () => {
    it('carries a false value onto the built-in surface', async () => {
      mockReadSettingsFile.mockResolvedValue({ [LEGACY_SHOW_DIFF_IN_IDE_KEY]: false });

      await migrateSettingsToCorrectStore();

      expect(mockSaveSettingToFile).toHaveBeenCalledWith(
        DIFF_SURFACE_KEY,
        DiffSurface.BUILT_IN,
      );
      expect(mockSaveSettingToFile).toHaveBeenCalledWith(LEGACY_SHOW_DIFF_IN_IDE_KEY, null);
    });

    it('carries a true value onto the IDE surface', async () => {
      mockReadSettingsFile.mockResolvedValue({ [LEGACY_SHOW_DIFF_IN_IDE_KEY]: true });

      await migrateSettingsToCorrectStore();

      expect(mockSaveSettingToFile).toHaveBeenCalledWith(DIFF_SURFACE_KEY, DiffSurface.IDE);
    });

    it('never writes the native file for a migration between two app keys', async () => {
      mockReadSettingsFile.mockResolvedValue({ [LEGACY_SHOW_DIFF_IN_IDE_KEY]: false });

      await migrateSettingsToCorrectStore();

      expect(mockSaveClaudeSetting).not.toHaveBeenCalled();
    });

    it('does nothing when the legacy key is absent', async () => {
      mockReadSettingsFile.mockResolvedValue({});

      await migrateSettingsToCorrectStore();

      expect(mockSaveSettingToFile).not.toHaveBeenCalled();
    });

    // Idempotency: the first run clears the legacy key, so a second run reads an
    // app store without it and has nothing to do.
    it('does nothing when the legacy key was already cleared to null', async () => {
      mockReadSettingsFile.mockResolvedValue({ [LEGACY_SHOW_DIFF_IN_IDE_KEY]: null });

      await migrateSettingsToCorrectStore();

      expect(mockSaveSettingToFile).not.toHaveBeenCalled();
    });

    // The new key is what the current version writes, so a value under it is
    // newer than anything still sitting under the old name.
    it('keeps an existing diffSurface choice and only clears the legacy key', async () => {
      mockReadSettingsFile.mockResolvedValue({
        [LEGACY_SHOW_DIFF_IN_IDE_KEY]: true,
        [DIFF_SURFACE_KEY]: DiffSurface.BUILT_IN,
      });

      await migrateSettingsToCorrectStore();

      expect(mockSaveSettingToFile).not.toHaveBeenCalledWith(
        DIFF_SURFACE_KEY,
        expect.anything(),
      );
      expect(mockSaveSettingToFile).toHaveBeenCalledWith(LEGACY_SHOW_DIFF_IN_IDE_KEY, null);
    });

    // The key only ever held a boolean, so anything else is corruption. Falling
    // back to the default surface beats guessing at a surface from garbage.
    it('drops a non-boolean legacy value rather than guessing a surface', async () => {
      mockReadSettingsFile.mockResolvedValue({ [LEGACY_SHOW_DIFF_IN_IDE_KEY]: 'yes' });

      await migrateSettingsToCorrectStore();

      expect(mockSaveSettingToFile).not.toHaveBeenCalledWith(
        DIFF_SURFACE_KEY,
        expect.anything(),
      );
      expect(mockSaveSettingToFile).toHaveBeenCalledWith(LEGACY_SHOW_DIFF_IN_IDE_KEY, null);
    });

    // A failed copy must leave the source alone so the value is never lost and
    // the next startup retries — the same contract the other migrations keep.
    it('keeps the legacy key when writing the new one fails', async () => {
      mockReadSettingsFile.mockResolvedValue({ [LEGACY_SHOW_DIFF_IN_IDE_KEY]: false });
      mockSaveSettingToFile.mockResolvedValue({ status: 'error', error: 'disk full' });

      await migrateSettingsToCorrectStore();

      expect(mockSaveSettingToFile).not.toHaveBeenCalledWith(
        LEGACY_SHOW_DIFF_IN_IDE_KEY,
        null,
      );
    });
  });
  describe('autoResumeOnLimit: pre-0.31 default reset', () => {
    it('turns a stored false back on once and marks it done', async () => {
      mockReadSettingsFile.mockResolvedValue({ autoResumeOnLimit: false, [AUTO_RESUME_RESET_KEY]: false });
      await resetLegacyAutoResumeDefault();
      expect(mockSaveSettingToFile).toHaveBeenCalledWith('autoResumeOnLimit', true);
      expect(mockSaveSettingToFile).toHaveBeenCalledWith(AUTO_RESUME_RESET_KEY, true);
    });

    it('keeps a deliberate false once the reset has run', async () => {
      mockReadSettingsFile.mockResolvedValue({ autoResumeOnLimit: false, [AUTO_RESUME_RESET_KEY]: true });
      await resetLegacyAutoResumeDefault();
      expect(mockSaveSettingToFile).not.toHaveBeenCalledWith('autoResumeOnLimit', true);
      expect(mockSaveSettingToFile).not.toHaveBeenCalledWith(AUTO_RESUME_RESET_KEY, true);
    });

    it('only sets the marker when the setting is already on', async () => {
      mockReadSettingsFile.mockResolvedValue({ autoResumeOnLimit: true, [AUTO_RESUME_RESET_KEY]: false });
      await resetLegacyAutoResumeDefault();
      expect(mockSaveSettingToFile).not.toHaveBeenCalledWith('autoResumeOnLimit', true);
      expect(mockSaveSettingToFile).toHaveBeenCalledWith(AUTO_RESUME_RESET_KEY, true);
    });

    it('is not part of the store migration, which must not run in this fork', async () => {
      mockReadSettingsFile.mockResolvedValue({ autoResumeOnLimit: false, [AUTO_RESUME_RESET_KEY]: false });
      await migrateSettingsToCorrectStore();
      expect(mockSaveSettingToFile).not.toHaveBeenCalledWith('autoResumeOnLimit', true);
    });

    it('leaves the marker unset when the reset fails, so the next start retries', async () => {
      mockReadSettingsFile.mockResolvedValue({ autoResumeOnLimit: false, [AUTO_RESUME_RESET_KEY]: false });
      mockSaveSettingToFile.mockImplementation(async (key) => key === 'autoResumeOnLimit' ? { status: 'error', error: 'disk' } : { status: 'ok' });
      await resetLegacyAutoResumeDefault();
      expect(mockSaveSettingToFile).not.toHaveBeenCalledWith(AUTO_RESUME_RESET_KEY, true);
    });
  });
});
