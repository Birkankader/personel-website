import { describe, it, expect, vi } from 'vitest';
import { AutoResumeStatusPhase, ScheduledMessageKind, type ScheduledMessage } from '../../../shared';
import { createAutoResumeHook } from '../auto-resume';

const msg: ScheduledMessage = {
  id: 'r1', sessionId: 'sess-a', sendAt: '2026-03-30T10:00:00.000Z',
  message: 'continue', kind: ScheduledMessageKind.AUTO_RESUME, createdAt: '2026-03-30T09:00:00.000Z',
};

describe('reported-reset timed retry', () => {
  it('reports normal delivery without fabricating any quota result', async () => {
    const broadcast = vi.fn();
    await expect(createAutoResumeHook({ broadcast })(msg)).resolves.toEqual({ proceed: true });
    expect(broadcast).toHaveBeenCalledExactlyOnceWith({
      sessionId: msg.sessionId, scheduleId: msg.id,
      phase: AutoResumeStatusPhase.PROCEEDING, attempt: 1,
    });
  });

  it('fails a malformed reset time instead of sending', async () => {
    const broadcast = vi.fn();
    await expect(createAutoResumeHook({ broadcast })({ ...msg, sendAt: 'invalid' })).resolves.toEqual({
      proceed: false, done: true, error: 'Invalid automatic resume time',
    });
    expect(broadcast).toHaveBeenCalledExactlyOnceWith({
      sessionId: msg.sessionId, scheduleId: msg.id,
      phase: AutoResumeStatusPhase.FAILED, attempt: 1,
      error: 'Invalid automatic resume time', errorKind: 'unknown',
    });
  });

  it('treats an unexpected local error as failure, not as available quota', async () => {
    const broadcast = vi.fn().mockImplementationOnce(() => { throw new Error('local failure'); });
    await expect(createAutoResumeHook({ broadcast })(msg)).resolves.toEqual({
      proceed: false, done: true, error: 'local failure',
    });
    expect(broadcast).toHaveBeenLastCalledWith(expect.objectContaining({
      phase: AutoResumeStatusPhase.FAILED, error: 'local failure', errorKind: 'unknown',
    }));
  });
});
