import { unsupportedServiceHandler } from './unsupportedServices';

export const getTelemetryConsentHandler = unsupportedServiceHandler;
