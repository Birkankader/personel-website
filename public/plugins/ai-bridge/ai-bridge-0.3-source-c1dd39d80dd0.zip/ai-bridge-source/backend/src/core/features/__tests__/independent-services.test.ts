import { afterEach, describe, expect, it, vi } from 'vitest';
import * as license from '../license';
import { claimSponsorByInstall } from '../license-claim';
import { revalidateStoredLicense } from '../license-revalidation';
import { trackEvent, trackActivity, trackError, flushTelemetry } from '../telemetry';
import { fetchAnnouncements } from '../announcements';
import { loadSpeechToText, getExtendKitVersion } from '../../extend-kit';

afterEach(() => { vi.unstubAllGlobals(); vi.unstubAllEnvs(); });

describe('no upstream service transport', () => {
  it('cannot revive upstream services with old endpoint/API-key environment variables or bypass-consent calls', async () => {
    const network = vi.fn(); vi.stubGlobal('fetch', network);
    vi.stubEnv('CCG_WWW_API_BASE', 'https://upstream.invalid/api');
    vi.stubEnv('_CCG_RYBBIT_API_KEY', 'old-secret');
    vi.stubEnv('AI_BRIDGE_ANNOUNCE_URL', 'https://upstream.invalid/announcements');
    expect(await license.verifyLicenseRemote('old-key')).toMatchObject({ valid: false, status: 'unsupported' });
    expect(await license.findSponsorByInstall('install')).toBeNull();
    await license.reportActivation('old-key');
    expect(await claimSponsorByInstall({ throttled: false })).toBe(false);
    const verifier = vi.fn(); await revalidateStoredLicense(verifier); expect(verifier).not.toHaveBeenCalled();
    expect(await license.getSponsorStatus()).toMatchObject({ isSponsor: false, cancellable: false });
    expect(await license.listSponsorDevices()).toEqual([]); expect(await license.listSponsorInvoices()).toEqual([]);
    expect(await license.removeSponsorDevice('device')).toBe(false); expect(await license.cancelSponsorSubscription()).toBe(false);
    trackEvent('startup', {}, { requireConsent: false }); trackActivity('LOGIN'); trackError(new Error('local failure'));
    await flushTelemetry();
    expect(await fetchAnnouncements()).toEqual({ schemaVersion: 1, announcements: [] });
    expect(await getExtendKitVersion()).toBeNull();
    await expect(loadSpeechToText()).rejects.toThrow('not supported');
    expect(network).not.toHaveBeenCalled();
  });

  it('does not store or pretend to deactivate an upstream license', async () => {
    await expect(license.saveLicense({ licenseKey: 'old-key', status: 'active', verifiedAt: new Date().toISOString() })).rejects.toThrow('not supported');
    await expect(license.deactivateLicense()).rejects.toThrow('not supported');
    expect(await license.readLicense()).toBeNull(); expect(await license.readDeactivatedAt()).toBeNull();
  });
});
