import { unsupportedServiceHandler } from './unsupportedServices';

export const getPluginUpdatesHandler = unsupportedServiceHandler;
