import { stat } from 'node:fs/promises';
import { isAbsolute, resolve } from 'node:path';
import type { ConnectionManager } from '../../ws/connection-manager';
import type { IPCMessage } from '../types';
import { MessageType } from '../../shared';
import type { ContextFilePreview } from '../../shared/context-preview';

// Only explicit user-selected references are inspected. Never recursively scan
// folders or read contents: Claude decides what to read later, after sending.
export async function previewContext(paths: unknown, workingDir: string): Promise<ContextFilePreview[]> {
  if (!Array.isArray(paths) || paths.length > 50 || paths.some(p => typeof p !== 'string' || !p || p.length > 4096 || p.includes('\0'))) {
    throw new Error('Expected up to 50 file paths');
  }
  const result: ContextFilePreview[] = [];
  for (const path of [...new Set(paths as string[])]) {
    try {
      const info = await stat(isAbsolute(path) ? path : resolve(workingDir, path));
      result.push(info.isFile()
        ? { path, bytes: info.size, estimatedTokens: Math.ceil(info.size / 4), kind: 'file' }
        : { path, bytes: null, estimatedTokens: null, kind: info.isDirectory() ? 'folder' : 'unavailable' });
    } catch {
      result.push({ path, bytes: null, estimatedTokens: null, kind: 'unavailable' });
    }
  }
  return result;
}

export async function previewContextHandler(connectionId: string, message: IPCMessage, connections: ConnectionManager): Promise<void> {
  try {
    const workingDir = message.payload?.workingDir;
    if (typeof workingDir !== 'string' || !isAbsolute(workingDir)) throw new Error('An absolute working directory is required');
    const files = await previewContext(message.payload?.paths, workingDir);
    connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId, status: 'ok', files });
  } catch (error) {
    connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId, status: 'error', error: String(error) });
  }
}
