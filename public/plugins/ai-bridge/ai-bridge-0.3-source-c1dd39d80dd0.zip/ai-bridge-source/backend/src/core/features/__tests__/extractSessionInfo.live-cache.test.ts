import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { appendFile, mkdtemp, rename, rm, stat, utimes, writeFile } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import { scanTail } from '../extractSessionInfo';

describe('session tail cache on disk', () => {
  let dir: string;
  let file: string;
  const before = '2026-09-08T12:00:00Z';
  const after = '2026-09-08T13:00:00Z';
  const line = (timestamp: string) => JSON.stringify({ type: 'user', timestamp }) + '\n';

  beforeEach(async () => {
    dir = await mkdtemp(join(tmpdir(), 'session-tail-cache-'));
    file = join(dir, 'session.jsonl');
    await writeFile(file, line(before));
  });
  afterEach(async () => { await rm(dir, { recursive: true, force: true }); });

  it('shows an appended message and summary immediately', async () => {
    expect((await scanTail(file)).lastTimestamp).toBe(before);
    await appendFile(file, line(after) + JSON.stringify({ type: 'summary', summary: 'New title' }) + '\n');
    expect(await scanTail(file)).toEqual({ lastTimestamp: after, summary: 'New title' });
  });

  it('detects atomic replacement even with the same length and modification time', async () => {
    const timestamp = new Date('2026-01-01T00:00:00Z');
    await utimes(file, timestamp, timestamp);
    expect((await scanTail(file)).lastTimestamp).toBe(before);
    const original = await stat(file);
    const replacement = join(dir, 'replacement.jsonl');
    await writeFile(replacement, line(after));
    await utimes(replacement, timestamp, timestamp);
    await rename(replacement, file);
    const updated = await stat(file);

    expect(updated.size).toBe(original.size);
    expect(updated.mtimeMs).toBe(original.mtimeMs);
    expect(updated.ino).not.toBe(original.ino);
    expect((await scanTail(file)).lastTimestamp).toBe(after);
  });

  it('invalidates a truncated transcript and does not retain its previous summary', async () => {
    await appendFile(file, JSON.stringify({ type: 'summary', summary: 'Old title' }) + '\n');
    expect((await scanTail(file)).summary).toBe('Old title');
    await writeFile(file, '');
    expect(await scanTail(file)).toEqual({ lastTimestamp: null, summary: null });
  });
});
