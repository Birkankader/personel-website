import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { ConnectionManager } from '../../../ws/connection-manager';
import type { Bridge } from '../../../bridge/bridge-interface';
import { MessageType } from '../../../shared';
import { TaskLimiter } from '../../features/task-limiter';
import { sendMessageHandler } from '../sendMessage';
import { ensureClaudeProcess, sendMessageToProcess } from '../../claude-process';
import { Claude } from '../../claude';

const holder = vi.hoisted(() => ({ manager: null as unknown }));
vi.mock('../../features/runtime-tasks', () => ({ runtimeTasks: () => holder.manager }));
vi.mock('../../claude-process', () => ({ ensureClaudeProcess: vi.fn(async () => {}), sendMessageToProcess: vi.fn(() => true), validateSteeringMessage: vi.fn() }));
vi.mock('../../features/telemetry', () => ({ trackEvent: vi.fn(), reportBackendError: vi.fn() }));
vi.mock('../../claude', () => ({ Claude: { killTree: vi.fn() } }));

describe('SEND_MESSAGE task admission', () => {
  let limiter: TaskLimiter;
  const connections = { subscribe: vi.fn(), sendTo: vi.fn(), broadcastToAll: vi.fn(), broadcastToSession: vi.fn(), getSession: vi.fn() };
  const bridge = {} as Bridge;
  const flush = async () => { for (let i = 0; i < 8; i++) await Promise.resolve(); };
  const send = (sessionId: string) => sendMessageHandler('client', {
    type: MessageType.SEND_MESSAGE, requestId: `request-${sessionId}`, timestamp: 0,
    payload: { sessionId, workingDir: '/project', content: 'hello', isNewSession: true },
  }, connections as unknown as ConnectionManager, bridge);

  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(ensureClaudeProcess).mockResolvedValue(undefined);
  vi.mocked(sendMessageToProcess).mockResolvedValue(true);
    limiter = new TaskLimiter(1, (snapshot) => connections.broadcastToAll(MessageType.TASK_QUEUE_CHANGED, snapshot));
    holder.manager = { limiter, ready: Promise.resolve() };
  });

  it('ACKs queued new sessions without spawning or writing and admits after the prior result', async () => {
    await send('first'); await flush();
    await send('second'); await flush();
    expect(ensureClaudeProcess).toHaveBeenCalledTimes(1);
    expect(sendMessageToProcess).toHaveBeenCalledTimes(1);
    expect(connections.sendTo).toHaveBeenCalledWith('client', MessageType.ACK, expect.objectContaining({ requestId: 'request-second', queued: true, taskId: expect.any(String) }));
    expect(limiter.snapshot().tasks[1]).toMatchObject({ sessionId: 'second', state: 'queued' });
    limiter.release('first'); await flush();
    expect(ensureClaudeProcess).toHaveBeenCalledTimes(2);
    expect(sendMessageToProcess).toHaveBeenLastCalledWith(connections, 'second', 'hello', undefined);
  });

  it('never starts an acknowledged task cancelled while queued', async () => {
    await send('first'); await flush(); await send('second'); await flush();
    const queued = limiter.snapshot().tasks.find((task) => task.sessionId === 'second')!;
    limiter.cancelQueued(queued.id); limiter.release('first'); await flush();
    expect(ensureClaudeProcess).toHaveBeenCalledTimes(1);
    expect(connections.broadcastToAll).toHaveBeenCalledWith(MessageType.TASK_QUEUE_CHANGED, expect.objectContaining({ changedTask: expect.objectContaining({ id: queued.id, state: 'cancelled' }) }));
  });

  it('keeps every pending prompt and its attachments and mode without touching the active process', async () => {
    await send('same'); await flush();
    const queue = (content: string, inputMode: string, attachments?: unknown[]) => sendMessageHandler('client', {
      type: MessageType.SEND_MESSAGE, timestamp: 0,
      payload: { sessionId: 'same', workingDir: '/project', content, inputMode, model: 'chosen-model', userMessageId: content, attachments },
    }, connections as unknown as ConnectionManager, bridge);
    await queue('old', 'plan', [{ type: 'file', fileName: 'old.ts', absolutePath: '/project/old.ts' }]);
    const attachments = [{ type: 'image', fileName: 'latest.png', mimeType: 'image/png', base64: 'aW1hZ2U=' }];
    await queue('latest', 'accept_edits', attachments); await flush();
    expect(ensureClaudeProcess).toHaveBeenCalledTimes(1);
    expect(sendMessageToProcess).toHaveBeenCalledTimes(1);
    expect(Claude.killTree).not.toHaveBeenCalled();
    expect(limiter.snapshot().tasks).toHaveLength(3);
    expect(connections.broadcastToSession).not.toHaveBeenCalledWith('same', MessageType.USER_MESSAGE_BROADCAST,
      expect.objectContaining({ content: 'old', deliveryState: 'sent' }));
    limiter.release('same'); await flush();
    expect(sendMessageToProcess).toHaveBeenLastCalledWith(connections, 'same', 'old', [{ type: 'file', fileName: 'old.ts', absolutePath: '/project/old.ts' }]);
    expect(ensureClaudeProcess).toHaveBeenLastCalledWith(connections, 'client', '/project', 'same', 'plan', bridge, 'chosen-model', true);
    limiter.release('same'); await flush();
    expect(sendMessageToProcess).toHaveBeenLastCalledWith(connections, 'same', 'latest', attachments);
    expect(ensureClaudeProcess).toHaveBeenLastCalledWith(connections, 'client', '/project', 'same', 'accept_edits', bridge, 'chosen-model', true);
    expect(connections.broadcastToSession).toHaveBeenCalledWith('same', MessageType.USER_MESSAGE_BROADCAST,
      expect.objectContaining({ content: 'latest', userMessageId: 'latest', deliveryState: 'sent', attachments }));
  });

  it('steers the backend-owned original prompt and attachments without respawning or changing modes', async () => {
    await send('same'); await flush(); limiter.setProcess('same', 42);
    const content = '<ide_selection>Selected code</ide_selection>\nChange only this';
    const attachments = [{ type: 'image', fileName: 'sample.png', mimeType: 'image/png', base64: 'aW1hZ2U=' }];
    await sendMessageHandler('client', { type: MessageType.SEND_MESSAGE, timestamp: 0,
      payload: { sessionId: 'same', workingDir: '/project', content, attachments, userMessageId: 'steered', inputMode: 'plan' },
    }, connections as unknown as ConnectionManager, bridge);
    const queued = limiter.snapshot().tasks.find(task => task.userMessageId === 'steered')!;
    await limiter.steerQueued(queued.id);
    expect(ensureClaudeProcess).toHaveBeenCalledOnce();
    expect(sendMessageToProcess).toHaveBeenLastCalledWith(connections, 'same', content, attachments, false, queued.id);
    expect(connections.broadcastToSession).not.toHaveBeenCalledWith('same', MessageType.USER_MESSAGE_BROADCAST, expect.objectContaining({ steering: true }));
    limiter.acceptSteering('same', 42, queued.id);
    expect(connections.broadcastToSession).toHaveBeenCalledWith('same', MessageType.USER_MESSAGE_BROADCAST,
      expect.objectContaining({ content, attachments, userMessageId: 'steered', deliveryState: 'sent', steering: true }));
    expect(Claude.killTree).not.toHaveBeenCalled();
  });

  it('sends merged backend-owned content and attachments once, including when steered', async () => {
    await send('same'); await flush(); limiter.setProcess('same', 42);
    const attachments = [{ type: 'image', fileName: 'sample.png', mimeType: 'image/png', base64: 'aW1hZ2U=' }];
    for (const content of ['B', 'C', 'D']) await sendMessageHandler('client', {
      type: MessageType.SEND_MESSAGE, timestamp: 0,
      payload: { sessionId: 'same', workingDir: '/project', content, userMessageId: content, attachments: content === 'C' ? attachments : undefined },
    }, connections as unknown as ConnectionManager, bridge);
    const queued = limiter.snapshot().tasks.filter(task => task.state === 'queued');
    limiter.reorderQueued('same', [queued[2].id, queued[1].id, queued[0].id]);
    limiter.mergeQueued('same', [queued[0].id, queued[1].id]);
    expect(connections.broadcastToSession).toHaveBeenCalledWith('same', MessageType.USER_MESSAGE_BROADCAST,
      expect.objectContaining({ content: 'C\n\nB', attachments, userMessageId: 'C', deliveryState: 'queued' }));
    await limiter.steerQueued(queued[1].id);
    expect(sendMessageToProcess).toHaveBeenLastCalledWith(connections, 'same', 'C\n\nB', attachments, false, queued[1].id);
    limiter.acceptSteering('same', 42, queued[1].id);
    limiter.release('same'); await flush();
    expect(sendMessageToProcess).toHaveBeenLastCalledWith(connections, 'same', 'D', undefined);
    expect(sendMessageToProcess).toHaveBeenCalledTimes(3);
  });

  it('reports async spawn failure and releases the slot for the next task', async () => {
    vi.mocked(ensureClaudeProcess).mockRejectedValueOnce(new Error('CLI missing'));
    await send('first'); await send('second'); await flush();
    expect(connections.broadcastToSession).toHaveBeenCalledWith('first', MessageType.SERVICE_ERROR, { error: 'CLI missing' });
    expect(sendMessageToProcess).toHaveBeenLastCalledWith(connections, 'second', 'hello', undefined);
    expect(limiter.snapshot().tasks.every((task) => task.sessionId !== 'first')).toBe(true);
  });

  it('retains an idle CLI when cancelled during startup and immediately admits a same-session resend', async () => {
    let finishSpawn!: () => void;
    vi.mocked(ensureClaudeProcess).mockImplementationOnce(() => new Promise<void>((resolve) => { finishSpawn = resolve; }));
    await send('same'); await flush();
    limiter.cancelSession('same');
    await send('same'); await flush();
    expect(sendMessageToProcess).not.toHaveBeenCalled();
    expect(ensureClaudeProcess).toHaveBeenCalledOnce();
    finishSpawn(); await flush();
    expect(Claude.killTree).not.toHaveBeenCalled();
    expect(ensureClaudeProcess).toHaveBeenCalledTimes(2);
    expect(sendMessageToProcess).toHaveBeenCalledOnce();
    expect(limiter.snapshot().tasks).toEqual([expect.objectContaining({ sessionId: 'same', state: 'running' })]);
  });
});
