import { EventEmitter } from 'events';
import type { ChildProcess } from 'child_process';
import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { Bridge } from '../../bridge/bridge-interface';
import { ConnectionManager } from '../../ws/connection-manager';
import { TaskLimiter } from '../features/task-limiter';
import { ensureClaudeProcess, sendMessageToProcess } from '../claude-process';
import { Claude } from '../claude';

const state = vi.hoisted(() => ({ manager: null as unknown, settings: {} as Record<string, unknown> }));
vi.mock('../features/runtime-tasks', () => ({ runtimeTasks: () => state.manager }));
vi.mock('../claude', () => ({ Claude: { command: 'claude', applyConfigDir: vi.fn(async () => {}), spawnAuthed: vi.fn(), killTree: vi.fn() } }));
vi.mock('../features/settings', () => ({ readMergedSettings: vi.fn(async () => ({ settings: state.settings })) }));
vi.mock('../features/claude-settings', () => ({ readMergedClaudeSettings: vi.fn(async () => ({ settings: {} })) }));
vi.mock('../features/scheduled-messages', () => ({ restoreSchedulesForSession: vi.fn(async () => {}) }));
vi.mock('../features/lastRecordedSend', () => ({ readLastRecordedSend: vi.fn(async () => null) }));
vi.mock('../cli-registry', () => ({ findLiveCliForSession: vi.fn(() => null), registerCliProcess: vi.fn(), unregisterCliProcess: vi.fn() }));
vi.mock('../features/workflow-tracker', () => ({ WorkflowProgressTracker: { create: () => ({ handleEvent: vi.fn(), stopSession: vi.fn() }) } }));
vi.mock('../features/telemetry', () => ({ reportBackendError: vi.fn() }));

function fakeProcess(pid: number) {
  return Object.assign(new EventEmitter(), {
    pid, exitCode: null as number | null, signalCode: null,
    stdout: new EventEmitter(), stderr: new EventEmitter(),
    stdin: Object.assign(new EventEmitter(), { writable: true, write: vi.fn((_text: string, callback?: (error?: Error | null) => void) => { callback?.(); return true; }) }),
  });
}
type FakeProcess = ReturnType<typeof fakeProcess>;
const bridge = {} as Bridge;
let counter = 0;
let launches: { proc: FakeProcess; args: string[] }[];
let limiter: TaskLimiter;
let connections: ConnectionManager;
let session: string;
let autoSpawn: boolean;

beforeEach(() => {
  vi.clearAllMocks();
  state.settings = {};
  launches = [];
  autoSpawn = true;
  limiter = new TaskLimiter(1);
  state.manager = { limiter, ready: Promise.resolve() };
  connections = new ConnectionManager(true);
  session = `start-concurrency-${++counter}`;
  connections.getOrCreateSession(session, '/fixture');
  vi.mocked(Claude.spawnAuthed).mockImplementation(async args => {
    const proc = fakeProcess(33000 + launches.length);
    launches.push({ proc, args });
    if (autoSpawn) setImmediate(() => proc.emit('spawn'));
    return proc as unknown as ChildProcess;
  });
  vi.mocked(Claude.killTree).mockImplementation(child => {
    const proc = child as unknown as FakeProcess;
    proc.exitCode = 0;
    proc.emit('close', 0);
  });
});
afterEach(() => {
  limiter.shutdown();
  for (const { proc } of launches) {
    if (proc.exitCode === null) { proc.exitCode = 0; proc.emit('close', 0); }
  }
});

describe('per-session Claude startup sharing', () => {
  it('launches once when eight concurrent warm/send paths ask for the same session', async () => {
    await Promise.all(Array.from({ length: 8 }, () =>
      ensureClaudeProcess(connections, 'client', '/fixture', session, undefined, bridge)));
    expect(Claude.spawnAuthed).toHaveBeenCalledTimes(1);
    expect(connections.getSession(session)?.process).toBe(launches[0].proc);
  });

  it('keeps different connection managers independent even when session IDs match', async () => {
    const other = new ConnectionManager(true);
    other.getOrCreateSession(session, '/fixture');
    await Promise.all([
      ensureClaudeProcess(connections, 'client', '/fixture', session, undefined, bridge),
      ensureClaudeProcess(other, 'other', '/fixture', session, undefined, bridge),
    ]);
    expect(Claude.spawnAuthed).toHaveBeenCalledTimes(2);
    expect(connections.getSession(session)?.process).not.toBe(other.getSession(session)?.process);
  });

  it('rechecks a different requested mode after the first startup completes', async () => {
    await Promise.all([
      ensureClaudeProcess(connections, 'client', '/fixture', session, 'plan', bridge),
      ensureClaudeProcess(connections, 'client', '/fixture', session, 'bypass', bridge),
    ]);
    expect(launches).toHaveLength(2);
    expect(Claude.killTree).toHaveBeenCalledTimes(1);
    expect(launches[0].proc.exitCode).toBe(0);
    // No message reached the first CLI, so it left no transcript to resume: the
    // replacement claims the id again (`--resume` would exit "No conversation found").
    expect(launches[1].args).toEqual(expect.arrayContaining(['--session-id', session, '--permission-mode', 'bypassPermissions']));
    expect(launches[1].args).not.toContain('--resume');
    expect(connections.getSession(session)?.process).toBe(launches[1].proc);
  });

  it('applies a new reasoning preference at the admitted send after a warm startup', async () => {
    autoSpawn = false;
    state.settings = { reasoningEffort: 'low' };
    const warm = ensureClaudeProcess(connections, 'client', '/fixture', session, undefined, bridge);
    await vi.waitFor(() => expect(launches).toHaveLength(1));
    state.settings = { reasoningEffort: 'high' };
    const send = ensureClaudeProcess(connections, 'client', '/fixture', session, undefined, bridge, undefined, true);
    launches[0].proc.emit('spawn');
    await vi.waitFor(() => expect(launches).toHaveLength(2));
    launches[1].proc.emit('spawn');
    await Promise.all([warm, send]);
    expect(launches[0].args).toEqual(expect.arrayContaining(['--effort', 'low']));
    expect(launches[1].args).toEqual(expect.arrayContaining(['--effort', 'high', '--session-id', session]));
    expect(Claude.killTree).toHaveBeenCalledTimes(1);
  });

  it('resumes the session on a restart once a message has reached the CLI', async () => {
    await ensureClaudeProcess(connections, 'client', '/fixture', session, 'plan', bridge);
    expect(launches[0].args).toEqual(expect.arrayContaining(['--session-id', session]));
    expect(await sendMessageToProcess(connections, session, 'first message')).toBe(true);
    await ensureClaudeProcess(connections, 'client', '/fixture', session, 'bypass', bridge);
    expect(launches).toHaveLength(2);
    expect(launches[1].args).toEqual(expect.arrayContaining(['--resume', session, '--permission-mode', 'bypassPermissions']));
  });

  it('clears a rejected startup so a later user retry can launch', async () => {
    vi.mocked(Claude.spawnAuthed).mockRejectedValueOnce(new Error('launch failed'));
    const attempts = await Promise.allSettled(Array.from({ length: 3 }, () =>
      ensureClaudeProcess(connections, 'client', '/fixture', session, undefined, bridge)));
    expect(attempts.every(attempt => attempt.status === 'rejected')).toBe(true);
    expect(Claude.spawnAuthed).toHaveBeenCalledTimes(1);
    await ensureClaudeProcess(connections, 'client', '/fixture', session, undefined, bridge);
    expect(Claude.spawnAuthed).toHaveBeenCalledTimes(2);
    expect(connections.getSession(session)?.process).toBe(launches[0].proc);
  });
});
