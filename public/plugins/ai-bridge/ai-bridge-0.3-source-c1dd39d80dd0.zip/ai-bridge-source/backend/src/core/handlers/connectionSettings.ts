import type { ConnectionManager } from '../../ws/connection-manager';
import type { IPCMessage } from '../types';
import { MessageType } from '../../shared';
import { CONNECTION_ENV_KEYS, type ConnectionEnv } from '../../shared/connection-settings';
import { getWindowsUserEnv, saveWindowsUserEnv } from '../features/windows-user-env';
import { testConnection } from '../features/test-connection';

export async function connectionSettingsHandler(connectionId: string, message: IPCMessage, connections: ConnectionManager): Promise<void> {
  const ack = (payload: Record<string, unknown>) => connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId, ...payload });
  try {
    if (message.type === MessageType.GET_WINDOWS_USER_ENV) {
      ack({ status: 'ok', ...await getWindowsUserEnv() });
    } else if (message.type === MessageType.SAVE_WINDOWS_USER_ENV) {
      await saveWindowsUserEnv(message.payload?.key, message.payload?.value);
      ack({ status: 'ok' });
    } else {
      const values = message.payload?.values as ConnectionEnv | undefined;
      if (!values || !CONNECTION_ENV_KEYS.every(key => typeof values[key] === 'string' && values[key].length <= 32760)) {
        ack({ status: 'error' });
        return;
      }
      ack({ status: 'ok', ...await testConnection(values) });
    }
  } catch {
    // Neither native error messages nor request values belong in logs/ACKs.
    ack({ status: 'error' });
  }
}
