import { unsupportedServiceHandler } from './unsupportedServices';

export const startDictationHandler = unsupportedServiceHandler;
export const sendDictationAudioHandler = unsupportedServiceHandler;
export const stopDictationHandler = unsupportedServiceHandler;
export const getDictationAvailabilityHandler = unsupportedServiceHandler;
export const getExtendKitInfoHandler = unsupportedServiceHandler;
export function releaseDictation(_connectionId: string): void {}
