import { describe, expect, it } from 'vitest';
import { CliDiagnostics } from '../cli-diagnostics';

describe('noisy CLI diagnostics', () => {
  it('bounds retained error output and log volume during a sustained burst', () => {
    const diagnostics = new CliDiagnostics();
    const emitted: string[] = [];
    const chunk = 'error '.repeat(2000);
    for (let i = 0; i < 10_000; i++) {
      const preview = diagnostics.stderrChunk(chunk, i / 10);
      if (preview) emitted.push(preview);
    }
    expect(diagnostics.stderr.length).toBeLessThanOrEqual(16 * 1024);
    expect(emitted).toHaveLength(1);
    expect(emitted.join('').length).toBeLessThan(700);
    expect(diagnostics.stderrChunk('latest error', 1000)).toContain('9999 diagnostic chunks suppressed');
    expect(diagnostics.stderr).toContain('latest error');
  });

  it('preserves a split session-conflict signal after subsequent output is evicted', () => {
    const diagnostics = new CliDiagnostics();
    diagnostics.stderrChunk('session is already in', 0);
    diagnostics.stderrChunk(' use', 0);
    diagnostics.stderrChunk('noise'.repeat(10000), 0);
    expect(diagnostics.sessionAlreadyInUse).toBe(true);
    expect(diagnostics.stderr).not.toContain('already in use');
  });

  it('keeps the useful end of a failed process and separates instances', () => {
    const first = new CliDiagnostics(), second = new CliDiagnostics();
    first.stderrChunk('noise'.repeat(10000) + '\nactual failure', 0);
    expect(first.stderr.endsWith('actual failure')).toBe(true);
    expect(second.stderr).toBe('');
    expect(second.stderrChunk('other error', 0)).toBe('other error');
    expect(second.sessionAlreadyInUse).toBe(false);
  });
});
