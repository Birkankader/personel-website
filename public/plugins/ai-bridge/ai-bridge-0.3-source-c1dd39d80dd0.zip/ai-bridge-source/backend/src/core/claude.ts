import { refreshWindowsUserEnv } from './features/windows-user-env';
import {
  spawn as cpSpawn,
  execFile as cpExecFile,
  execFileSync,
  type ChildProcess,
  type SpawnOptions,
  type ExecFileOptions,
  type ExecFileOptionsWithBufferEncoding,
} from 'child_process';
import { readMergedSettings, resolveClaudeConfigDirOverride } from './features/settings';
import { getStrippableAuthEnvKeys } from './features/claude-settings';
import { augmentedPath } from './augmented-path';
import { attachMcpContainerReclaim } from './mcp-container-reclaimer';
import { resolveWslCwd } from './wsl-path';
import { execViaCmdArgv } from './win-exec';
import { pickWin32Launcher } from './which-launcher';
import { spawnWin32JobCli, utf8BashEnv } from './win-job';
import { decodeConsoleOutput } from './console-encoding';

interface ProcessLifecycle {
  trackProcess: (proc: ChildProcess) => void;
  isShuttingDown: () => boolean;
}

export class Claude {
  private static cliPath: string | null = null;
  private static initialized = false;
  private static readonly terminatingWindowsChildren = new WeakMap<ChildProcess, Promise<void>>();
  private static readonly windowsTerminationQueue: Array<() => void> = [];
  private static activeWindowsTerminations = 0;
  private static pumpingWindowsTerminations = false;
  private static processLifecycle: ProcessLifecycle | undefined;

  /** The running backend owns helpers as well as chat children. CLI-only users
   * leave this unset; no unrelated process or external task is adopted. */
  static configureProcessLifecycle(owner?: ProcessLifecycle): void {
    Claude.processLifecycle = owner;
  }

  private static assertCanStart(signal?: AbortSignal): void {
    if (Claude.processLifecycle?.isShuttingDown()) throw new Error('The backend is shutting down.');
    if (signal?.aborted) throw new Error('Claude command cancelled.');
  }

  // Cache of the resolved launcher absolute path on win32 (the result of
  // `where claude`). Populated lazily by execViaCmd() so repeated MCP calls
  // don't re-shell `where` each time. Reset on refresh() in case cliPath changes.
  private static resolvedWin32Path: string | null = null;
  // The CLAUDE_CONFIG_DIR the backend inherited at startup (e.g. exported in the
  // user's shell, or echoed temporarily). Captured once, before any plugin-settings
  // override is applied, so we can restore it when the override is later cleared.
  private static readonly inheritedConfigDir = process.env.CLAUDE_CONFIG_DIR;

  /** Load cliPath from settings. Call at server start or on settings change. */
  static async refresh(workingDir?: string): Promise<void> {
    await refreshWindowsUserEnv();
    Claude.initialized = true;
    await Claude.applyConfigDir(workingDir);
  }

  /**
   * Project the effective CLAUDE_CONFIG_DIR for the given working directory onto
   * process.env, so getClaudeConfigDir(), the spawned `claude`, and the `ccb` usage
   * child all resolve the SAME Claude data directory.
   *
   * Call this whenever an active context LOADS — a chat for a given workingDir, or the
   * project picker with no workingDir — NOT merely when a setting is saved. process.env
   * is a single shared slot on the backend, so projecting only at load time keeps a
   * project-scoped value from leaking across the whole backend (issue #123 follow-up).
   *
   * The Claude CLI reads CLAUDE_CONFIG_DIR only from process.env (never from
   * settings.json's `env`, which it consults too late), so we mirror our setting here.
   * Priority: settings env (project > global) > inherited startup env > ~/.claude.
   */
  static async applyConfigDir(workingDir?: string): Promise<void> {
    // `cliPath` rides along on the same load-time projection. A terminal user can
    // point a project at a specific claude binary, so the GUI must allow it too
    // (CLI equivalence, CLAUDE.md) — hence the merged read rather than the global
    // file. Like process.env below, the resolved command is a single shared slot,
    // so it is re-projected whenever a context loads instead of being cached per
    // call site; that is what keeps a project-scoped value from leaking backend-wide.
    const { settings } = await readMergedSettings(workingDir);
    const nextCliPath = (settings.cliPath as string) || null;
    if (nextCliPath !== Claude.cliPath) {
      Claude.cliPath = nextCliPath;
      // The win32 launcher cache was resolved from the previous binary.
      Claude.resolvedWin32Path = null;
    }

    const override = await resolveClaudeConfigDirOverride(workingDir);
    if (override) {
      process.env.CLAUDE_CONFIG_DIR = override;
    } else if (Claude.inheritedConfigDir !== undefined) {
      process.env.CLAUDE_CONFIG_DIR = Claude.inheritedConfigDir;
    } else {
      delete process.env.CLAUDE_CONFIG_DIR;
    }
  }

  static get command(): string {
    return Claude.cliPath || 'claude';
  }

  /**
   * The CLAUDE_CONFIG_DIR the backend inherited from its environment at startup,
   * before any plugin-settings override was applied (undefined if none). The settings
   * UI surfaces this so a value set only transiently (e.g. echoed/exported in a shell)
   * can be offered for persistence. (#123)
   */
  static get inheritedClaudeConfigDir(): string | undefined {
    return Claude.inheritedConfigDir;
  }

  static get env(): NodeJS.ProcessEnv {
    return {
      ...process.env,
      PATH: augmentedPath(),
    };
  }

  /**
   * Spawn `claude`. Pass `win32JobSessionId` ONLY for the long-lived chat CLI: on
   * win32 it routes the spawn through a Job Object wrapper so the whole CLI tree —
   * including MSYS/git-bash workers that reparent out of the taskkill /F /T tree —
   * is torn down when the wrapper (or the backend) dies. The sessionId rides along
   * so the on-disk registry's orphan sweep can find and kill that wrapper. Short-
   * lived spawns (auth, /usage, config) omit it and keep the plain shell path.
   */
  static spawn(args: string[], options?: SpawnOptions, win32JobSessionId?: string): ChildProcess {
    return Claude.spawnWith(Claude.command, args, options, win32JobSessionId);
  }

  /**
   * {@link spawn} for a stand-in that speaks the CLI's protocol in its place —
   * the ACP bridge that runs a third-party harness. It goes through the very same
   * funnel (job object, environment, lifecycle tracking), so nothing that keeps
   * the CLI supervised is skipped for it. The command is used verbatim: on win32
   * the caller quotes tokens that hold spaces, as the shell path does not.
   */
  static spawnWith(command: string, args: string[], options?: SpawnOptions, win32JobSessionId?: string): ChildProcess {
    Claude.assertCanStart(options?.signal);
    const cwd = resolveWslCwd(options?.cwd);
    const merged = { ...Claude.env, ...options?.env };
    const env = { ...merged, ...utf8BashEnv(merged) };
    const proc =
      process.platform === 'win32' && win32JobSessionId
        ? spawnWin32JobCli(command, args, win32JobSessionId, { ...options, cwd, env })
        : cpSpawn(command, args, {
            ...options,
            cwd,
            shell: options?.shell ?? (process.platform === 'win32'),
            env,
          });
    // A CLI that loads the workspace's MCP servers also starts them, and a server
    // configured as `docker run` outlives that CLI unless its container is removed
    // by id (#363).
    //
    // Attached at this one funnel rather than at the spawns known to load MCP,
    // because which commands those are is not readable from the code and is not
    // stable: it took isolated measurement to establish that `claude mcp list` and
    // a chat session do while `auth status`, `--version`, `-p /usage` and the
    // config probe do not, and a CLI release can move that line. Costs nothing
    // when no `docker run` MCP server is configured — the reclaimer reads the
    // configuration first and stops there.
    // Only a string cwd is meaningful to the reclaimer, which resolves MCP
    // configuration relative to a plain path. No caller passes the URL form.
    Claude.processLifecycle?.trackProcess(proc);
    attachMcpContainerReclaim(proc, typeof cwd === 'string' ? cwd : undefined);
    return proc;
  }

  /**
   * The env overrides that strip inherited OAuth *tokens* before handing the env to a
   * spawned CLI child, given the merged Claude settings for [workingDir]. Centralizes the
   * strip policy (see {@link getStrippableAuthEnvKeys}) so every auth-bearing CLI invocation
   * — chat AND `auth status` — sees the SAME credentials. Previously only the chat spawn
   * stripped, so `auth status` could report a "logged in" state the chat then didn't use.
   * Returns `{ KEY: undefined }` pairs; child_process omits undefined-valued keys from the
   * spawned env. ANTHROPIC_API_KEY is never stripped — see getStrippableAuthEnvKeys.
   */
  private static async authStripEnv(workingDir?: string): Promise<Record<string, undefined>> {
    const keys = await getStrippableAuthEnvKeys(workingDir);
    if (keys.length > 0) {
      console.error('[node-backend]', `Stripping inherited auth env from CLI: ${keys.join(', ')}`);
    }
    return Object.fromEntries(keys.map((k) => [k, undefined]));
  }

  /**
   * {@link spawn} for auth-bearing CLI calls (chat `-p`, `/usage`): identical to spawn but
   * also strips inherited OAuth tokens for [workingDir] so the child authenticates the same
   * way `auth status` reports. Use this instead of spawn for anything whose result depends on
   * the active credentials. Do NOT use it for `auth login` (it intentionally re-authenticates).
   */
  static async spawnAuthed(
    args: string[],
    workingDir?: string,
    options?: SpawnOptions,
    win32JobSessionId?: string,
  ): Promise<ChildProcess> {
    return Claude.spawnAuthedWith(Claude.command, args, workingDir, options, win32JobSessionId);
  }

  /** {@link spawnAuthed} for a stand-in command; see {@link spawnWith}. */
  static async spawnAuthedWith(
    command: string,
    args: string[],
    workingDir?: string,
    options?: SpawnOptions,
    win32JobSessionId?: string,
  ): Promise<ChildProcess> {
    const stripEnv = await Claude.authStripEnv(workingDir);
    return Claude.spawnWith(command, args, { ...options, env: { ...options?.env, ...stripEnv } }, win32JobSessionId);
  }

  /**
   * {@link exec} for auth-bearing CLI calls (`auth status`): identical to exec but also strips
   * inherited OAuth tokens for [workingDir], so the login state it reports matches what the
   * chat spawn actually uses.
   */
  static async execAuthed(
    args: string[],
    workingDir?: string,
    options?: ExecFileOptions,
  ): Promise<{ stdout: string; stderr: string }> {
    const stripEnv = await Claude.authStripEnv(workingDir);
    return Claude.exec(args, { ...options, env: { ...options?.env, ...stripEnv } });
  }

  /**
   * Terminate a process spawned via {@link spawn} AND its children. On win32
   * spawn() runs through a shell, so the real `claude` is a grandchild of
   * cmd.exe — a plain SIGTERM to `proc` leaves it orphaned. `taskkill /T` tears
   * down the whole tree. On macOS/Linux, chat CLIs are spawned detached (see
   * claude-process.ts) so they lead their own process group and signalling
   * `-pid` reaches the CLI plus every descendant (subagent shells, background
   * tasks); for non-detached children the group signal fails with ESRCH and we
   * fall back to a plain signal, which is the pre-existing behavior. Used by
   * every kill path for a spawned CLI child.
   */
  static killTree(proc: ChildProcess, signal: NodeJS.Signals = 'SIGTERM'): void {
    if (!proc.pid) return;
    // Once the child has been reaped, proc.pid is a stale number the OS may have
    // reused. Signalling -proc.pid (or taskkill /T) then hits an unrelated process
    // group/tree. proc.kill() would be a no-op here, but the raw group signal is
    // not liveness-aware — bail before issuing it. (Guards e.g. an uncleared
    // safety-timeout killTree firing after the process already closed.)
    if (proc.exitCode !== null || proc.signalCode !== null) return;
    if (process.platform === 'win32') {
      try {
        execFileSync('taskkill', ['/F', '/T', '/PID', String(proc.pid)],
          { windowsHide: true, timeout: 5000 });
      } catch {
        proc.kill();
      }
    } else {
      try {
        process.kill(-proc.pid, signal);
      } catch {
        // Not a process-group leader (or already gone) — plain signal as before.
        proc.kill(signal);
      }
    }
  }

  /** Normal cleanup, with at most two Windows taskkill helpers running at once.
   * Resolves when the termination attempt finishes; observing child close is a
   * separate lifecycle wait. Never rejects, so probe callers may ignore it.
   * Process exit hooks must use synchronous killTree instead. */
  static killTreeNonBlocking(proc: ChildProcess, signal: NodeJS.Signals = 'SIGTERM'): Promise<void> {
    if (process.platform !== 'win32') {
      try { Claude.killTree(proc, signal); } catch { /* Best-effort cleanup. */ }
      return Promise.resolve();
    }
    const pending = Claude.terminatingWindowsChildren.get(proc);
    if (pending) return pending;
    if (!proc.pid || proc.exitCode !== null || proc.signalCode !== null) return Promise.resolve();
    let complete!: () => void;
    const completion = new Promise<void>((resolve) => { complete = resolve; });
    Claude.terminatingWindowsChildren.set(proc, completion);
    let finished = false;
    const finish = (error: Error | null) => {
      if (finished) return;
      finished = true;
      // A delayed failure must never signal a child that has already been reaped.
      if (error && proc.exitCode === null && proc.signalCode === null) {
        try { proc.kill(signal); } catch { /* Child already exited. */ }
      }
      Claude.terminatingWindowsChildren.delete(proc);
      complete();
      Claude.activeWindowsTerminations--;
      Claude.pumpWindowsTerminations();
    };
    Claude.windowsTerminationQueue.push(() => {
      // A queued child may exit before a helper slot opens. Its old numeric PID
      // must never become a taskkill target after the OS can reuse it.
      if (proc.exitCode !== null || proc.signalCode !== null) { finish(null); return; }
      try {
        cpExecFile('taskkill', ['/F', '/T', '/PID', String(proc.pid)],
          { windowsHide: true, timeout: 5000 }, (error) => finish(error));
      } catch (error) {
        finish(error instanceof Error ? error : new Error(String(error)));
      }
    });
    Claude.pumpWindowsTerminations();
    return completion;
  }

  private static pumpWindowsTerminations(): void {
    if (Claude.pumpingWindowsTerminations) return;
    Claude.pumpingWindowsTerminations = true;
    try {
      while (Claude.activeWindowsTerminations < 2) {
        const next = Claude.windowsTerminationQueue.shift();
        if (!next) break;
        Claude.activeWindowsTerminations++;
        next();
      }
    } finally {
      Claude.pumpingWindowsTerminations = false;
    }
  }

  static async exec(args: string[], options?: ExecFileOptions): Promise<{ stdout: string; stderr: string }> {
    Claude.assertCanStart(options?.signal);
    // The default win32 path runs through a shell so the `.cmd`/`.ps1` launcher
    // resolves (issue #99 — see runExecFile). But a shell tokenizes the argv:
    // for callers that pass arbitrary values (e.g. `mcp add-json <json>` whose
    // JSON carries `"`, `&`, `%`, `|`, spaces), cmd.exe would corrupt the
    // argument and open a command-injection surface. Such callers pass
    // shell:false to demand non-shell-tokenized argv. On win32 that needs special
    // handling: Node 18.20.2/20.12.2+ (CVE-2024-27980) refuses to execFile a
    // .cmd/.bat with shell:false directly (EINVAL), so we spawn cmd.exe ourselves
    // with the launcher as an argv element (see execViaCmd). macOS/Linux run the
    // launcher directly with shell:false and need none of this.
    if (process.platform === 'win32' && options?.shell === false) {
      // MCP container reclaim is disabled on this branch because its only
      // caller is `mcp add-json`, which was measured not to start MCP servers.
      // Managed cancellation and backend process ownership still apply.
      return Claude.execViaCmd(args, options);
    }
    return Claude.runExecFile(Claude.command, args, options);
  }

  /**
   * Run cpExecFile against `command` with the standard env/cwd projection.
   * `shell` defaults to true on win32 (the #99 launcher-resolution path) unless
   * the caller overrides it.
   */
  private static runExecFile(
    command: string,
    args: string[],
    options?: ExecFileOptions,
    reclaimMcpContainers = true,
  ): Promise<{ stdout: string; stderr: string }> {
    return new Promise((resolve, reject) => {
      const { signal, timeout = 10000, ...processOptions } = options ?? {};
      let timer: ReturnType<typeof setTimeout> | undefined;
      let stopping = false;
      let settled = false;
      let callbackDone = false;
      let captured = { stdout: '', stderr: '' };
      let onCallback!: () => void;
      const callbackFinished = new Promise<void>((done) => { onCallback = done; });
      let detachCancellation = () => {};
      const clear = () => { if (timer) clearTimeout(timer); detachCancellation(); };
      // Keep decoding at this boundary, preserving CLI stdout/stderr verbatim.
      // Native execFile timeout/abort destroys only the Windows shell, losing
      // the live root needed for tree cleanup. Manage those two cases ourselves.
      const execOptions: ExecFileOptionsWithBufferEncoding = {
        ...processOptions, timeout: 0, encoding: 'buffer',
        cwd: resolveWslCwd(options?.cwd),
        shell: options?.shell ?? (process.platform === 'win32'),
        env: { ...Claude.env, ...options?.env },
      };
      const child = cpExecFile(command, args, execOptions, (err, stdout, stderr) => {
        captured = { stdout: decodeConsoleOutput(stdout ?? ''), stderr: decodeConsoleOutput(stderr ?? '') };
        callbackDone = true;
        onCallback();
        if (stopping || settled) return;
        settled = true;
        clear();
        if (err) {
          Object.assign(err, captured);
          reject(err);
        } else resolve(captured);
      });
      Claude.processLifecycle?.trackProcess(child);
      const stop = (error: Error): void => {
        if (settled || stopping) return;
        stopping = true;
        clear();
        // Do not free a caller's concurrency slot while its old helper is
        // still waiting for tree cleanup. The callback drains captured output;
        // bound that final wait in case an inherited pipe never closes.
        void (async () => {
          await Claude.killTreeNonBlocking(child);
          if (!callbackDone) {
            let closeTimer: ReturnType<typeof setTimeout> | undefined;
            try {
              await Promise.race([callbackFinished, new Promise<void>((done) => { closeTimer = setTimeout(done, 5000); })]);
            } finally { if (closeTimer) clearTimeout(closeTimer); }
          }
          settled = true;
          reject(Object.assign(error, captured));
        })();
      };
      if (!settled) {
        const onAbort = () => stop(Object.assign(new Error('Claude command cancelled.'), { name: 'AbortError', code: 'ABORT_ERR' }));
        signal?.addEventListener('abort', onAbort, { once: true });
        detachCancellation = () => signal?.removeEventListener('abort', onAbort);
        if (timeout > 0) timer = setTimeout(() => stop(Object.assign(new Error('Claude command timed out.'), { code: 'ETIMEDOUT', killed: true })), timeout);
        if (signal?.aborted) onAbort();
      }
      if (reclaimMcpContainers) attachMcpContainerReclaim(child, typeof execOptions.cwd === 'string' ? execOptions.cwd : undefined);
    });
  }

  /**
   * win32 non-shell-tokenized path: resolve the `.cmd` launcher to an absolute
   * path, then run `cmd.exe /d /s /c <launcher> <...args>` with shell:false and
   * an argv ARRAY (each original argument stays its own element).
   *
   * Escaping reality: the spawned file is cmd.exe (a .exe), NOT a .cmd/.bat, so
   * Node's batch-file caret/quote hardening (CVE-2024-27980) does NOT fire here.
   * Node applies only standard CommandLineToArgvW quoting — it wraps each arg in
   * double quotes. Inside those quotes `&` `|` `<` `>` are literal, so command
   * injection is blocked. BUT cmd.exe still expands `%FOO%` even inside double
   * quotes, which would silently corrupt the JSON before it reaches the launcher.
   *
   * Per the original-data-preservation rule, corrupting config silently is worse
   * than failing, so we reject any arg containing `%` up front. In practice the
   * only shell:false caller is `mcp add-json`, whose JSON carries literal `%`
   * only inside an env value the user can rewrite.
   */
  private static async execViaCmd(
    args: string[],
    options?: ExecFileOptions,
  ): Promise<{ stdout: string; stderr: string }> {
    // Resolve the `.cmd` launcher to an absolute path, then delegate the
    // cmd.exe argv-array wrapping to the shared helper (execViaCmdArgv). The
    // helper enforces the `%`-expansion guard and standard-quoting rules; here
    // we only add the launcher resolution + env/cwd projection specific to the
    // Claude launcher. See win-exec.ts for the full rationale.
    const launcher = (await Claude.which()) ?? Claude.command;
    Claude.assertCanStart(options?.signal);
    const { err, stdout, stderr } = await execViaCmdArgv(launcher, args, {
      ...options,
      cwd: resolveWslCwd(options?.cwd),
      env: {
        ...Claude.env,
        ...options?.env,
      },
    }, (command, argv, execOptions) => Claude.runExecFile(command, argv, execOptions, false));
    if (err) {
      // Keep the captured output on the error so a clean non-zero exit that still
      // printed valid data stays recoverable, matching runExecFile's contract.
      const execErr = err as Error & { stdout?: string; stderr?: string };
      execErr.stdout = stdout;
      execErr.stderr = stderr;
      throw execErr;
    }
    return { stdout, stderr };
  }

  static which(): Promise<string | null> {
    if (process.platform === 'win32' && Claude.resolvedWin32Path) {
      return Promise.resolve(Claude.resolvedWin32Path);
    }
    if (Claude.processLifecycle?.isShuttingDown()) return Promise.resolve(null);
    const cmd = process.platform === 'win32' ? 'where' : 'which';
    // encoding:'buffer' — `where` prints the launcher path in the console's legacy OEM
    // codepage. Under a Korean/Chinese user directory, utf8-decoding it yields a path full
    // of U+FFFD that no longer exists on disk, so the launcher we resolve cannot be spawned.
    const whichOptions: ExecFileOptionsWithBufferEncoding = {
      env: Claude.env,
      timeout: 5000,
      encoding: 'buffer',
    };
    return new Promise((resolve) => {
      const child = cpExecFile(cmd, [Claude.command], whichOptions, (err, stdout) => {
        const out = decodeConsoleOutput(stdout ?? '');
        let resolved: string | null;
        if (err) {
          resolved = null;
        } else if (process.platform === 'win32') {
          // `where` also lists the extension-less MSYS script (`...\npm\claude`);
          // pick the launcher cmd.exe actually runs (first PATHEXT match) so
          // which() agrees with the binary spawn()/exec() resolve through cmd.exe.
          resolved = pickWin32Launcher(out);
        } else {
          resolved = (stdout?.toString() ?? '').trim().split('\n')[0]?.trim() || null;
        }
        if (process.platform === 'win32' && resolved) {
          Claude.resolvedWin32Path = resolved;
        }
        resolve(resolved);
      });
      Claude.processLifecycle?.trackProcess(child);
    });
  }

}
