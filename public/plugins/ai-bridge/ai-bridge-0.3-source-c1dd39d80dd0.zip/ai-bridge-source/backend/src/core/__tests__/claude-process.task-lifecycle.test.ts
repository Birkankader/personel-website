import { EventEmitter } from 'events';
import type { ChildProcess } from 'child_process';
import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { Bridge } from '../../bridge/bridge-interface';
import { ConnectionManager } from '../../ws/connection-manager';
import { TaskLimiter } from '../features/task-limiter';
import { ensureClaudeProcess, sendMessageToProcess, validateSteeringMessage, sendInterruptToProcess } from '../claude-process';
import { Claude } from '../claude';

const holder = vi.hoisted(() => ({ manager: null as unknown }));
vi.mock('../features/runtime-tasks', () => ({ runtimeTasks: () => holder.manager }));
vi.mock('../claude', () => ({ Claude: { command: 'claude', applyConfigDir: vi.fn(async () => {}), spawnAuthed: vi.fn(), killTree: vi.fn(), killTreeNonBlocking: vi.fn(async () => {}) } }));
vi.mock('../features/settings', () => ({ readMergedSettings: vi.fn(async () => ({ settings: {} })) }));
vi.mock('../features/claude-settings', () => ({ readMergedClaudeSettings: vi.fn(async () => ({ settings: {} })) }));
vi.mock('../features/scheduled-messages', () => ({ restoreSchedulesForSession: vi.fn(async () => {}) }));
vi.mock('../features/lastRecordedSend', () => ({ readLastRecordedSend: vi.fn(async () => null) }));
vi.mock('../cli-registry', () => ({ findLiveCliForSession: vi.fn(() => null), registerCliProcess: vi.fn(), unregisterCliProcess: vi.fn() }));
vi.mock('../features/workflow-tracker', () => ({ WorkflowProgressTracker: { create: () => ({ handleEvent: vi.fn(), stopSession: vi.fn() }) } }));
vi.mock('../features/telemetry', () => ({ reportBackendError: vi.fn() }));

function processFixture(pid: number) {
  const proc = Object.assign(new EventEmitter(), {
    pid, stdout: new EventEmitter(), stderr: new EventEmitter(),
    stdin: Object.assign(new EventEmitter(), { writable: true, write: vi.fn((_text: string, callback?: (error?: Error | null) => void) => { callback?.(); return true; }) }),
  });
  return proc;
}

describe('CLI result and close task admission', () => {
  beforeEach(() => vi.clearAllMocks());
  const flush = async () => { for (let i = 0; i < 20; i++) await Promise.resolve(); };
  const spawnReady = async (proc: ReturnType<typeof processFixture>) => {
    // Settings-file I/O must finish before the fixture emits the spawn event.
    await vi.waitFor(() => expect(proc.listenerCount('spawn')).toBeGreaterThan(0));
    proc.emit('spawn');
    await flush();
  };

  it.each([false, true])('retains the slot until steering completes (separate turn: %s)', async (late) => {
    const limiter = new TaskLimiter(1);
    holder.manager = { limiter, ready: Promise.resolve() };
    const connections = new ConnectionManager(true);
    const session = `steer-${late}`;
    connections.getOrCreateSession(session, '/project');
    const proc = processFixture(late ? 12501 : 12502);
    vi.mocked(Claude.spawnAuthed).mockResolvedValueOnce(proc as unknown as ChildProcess);
    const first = limiter.enqueue(session, '/project', async () => {
      await ensureClaudeProcess(connections, 'client', '/project', session, undefined, {} as Bridge);
      return sendMessageToProcess(connections, session, 'original');
    }, vi.fn());
    await spawnReady(proc);
    const accepted = vi.fn();
    const queued = limiter.enqueueUser(session, '/project', vi.fn(() => true), vi.fn(), 'steer-user', {
      validate: () => validateSteeringMessage(connections, session, 'make it blue'),
      write: id => sendMessageToProcess(connections, session, 'make it blue', undefined, false, id), accepted,
    });
    const other = vi.fn(() => true);
    limiter.enqueue('other', '/other', other, vi.fn());
    await limiter.steerQueued(queued.id);
    expect(JSON.parse(proc.stdin.write.mock.calls[1][0])).toMatchObject({ type: 'user', uuid: queued.id, message: { content: 'make it blue' } });
    const event = (data: Record<string, unknown>) => proc.stdout.emit('data', Buffer.from(JSON.stringify({ ...data, session_id: session }) + '\n'));
    if (late) {
      event({ type: 'result', is_error: false }); await flush();
      expect(limiter.get(first.id)?.state).toBe('running'); expect(other).not.toHaveBeenCalled();
    }
    event({ type: 'user', isReplay: true, uuid: queued.id, message: { role: 'user', content: 'make it blue' } });
    expect(accepted).toHaveBeenCalledOnce();
    expect(limiter.get(queued.id)).toBeUndefined();
    event({ type: 'result', is_error: false }); await flush();
    expect(other).toHaveBeenCalledOnce();
    expect(proc.stdin.write).toHaveBeenCalledTimes(2);
    proc.emit('close', 0); limiter.shutdown();
  });

  it('stops the process when an explicit Stop must also withdraw unconsumed steering', async () => {
    const limiter = new TaskLimiter(1); holder.manager = { limiter, ready: Promise.resolve() };
    const connections = new ConnectionManager(true); const session = 'stop-steer';
    connections.getOrCreateSession(session, '/project');
    const proc = processFixture(12503);
    vi.mocked(Claude.spawnAuthed).mockResolvedValueOnce(proc as unknown as ChildProcess);
    limiter.enqueue(session, '/project', async () => {
      await ensureClaudeProcess(connections, 'client', '/project', session, undefined, {} as Bridge);
      return sendMessageToProcess(connections, session, 'original');
    }, vi.fn());
    await spawnReady(proc);
    const queued = limiter.enqueueUser(session, '/project', () => true, vi.fn(), 'steer', {
      validate: () => {}, write: id => sendMessageToProcess(connections, session, 'steer', undefined, false, id), accepted: vi.fn(),
    });
    await limiter.steerQueued(queued.id); limiter.cancelSession(session);
    expect(sendInterruptToProcess(connections, session)).toBe(true);
    expect(Claude.killTree).toHaveBeenCalledWith(proc);
    proc.emit('close', 0); expect(limiter.snapshot().tasks).toEqual([]);
  });

  it('keeps the next same-session task reserved when a newline-less final result and close both settle its predecessor', async () => {
    const limiter = new TaskLimiter(1);
    holder.manager = { limiter, ready: Promise.resolve() };
    const connections = new ConnectionManager(true);
    connections.getOrCreateSession('lifecycle-same', '/project');
    connections.getOrCreateSession('lifecycle-other', '/project');
    const firstProc = processFixture(12301), secondProc = processFixture(12302);
    vi.mocked(Claude.spawnAuthed).mockResolvedValueOnce(firstProc as unknown as ChildProcess).mockResolvedValueOnce(secondProc as unknown as ChildProcess);
    const bridge = {} as Bridge;
    const work = (session: string, text: string) => async () => {
      await ensureClaudeProcess(connections, 'client', '/project', session, undefined, bridge);
      return sendMessageToProcess(connections, session, text);
    };
    const onError = vi.fn();
    const first = limiter.enqueue('lifecycle-same', '/project', work('lifecycle-same', 'first'), onError);
    const second = limiter.enqueue('lifecycle-same', '/project', work('lifecycle-same', 'second'), onError);
    const otherWork = vi.fn(() => true);
    const other = limiter.enqueue('lifecycle-other', '/project', otherWork, onError);
    await spawnReady(firstProc);
    expect(firstProc.stdin.write).toHaveBeenCalledOnce();
    expect(limiter.get(first.id)?.state).toBe('running');
    firstProc.stdout.emit('data', Buffer.from(JSON.stringify({ type: 'result', session_id: 'lifecycle-same', is_error: false })));
    firstProc.emit('close', 0);
    expect(limiter.get(first.id)).toBeUndefined();
    expect(limiter.get(second.id)?.state).toBe('starting');
    expect(limiter.get(other.id)?.state).toBe('queued');
    await spawnReady(secondProc);
    expect(secondProc.stdin.write).toHaveBeenCalledOnce();
    expect(limiter.get(second.id)?.state).toBe('running');
    expect(otherWork).not.toHaveBeenCalled();
    secondProc.stdout.emit('data', Buffer.from(JSON.stringify({ type: 'result', session_id: 'lifecycle-same', is_error: false }) + '\n'));
    await flush();
    expect(otherWork).toHaveBeenCalledOnce();
    expect(limiter.get(other.id)?.state).toBe('running');
    expect(onError).not.toHaveBeenCalled();
    secondProc.emit('close', 0);
    expect(limiter.get(other.id)?.state).toBe('running');
    limiter.shutdown();
  });

  it('releases a closed tab task after grace cleanup removed its session record', async () => {
    vi.useFakeTimers();
    const limiter = new TaskLimiter(1);
    holder.manager = { limiter, ready: Promise.resolve() };
    const connections = new ConnectionManager(true);
    const ws = { send: vi.fn(), close: vi.fn(), readyState: 1 } as any;
    const connectionId = connections.addConnection(ws);
    connections.subscribe(connectionId, 'closed-tab', '/project');
    const proc = processFixture(12320);
    vi.mocked(Claude.spawnAuthed).mockResolvedValueOnce(proc as unknown as ChildProcess);
    const task = limiter.enqueue('closed-tab', '/project', async () => {
      await ensureClaudeProcess(connections, connectionId, '/project', 'closed-tab', undefined, {} as Bridge);
      return sendMessageToProcess(connections, 'closed-tab', 'hello');
    }, vi.fn());
    const next = vi.fn(() => true);
    limiter.enqueue('other-tab', '/project', next, vi.fn());
    try {
      await spawnReady(proc);
      connections.removeConnection(connectionId);
      await vi.advanceTimersByTimeAsync(30_000);
      expect(connections.getSession('closed-tab')).toBeUndefined();
      expect(limiter.get(task.id)?.state).toBe('stopping');
      expect(next).not.toHaveBeenCalled();
      proc.emit('close', 0); await flush();
      expect(limiter.get(task.id)).toBeUndefined();
      expect(next).toHaveBeenCalledOnce();
    } finally { limiter.shutdown(); vi.useRealTimers(); }
  });

  it('releases a turn on process exit even when no result arrived', async () => {
    const limiter = new TaskLimiter(1);
    holder.manager = { limiter, ready: Promise.resolve() };
    const connections = new ConnectionManager(true);
    connections.getOrCreateSession('lifecycle-exit', '/project');
    const proc = processFixture(12303);
    vi.mocked(Claude.spawnAuthed).mockResolvedValueOnce(proc as unknown as ChildProcess);
    const first = limiter.enqueue('lifecycle-exit', '/project', async () => {
      await ensureClaudeProcess(connections, 'client', '/project', 'lifecycle-exit', undefined, {} as Bridge);
      return sendMessageToProcess(connections, 'lifecycle-exit', 'first');
    }, vi.fn());
    const next = vi.fn(() => true);
    limiter.enqueue('lifecycle-next', '/project', next, vi.fn());
    await spawnReady(proc);
    expect(limiter.get(first.id)?.state).toBe('running');
    proc.emit('close', 0); await flush();
    expect(limiter.get(first.id)).toBeUndefined();
    expect(next).toHaveBeenCalledOnce();
    limiter.shutdown();
  });
});
