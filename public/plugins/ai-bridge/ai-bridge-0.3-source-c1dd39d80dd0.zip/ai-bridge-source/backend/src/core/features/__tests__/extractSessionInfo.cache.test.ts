import { beforeEach, describe, expect, it, vi } from 'vitest';
import { open } from 'fs/promises';

vi.mock('fs/promises', () => ({ open: vi.fn() }));

describe('session tail cache', () => {
  beforeEach(() => {
    vi.resetModules();
    vi.clearAllMocks();
  });

  function setup() {
    const body = Buffer.from(JSON.stringify({ type: 'user', timestamp: '2026-09-08T12:00:00Z' }) + '\n');
    const stats = { dev: 1, ino: 2, size: body.length, mtimeMs: 100, ctimeMs: 100 };
    let totalBytesRead = 0;
    const read = vi.fn(async (buffer: Buffer, offset: number, length: number, position: number) => {
      const bytesRead = body.copy(buffer, offset, position, position + length);
      totalBytesRead += bytesRead;
      return { bytesRead, buffer };
    });
    const close = vi.fn(async () => {});
    vi.mocked(open).mockImplementation(async () => ({
      stat: async () => ({ ...stats }), read, close,
    }) as unknown as Awaited<ReturnType<typeof open>>);
    return { stats, body, read, close, bytesRead: () => totalBytesRead };
  }

  it('does no content reads for 100 repeated listings of an unchanged session', async () => {
    const fixture = setup();
    const { scanTail } = await import('../extractSessionInfo');
    const first = await scanTail('/sessions/one.jsonl');
    for (let i = 0; i < 100; i++) expect(await scanTail('/sessions/one.jsonl')).toEqual(first);

    expect(fixture.bytesRead()).toBe(fixture.body.length);
    expect(fixture.read).toHaveBeenCalledOnce();
    expect(fixture.close).toHaveBeenCalledTimes(101);
  });

  it.each(['size', 'mtimeMs', 'ctimeMs', 'ino', 'dev'] as const)('invalidates immediately when %s changes', async (field) => {
    const fixture = setup();
    const { scanTail } = await import('../extractSessionInfo');
    await scanTail('/sessions/one.jsonl');
    const reads = fixture.read.mock.calls.length;
    fixture.stats[field]++;
    await scanTail('/sessions/one.jsonl');
    expect(fixture.read.mock.calls.length).toBeGreaterThan(reads);
  });

  it('shares one content read for concurrent requests of the same version', async () => {
    const fixture = setup();
    const { scanTail } = await import('../extractSessionInfo');
    const results = await Promise.all(Array.from({ length: 10 }, () => scanTail('/sessions/one.jsonl')));

    expect(results.every((result) => result.lastTimestamp === '2026-09-08T12:00:00Z')).toBe(true);
    expect(fixture.read).toHaveBeenCalledOnce();
    expect(fixture.close).toHaveBeenCalledTimes(10);
  });

  it('does not cache a read failure', async () => {
    const fixture = setup();
    const { scanTail } = await import('../extractSessionInfo');
    fixture.read.mockRejectedValueOnce(new Error('read failed'));
    await expect(scanTail('/sessions/one.jsonl')).rejects.toThrow('read failed');
    expect((await scanTail('/sessions/one.jsonl')).lastTimestamp).toBe('2026-09-08T12:00:00Z');
    expect(fixture.read).toHaveBeenCalledTimes(2);
    expect(fixture.close).toHaveBeenCalledTimes(2);
  });

  it('does not cache a file that changes while being read', async () => {
    const fixture = setup();
    const { scanTail } = await import('../extractSessionInfo');
    const read = fixture.read.getMockImplementation()!;
    fixture.read.mockImplementationOnce(async (...args) => {
      const result = await read(...args);
      fixture.stats.mtimeMs++;
      return result;
    });
    await scanTail('/sessions/one.jsonl');
    await scanTail('/sessions/one.jsonl');
    expect(fixture.read).toHaveBeenCalledTimes(2);
  });

  it('evicts old files so opening projects does not grow the cache indefinitely', async () => {
    const fixture = setup();
    const { scanTail } = await import('../extractSessionInfo');
    for (let i = 0; i <= 1024; i++) await scanTail(`/sessions/${i}.jsonl`);
    const reads = fixture.read.mock.calls.length;
    await scanTail('/sessions/1024.jsonl');
    expect(fixture.read.mock.calls.length).toBe(reads);
    await scanTail('/sessions/0.jsonl');
    expect(fixture.read.mock.calls.length).toBe(reads + 1);
  });

  it('returns independent values so a caller cannot mutate cached metadata', async () => {
    setup();
    const { scanTail } = await import('../extractSessionInfo');
    const first = await scanTail('/sessions/one.jsonl');
    first.lastTimestamp = 'mutated';
    expect((await scanTail('/sessions/one.jsonl')).lastTimestamp).toBe('2026-09-08T12:00:00Z');
  });
});
