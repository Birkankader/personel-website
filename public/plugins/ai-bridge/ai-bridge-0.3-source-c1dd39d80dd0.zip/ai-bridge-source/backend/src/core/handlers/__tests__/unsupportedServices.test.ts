import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { ConnectionManager } from '../../../ws/connection-manager';
import type { Bridge } from '../../../bridge/bridge-interface';
import { ClientEnv, MessageType } from '../../../shared';
import { handleMessage } from '../index';
import { isUnsupportedService } from '../unsupportedServices';
import { Claude } from '../../claude';
import { Command } from '../../command';

describe('independent optional-service endpoints', () => {
  const network = vi.fn(() => { throw new Error('Unexpected network request'); });
  const sendTo = vi.fn();
  const bridge = { updatePlugin: vi.fn() } as unknown as Bridge;
  const connections = { sendTo } as unknown as ConnectionManager;
  beforeEach(() => {
    vi.clearAllMocks(); vi.stubGlobal('fetch', network);
    vi.spyOn(Claude, 'applyConfigDir').mockResolvedValue(undefined);
    vi.spyOn(Command.prototype, 'exec').mockRejectedValue(new Error('Unexpected child process'));
  });
  afterEach(() => { vi.unstubAllGlobals(); vi.restoreAllMocks(); });

  it.each([
    MessageType.GET_TELEMETRY_CONSENT, MessageType.SET_TELEMETRY_CONSENT,
    MessageType.GET_ANNOUNCEMENTS, MessageType.DISMISS_ANNOUNCEMENT, MessageType.GET_ANNOUNCEMENTS_ENABLED, MessageType.SET_ANNOUNCEMENTS_ENABLED,
    MessageType.GET_SPONSOR_URL, MessageType.GET_SPONSOR_STATUS, MessageType.CHECK_SPONSOR, MessageType.VERIFY_LICENSE, MessageType.DEACTIVATE_LICENSE,
    MessageType.GET_SPONSOR_DEVICES, MessageType.REMOVE_SPONSOR_DEVICE, MessageType.GET_SPONSOR_INVOICES, MessageType.CANCEL_SPONSOR_SUBSCRIPTION,
    MessageType.GET_PLUGIN_UPDATES, MessageType.UPDATE_PLUGIN,
    MessageType.INSTALL_CCB, MessageType.UNINSTALL_CCB, MessageType.GET_CCB_INSTALL_HINT, MessageType.GET_EXTEND_KIT_INFO,
    MessageType.GET_DICTATION_AVAILABILITY, MessageType.START_DICTATION, MessageType.SEND_DICTATION_AUDIO, MessageType.STOP_DICTATION,
    MessageType.GET_VOICE_PROMPT, MessageType.SET_VOICE_PROMPT, MessageType.GET_USAGE, MessageType.GET_ALL_USAGE,
  ])('%s refuses without network, a child process or credential-context changes', async (type) => {
    await handleMessage('window', { type, requestId: 'request', timestamp: 0,
      payload: { workingDir: '/project', licenseKey: 'old-key', accepted: true, enabled: true, force: true, email: 'private@example.test' },
    }, connections, bridge, { [ClientEnv.BROWSER]: bridge, [ClientEnv.JETBRAINS]: bridge });
    expect(sendTo).toHaveBeenCalledWith('window', MessageType.ACK, expect.objectContaining({ requestId: 'request', status: 'unsupported', supported: false, enabled: false, success: false }));
    expect(network).not.toHaveBeenCalled(); expect(Command.prototype.exec).not.toHaveBeenCalled();
    expect(Claude.applyConfigDir).not.toHaveBeenCalled(); expect(bridge.updatePlugin).not.toHaveBeenCalled();
    expect(sendTo.mock.calls[0][2].isSponsor).not.toBe(true);
    expect(sendTo.mock.calls[0][2].valid).not.toBe(true);
  });

  it.each([MessageType.LOGIN, MessageType.GET_ACCOUNT, MessageType.SUBMIT_LOGIN_CODE, MessageType.UPDATE_CLI, MessageType.GET_CLI_UPDATE_INFO, MessageType.GET_USAGE_REPORT])('retains the official provider route %s', (type) => {
    expect(isUnsupportedService(type)).toBe(false);
  });
});
