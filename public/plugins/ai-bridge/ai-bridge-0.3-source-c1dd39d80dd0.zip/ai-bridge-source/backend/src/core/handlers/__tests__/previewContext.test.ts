import { afterEach, describe, expect, it } from 'vitest';
import { mkdtemp, mkdir, rm, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { previewContext } from '../previewContext';
import { validTaskTemplates } from '../../../shared/task-template';
import { estimateTextTokens } from '../../../shared/context-preview';

let directory: string;
afterEach(async () => { if (directory) await rm(directory, { recursive: true, force: true }); });

describe('context preview', () => {
  it('reports bytes, deduplicates explicit files and leaves folders/missing files unknown', async () => {
    directory = await mkdtemp(join(tmpdir(), 'ai-bridge-context-'));
    await writeFile(join(directory, 'test.txt'), 'Köprü');
    await mkdir(join(directory, 'folder'));
    const result = await previewContext(['test.txt', 'test.txt', 'folder', 'missing'], directory);
    expect(result).toEqual([
      { path: 'test.txt', bytes: 7, estimatedTokens: 2, kind: 'file' },
      { path: 'folder', bytes: null, estimatedTokens: null, kind: 'folder' },
      { path: 'missing', bytes: null, estimatedTokens: null, kind: 'unavailable' },
    ]);
  });
  it('rejects oversized or invalid requests before filesystem work', async () => {
    await expect(previewContext(Array(51).fill('a'), '/')).rejects.toThrow();
    await expect(previewContext(['bad\0path'], '/')).rejects.toThrow();
    await expect(previewContext([null], '/')).rejects.toThrow();
  });
  it('estimates UTF-8 bytes rather than assuming all characters are ASCII', () => {
    expect(estimateTextTokens('Köprü')).toBe(2);
    expect(estimateTextTokens('')).toBe(0);
  });
});

describe('task templates', () => {
  const template = { id: 'one', name: 'Review', prompt: 'Review the changes', model: 'sonnet', effort: 'high', includeEditorContext: true, attachments: [{ path: '/project/a.ts', name: 'a.ts', type: 'file' }] };
  it('accepts a complete model/effort/context snapshot', () => {
    expect(validTaskTemplates([template])).toBe(true);
    expect(validTaskTemplates([])).toBe(true);
  });
  it('rejects malformed, duplicate, oversized and binary-bearing records', () => {
    expect(validTaskTemplates([template, template])).toBe(false);
    expect(validTaskTemplates([{ ...template, prompt: 'a'.repeat(100001) }])).toBe(false);
    expect(validTaskTemplates([{ ...template, attachments: [{ type: 'image', base64: '123' }] }])).toBe(false);
    expect(validTaskTemplates([{ ...template, name: ' ' }])).toBe(false);
    expect(validTaskTemplates([{ ...template, effort: 'unknown' }])).toBe(false);
  });
});
