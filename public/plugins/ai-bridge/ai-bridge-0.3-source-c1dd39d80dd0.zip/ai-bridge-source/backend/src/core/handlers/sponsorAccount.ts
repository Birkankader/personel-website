import { unsupportedServiceHandler } from './unsupportedServices';

export const getSponsorDevicesHandler = unsupportedServiceHandler;
export const removeSponsorDeviceHandler = unsupportedServiceHandler;
export const getSponsorInvoicesHandler = unsupportedServiceHandler;
export const cancelSponsorSubscriptionHandler = unsupportedServiceHandler;
