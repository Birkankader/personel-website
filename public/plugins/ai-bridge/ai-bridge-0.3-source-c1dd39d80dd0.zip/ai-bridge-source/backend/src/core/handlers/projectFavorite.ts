import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { setProjectFavorite } from '../features/projects-store';
import { MessageType } from '../../shared';

/**
 * Adds a single project to, or removes it from, the favorites.
 *
 * Returns the full updated list, so the webview reflects the saved result as-is
 * instead of guessing its own state. If saving fails, status comes back as error
 * so the webview can revert the star it drew optimistically. A screen that keeps
 * claiming a pin that was never saved is exactly the state this response prevents.
 */
export async function setProjectFavoriteHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const { path, favorite } = (message.payload ?? {}) as { path?: unknown; favorite?: unknown };
  const { ok, favoritePaths } = await setProjectFavorite(
    typeof path === 'string' ? path : '',
    favorite === true,
  );

  connections.sendTo(connectionId, MessageType.ACK, {
    requestId: message.requestId,
    status: ok ? 'ok' : 'error',
    favoritePaths,
  });
}
