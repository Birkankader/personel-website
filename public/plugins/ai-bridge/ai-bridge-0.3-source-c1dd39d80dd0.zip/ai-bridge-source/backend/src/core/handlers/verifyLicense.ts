import { unsupportedServiceHandler } from './unsupportedServices';

export const verifyLicenseHandler = unsupportedServiceHandler;
