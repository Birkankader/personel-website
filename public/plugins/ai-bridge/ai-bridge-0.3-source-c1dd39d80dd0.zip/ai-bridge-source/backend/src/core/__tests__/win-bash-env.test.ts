import { execFileSync } from 'child_process';
import { mkdtempSync, writeFileSync, rmSync } from 'fs';
import { tmpdir } from 'os';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { afterEach, beforeEach, describe, expect, it } from 'vitest';

const wrapper = fileURLToPath(new URL('../win-bash-env.sh', import.meta.url));
let fixture: string;

describe.skipIf(process.platform === 'win32')('shipped Bash environment source chain (bounded real Bash)', () => {
  beforeEach(() => { fixture = mkdtempSync(join(tmpdir(), 'ai-bridge-bash-source-')); });
  afterEach(() => { rmSync(fixture, { recursive: true, force: true }); });

  function source(previous: string, repeat = false) {
    const env = { ...process.env };
    delete env.BASH_ENV;
    delete env.AI_BRIDGE_PREV_BASH_ENV;
    delete env.AI_BRIDGE_BASH_ENV_ACTIVE;
    const command = `
source_depth=0
function .() {
  source_depth=$((source_depth + 1))
  if [ "$source_depth" -gt 8 ]; then exit 77; fi
  builtin . "$@"
  source_depth=$((source_depth - 1))
}
codepage_calls=0
original_calls=0
legacy_calls=0
function chcp.com() { codepage_calls=$((codepage_calls + 1)); }
export AI_BRIDGE_PREV_BASH_ENV="$2"
. "$1"
${repeat ? '. "$1"' : ''}
printf 'codepage=%s original=%s legacy=%s previous=%s\\n' "$codepage_calls" "$original_calls" "$legacy_calls" "$AI_BRIDGE_PREV_BASH_ENV"
`;
    return execFileSync('/bin/bash', ['--noprofile', '--norc', '-c', command, 'source-probe', wrapper, previous], {
      env, encoding: 'utf8', timeout: 1000, maxBuffer: 4096, stdio: ['ignore', 'pipe', 'pipe'],
    });
  }

  it('does not recurse when the previous hook is the current wrapper', () => {
    expect(source(wrapper)).toContain('codepage=1 original=0 legacy=0');
  });

  it('prevents an older wrapper from sourcing itself through the inherited previous-hook variable', () => {
    const old = join(fixture, 'old-wrapper.sh');
    writeFileSync(old, 'if [ -n "$AI_BRIDGE_PREV_BASH_ENV" ]; then . "$AI_BRIDGE_PREV_BASH_ENV"; fi\nlegacy_calls=$((legacy_calls + 1))\n');
    expect(source(old)).toContain(`codepage=1 original=0 legacy=1 previous=${old}`);
  });

  it('runs and preserves a genuine user hook on each independent source', () => {
    const original = join(fixture, 'user hook.sh');
    writeFileSync(original, 'original_calls=$((original_calls + 1))\n');
    expect(source(original, true)).toContain(`codepage=2 original=2 legacy=0 previous=${original}`);
  });
});
