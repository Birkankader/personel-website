import { unsupportedServiceHandler } from './unsupportedServices';

export const getSponsorUrlHandler = unsupportedServiceHandler;
