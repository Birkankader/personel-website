import { unsupportedServiceHandler } from './unsupportedServices';

export const getAnnouncementsHandler = unsupportedServiceHandler;
