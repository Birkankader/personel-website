import type { ConnectionManager } from '../../ws/connection-manager';
import type { Bridge } from '../../bridge/bridge-interface';
import type { IPCMessage } from '../types';
import { Claude } from '../claude';
import { getCliVersion } from './getVersion';
import { configuredHarnessPath, harnessVersion, locateHarness } from '../features/harness-locator';
import { readMergedSettings } from '../features/settings';
import { HARNESS_IDS, isAcpHarness, MessageType, type AcpHarnessId, type HarnessStatus } from '../../shared';

/**
 * Whether each harness can run here, for the Connection page: found or not,
 * where, and its `--version`. Every harness is listed, not only the selected
 * one, so a user can see what switching would need before switching.
 */
export async function getHarnessStatusHandler(
  connectionId: string,
  message: IPCMessage,
  connections: ConnectionManager,
  _bridge: Bridge,
): Promise<void> {
  const payload = (message.payload as Record<string, unknown>) ?? {};
  const workingDir = (typeof payload.workingDir === 'string' && payload.workingDir) || process.cwd();
  try {
    const harnesses = await getHarnessStatuses(workingDir);
    connections.sendTo(connectionId, MessageType.ACK, { requestId: message.requestId, status: 'ok', harnesses });
  } catch (err) {
    connections.sendTo(connectionId, MessageType.ACK, {
      requestId: message.requestId,
      status: 'error',
      error: err instanceof Error ? err.message : String(err),
    });
  }
}

export function getHarnessStatuses(workingDir: string): Promise<HarnessStatus[]> {
  return Promise.all(HARNESS_IDS.map(id => (isAcpHarness(id) ? acpHarnessStatus(id, workingDir) : claudeStatus(workingDir))));
}

async function claudeStatus(workingDir: string): Promise<HarnessStatus> {
  const [location, version, cliPath] = await Promise.all([
    Claude.which(),
    getCliVersion(),
    readMergedSettings(workingDir).then(({ settings }) => settings.cliPath, () => null),
  ]);
  return {
    harness: 'claude',
    installed: version !== null,
    source: typeof cliPath === 'string' && cliPath ? 'setting' : 'path',
    ...(location ? { location } : {}),
    ...(version ? { version } : {}),
    installable: false,
  };
}

async function acpHarnessStatus(harness: AcpHarnessId, workingDir: string): Promise<HarnessStatus> {
  const { located, settingError } = await locateHarness(harness, await configuredHarnessPath(harness, workingDir));
  if (!located) return { harness, installed: false, installable: true, ...(settingError ? { error: settingError } : {}) };
  const probe = await harnessVersion(located, harness);
  const error = [settingError, probe.error].filter(Boolean).join('\n');
  return {
    harness,
    installed: true,
    source: located.source,
    location: located.location,
    ...(probe.version ? { version: probe.version } : {}),
    ...(error ? { error } : {}),
    installable: true,
  };
}
