import { unsupportedServiceHandler } from './unsupportedServices';

export const dismissAnnouncementHandler = unsupportedServiceHandler;
