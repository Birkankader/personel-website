import { execFile } from 'child_process';
import { promisify } from 'util';
import type { ConnectionManager } from '../../ws/connection-manager';
import type { RuntimeProcessUsage, RuntimeResources } from '../../shared/runtime-resources';
import { runtimeTasks } from './runtime-tasks';

const exec = promisify(execFile);
export interface ProcessSample { pid: number; ppid: number; rssBytes: number; cpuSeconds: number }

export function parseCpuTime(value: string): number | null {
  const match = /^(?:(\d+)-)?(?:(\d+):)?(\d+):(\d+(?:\.\d+)?)$/.exec(value);
  if (!match) return null;
  return Number(match[1] ?? 0) * 86400 + Number(match[2] ?? 0) * 3600 + Number(match[3]) * 60 + Number(match[4]);
}

export function parseProcessSamples(output: string): ProcessSample[] {
  const samples: ProcessSample[] = [];
  for (const line of output.split('\n')) {
    const [pid, ppid, rss, time] = line.trim().split(/\s+/);
    const cpuSeconds = time ? parseCpuTime(time) : null;
    if (!/^\d+$/.test(pid ?? '') || !/^\d+$/.test(ppid ?? '') || !/^\d+$/.test(rss ?? '') || cpuSeconds === null) continue;
    samples.push({ pid: Number(pid), ppid: Number(ppid), rssBytes: Number(rss) * 1024, cpuSeconds });
  }
  return samples;
}

export function processTree(root: number, samples: ProcessSample[]): ProcessSample[] {
  const byParent = new Map<number, ProcessSample[]>();
  const byPid = new Map(samples.map((sample) => [sample.pid, sample]));
  for (const sample of samples) {
    const children = byParent.get(sample.ppid) ?? [];
    children.push(sample);
    byParent.set(sample.ppid, children);
  }
  const result: ProcessSample[] = [];
  const pending = [root];
  const seen = new Set<number>();
  while (pending.length) {
    const pid = pending.pop()!;
    if (seen.has(pid)) continue;
    seen.add(pid);
    const sample = byPid.get(pid);
    if (sample) result.push(sample);
    for (const child of byParent.get(pid) ?? []) pending.push(child.pid);
  }
  return result;
}

export function cpuPercent(previous: number, current: number, elapsedMs: number): number | null {
  if (elapsedMs <= 0 || current < previous) return null;
  return (current - previous) * 100_000 / elapsedMs;
}

/** No timers: snapshots are requested only by a visible resource panel. */
export class RuntimeResourceSampler {
  private previous = new Map<number, { cpuSeconds: number; at: number }>();
  private backendPrevious: { usage: NodeJS.CpuUsage; at: number } | null = null;
  private latest: RuntimeResources | null = null;
  private pending: Promise<RuntimeResources> | null = null;

  constructor(private readonly readProcesses: () => Promise<ProcessSample[]> = async () => {
    if (process.platform === 'win32') throw new Error('CLI CPU and memory sampling is unavailable on Windows.');
    const { stdout } = await exec('ps', ['-axo', 'pid=,ppid=,rss=,time='], { timeout: 1500, maxBuffer: 4 * 1024 * 1024 });
    return parseProcessSamples(stdout);
  }) {}

  sample(connections: ConnectionManager): Promise<RuntimeResources> {
    if (this.pending) return this.pending;
    if (this.latest && Date.now() - this.latest.sampledAt < 1000) {
      return Promise.resolve({ ...this.latest, ...runtimeTasks(connections).limiter.snapshot(), connectedViews: connections.getConnectionStats().total });
    }
    this.pending = this.collect(connections).finally(() => { this.pending = null; });
    return this.pending;
  }

  private async collect(connections: ConnectionManager): Promise<RuntimeResources> {
    const manager = runtimeTasks(connections);
    await manager.ready;
    const sessions = connections.getRuntimeSessions();
    let samples: ProcessSample[] = [];
    let measurementError: string | undefined;
    if (sessions.length) {
      try { samples = await this.readProcesses(); }
      catch (error) { measurementError = error instanceof Error ? error.message : 'Process sampling failed.'; }
    }
    const at = performance.now();
    const usage = process.cpuUsage();
    const backendCpu = this.backendPrevious && at - this.backendPrevious.at <= 5000
      ? cpuPercent((this.backendPrevious.usage.user + this.backendPrevious.usage.system) / 1e6, (usage.user + usage.system) / 1e6, at - this.backendPrevious.at)
      : null;
    this.backendPrevious = { usage, at };
    const nextPrevious = new Map<number, { cpuSeconds: number; at: number }>();
    const cli: RuntimeProcessUsage[] = sessions.map((session) => {
      const tree = processTree(session.pid, samples);
      let measuredCpu = 0;
      let completeCpu = tree.length > 0;
      for (const sample of tree) {
        const prior = this.previous.get(sample.pid);
        const measured = prior && at - prior.at <= 5000 ? cpuPercent(prior.cpuSeconds, sample.cpuSeconds, at - prior.at) : null;
        if (measured === null) completeCpu = false;
        else measuredCpu += measured;
        nextPrevious.set(sample.pid, { cpuSeconds: sample.cpuSeconds, at });
      }
      return {
        ...session,
        cpuPercent: completeCpu ? measuredCpu : null,
        rssBytes: tree.length ? tree.reduce((sum, item) => sum + item.rssBytes, 0) : null,
        processCount: tree.length,
      };
    });
    this.previous = nextPrevious;
    this.latest = {
      ...manager.limiter.snapshot(), sampledAt: Date.now(), connectedViews: connections.getConnectionStats().total,
      backend: { pid: process.pid, cpuPercent: backendCpu, rssBytes: process.memoryUsage().rss, processCount: 1 },
      cli, ...(measurementError ? { measurementError } : {}),
    };
    return this.latest;
  }
}

const samplers = new WeakMap<ConnectionManager, RuntimeResourceSampler>();
export function sampleRuntimeResources(connections: ConnectionManager): Promise<RuntimeResources> {
  let sampler = samplers.get(connections);
  if (!sampler) { sampler = new RuntimeResourceSampler(); samplers.set(connections, sampler); }
  return sampler.sample(connections);
}
