import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import type { ChildProcess } from 'child_process';
const { execFile, execFileSync } = vi.hoisted(() => ({ execFile: vi.fn(), execFileSync: vi.fn() }));
vi.mock('child_process', () => ({ spawn: vi.fn(), execFile, execFileSync }));
vi.mock('../features/settings', () => ({ readMergedSettings: vi.fn(), resolveClaudeConfigDirOverride: vi.fn() }));
vi.mock('../features/claude-settings', () => ({ getStrippableAuthEnvKeys: vi.fn() }));
vi.mock('../mcp-container-reclaimer', () => ({ attachMcpContainerReclaim: vi.fn() }));
import { Claude } from '../claude';
const platform = process.platform;
const child = (pid = 7654) => ({ pid, exitCode: null, signalCode: null, kill: vi.fn() }) as unknown as ChildProcess;
let completions: Array<(error: Error | null) => void>;
let activeHelpers: number;
let peakHelpers: number;
beforeEach(() => {
  Object.defineProperty(process, 'platform', { value: 'win32', configurable: true });
  vi.resetAllMocks();
  completions = [];
  activeHelpers = 0;
  peakHelpers = 0;
  execFile.mockImplementation((_command, _args, _options, callback) => {
    activeHelpers++;
    peakHelpers = Math.max(peakHelpers, activeHelpers);
    completions.push((error) => { activeHelpers--; callback(error); });
  });
});
afterEach(async () => {
  while (completions.length) completions.shift()!(null);
  await Promise.resolve();
  Object.defineProperty(process, 'platform', { value: platform, configurable: true });
});
describe('Windows child termination', () => {
  it('preserves synchronous tree cleanup for process exit hooks', () => {
    Claude.killTree(child(), 'SIGKILL');
    expect(execFileSync).toHaveBeenCalledWith('taskkill', ['/F', '/T', '/PID', '7654'],
      { windowsHide: true, timeout: 5000 });
    expect(execFile).not.toHaveBeenCalled();
  });
  it('returns before taskkill finishes and never blocks through execFileSync', async () => {
    const proc = child();
    const completion = Claude.killTreeNonBlocking(proc);
    await new Promise<void>((resolve) => setImmediate(resolve));
    expect(execFileSync).not.toHaveBeenCalled();
    expect(execFile).toHaveBeenCalledWith('taskkill', ['/F', '/T', '/PID', '7654'],
      { windowsHide: true, timeout: 5000 }, expect.any(Function));
    expect(proc.kill).not.toHaveBeenCalled();
    completions.shift()!(null);
    await completion;
  });
  it('shares one completion for duplicate termination while taskkill is pending', async () => {
    const proc = child();
    const first = Claude.killTreeNonBlocking(proc);
    const second = Claude.killTreeNonBlocking(proc, 'SIGKILL');
    expect(first).toBe(second);
    expect(execFile).toHaveBeenCalledTimes(1);
    completions.shift()!(null);
    await Promise.all([first, second]);
  });
  it('falls back only if the original child remains live after a failed taskkill', async () => {
    const proc = child();
    const completion = Claude.killTreeNonBlocking(proc, 'SIGKILL');
    completions.shift()!(new Error('timeout'));
    await completion;
    expect(proc.kill).toHaveBeenCalledWith('SIGKILL');
  });
  it('does not signal a reaped child after a delayed taskkill failure', async () => {
    const proc = child();
    const completion = Claude.killTreeNonBlocking(proc);
    Object.defineProperty(proc, 'exitCode', { value: 0 });
    completions.shift()!(new Error('not found'));
    await completion;
    expect(proc.kill).not.toHaveBeenCalled();
  });
  it('never launches taskkill for an already reaped child', () => {
    const proc = child();
    Object.defineProperty(proc, 'signalCode', { value: 'SIGTERM' });
    Claude.killTreeNonBlocking(proc);
    expect(execFile).not.toHaveBeenCalled();
  });
  it('drains twenty distinct children with no more than two helpers, including failed attempts', async () => {
    const children = Array.from({ length: 20 }, (_, index) => child(8000 + index));
    const pending = children.map(proc => Claude.killTreeNonBlocking(proc));
    expect(execFile).toHaveBeenCalledTimes(2);
    let completed = 0;
    while (completions.length) {
      completions.shift()!(completed++ % 3 === 0 ? new Error('controlled failure') : null);
      expect(activeHelpers).toBeLessThanOrEqual(2);
    }
    await Promise.all(pending);
    expect(completed).toBe(20);
    expect(peakHelpers).toBe(2);
    expect(activeHelpers).toBe(0);
    expect(execFile.mock.calls.map(([, args]) => args.at(-1))).toEqual(children.map(proc => String(proc.pid)));
    expect(execFileSync).not.toHaveBeenCalled();
  });
  it('skips a queued child that exits before a helper slot opens', async () => {
    const children = [child(8101), child(8102), child(8103), child(8104)];
    const pending = children.map(proc => Claude.killTreeNonBlocking(proc));
    expect(Claude.killTreeNonBlocking(children[2])).toBe(pending[2]);
    Object.defineProperty(children[2], 'exitCode', { value: 0 });
    while (completions.length) completions.shift()!(null);
    await Promise.all(pending);
    expect(execFile.mock.calls.map(([, args]) => args.at(-1))).toEqual(['8101', '8102', '8104']);
    expect(children[2].kill).not.toHaveBeenCalled();
    expect(peakHelpers).toBe(2);
  });
  it('resolves synchronous launch failures and releases their helper slots', async () => {
    execFile.mockImplementation(() => { throw new Error('controlled spawn failure'); });
    const children = Array.from({ length: 20 }, (_, index) => child(8200 + index));
    await Promise.all(children.map(proc => Claude.killTreeNonBlocking(proc)));
    expect(execFile).toHaveBeenCalledTimes(20);
    for (const proc of children) expect(proc.kill).toHaveBeenCalledOnce();
  });
  it('keeps synchronous exit fallback available for a child still queued for async cleanup', async () => {
    const children = [child(8301), child(8302), child(8303)];
    const pending = children.map(proc => Claude.killTreeNonBlocking(proc));
    Claude.killTree(children[2], 'SIGKILL');
    expect(execFileSync).toHaveBeenCalledWith('taskkill', ['/F', '/T', '/PID', '8303'],
      { windowsHide: true, timeout: 5000 });
    Object.defineProperty(children[2], 'exitCode', { value: 0 });
    while (completions.length) completions.shift()!(null);
    await Promise.all(pending);
    expect(execFile).toHaveBeenCalledTimes(2);
  });
});
