import { unsupportedServiceHandler } from './unsupportedServices';

export const updatePluginHandler = unsupportedServiceHandler;
