# CCG win32 chat-CLI job wrapper.
#
# Why this exists: win32 has no process groups. `taskkill /F /T` walks the LIVE
# parent-child tree, but git-bash (MSYS) spawns its worker processes under a
# short-lived fork helper that exits immediately, detaching the worker from the
# cmd->claude->bash tree (children even reparent to ppid 1). Windows never
# reparents to a reaper, so those workers become invisible orphans that keep
# running (and billing). POSIX avoids this by launching the CLI detached as a
# process-group leader and signalling the whole group (see claude.ts killTree).
#
# A Windows Job Object is the kernel equivalent of a process group: every
# descendant of a job member stays in the job regardless of PPID reparenting.
# This wrapper creates a job with JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE, launches the
# real chat CLI inside it, then holds the job handle for the CLI's lifetime. When
# the backend kills THIS process (or the backend itself dies), the last job handle
# closes and the kernel tears down the ENTIRE tree - the MSYS orphans included.
#
# Contract with the backend (claude.ts / win-job.ts):
#   - $env:AI_BRIDGE_JOB_CMDLINE holds the exact `cmd /d /s /c` command line to run.
#   - $env:AI_BRIDGE_JOB_CACHE_DIR (optional) is where the compiled Job Object interop
#     is kept between launches. Without it every launch compiles it in memory.
#   - argv[0] (if present) is the sessionId, carried ONLY so the on-disk registry's
#     sessionId-keyed orphan sweep can find and kill THIS wrapper. The wrapper
#     itself ignores it.
#   - MUST be silent on stdout: the backend reads the child's stdout as the chat
#     stream-json protocol. Only genuine errors go to stderr.
#
# Keep this file ASCII: Windows PowerShell 5.1 reads a script without a BOM in the
# system ANSI code page.
$ErrorActionPreference = 'Stop'

# Add-Type compiles this with csc.exe: seconds per launch, plus an antivirus scan of
# the output, before the CLI even starts. So the compiled assembly is kept in
# AI_BRIDGE_JOB_CACHE_DIR under a name derived from this exact source text.
$CcgJobNativeSource = @'
using System;
using System.Runtime.InteropServices;
public static class CcgJobNative {
  [DllImport("kernel32.dll", SetLastError=true)] public static extern IntPtr CreateJobObject(IntPtr a, string name);
  [DllImport("kernel32.dll", SetLastError=true)] public static extern bool SetInformationJobObject(IntPtr job, int infoClass, IntPtr info, uint len);
  [DllImport("kernel32.dll", SetLastError=true)] public static extern bool AssignProcessToJobObject(IntPtr job, IntPtr process);
}
'@

function Import-CcgNativeType([string]$Path, [string]$TypeName) {
  foreach ($type in @(Add-Type -LiteralPath $Path -PassThru)) {
    if ($type.FullName -eq $TypeName) { return $type }
  }
  return $null
}

function Test-CcgBadImage($Exception) {
  for ($e = $Exception; $null -ne $e; $e = $e.InnerException) {
    if ($e -is [BadImageFormatException]) { return $true }
  }
  return $false
}

# The compiled interop type, or $null when it cannot be had at all. Each failure
# falls one step back: cached assembly -> compile into the cache -> compile in
# memory (the behaviour before the cache existed) -> $null, i.e. run without a job.
function Get-CcgNativeType([string]$Source, [string]$TypeName, [string]$CacheDir) {
  if (-not [string]::IsNullOrEmpty($CacheDir)) {
    try {
      # Keyed by the source, so an edited interop never loads a stale build, and by
      # the CLR major version, because a build for one runtime does not load in another.
      $sha = New-Object Security.Cryptography.SHA256CryptoServiceProvider
      try {
        $digest = $sha.ComputeHash([Text.Encoding]::UTF8.GetBytes("$([Environment]::Version.Major)`n$Source"))
      } finally {
        $sha.Dispose()
      }
      $id = [BitConverter]::ToString($digest, 0, 8).Replace('-', '').ToLowerInvariant()
      $dll = [IO.Path]::Combine($CacheDir, "$TypeName-$id.dll")

      $compile = $true
      if ([IO.File]::Exists($dll)) {
        try {
          $type = Import-CcgNativeType $dll $TypeName
          if ($null -ne $type) { return $type }
          $compile = $false  # loaded (so locked) yet not ours: leave it alone
        } catch {
          # Replace only a damaged image (a torn or zeroed write). A load refused for
          # any other reason, such as an application-control policy, would refuse a
          # fresh copy too, and recompiling on every launch would double the cost.
          $compile = Test-CcgBadImage $_.Exception
          if ($compile) { [IO.File]::Delete($dll) }
        }
      }

      if ($compile) {
        [void][IO.Directory]::CreateDirectory($CacheDir)
        # A wrapper killed mid-compile (a prewarmed chat closed at once) leaves its
        # temp file behind. Reap those once they are clearly abandoned.
        $cutoff = [DateTime]::UtcNow.AddMinutes(-10)
        foreach ($stale in [IO.Directory]::GetFiles($CacheDir, "$TypeName-*.tmp.dll")) {
          try {
            if ([IO.File]::GetLastWriteTimeUtc($stale) -lt $cutoff) { [IO.File]::Delete($stale) }
          } catch {}
        }

        $tmp = [IO.Path]::Combine($CacheDir, "$TypeName-$id-$([Guid]::NewGuid().ToString('N')).tmp.dll")
        # Without -PassThru this only writes the file: nothing is loaded or locked yet.
        Add-Type -TypeDefinition $Source -OutputAssembly $tmp
        # File.Move never replaces an existing file, so simultaneous first launches
        # publish exactly one copy and the others load the winner's.
        $load = $dll
        try {
          [IO.File]::Move($tmp, $dll)
        } catch {
          if ([IO.File]::Exists($dll)) {
            try { [IO.File]::Delete($tmp) } catch {}
          } else {
            $load = $tmp
          }
        }
        $type = Import-CcgNativeType $load $TypeName
        if ($null -ne $type) { return $type }
      }
    } catch {}
  }

  try {
    foreach ($type in @(Add-Type -TypeDefinition $Source -PassThru)) {
      if ($type.FullName -eq $TypeName) { return $type }
    }
  } catch {}
  return $null
}

$cmdline = $env:AI_BRIDGE_JOB_CMDLINE
if ([string]::IsNullOrEmpty($cmdline)) {
  [Console]::Error.WriteLine('[ccg-job] AI_BRIDGE_JOB_CMDLINE not set')
  exit 210
}

# Create the job + set KILL_ON_JOB_CLOSE. If any of this fails we still launch the
# CLI (degrading to the pre-job behavior) rather than break chat - a missing job
# only reopens the orphan gap, it never blocks the user.
$job = [IntPtr]::Zero
$native = Get-CcgNativeType -Source $CcgJobNativeSource -TypeName 'CcgJobNative' -CacheDir $env:AI_BRIDGE_JOB_CACHE_DIR
if ($null -eq $native) {
  [Console]::Error.WriteLine('[ccg-job] Job Object interop unavailable; running without the orphan guard')
} else {
  try {
    $job = $native::CreateJobObject([IntPtr]::Zero, $null)
    if ($job -ne [IntPtr]::Zero) {
      # JOBOBJECT_EXTENDED_LIMIT_INFORMATION is 144 bytes on x64: BASIC_LIMIT(64) +
      # IO_COUNTERS(48) + 4x SIZE_T memory fields(32). LimitFlags sits at offset 16.
      $size = 144
      $buf = [Runtime.InteropServices.Marshal]::AllocHGlobal($size)
      try {
        for ($i = 0; $i -lt $size; $i++) { [Runtime.InteropServices.Marshal]::WriteByte($buf, $i, 0) }
        [Runtime.InteropServices.Marshal]::WriteInt32($buf, 16, 0x2000)  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
        # JobObjectExtendedLimitInformation = 9
        [void]$native::SetInformationJobObject($job, 9, $buf, $size)
      } finally {
        [Runtime.InteropServices.Marshal]::FreeHGlobal($buf)
      }
    }
  } catch {
    $job = [IntPtr]::Zero
  }
}

$psi = New-Object Diagnostics.ProcessStartInfo
$psi.FileName = 'cmd.exe'
# cmd resolves the claude launcher via PATHEXT exactly as the pre-job spawn did.
$psi.Arguments = '/d /s /c "' + $cmdline + '"'
# Inherit our std handles so the child's stdio is the backend's pipes, byte-for-byte.
$psi.UseShellExecute = $false
$proc = [Diagnostics.Process]::Start($psi)

# Put the CLI (and thus every descendant) in the job. Non-fatal on failure: the
# wrapper must outlive the CLI, or the backend loses track of a still-running tree.
if ($job -ne [IntPtr]::Zero) {
  try { [void]$native::AssignProcessToJobObject($job, $proc.Handle) } catch {}
}

$proc.WaitForExit()
exit $proc.ExitCode
