import { beforeEach, describe, expect, it, vi } from 'vitest';
import type { ConnectionManager } from '../../../ws/connection-manager';
import { MessageType } from '../../../shared';
import { TaskLimiter } from '../../features/task-limiter';
import { runtimeResourcesHandler } from '../runtimeResources';
import { sendInterruptToProcess } from '../../claude-process';

const holder = vi.hoisted(() => ({ manager: null as unknown }));
vi.mock('../../features/runtime-tasks', () => ({ runtimeTasks: () => holder.manager, setTaskConcurrency: vi.fn() }));
vi.mock('../../claude-process', () => ({ sendInterruptToProcess: vi.fn(() => true) }));
vi.mock('../../claude', () => ({ Claude: { killTree: vi.fn() } }));

describe('task-row stop', () => {
  beforeEach(() => vi.clearAllMocks());
  const flush = async () => { for (let i = 0; i < 8; i++) await Promise.resolve(); };

  it('interrupts only the selected running task and preserves queued same-session siblings', async () => {
    const limiter = new TaskLimiter(1);
    holder.manager = { limiter, ready: Promise.resolve() };
    const work = vi.fn(() => true);
    const first = limiter.enqueue('session', '/project', work, vi.fn());
    const second = limiter.enqueue('session', '/project', work, vi.fn());
    const third = limiter.enqueue('session', '/project', work, vi.fn());
    await flush();
    const connections = { getSession: () => ({ process: {} }), sendTo: vi.fn() } as unknown as ConnectionManager;
    await runtimeResourcesHandler('client', { type: MessageType.STOP_RUNTIME_TASK, timestamp: 0, payload: { taskId: first.id } }, connections);
    expect(sendInterruptToProcess).toHaveBeenCalledWith(connections, 'session');
    expect(limiter.get(first.id)?.state).toBe('stopping');
    expect(limiter.get(second.id)?.state).toBe('queued');
    expect(limiter.get(third.id)?.state).toBe('queued');
    expect(work).toHaveBeenCalledOnce();
    limiter.release('session'); await flush();
    expect(limiter.get(second.id)?.state).toBe('running');
    expect(limiter.get(third.id)?.state).toBe('queued');
    expect(work).toHaveBeenCalledTimes(2);
  });
});
