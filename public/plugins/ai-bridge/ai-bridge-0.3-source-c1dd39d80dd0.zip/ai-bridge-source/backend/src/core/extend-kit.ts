export interface SpeechToTextStream {
  sendAudio: (chunk: Uint8Array) => void;
  close: () => Promise<void>;
}

export interface SpeechToTextHandlers {
  onTranscript: (text: string, isFinal: boolean) => void;
  onError: (message: string, info?: { fatal?: boolean }) => void;
  onOpen?: () => void;
}

export interface SpeechToTextOptions {
  language?: string;
  extraKeyterms?: string[];
  typedInterims?: boolean;
}

interface ExtendKitStt {
  openSpeechToTextStream: (
    handlers: SpeechToTextHandlers,
    options?: SpeechToTextOptions,
  ) => Promise<SpeechToTextStream>;
  isSpeechToTextAvailable: () => Promise<boolean>;
}


/** This independent build never loads an upstream extension package. */
export class ExtendKitMissingError extends Error {
  constructor() { super('Voice integration is not supported by AI Bridge.'); this.name = 'ExtendKitMissingError'; }
}
export async function loadSpeechToText(): Promise<ExtendKitStt> { throw new ExtendKitMissingError(); }
export async function getExtendKitVersion(): Promise<string | null> { return null; }
export function resetExtendKitCache(): void {}
