import { describe, expect, it, vi } from 'vitest';
import type { QueuedPrompt } from '../../../shared';
import { TaskLimiter } from '../task-limiter';

const flush = async () => { for (let i = 0; i < 8; i++) await Promise.resolve(); };
function setup() {
  const updates = vi.fn();
  const limiter = new TaskLimiter(1, updates);
  const delivered: string[] = [];
  const add = (content: string, sessionId = 's', extra: Partial<QueuedPrompt> = {}) => {
    const prompt = { content, ...extra };
    const updated = vi.fn();
    const task = limiter.enqueueUser(sessionId, '/project', () => { delivered.push(prompt.content); return true; }, vi.fn(), content,
      { validate: vi.fn(), write: vi.fn(async () => true), accepted: vi.fn() }, { prompt, updated });
    return { task, prompt, updated };
  };
  const active = add('active');
  return { limiter, add, active, delivered, updates };
}

describe('editable message queue', () => {
  it('reorders the real delivery order while leaving other sessions and internal slots in place', async () => {
    const { limiter, add, delivered } = setup();
    const b = add('B'), other = add('other', 'other');
    const internal = limiter.enqueue('s', '/project', () => { delivered.push('internal'); return true; }, vi.fn());
    const c = add('C'), d = add('D');
    limiter.reorderQueued('s', [d.task.id, b.task.id, c.task.id]);
    expect(limiter.snapshot().tasks.map(task => task.id).slice(1)).toEqual([d.task.id, other.task.id, internal.id, b.task.id, c.task.id]);
    await flush();
    for (const session of ['s', 's', 'other', 's', 's']) { limiter.release(session); await flush(); }
    expect(delivered).toEqual(['active', 'D', 'other', 'internal', 'B', 'C']);
  });

  it('merges selected prompts in current queue order and preserves every attachment and context', async () => {
    const { limiter, add, delivered, active } = setup();
    const b = add('<ide_selection>code</ide_selection>\nB', 's', { attachments: [{ type: 'file', fileName: 'B.ts', absolutePath: '/B.ts' }] });
    const c = add('C');
    const d = add('D', 's', { attachments: [{ type: 'image', fileName: 'D.png', mimeType: 'image/png', base64: 'abc' }] });
    limiter.reorderQueued('s', [d.task.id, c.task.id, b.task.id]);
    limiter.mergeQueued('s', [b.task.id, d.task.id]);
    expect(d.prompt.content).toBe('D\n\n<ide_selection>code</ide_selection>\nB');
    expect(d.prompt.attachments?.map(item => item.type)).toEqual(['image', 'file']);
    expect(d.updated).toHaveBeenCalledOnce();
    expect(limiter.get(b.task.id)).toBeUndefined();
    expect(limiter.get(active.task.id)?.state).toBe('starting');
    await flush(); limiter.release('s'); await flush(); limiter.release('s'); await flush();
    expect(delivered).toEqual(['active', d.prompt.content, 'C']);
  });

  it.each(['duplicate', 'missing', 'other-session', 'active', 'mode', 'model', 'command', 'steering'])('rejects invalid %s merges without changing any messages', async (kind) => {
    const { limiter, add, active } = setup();
    const b = add('B');
    const c = add(kind === 'command' ? '/compact' : 'C', kind === 'other-session' ? 'other' : 's',
      kind === 'mode' ? { inputMode: 'plan' } : kind === 'model' ? { model: 'other' } : {});
    await flush();
    if (kind === 'steering') await limiter.steerQueued(c.task.id);
    const before = limiter.snapshot();
    const ids = kind === 'duplicate' ? [b.task.id, b.task.id] : kind === 'missing' ? [b.task.id, 'gone']
      : kind === 'active' ? [b.task.id, active.task.id] : [b.task.id, c.task.id];
    expect(() => limiter.mergeQueued('s', ids)).toThrow();
    expect(limiter.snapshot()).toEqual(before);
    expect(b.prompt.content).toBe('B');
  });

  it('rejects a stale reorder after admission or a new send, preserving the latest queue', async () => {
    const { limiter, add } = setup();
    const b = add('B'), c = add('C');
    add('D');
    const before = limiter.snapshot();
    expect(() => limiter.reorderQueued('s', [c.task.id, b.task.id])).toThrow('queue changed');
    expect(limiter.snapshot()).toEqual(before);
    await flush(); limiter.release('s'); await flush();
    expect(() => limiter.reorderQueued('s', [c.task.id, b.task.id])).toThrow('queue changed');
  });

  it('restores only the requested session messages, never publishing their content in global snapshots', () => {
    const { limiter, add } = setup();
    add('B'); add('private', 'other');
    expect(limiter.queuedMessages('s').map(message => message.content)).toEqual(['active', 'B']);
    expect(JSON.stringify(limiter.snapshot())).not.toContain('"content"');
  });
});
