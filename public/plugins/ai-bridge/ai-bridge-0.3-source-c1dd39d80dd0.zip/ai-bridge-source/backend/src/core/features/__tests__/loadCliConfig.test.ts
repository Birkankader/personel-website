import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import { performance } from 'perf_hooks';
import { EventEmitter } from 'events';
import { Readable, Writable } from 'stream';
import type { ChildProcess } from 'child_process';

vi.mock('../../claude', () => ({
  Claude: {
    command: 'claude',
    env: { PATH: '/fixture/bin' },
    // loadCliConfig now goes through spawnAuthed (auth-env strip centralized in Claude).
    // killTreeNonBlocking is mocked too so the 15s safety-timeout callback — which can fire after a
    // fast test has torn down — doesn't throw "Claude.killTreeNonBlocking is not a function".
    spawnAuthed: vi.fn(),
    killTreeNonBlocking: vi.fn(),
  },
}));

import { Claude } from '../../claude';
import { loadCliConfig, parseCliConfigResponse, _resetCliConfigCache } from '../loadCliConfig';

function makeFakeProc(stdoutPayload?: string): ChildProcess {
  const proc = new EventEmitter() as unknown as ChildProcess;
  const stdout = new Readable({ read() {} });
  const stderr = new Readable({ read() {} });
  const stdin = new Writable({ write(_c, _e, cb) { cb(); } });
  (proc as unknown as { stdout: Readable }).stdout = stdout;
  (proc as unknown as { stderr: Readable }).stderr = stderr;
  (proc as unknown as { stdin: Writable }).stdin = stdin;
  (proc as unknown as { pid: number }).pid = 1234;
  (proc as unknown as { kill: () => void }).kill = () => {};
  setImmediate(() => {
    proc.emit('spawn');
    if (stdoutPayload !== undefined) stdout.push(stdoutPayload);
  });
  return proc;
}

function controlResponse(commandName: string): string {
  return JSON.stringify({
    type: 'control_response',
    response: {
      subtype: 'success',
      request_id: 'config_init',
      response: {
        commands: [{ name: commandName, description: '', argumentHint: '' }],
        agents: [],
        output_style: 'default',
        available_output_styles: [],
        models: [],
        account: { email: '', subscriptionType: '' },
        pid: 1,
      },
    },
  }) + '\n';
}

describe('loadCliConfig', () => {
  beforeEach(() => {
    _resetCliConfigCache();
    vi.mocked(Claude.spawnAuthed).mockReset();
    vi.mocked(Claude.killTreeNonBlocking).mockReset();
  });
  afterEach(() => {
    vi.restoreAllMocks();
    vi.unstubAllEnvs();
    vi.useRealTimers();
  });

  describe('cache', () => {
    it('caches per workingDir — different projects get different configs', async () => {
      vi.mocked(Claude.spawnAuthed).mockImplementation(async (_args, workingDir) => {
        const cmdName = workingDir === '/project/a' ? 'skill-a' : 'skill-b';
        return makeFakeProc(controlResponse(cmdName));
      });

      const configA = await loadCliConfig('/project/a');
      const configB = await loadCliConfig('/project/b');

      expect(configA?.response.response.commands[0].name).toBe('skill-a');
      expect(configB?.response.response.commands[0].name).toBe('skill-b');
    });

    it('returns the cached config for the same workingDir without respawning', async () => {
      vi.mocked(Claude.spawnAuthed).mockImplementation(async () => makeFakeProc(controlResponse('skill-a')));

      await loadCliConfig('/project/a');
      await loadCliConfig('/project/a');

      expect(vi.mocked(Claude.spawnAuthed)).toHaveBeenCalledTimes(1);
    });

    it('refresh:true bypasses the cache and re-spawns', async () => {
      vi.mocked(Claude.spawnAuthed).mockImplementationOnce(async () => makeFakeProc(controlResponse('first')));
      const first = await loadCliConfig('/project/a');

      vi.mocked(Claude.spawnAuthed).mockImplementationOnce(async () => makeFakeProc(controlResponse('second')));
      const second = await loadCliConfig('/project/a', { refresh: true });

      expect(first?.response.response.commands[0].name).toBe('first');
      expect(second?.response.response.commands[0].name).toBe('second');
      expect(vi.mocked(Claude.spawnAuthed)).toHaveBeenCalledTimes(2);
    });

    it('joins simultaneous forced refreshes from separate tabs into one probe', async () => {
      const proc = makeFakeProc();
      vi.mocked(Claude.spawnAuthed).mockResolvedValue(proc);
      const requests = Array.from({ length: 8 }, () => loadCliConfig('/project/a', { refresh: true }));
      await Promise.resolve();
      proc.stdout!.emit('data', Buffer.from(controlResponse('shared')));
      const configs = await Promise.all(requests);
      expect(configs.every((config) => config?.response.response.commands[0].name === 'shared')).toBe(true);
      expect(Claude.spawnAuthed).toHaveBeenCalledTimes(1);
      await loadCliConfig('/project/a');
      expect(Claude.spawnAuthed).toHaveBeenCalledTimes(1);
    });

    it('expires completed snapshots so later openings discover external changes', async () => {
      const now = vi.spyOn(performance, 'now').mockReturnValue(0);
      vi.mocked(Claude.spawnAuthed).mockImplementation(async () => makeFakeProc(controlResponse('skill')));
      await loadCliConfig('/project/a');
      now.mockReturnValue(29_999);
      await loadCliConfig('/project/a');
      expect(Claude.spawnAuthed).toHaveBeenCalledTimes(1);
      now.mockReturnValue(30_000);
      await loadCliConfig('/project/a');
      expect(Claude.spawnAuthed).toHaveBeenCalledTimes(2);
    });

    it('does not reuse or join snapshots from another configured CLI profile', async () => {
      const first = makeFakeProc();
      const second = makeFakeProc();
      vi.mocked(Claude.spawnAuthed).mockResolvedValueOnce(first).mockResolvedValueOnce(second);
      vi.stubEnv('CLAUDE_CONFIG_DIR', '/fixture/account-a');
      const a = loadCliConfig('/project/a');
      vi.stubEnv('CLAUDE_CONFIG_DIR', '/fixture/account-b');
      const b = loadCliConfig('/project/a');
      await Promise.resolve();
      second.stdout!.emit('data', Buffer.from(controlResponse('account-b')));
      first.stdout!.emit('data', Buffer.from(controlResponse('account-a')));
      expect((await a)?.response.response.commands[0].name).toBe('account-a');
      expect((await b)?.response.response.commands[0].name).toBe('account-b');
      expect((await loadCliConfig('/project/a'))?.response.response.commands[0].name).toBe('account-b');
      expect(Claude.spawnAuthed).toHaveBeenCalledTimes(2);
    });
  });

  describe('probe lifecycle', () => {
    it('settles after the deadline even when the Windows shell never emits close', async () => {
      vi.useFakeTimers();
      const proc = makeFakeProc();
      vi.mocked(Claude.spawnAuthed).mockResolvedValue(proc);
      const pending = loadCliConfig('/project/a');
      await vi.advanceTimersByTimeAsync(15_000);
      expect(await pending).toBeNull();
      expect(Claude.killTreeNonBlocking).toHaveBeenCalledTimes(1);
      const retry = loadCliConfig('/project/a');
      await Promise.resolve();
      proc.stdout!.emit('data', Buffer.from(controlResponse('retry')));
      expect((await retry)?.response.response.commands[0].name).toBe('retry');
      expect(Claude.spawnAuthed).toHaveBeenCalledTimes(2);
    });

    it('parses each completed line once and preserves UTF-8 across byte chunks', async () => {
      const proc = makeFakeProc();
      vi.mocked(Claude.spawnAuthed).mockResolvedValue(proc);
      const pending = loadCliConfig('/project/a');
      await Promise.resolve();
      const parse = vi.spyOn(JSON, 'parse');
      const prefix = '{"type":"system","subtype":"hook_started"}\n';
      for (let i = 0; i < 100; i++) proc.stdout!.emit('data', Buffer.from(prefix));
      // 2-byte (ş, é) and 3-byte (€) UTF-8 characters, fed one byte at a time.
      const response = Buffer.from(controlResponse('Köprü café €'));
      for (let i = 0; i < response.length; i++) proc.stdout!.emit('data', response.subarray(i, i + 1));
      const result = await pending;
      expect(result?.response.response.commands[0].name).toBe('Köprü café €');
      expect(parse).toHaveBeenCalledTimes(101);
      expect(Claude.killTreeNonBlocking).toHaveBeenCalledTimes(1);
    });

    it('accepts a final response without a newline when the process closes', async () => {
      const proc = makeFakeProc();
      vi.mocked(Claude.spawnAuthed).mockResolvedValue(proc);
      const pending = loadCliConfig('/project/a');
      await Promise.resolve();
      proc.stdout!.emit('data', Buffer.from(controlResponse('final').trimEnd()));
      proc.emit('close', 0);
      expect((await pending)?.response.response.commands[0].name).toBe('final');
    });

    it('bounds an unterminated output line and allows a fresh attempt', async () => {
      const proc = makeFakeProc();
      vi.mocked(Claude.spawnAuthed).mockResolvedValue(proc);
      const pending = loadCliConfig('/project/a');
      await Promise.resolve();
      const chunk = Buffer.alloc(1024 * 1024, 120);
      for (let i = 0; i < 9; i++) proc.stdout!.emit('data', chunk);
      expect(await pending).toBeNull();
      expect(Claude.killTreeNonBlocking).toHaveBeenCalledTimes(1);
    });

    it('settles stdin errors and clears the stale timeout after success', async () => {
      vi.useFakeTimers();
      const proc = makeFakeProc();
      vi.mocked(Claude.spawnAuthed).mockResolvedValue(proc);
      const pending = loadCliConfig('/project/a');
      await Promise.resolve();
      proc.stdin!.emit('error', new Error('EPIPE'));
      expect(await pending).toBeNull();
      await vi.advanceTimersByTimeAsync(30_000);
      expect(Claude.killTreeNonBlocking).toHaveBeenCalledTimes(1);
    });
  });

  describe('parseCliConfigResponse', () => {
    it('should return control_response as-is', () => {
      const controlResponse = {
        type: 'control_response',
        response: {
          subtype: 'success',
          request_id: 'init_1',
          response: {
            commands: [
              { name: 'compact', description: 'Compact conversation history', argumentHint: '' },
              { name: 'debug', description: 'Enable debug logging', argumentHint: '[issue]' },
            ],
            agents: [],
            output_style: 'default',
            available_output_styles: ['default'],
            models: [],
            account: { email: 'test@test.com', subscriptionType: 'Pro' },
            pid: 12345,
          },
        },
      };
      const stdout = JSON.stringify(controlResponse) + '\n';
      const result = parseCliConfigResponse(stdout);
      expect(result).toEqual(controlResponse);
    });

    it('should find control_response among other events', () => {
      const lines = [
        '{"type":"system","subtype":"hook_started","hook_id":"abc"}',
        '{"type":"control_response","response":{"subtype":"success","request_id":"config_init","response":{"commands":[{"name":"debug","description":"Enable debug logging","argumentHint":"[issue]"}],"agents":[],"output_style":"default","available_output_styles":[],"models":[],"account":{"email":"a@b.com","subscriptionType":"Free"},"pid":1}}}',
      ];
      const stdout = lines.join('\n') + '\n';
      const result = parseCliConfigResponse(stdout);
      expect(result).not.toBeNull();
      expect(result!.type).toBe('control_response');
      expect(result!.response.response.commands).toHaveLength(1);
      expect(result!.response.response.commands[0].name).toBe('debug');
    });

    it('should return null when no control_response is found', () => {
      const stdout = '{"type":"system","subtype":"hook_started","hook_id":"abc"}\n';
      const result = parseCliConfigResponse(stdout);
      expect(result).toBeNull();
    });

    it('should handle empty stdout', () => {
      const result = parseCliConfigResponse('');
      expect(result).toBeNull();
    });

    it('should skip malformed JSON lines gracefully', () => {
      const controlResponse = {
        type: 'control_response',
        response: {
          subtype: 'success',
          request_id: 'init_1',
          response: {
            commands: [{ name: 'foo', description: '', argumentHint: '' }],
            agents: [],
            output_style: 'default',
            available_output_styles: [],
            models: [],
            account: { email: '', subscriptionType: '' },
            pid: 0,
          },
        },
      };
      const lines = [
        'not valid json',
        JSON.stringify(controlResponse),
      ];
      const stdout = lines.join('\n') + '\n';
      const result = parseCliConfigResponse(stdout);
      expect(result).toEqual(controlResponse);
    });
  });
});
