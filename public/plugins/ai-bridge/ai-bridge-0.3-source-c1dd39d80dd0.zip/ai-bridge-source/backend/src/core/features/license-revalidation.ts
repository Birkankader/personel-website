import type { LicenseVerifyResult } from './license';
export const REVALIDATE_INTERVAL_MS = 24 * 60 * 60 * 1000;
export type LicenseVerifier = (key: string) => Promise<LicenseVerifyResult>;
/** No upstream license exists in this build; never invoke an injected verifier. */
export async function revalidateStoredLicense(_verify: LicenseVerifier): Promise<void> {}
