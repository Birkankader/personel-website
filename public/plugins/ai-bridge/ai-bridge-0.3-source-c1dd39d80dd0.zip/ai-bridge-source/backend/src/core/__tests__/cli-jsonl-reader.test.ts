import { describe, expect, it } from 'vitest';
import { CliJsonlReader } from '../cli-jsonl-reader';

describe('CLI JSONL byte framing', () => {
  it('preserves Turkish text and emoji at every byte boundary', () => {
    const line = JSON.stringify({ text: 'Üçüncü yanıt 🧭', extra: { value: 'ıİşğçöü' } });
    const bytes = Buffer.from(line + '\n');
    for (let split = 0; split <= bytes.length; split++) {
      const reader = new CliJsonlReader();
      expect([...reader.write(bytes.subarray(0, split)), ...reader.write(bytes.subarray(split)), ...reader.end()])
        .toEqual([line]);
    }
  });

  it('keeps empty lines, CRLF and the final unterminated line in their original order', () => {
    const reader = new CliJsonlReader();
    expect(reader.write(Buffer.from('one\r\n\ntw'))).toEqual(['one\r', '']);
    expect(reader.write(Buffer.from('o\nthree'))).toEqual(['two']);
    expect(reader.end()).toEqual(['three']);
    expect(reader.end()).toEqual([]);
  });

  it('delivers a large fragmented event without dropping or duplicating bytes', () => {
    const line = JSON.stringify({ text: 'ç🧭'.repeat(100_000), extra: 'retained' });
    const bytes = Buffer.from(line);
    const reader = new CliJsonlReader();
    const output: string[] = [];
    for (let i = 0; i < bytes.length; i += 1023) output.push(...reader.write(bytes.subarray(i, i + 1023)));
    expect(output).toEqual([]);
    expect(reader.write(Buffer.from('\n{"type":"result"}\n'))).toEqual([line, '{"type":"result"}']);
    expect(reader.end()).toEqual([]);
  });

  it('isolates partial lines and UTF-8 decoding between simultaneous processes', () => {
    const first = new CliJsonlReader(), second = new CliJsonlReader();
    const compass = Buffer.from('🧭');
    expect(first.write(compass.subarray(0, 2))).toEqual([]);
    expect(second.write(Buffer.from('second'))).toEqual([]);
    expect(first.write(compass.subarray(2))).toEqual([]);
    expect(second.end()).toEqual(['second']);
    expect(first.end()).toEqual(['🧭']);
  });
});
