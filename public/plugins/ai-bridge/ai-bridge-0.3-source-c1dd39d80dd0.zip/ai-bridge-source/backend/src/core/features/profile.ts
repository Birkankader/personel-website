import { readFile, mkdir } from 'fs/promises';
import { existsSync } from 'fs';
import { join } from 'path';
import { homedir } from 'os';
import { randomUUID } from 'crypto';
import { atomicWriteFile } from './atomic-json';

// ─── User profile (global, telemetry-independent) ────────────────────────────
// `~/.ai-bridge/profile.json` holds a per-install pseudonymous uuid and the
// telemetry consent decision. The uuid is created for EVERY user regardless of
// consent; nothing is transmitted unless consent status is ACCEPTED.

const PROFILE_DIR = join(homedir(), '.ai-bridge');
const PROFILE_FILE = join(PROFILE_DIR, 'profile.json');

/** Telemetry consent status. PENDING = the user has neither accepted nor declined yet. */
export enum ConsentStatus {
  PENDING = 'pending',
  ACCEPTED = 'accepted',
  DENIED = 'denied',
}

export interface TelemetryConsent {
  status: ConsentStatus;
  /** When the accept/decline decision was made (ISO 8601). null if not answered. */
  decidedAt: string | null;
}

/**
 * Answer to the one-time question asked the first time the user tries voice input.
 * PENDING = not answered yet (asked again on the next mic click).
 */
export enum VoicePromptStatus {
  PENDING = 'pending',
  ACCEPTED = 'accepted',
  DECLINED = 'declined',
}

export interface VoicePrompt {
  status: VoicePromptStatus;
  /**
   * When the question was shown (ISO 8601). null if it has never been shown.
   *
   * Kept separate from the answer time so that "asked, but the app was closed without
   * answering" can be distinguished from "never asked". Updated to the latest time on every re-ask.
   * Stays null when the kit was already installed and we started as ACCEPTED without asking.
   */
  askedAt: string | null;
  /** When the user answered (ISO 8601). null if not answered. */
  decidedAt: string | null;
}

export interface ProfileData {
  /** Per-install pseudonymous identifier. Always present, regardless of consent. */
  uuid: string;
  telemetryConsent: TelemetryConsent;
  /** Ids of announcements the user dismissed. Matched against the server announcement's `id` field. */
  dismissedAnnouncementIds: string[];
  /** Whether to receive announcements. Default true. If false, the backend does not fetch remotely at all. */
  announcementsEnabled: boolean;
  /** Best score in the runner game (easter egg). 0 if there is no record yet. */
  runnerBestScore: number;
  /** Answer to the one-time question about using voice input. Asked only once per install (global). */
  voicePrompt: VoicePrompt;
}

function createDefaultProfile(): ProfileData {
  return {
    uuid: randomUUID(),
    telemetryConsent: { status: ConsentStatus.DENIED, decidedAt: null },
    dismissedAnnouncementIds: [],
    announcementsEnabled: false,
    runnerBestScore: 0,
    voicePrompt: { status: VoicePromptStatus.PENDING, askedAt: null, decidedAt: null },
  };
}

/** Normalizes by filtering out non-string values. A non-array is treated as an empty array. */
export function normalizeDismissedAnnouncementIds(value: unknown): string[] {
  return Array.isArray(value) ? value.filter((id): id is string => typeof id === 'string') : [];
}

/** Normalizes a stored status to PENDING if it is an unknown value. */
function normalizeStatus(_status: ConsentStatus | undefined): ConsentStatus {
  return ConsentStatus.DENIED;
}

function normalizeAnnouncementsEnabled(_value: unknown): boolean {
  return false;
}

function normalizeRunnerBestScore(value: unknown): number {
  return typeof value === 'number' && Number.isFinite(value) && value > 0 ? Math.floor(value) : 0;
}

/** Normalizes values that are not ISO strings (missing/corrupt) to null. */
function normalizeTimestamp(value: unknown): string | null {
  return typeof value === 'string' && value.length > 0 ? value : null;
}

/**
 * Normalizes voicePrompt. Existing users who lack the field entirely start as PENDING,
 * so they are asked the next time they press the mic.
 */
export function normalizeVoicePrompt(value: unknown): VoicePrompt {
  const raw = (value ?? {}) as Partial<VoicePrompt>;
  const status =
    raw.status === VoicePromptStatus.ACCEPTED || raw.status === VoicePromptStatus.DECLINED
      ? raw.status
      : VoicePromptStatus.PENDING;
  return {
    status,
    askedAt: normalizeTimestamp(raw.askedAt),
    // An answer time left over while still unanswered is contradictory, so drop it.
    decidedAt: status === VoicePromptStatus.PENDING ? null : normalizeTimestamp(raw.decidedAt),
  };
}

async function writeProfile(profile: ProfileData): Promise<void> {
  await mkdir(PROFILE_DIR, { recursive: true });
  await atomicWriteFile(PROFILE_FILE, JSON.stringify(profile, null, 2) + '\n');
}

/**
 * Reads and returns profile.json. If the file or fields are missing or corrupt, normalizes and saves it again.
 * The uuid is always guaranteed regardless of consent (created if missing). Called once at server startup.
 */
export async function ensureProfile(): Promise<ProfileData> {
  if (!existsSync(PROFILE_FILE)) {
    const profile = createDefaultProfile();
    await writeProfile(profile);
    return profile;
  }

  try {
    const raw = await readFile(PROFILE_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as Partial<ProfileData>;

    const dismissedAnnouncementIds = normalizeDismissedAnnouncementIds(
      parsed.dismissedAnnouncementIds,
    );
    const announcementsEnabled = normalizeAnnouncementsEnabled(parsed.announcementsEnabled);
    const runnerBestScore = normalizeRunnerBestScore(parsed.runnerBestScore);
    const voicePrompt = normalizeVoicePrompt(parsed.voicePrompt);

    const profile: ProfileData = {
      uuid:
        typeof parsed.uuid === 'string' && parsed.uuid.length > 0 ? parsed.uuid : randomUUID(),
      telemetryConsent: {
        status: normalizeStatus(parsed.telemetryConsent?.status),
        decidedAt: parsed.telemetryConsent?.decidedAt ?? null,
      },
      dismissedAnnouncementIds,
      announcementsEnabled,
      runnerBestScore,
      voicePrompt,
    };

    // If missing/corrupt fields were normalized, rewrite the file to normalize it.
    const needsRewrite =
      parsed.uuid !== profile.uuid ||
      parsed.telemetryConsent?.status !== profile.telemetryConsent.status ||
      parsed.telemetryConsent?.decidedAt !== profile.telemetryConsent.decidedAt ||
      !Array.isArray(parsed.dismissedAnnouncementIds) ||
      parsed.dismissedAnnouncementIds.length !== dismissedAnnouncementIds.length ||
      typeof parsed.announcementsEnabled !== 'boolean' ||
      parsed.runnerBestScore !== runnerBestScore ||
      parsed.voicePrompt?.status !== voicePrompt.status ||
      parsed.voicePrompt?.askedAt !== voicePrompt.askedAt ||
      parsed.voicePrompt?.decidedAt !== voicePrompt.decidedAt;
    if (needsRewrite) {
      await writeProfile(profile);
    }
    return profile;
  } catch {
    // Corruption such as a JSON parse failure: recover with a new profile (the old uuid cannot be preserved).
    const profile = createDefaultProfile();
    await writeProfile(profile);
    return profile;
  }
}

/** Reads the current profile (creating it if missing). */
export async function readProfile(): Promise<ProfileData> {
  return ensureProfile();
}

/** Records telemetry accept/deny along with a timestamp. */
export async function setTelemetryConsent(accepted: boolean): Promise<ProfileData> {
  const profile = await ensureProfile();
  profile.telemetryConsent = {
    status: ConsentStatus.DENIED,
    decidedAt: new Date().toISOString(),
  };
  await writeProfile(profile);
  return profile;
}

/** Reads the current answer state of the voice input question. */
export async function getVoicePrompt(): Promise<VoicePrompt> {
  const profile = await ensureProfile();
  return profile.voicePrompt;
}

/**
 * Records when the question was shown. Does not touch the status — showing it is not an answer yet.
 * If the user has already answered, we will not ask again, so this does nothing.
 */
export async function markVoicePromptAsked(): Promise<VoicePrompt> {
  const profile = await ensureProfile();
  if (profile.voicePrompt.status !== VoicePromptStatus.PENDING) return profile.voicePrompt;
  profile.voicePrompt = { ...profile.voicePrompt, askedAt: new Date().toISOString() };
  await writeProfile(profile);
  return profile.voicePrompt;
}

/**
 * Records the user's answer.
 *
 * An install failure does not revert the answer — the user's intent was "I'll use it", and the
 * failure is separate from that intent. So accepted records the button press, not the install result.
 */
export async function setVoicePromptDecision(accepted: boolean): Promise<VoicePrompt> {
  const profile = await ensureProfile();
  profile.voicePrompt = {
    status: accepted ? VoicePromptStatus.ACCEPTED : VoicePromptStatus.DECLINED,
    askedAt: profile.voicePrompt.askedAt,
    decidedAt: new Date().toISOString(),
  };
  await writeProfile(profile);
  return profile.voicePrompt;
}

/**
 * If the kit is already installed, start as ACCEPTED without asking.
 *
 * There is no reason to ask "Install it?" to someone who already has the kit. Since we did not ask,
 * askedAt stays null and decidedAt records when this was decided.
 * If there is already an answer, that answer takes precedence, so it is left untouched.
 */
export async function acceptVoicePromptForInstalledKit(): Promise<VoicePrompt> {
  const profile = await ensureProfile();
  if (profile.voicePrompt.status !== VoicePromptStatus.PENDING) return profile.voicePrompt;
  profile.voicePrompt = {
    status: VoicePromptStatus.ACCEPTED,
    askedAt: null,
    decidedAt: new Date().toISOString(),
  };
  await writeProfile(profile);
  return profile.voicePrompt;
}

/** Reads the ids of announcements dismissed so far. */
export async function getDismissedAnnouncementIds(): Promise<string[]> {
  const profile = await ensureProfile();
  return profile.dismissedAnnouncementIds;
}

/** Upper bound for dismissedAnnouncementIds. When exceeded, the oldest entries are dropped to prevent unbounded growth. */
const MAX_DISMISSED_ANNOUNCEMENT_IDS = 500;

/**
 * Adds an announcement id to dismissedAnnouncementIds (ignored if already present; no duplicates).
 * When the list exceeds the bound, the oldest entries are removed first (FIFO).
 * Returns the full updated (or unchanged) list.
 */
export async function setDismissedAnnouncement(id: string): Promise<string[]> {
  const profile = await ensureProfile();
  if (!profile.dismissedAnnouncementIds.includes(id)) {
    profile.dismissedAnnouncementIds = [...profile.dismissedAnnouncementIds, id].slice(
      -MAX_DISMISSED_ANNOUNCEMENT_IDS,
    );
    await writeProfile(profile);
  }
  return profile.dismissedAnnouncementIds;
}

/** Reads the current announcement subscription setting (default true). */
export async function getAnnouncementsEnabled(): Promise<boolean> {
  const profile = await ensureProfile();
  return profile.announcementsEnabled;
}

/** Records whether announcements are on or off. */
export async function setAnnouncementsEnabled(enabled: boolean): Promise<ProfileData> {
  const profile = await ensureProfile();
  profile.announcementsEnabled = false;
  await writeProfile(profile);
  return profile;
}

/** Reads the runner game best score (0 if there is no record). */
export async function getRunnerBestScore(): Promise<number> {
  const profile = await ensureProfile();
  return profile.runnerBestScore;
}

/**
 * Records a runner game score. Only updates when it beats the existing best, so sending
 * every finished round as-is never lowers the best score.
 * Returns the current best score whether or not it was updated.
 */
export async function setRunnerBestScore(score: number): Promise<number> {
  const best = normalizeRunnerBestScore(score);
  const profile = await ensureProfile();
  if (best > profile.runnerBestScore) {
    profile.runnerBestScore = best;
    await writeProfile(profile);
  }
  return profile.runnerBestScore;
}
