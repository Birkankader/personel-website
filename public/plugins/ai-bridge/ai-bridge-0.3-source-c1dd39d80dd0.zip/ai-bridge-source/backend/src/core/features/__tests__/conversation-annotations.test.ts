import { beforeEach, afterEach, describe, expect, it } from 'vitest';
import { mkdtemp, readFile, writeFile, rm } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import { ConversationAnnotationStore } from '../conversation-annotations';

let directory: string;
let path: string;
const target = { workingDir: '/work', sessionId: 'session-a', messageUuid: 'message-a' };
beforeEach(async () => { directory = await mkdtemp(join(tmpdir(), 'swttch-notes-')); path = join(directory, 'annotations.json'); });
afterEach(async () => { await rm(directory, { recursive: true, force: true }); });

describe('separate conversation annotations', () => {
  it('persists bookmarks and decisions across store instances without modifying the transcript', async () => {
    const transcript = join(directory, 'session-a.jsonl');
    await writeFile(transcript, 'original Claude content');
    await new ConversationAnnotationStore(path).save({ ...target, bookmarked: true, note: ' Use the local cache ' });
    const page = await new ConversationAnnotationStore(path).list();
    expect(page.annotations[0]).toMatchObject({ ...target, bookmarked: true, note: 'Use the local cache' });
    expect(await readFile(transcript, 'utf8')).toBe('original Claude content');
  });

  it('serializes concurrent changes and supports exact-message lookup and deletion', async () => {
    const store = new ConversationAnnotationStore(path);
    await Promise.all([
      store.save({ ...target, bookmarked: true, note: 'one' }),
      store.save({ ...target, messageUuid: 'message-b', bookmarked: false, note: 'two' }),
    ]);
    expect((await store.list({ limit: 1 })).nextOffset).toBe(1);
    expect((await store.list({ messageUuid: 'message-b' })).annotations[0].note).toBe('two');
    await store.save({ ...target, bookmarked: false, note: '' });
    expect((await store.list()).annotations).toHaveLength(1);
  });

  it('rejects traversal identifiers and oversized notes', async () => {
    const store = new ConversationAnnotationStore(path);
    await expect(store.save({ ...target, sessionId: '../../outside', bookmarked: true, note: '' })).rejects.toThrow('Invalid');
    await expect(store.save({ ...target, messageUuid: undefined as unknown as string, bookmarked: true, note: '' })).rejects.toThrow('Invalid');
    await expect(store.save({ ...target, bookmarked: true, note: 'x'.repeat(4001) })).rejects.toThrow('4000');
  });

  it('refuses to overwrite unreadable annotation data', async () => {
    await writeFile(path, '{damaged');
    const store = new ConversationAnnotationStore(path);
    await expect(store.save({ ...target, bookmarked: true, note: 'decision' })).rejects.toThrow('refusing to overwrite');
    expect(await readFile(path, 'utf8')).toBe('{damaged');
  });
});
