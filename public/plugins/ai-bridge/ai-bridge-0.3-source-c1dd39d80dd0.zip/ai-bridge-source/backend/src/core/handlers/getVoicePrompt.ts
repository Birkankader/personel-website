import { unsupportedServiceHandler } from './unsupportedServices';

export const getVoicePromptHandler = unsupportedServiceHandler;
