import { mkdir, readFile, writeFile } from 'fs/promises';
import { homedir } from 'os';
import { join } from 'path';
import { agentToolsLaunch } from '../harness-launch';

/** The name the computer-use tools appear under (`mcp__ai-bridge-computer-use__screenshot`). */
export const COMPUTER_USE_MCP_NAME = 'ai-bridge-computer-use';

/** The stdio command that serves computer use (agent-tools.mjs computer-use-mcp). */
export function computerUseServer(): { command: string; args: string[] } {
  const tools = agentToolsLaunch();
  return { command: tools.command, args: [...tools.args, 'computer-use-mcp'] };
}

/**
 * The flags that add the computer-use server to a Claude CLI launch.
 *
 * `--mcp-config` is the CLI's documented way to load extra MCP servers for one
 * run, on top of the user's own; nothing is written into their configuration.
 * The config goes in a file because JSON does not survive the Windows command
 * line, and the file is only rewritten when its content changes.
 */
export async function computerUseMcpArgs(): Promise<string[]> {
  const dir = join(homedir(), '.ai-bridge', 'mcp');
  const file = join(dir, 'computer-use.json');
  const content = JSON.stringify({ mcpServers: { [COMPUTER_USE_MCP_NAME]: { type: 'stdio', ...computerUseServer() } } }, null, 2);
  const current = await readFile(file, 'utf8').catch(() => null);
  if (current !== content) {
    await mkdir(dir, { recursive: true });
    await writeFile(file, content, 'utf8');
  }
  const quoted = process.platform === 'win32' && /\s/.test(file) ? `"${file}"` : file;
  return ['--mcp-config', quoted];
}

/** The env that tells the ACP bridge to hand the same server to a harness session. */
export function computerUseBridgeEnv(): Record<string, string> {
  return { AI_BRIDGE_COMPUTER_USE_MCP: JSON.stringify({ name: COMPUTER_USE_MCP_NAME, ...computerUseServer() }) };
}
