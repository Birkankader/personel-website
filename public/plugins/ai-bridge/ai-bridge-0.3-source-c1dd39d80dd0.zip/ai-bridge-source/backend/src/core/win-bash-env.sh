# CCG: force the console to UTF-8 for every non-interactive bash the Claude CLI spawns.
#
# The CLI's Bash tool decodes its subprocess output as UTF-8, but Windows console
# programs print localized text in the legacy OEM codepage (CP949/CP936/CP932), so
# every non-ASCII character reaches the chat as U+FFFD. Setting the codepage at
# CLI spawn time does not survive: measured on ko-KR, the codepage is 65001 in cmd
# and in bash launched from it, but drops back to 949 once the CLI launches the
# tool's bash. bash sources $BASH_ENV on every non-interactive start, which is the
# one hook that runs inside that bash — so the codepage is set there instead.
#
# Under 65001 those programs cannot load their localized string resources and fall
# back to English: readable ASCII instead of garbled text.

# An inherited wrapper (including an older extracted copy) can lead back here.
# Limit this source chain and hide its previous hook while invoking it, so an
# older wrapper cannot recursively source itself or propagate the cycle to Bash.
if [ "${AI_BRIDGE_BASH_ENV_ACTIVE:-}" = 1 ]; then
  return 0
fi
AI_BRIDGE_BASH_ENV_ACTIVE=1
AI_BRIDGE_BASH_ENV_PREVIOUS=${AI_BRIDGE_PREV_BASH_ENV:-}
AI_BRIDGE_PREV_BASH_ENV=
if [ -n "$AI_BRIDGE_BASH_ENV_PREVIOUS" ] && [ -f "$AI_BRIDGE_BASH_ENV_PREVIOUS" ]; then
  . "$AI_BRIDGE_BASH_ENV_PREVIOUS"
fi
AI_BRIDGE_PREV_BASH_ENV=$AI_BRIDGE_BASH_ENV_PREVIOUS
unset AI_BRIDGE_BASH_ENV_PREVIOUS AI_BRIDGE_BASH_ENV_ACTIVE

chcp.com 65001 > /dev/null 2>&1
