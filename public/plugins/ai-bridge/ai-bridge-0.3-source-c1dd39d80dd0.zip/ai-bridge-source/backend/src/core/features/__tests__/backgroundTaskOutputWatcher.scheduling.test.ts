import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { watch } from 'fs';
import type { ConnectionManager } from '../../../ws/connection-manager';
import { loadBackgroundTaskOutput, type BackgroundTaskOutput } from '../loadBackgroundTaskOutput';
import { watchBackgroundTaskOutput, unwatchAllForConnection, unwatchBackgroundTaskOutput } from '../backgroundTaskOutputWatcher';

vi.mock('fs', () => ({ watch: vi.fn() }));
vi.mock('../loadBackgroundTaskOutput', () => ({ loadBackgroundTaskOutput: vi.fn() }));

describe('background output scheduling', () => {
  let changed: () => void;
  let watcherError: () => void;
  const sendTo = vi.fn();
  const connections = { sendTo } as unknown as ConnectionManager;

  beforeEach(() => {
    vi.useFakeTimers();
    vi.clearAllMocks();
    vi.mocked(loadBackgroundTaskOutput).mockResolvedValue({ text: 'current', truncated: false });
    vi.mocked(watch).mockImplementation(((_file: string, callback: () => void) => {
      changed = callback;
      return {
        close: vi.fn(),
        on: (_event: string, callback: () => void) => { watcherError = callback; },
      };
    }) as unknown as typeof watch);
  });

  afterEach(() => {
    unwatchAllForConnection('conn');
    vi.useRealTimers();
  });

  it('keeps a continuous log live while limiting updates to five per second', async () => {
    watchBackgroundTaskOutput('conn', '/task.output', connections);
    await vi.advanceTimersByTimeAsync(0);
    sendTo.mockClear();
    for (let i = 0; i < 20; i++) {
      changed();
      await vi.advanceTimersByTimeAsync(50);
    }

    expect(sendTo).toHaveBeenCalledTimes(5);
  });

  it('coalesces changes into one follow-up while a slow read is in flight', async () => {
    let finish!: (output: BackgroundTaskOutput) => void;
    vi.mocked(loadBackgroundTaskOutput).mockImplementationOnce(() => new Promise((resolve) => { finish = resolve; }));
    watchBackgroundTaskOutput('conn', '/task.output', connections);
    for (let i = 0; i < 20; i++) {
      changed();
      await vi.advanceTimersByTimeAsync(50);
    }
    expect(loadBackgroundTaskOutput).toHaveBeenCalledOnce();

    finish({ text: 'earlier', truncated: false });
    await vi.advanceTimersByTimeAsync(0);
    expect(loadBackgroundTaskOutput).toHaveBeenCalledTimes(2);
    expect(sendTo.mock.calls.map((call) => call[2].text)).toEqual(['earlier', 'current']);
  });

  it('does not emit a read that finishes after unwatch and resubscribe', async () => {
    let finish!: (output: BackgroundTaskOutput) => void;
    vi.mocked(loadBackgroundTaskOutput).mockImplementationOnce(() => new Promise((resolve) => { finish = resolve; }));
    watchBackgroundTaskOutput('conn', '/task.output', connections);
    const oldError = watcherError;
    unwatchBackgroundTaskOutput('conn', '/task.output');
    watchBackgroundTaskOutput('conn', '/task.output', connections);
    await vi.advanceTimersByTimeAsync(0);

    finish({ text: 'stale', truncated: false });
    oldError(); // A late old-watcher error cannot tear down the new subscription.
    await vi.advanceTimersByTimeAsync(0);
    changed();
    await vi.advanceTimersByTimeAsync(200);
    expect(sendTo.mock.calls.map((call) => call[2].text)).toEqual(['current', 'current']);
  });

  it('loads a short task that completed before its output file was created', async () => {
    vi.mocked(watch).mockImplementationOnce(() => { throw new Error('ENOENT'); });
    vi.mocked(loadBackgroundTaskOutput).mockResolvedValueOnce({ text: '', truncated: false });
    watchBackgroundTaskOutput('conn', '/task.output', connections);
    await vi.advanceTimersByTimeAsync(500);

    expect(sendTo.mock.calls.map((call) => call[2].text)).toEqual(['', 'current']);
    expect(watch).toHaveBeenCalledTimes(2);
  });
});
