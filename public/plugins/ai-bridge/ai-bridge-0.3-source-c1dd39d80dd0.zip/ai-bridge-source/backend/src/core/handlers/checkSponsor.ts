import { unsupportedServiceHandler } from './unsupportedServices';

export const checkSponsorHandler = unsupportedServiceHandler;
