import { cpSync, existsSync, mkdirSync, readdirSync, writeFileSync } from 'fs';
import { copyFile, mkdir } from 'fs/promises';
import { dirname, join } from 'path';
import { homedir } from 'os';

/**
 * One-time carry-over of data written under the plugin's previous identity.
 *
 * Releases up to 0.39 were published under another plugin ID and stored their data
 * under the names below. AI Bridge installs as a new plugin, so without this the
 * user's settings, saved accounts, harness conversations and chat titles would stay
 * behind. Nothing is moved or deleted: the old files stay where they are.
 */
export const LEGACY_DATA_DIR_NAME = '.claude-code-for-kasif';
const LEGACY_SESSION_TITLES_FILE = '.claude-code-for-kasif-session-titles.json';

/** Written into the new data dir once the import ran, so it never runs again. */
export const LEGACY_IMPORT_MARKER = '.legacy-data-imported';

/**
 * Not carried over: logs, process registries and caches belong to the old
 * installation's own processes (copying the CLI registry would make this backend
 * reclaim the other plugin's children), `mcp/` holds configs pointing at the old
 * plugin's extracted files, and the auth secret is per installation.
 */
const NOT_CARRIED = new Set(['logs', 'cli-registry', 'win-job-cache', 'runtimes', 'bin', 'mcp', 'auth-secret']);

/**
 * Copies every legacy entry the new data dir does not have yet. Must run before
 * anything writes into `~/.ai-bridge` (the logger creates it). Never throws: a
 * failed import only means starting with defaults.
 */
export function importLegacyDataDir(home: string = homedir()): void {
  const legacy = join(home, LEGACY_DATA_DIR_NAME);
  const target = join(home, '.ai-bridge');
  const marker = join(target, LEGACY_IMPORT_MARKER);
  try {
    if (!existsSync(legacy) || existsSync(marker)) return;
    mkdirSync(target, { recursive: true });
    for (const name of readdirSync(legacy)) {
      if (NOT_CARRIED.has(name) || existsSync(join(target, name))) continue;
      cpSync(join(legacy, name), join(target, name), { recursive: true, force: false, preserveTimestamps: true });
    }
    writeFileSync(marker, `${new Date().toISOString()}\n`);
  } catch (err) {
    console.error('[node-backend]', 'Could not import data from the previous installation:', err);
  }
}

/** Copies [legacy] to [target] unless [target] exists or there is nothing to copy. */
async function adoptFile(legacy: string, target: string): Promise<void> {
  if (existsSync(target) || !existsSync(legacy)) return;
  try {
    await mkdir(dirname(target), { recursive: true });
    await copyFile(legacy, target);
  } catch (err) {
    console.error('[node-backend]', `Could not adopt ${legacy}:`, err);
  }
}

/** Project settings saved by the previous installation become this project's settings. */
export function adoptLegacyProjectSettings(projectPath: string): Promise<void> {
  return adoptFile(
    join(projectPath, LEGACY_DATA_DIR_NAME, 'settings.json'),
    join(projectPath, '.ai-bridge', 'settings.json'),
  );
}

/** Chat titles typed in the previous installation, kept next to Claude's transcripts. */
export function adoptLegacySessionTitles(sessionsPath: string, target: string): Promise<void> {
  return adoptFile(join(sessionsPath, LEGACY_SESSION_TITLES_FILE), target);
}
