/** AI Bridge preferences; unlike Claude's persisted schema, a launch can use max. */
export const REASONING_EFFORTS = ['auto', 'low', 'medium', 'high', 'xhigh', 'max'] as const;
export type ReasoningEffort = typeof REASONING_EFFORTS[number];

export function isReasoningEffort(value: unknown): value is ReasoningEffort {
  return typeof value === 'string' && (REASONING_EFFORTS as readonly string[]).includes(value);
}

export interface ReasoningLaunch {
  args: string[];
  env: Record<string, string>;
  fingerprint: string;
}

/** Only launch-affecting values are retained; provider credentials never enter the fingerprint. */
export function reasoningLaunch(
  preference: unknown,
  providerSettings: Record<string, unknown>,
  inheritedEnv: NodeJS.ProcessEnv,
): ReasoningLaunch {
  const effort = isReasoningEffort(preference) ? preference : 'auto';
  if (effort !== 'auto') {
    return {
      args: ['--effort', effort],
      // Claude consults this inherited variable before its session flag. Keep
      // both consistent so a parent shell's effort cannot silently win.
      env: { CLAUDE_CODE_EFFORT_LEVEL: effort },
      fingerprint: JSON.stringify([effort, providerSettings.ultracode === true, providerSettings.disableWorkflows === true]),
    };
  }
  const env = providerSettings.env;
  const providerEnvEffort = env && typeof env === 'object'
    ? (env as Record<string, unknown>).CLAUDE_CODE_EFFORT_LEVEL : undefined;
  return {
    args: [],
    env: {},
    // Auto delegates to the provider. Changes to its launch-time inputs need a
    // new process too: a warm CLI does not reload its active effort from disk.
    fingerprint: JSON.stringify([
      'auto',
      typeof providerSettings.effortLevel === 'string' ? providerSettings.effortLevel : null,
      providerSettings.ultracode === true,
      providerSettings.disableWorkflows === true,
      typeof providerEnvEffort === 'string' ? providerEnvEffort : null,
      inheritedEnv.CLAUDE_CODE_EFFORT_LEVEL ?? null,
      inheritedEnv.CLAUDE_CONFIG_DIR ?? null,
    ]),
  };
}
