import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { existsSync } from 'fs';
import { mkdir, mkdtemp, readFile, rm, writeFile } from 'fs/promises';
import { tmpdir } from 'os';
import { join } from 'path';
import {
  LEGACY_DATA_DIR_NAME,
  LEGACY_IMPORT_MARKER,
  adoptLegacyProjectSettings,
  adoptLegacySessionTitles,
  importLegacyDataDir,
} from '../legacy-data';

describe('legacy data import', () => {
  let home: string;
  let legacy: string;
  let target: string;

  beforeEach(async () => {
    home = await mkdtemp(join(tmpdir(), 'ai-bridge-legacy-'));
    legacy = join(home, LEGACY_DATA_DIR_NAME);
    target = join(home, '.ai-bridge');
    await mkdir(join(legacy, 'accounts'), { recursive: true });
    await mkdir(join(legacy, 'harness-sessions'), { recursive: true });
    await mkdir(join(legacy, 'cli-registry'), { recursive: true });
    await mkdir(join(legacy, 'logs'), { recursive: true });
    await writeFile(join(legacy, 'settings.js'), 'module.exports = { fontSize: 15 };\n');
    await writeFile(join(legacy, 'accounts.json'), '{"current":null}');
    await writeFile(join(legacy, 'accounts', 'acc-1.json'), '{"credentials":"x"}');
    await writeFile(join(legacy, 'harness-sessions', 'h.jsonl'), '{}\n');
    await writeFile(join(legacy, 'cli-registry', '123.json'), '{}');
    await writeFile(join(legacy, 'logs', 'backend.log'), 'old');
    await writeFile(join(legacy, 'auth-secret'), 'old-secret');
  });

  afterEach(async () => {
    await rm(home, { recursive: true, force: true });
  });

  it('copies settings, accounts and conversations but not process state, caches or the auth secret', async () => {
    importLegacyDataDir(home);

    expect(await readFile(join(target, 'settings.js'), 'utf-8')).toContain('fontSize: 15');
    expect(await readFile(join(target, 'accounts', 'acc-1.json'), 'utf-8')).toBe('{"credentials":"x"}');
    expect(existsSync(join(target, 'harness-sessions', 'h.jsonl'))).toBe(true);
    expect(existsSync(join(target, 'cli-registry'))).toBe(false);
    expect(existsSync(join(target, 'logs'))).toBe(false);
    expect(existsSync(join(target, 'auth-secret'))).toBe(false);
    expect(existsSync(join(target, LEGACY_IMPORT_MARKER))).toBe(true);
    // The previous installation keeps its own files.
    expect(await readFile(join(legacy, 'settings.js'), 'utf-8')).toContain('fontSize: 15');
  });

  it('keeps entries the new installation already wrote (the IDE writes its auth secret first)', async () => {
    await mkdir(target, { recursive: true });
    await writeFile(join(target, 'settings.js'), 'module.exports = { fontSize: 20 };\n');

    importLegacyDataDir(home);

    expect(await readFile(join(target, 'settings.js'), 'utf-8')).toContain('fontSize: 20');
    expect(existsSync(join(target, 'accounts.json'))).toBe(true);
  });

  it('runs once: entries removed afterwards are not brought back', async () => {
    importLegacyDataDir(home);
    await rm(join(target, 'accounts.json'));

    importLegacyDataDir(home);

    expect(existsSync(join(target, 'accounts.json'))).toBe(false);
  });

  it('does nothing without a previous installation', async () => {
    await rm(legacy, { recursive: true, force: true });

    importLegacyDataDir(home);

    expect(existsSync(target)).toBe(false);
  });

  it('adopts project settings and chat titles only when the new file is missing', async () => {
    const project = join(home, 'project');
    await mkdir(join(project, LEGACY_DATA_DIR_NAME), { recursive: true });
    await writeFile(join(project, LEGACY_DATA_DIR_NAME, 'settings.json'), '{"reasoningEffort":"high"}');
    await adoptLegacyProjectSettings(project);
    expect(await readFile(join(project, '.ai-bridge', 'settings.json'), 'utf-8')).toBe('{"reasoningEffort":"high"}');

    await writeFile(join(project, LEGACY_DATA_DIR_NAME, 'settings.json'), '{"reasoningEffort":"low"}');
    await adoptLegacyProjectSettings(project);
    expect(await readFile(join(project, '.ai-bridge', 'settings.json'), 'utf-8')).toBe('{"reasoningEffort":"high"}');

    const sessions = join(home, 'sessions');
    await mkdir(sessions);
    await writeFile(join(sessions, `${LEGACY_DATA_DIR_NAME}-session-titles.json`), '{"s1":"Title"}');
    const titles = join(sessions, '.ai-bridge-session-titles.json');
    await adoptLegacySessionTitles(sessions, titles);
    expect(await readFile(titles, 'utf-8')).toBe('{"s1":"Title"}');
  });
});
