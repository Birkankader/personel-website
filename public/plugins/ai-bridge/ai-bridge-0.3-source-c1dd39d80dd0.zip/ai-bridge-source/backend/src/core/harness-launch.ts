import { existsSync } from 'fs';
import { fileURLToPath } from 'url';
import type { AcpHarnessId } from '../shared';

/**
 * How to start `agent-tools.mjs`, the helper that runs ACP harnesses (and the
 * computer-use MCP server) as child processes.
 *
 * The shipped bundle carries it next to backend.mjs, the same way it carries
 * the win32 job wrapper. A backend running from source under tsx (`pnpm dev`)
 * has no bundle beside it, so it runs the TypeScript entry through tsx instead.
 */
export function agentToolsLaunch(): { command: string; args: string[] } {
  const bundled = fileURLToPath(new URL('./agent-tools.mjs', import.meta.url));
  if (existsSync(bundled)) return { command: process.execPath, args: [bundled] };
  const source = fileURLToPath(new URL('../agent-tools/main.ts', import.meta.url));
  let loader = 'tsx/esm';
  try {
    loader = import.meta.resolve('tsx/esm');
  } catch {
    // Resolved relative to the child's cwd then, which works inside the repo.
  }
  return { command: process.execPath, args: ['--import', loader, source] };
}

export interface HarnessLaunch {
  command: string;
  args: string[];
  env: Record<string, string>;
}

/**
 * The ACP bridge command standing in for `claude <claudeArgs>`.
 *
 * Every Claude flag is passed through unchanged, so the bridge reads the same
 * vocabulary the CLI does. The one exception is `--model`: harness model ids
 * can be JSON (`["provider","model"]`), which cmd.exe would mangle on the way
 * to the bridge, so the model travels in the environment instead.
 */
export function harnessLaunch(harness: AcpHarnessId, claudeArgs: readonly string[]): HarnessLaunch {
  const tools = agentToolsLaunch();
  const args: string[] = [];
  const env: Record<string, string> = {};
  for (let i = 0; i < claudeArgs.length; i++) {
    if (claudeArgs[i] === '--model' && i + 1 < claudeArgs.length) {
      env.AI_BRIDGE_HARNESS_MODEL = claudeArgs[i + 1];
      i++;
      continue;
    }
    args.push(claudeArgs[i]);
  }
  const win = process.platform === 'win32';
  return {
    // The win32 spawn paths join tokens with spaces and no quoting (cmd /s /c),
    // so a node or bundle path under "Program Files" must arrive quoted.
    command: win ? winQuote(tools.command) : tools.command,
    args: [...(win ? tools.args.map(winQuote) : tools.args), 'acp-bridge', '--harness', harness, ...args],
    env,
  };
}

function winQuote(token: string): string {
  return /\s/.test(token) && !/^".*"$/.test(token) ? `"${token}"` : token;
}
