import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { mkdtemp, mkdir, writeFile, readFile, rm } from 'fs/promises';
import { join } from 'path';
import { tmpdir } from 'os';

const state = vi.hoisted(() => ({ home: '' }));
vi.mock('os', async (original) => ({ ...await original<typeof import('os')>(), homedir: () => state.home }));

describe('AI Bridge private data isolation', () => {
  beforeEach(async () => { vi.resetModules(); state.home = await mkdtemp(join(tmpdir(), 'ai-bridge-data-')); });
  afterEach(async () => { vi.unstubAllEnvs(); await rm(state.home, { recursive: true, force: true }); });

  it('uses fresh private settings, pins and account registry while leaving upstream and Claude data byte-for-byte unchanged', async () => {
    const old = join(state.home, '.claude-code-gui');
    const fresh = join(state.home, '.ai-bridge');
    const official = join(state.home, '.claude');
    const project = join(state.home, 'project');
    await Promise.all([mkdir(old), mkdir(official), mkdir(join(project, '.claude-code-gui'), { recursive: true })]);
    const protectedFiles = new Map([
      [join(old, 'settings.js'), 'module.exports = { fontSize: 29 };\n'],
      [join(old, 'projects.json'), JSON.stringify({ favoritePaths: ['/upstream'] })],
      [join(old, 'accounts.json'), JSON.stringify({ current: 'upstream', accounts: { upstream: { emailAddress: 'old@example.test' } } })],
      [join(old, 'license.json'), JSON.stringify({ licenseKey: 'upstream-key', status: 'active' })],
      [join(official, 'settings.json'), JSON.stringify({ model: 'provider-model', permissions: { defaultMode: 'plan' } })],
      [join(project, '.claude-code-gui', 'settings.json'), JSON.stringify({ fontSize: 28 })],
    ]);
    await Promise.all([...protectedFiles].map(([path, contents]) => writeFile(path, contents)));
    const settings = await import('../settings');
    const pins = await import('../projects-store');
    const accounts = await import('../account-store');
    const profile = await import('../profile');
    const { getClaudeConfigDir } = await import('../claudeConfigDir');
    expect((await settings.readSettingsFile()).fontSize).not.toBe(29);
    expect(await settings.readProjectSettings(project)).toEqual({});
    expect(await pins.readFavoritePaths()).toEqual([]);
    expect((await accounts.readRegistry()).accounts).toEqual({});
    await settings.saveSettingToFile('fontSize', 16);
    await pins.setProjectFavorite('/ai-bridge-project', true);
    await accounts.writeRegistry({ current: null, accounts: {}, accountPools: [], accountOrder: [] });
    const localProfile = await profile.ensureProfile();
    expect(localProfile.telemetryConsent.status).toBe('denied'); expect(localProfile.announcementsEnabled).toBe(false);
    expect(await readFile(join(fresh, 'settings.js'), 'utf8')).toContain('16');
    expect(JSON.parse(await readFile(join(fresh, 'projects.json'), 'utf8')).favoritePaths).toEqual(['/ai-bridge-project']);
    expect(await readFile(join(fresh, 'accounts.json'), 'utf8')).toContain('accounts');
    expect(getClaudeConfigDir()).toBe(official);
    for (const [path, contents] of protectedFiles) expect(await readFile(path, 'utf8')).toBe(contents);
  });

  it('keeps explicitly configured official Claude data paths unchanged', async () => {
    vi.stubEnv('CLAUDE_CONFIG_DIR', '/official/claude-profile');
    const { getClaudeConfigDir } = await import('../claudeConfigDir');
    expect(getClaudeConfigDir()).toBe('/official/claude-profile');
  });
});
