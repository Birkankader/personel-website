# Claude Code Workspace 0.35 — bağlantı kopmalarında otomatik devam

5 Ekim 2026. Önceki sürüm: 0.34 (canlı feed'de "AI Bridge"). Plugin kimliği `com.birkankader.ai-bridge` değişmedi; ayarlar (`~/.ai-bridge`) ve Claude konuşmaları olduğu gibi kalır, güncelleme yerinde uygulanır.

## 1. "The socket connection was closed unexpectedly" hatası

**Kök neden.** Mesaj, Claude CLI'nın native (Bun) sürümündeki `fetch` hatasıdır. CLI 2.1.220 incelendi: bağlantı akış başlamadan koparsa CLI kendisi 10 kez yeniden dener; akış sırasında koparsa kısmi cevabı kapatıp `API Error: …` metinli sentetik bir hata mesajı (`error: "unknown"` veya `"server_error"`, durum kodu yok) üretir ve turu bitirir. Eklentinin otomatik kurtarması yalnızca durum kodlu 5xx/429 ve bağlam hatalarını tanıyordu; durum kodu olmayan bağlantı hataları hiç yakalanmıyordu, kullanıcı hatayı görüp elle yeniden yazmak zorunda kalıyordu.

**Düzeltme.**
- Ortak sınıflandırıcı (`shared/api-failure.ts`, backend ve arayüzde aynı): ağ (socket kapandı, bağlantı sıfırlandı/kayboldu, akış takıldı, zaman aşımı, `ECONNRESET`, `fetch failed`, `terminated` …), sunucu (5xx, overloaded, `server_error`), istek sınırı (429) ve bağlam hataları. Sertifika/SSL hataları, kimlik doğrulama, fatura ve geçersiz istek hataları yeniden denenmez. Model cevabında geçen hata metinleri, araç hataları ve alt ajan hataları tetiklemez.
- Geçici hatalarda aynı CLI'ya "kaldığın yerden devam et" mesajı gönderilir; bekleme artarak uzar: ağ 2-4-8-16-30-30-30-30 sn (8 deneme, ~2,5 dk), sunucu 5-10-20-40-60-60 sn (6 deneme), istek sınırı sağlayıcının `retry-after` süresi veya 60 sn (4 deneme). Konuşmayı özetleyen `/compact` yalnızca bağlam hatasında kullanılır.
- Kurtarma sürerken kullanıcının sıradaki mesajları beklemede kalır, araya girmez. CLI bağlantı hatasıyla çökerse yeniden başlatılır; bu sırada kırmızı hata banner'ı gösterilmez.
- Denemeler tükenirse yapılandırılmış bir hata kodu (`API_RECOVERY_STOPPED`) gönderilir; görev serbest bırakılır, konuşma korunur.

## 2. Arayüz: hata geldi ama devam ediyor (ekranı kaplamadan)

- API hatası artık "Claude" cevabı gibi büyük bir metin değil, tek satır: **● Bağlantı kesildi (geçici ağ hatası) · Ayrıntılar**. Sağlayıcının özgün metni "Ayrıntılar" ile açılır. Kalıcı/eyleme dönük hatalar (ör. fatura) metniyle gösterilir.
- Cevabın devam edeceği yerde tek satır geri sayım: **Bağlantı koptu — 4 sn içinde otomatik olarak devam edilecek… · deneme 2/8**.
- Devam mesajı kullanıcı balonu olarak değil, ince bir notla görünür: **↻ Yanıt kesildiği yerden sürdürüldü**. Yapışkan başlık açmaz, otomatik kaydırmayı tetiklemez, ↑ geçmişine girmez. Sayfa yenilendiğinde de aynı görünür.
- Ağ uzun süre kapalıysa art arda başarısız denemeler tek satıra katlanır: **· 9 deneme**. Denemeler bittiğinde küçük bir sarı banner: "Bağlantı sorunu sürüyor; otomatik denemeler durduruldu. Konuşmanız korunuyor…" + **Kaldığı yerden devam et** düğmesi + kapatma.
- **Mevcut hata düzeltildi:** akış dışındayken gelen bir hata oturumu "Error" durumunda bırakıyor ve **yazma alanını kilitliyordu** (sohbet değiştirilene kadar yazılamıyordu). Artık yalnızca oturum çakışmasında kilitlenir; diğer hatalarda yazma alanı açık kalır.
- Hata banner'ları başlıklı ve kapatılabilir ("Claude CLI beklenmedik şekilde kapandı" + ayrıntı); "Service error: CLI_EXIT_ERROR - …" ham metni gösterilmez.

## 3. "Düşünüyor" göstergesi

Rastgele fiiller ("Pişiriyor", "Dizginliyor", "Filizlendiriyor"…) ve harf karıştırma efekti kaldırıldı. Yerine yanıp sönen **Düşünüyor…** ve 2 sn'den sonra geçen süre (**12 sn**, **1 dk 05 sn**) geldi; 13 dilde çevrildi. Düşük kaynak modu (varsayılan açık) iki adımlı yanıp sönme kullanır: JCEF paneli her karede değil, döngü başına iki kez yeniden çizilir. Gizli panelde animasyon durur; "hareketi azalt" tercihine uyulur. Not: düşük kaynak modunda eski gösterge hiç hareket etmiyor, sabit bir rastgele fiil gösteriyordu.

## 4. Hızlandırma: yazarken ön ısıtma

Kullanıcı yazma alanına yazmaya başladığında (400 ms sonra) sohbetin CLI'ı arka planda başlatılır; gönderim hazır sürece yazar. Ölçüm (macOS, CLI 2.1.220, 3 SessionStart hook'u, API çağrısı yok): soğuk başlangıç ~340–380 ms, ısınmış süreçte ~20 ms. Windows'ta her CLI başlatma ayrıca `powershell.exe` iş nesnesi sarmalayıcısını ve C# derlemesini (`Add-Type`) çalıştırıyor; orada kazanç daha büyük olmalı, ancak Windows'ta ölçülmedi.

Güvenlik önlemleri: hata gösterilmez (asıl gönderim raporlar); çalışan/başlayan süreç veya kuyruktaki görev varsa hiçbir şey yapmaz; mesaj almayan ön ısıtılmış CLI 10 dk sonra kapatılır; sekme başka sohbete geçince mevcut temizlik mekanizmasıyla kapanır.

Bulunan ve düzeltilen gizli hata: yeni bir oturumun CLI'ı ilk mesajdan önce yeniden başlatılırsa (ör. izin modu değişimi) eklenti `--resume` kullanıyordu. Gerçek CLI'da ölçüldü: mesaj almamış oturum dosya bırakmaz ve `--resume` "No conversation found" ile çıkar. Artık oturum ancak ilk mesaj yazıldıktan sonra devam ettirilebilir sayılıyor.

## 5. Bu sürüme dahil olan 1 Ekim değişiklikleri

1 Ekim'de yapılıp yayınlanmamış kod inceleme düzeltmeleri (10 bulgu: Escape görevi durdurmuyor, reddedilen mesaj taslakta kalıyor, izin/plan soruları doğru sohbette, eski sohbet doğrudan açılıyor, silme/adlandırma doğru dizinde, kaydedilemeyen ayar bildiriliyor, Durdur düğmesi görünür, mod menüsü dar panele sığıyor, çeviriler) ve **ad değişikliği: Claude Code Workspace** (kullanıcı onayıyla).

## Doğrulama

| Kontrol | Önce (0.34 + 1 Ekim) | Sonra |
|---|---|---|
| Backend testleri | 190 dosya, 2.141 geçti, 10 atlandı | 191 dosya, 2.159 geçti, 10 atlandı |
| WebView testleri | 344 dosya, 3.424 geçti | 350 dosya, 3.454 geçti |
| Kotlin testleri | — | 98 dosya, 490 geçti |
| Backend / WebView TypeScript | — | temiz |
| Tarayıcı senaryoları (gerçek backend + sahte CLI) | — | 20/20 |
| Plugin Verifier | — | 6/6 Compatible (IC 2023.1, 2023.2, 2023.3, 2024.2.6; IU 2026.1; IU 2026.2 EAP). 2023.1: 0.34'teki aynı 1 deprecated API uyarısı |

- **Hata yeniden üretildi:** yeni socket testleri eski `api-recovery.ts` ile çalıştırıldı; 2 test kırmızı (kuyruktaki mesaj araya giriyor, çökmede kırmızı banner). Yeni kodla yeşil.
- **Tarayıcı:** izole HOME, dış ağ kapalı backend ve socket hatası üreten sahte CLI ile headless Chromium (440 ve 320 px, açık ve koyu tema). Ön ısıtma (yazarken tek başlatma, gönderimde aynı süreç), "Düşünüyor…" + süre, kısmi cevap → tek satır hata → geri sayım → devam notu → kalan cevap, ayrıntı aç/kapa, yenilemede aynı görünüm, 8 başarısız denemede tek satır "· 9 deneme" + banner, yazma alanının açık kalması, banner kapatma. Ekran görüntüleri: `screens/`, makine çıktısı: `ui-results.json`.

## Bilinen sınırlar

- Gerçek Windows makinesinde ve gerçek JCEF/IDE içinde çalıştırılmadı; gerçek Claude API'sine istek gönderilmedi (sahte CLI). CLI davranışı 2.1.220 ikili dosyası incelenerek ve yerel çalıştırmayla doğrulandı.
- Ağ ~2,5 dk'dan uzun kesik kalırsa otomatik denemeler durur; banner'daki düğmeyle devam edilir.
- Devam mesajı CLI transkriptinde normal bir kullanıcı mesajı olarak durur; terminalden `claude --resume` ile açılırsa "Continue from where you left off. (…interrupted by a temporary connection or API error.)" görünür.
- Ön ısıtma, SessionStart hook'larını ve CLI başlangıç işlerini mesaj gönderilmeden önce çalıştırır; yazılıp gönderilmeyen taslaklar için de bir CLI süreci açılmış olur (10 dk sonra kapanır).

## Yayın notu

- Gradle `verifyPlugin`, 2026.2 EAP snapshot'ı JetBrains deposundan artık çözümleyemediği için durdu; aynı 6 IDE'lik matris Plugin Verifier 1.410 CLI ile yerel kopyalara karşı çalıştırıldı (`run-plugin-verifier.sh`, raporlar `plugin-verifier/`). Bu sırada Gradle, IU 2026.1 dağıtımını (~1,5 GB) indirdi.
- Yayınlanan dosyalar, denetlenen dosyaların aynısıdır (yeniden derlenmedi): `check_release.py` yerel 17/17, sitenin feed birleştirici testi 3/3.
- **Canlı:** web sitesi commit `0d52153` ("Publish AI Bridge plugin 0.35"). Netlify yayınından sonra `check_release.py --live` 10/10: birleşik feed ve eski `/plugins/ai-bridge/updatePlugins.xml` adresi 0.35'i listeliyor, canlı plugin/kaynak ZIP SHA-256 değerleri yereldekiyle aynı, 0.34 arşivi değişmeden iniyor, Arcade Machine 0.4.4 ve Haftanın Seyirliği 0.3.2 yerinde.

## Kurulum

Depoyu ekli IDE'ler güncellemeyi Settings → Plugins'te görür (veya otomatik indirir); IDE yeniden başlatılınca uygulanır. Plugin SHA-256: `066293b2dfa69fd1583ece7cee0fabb8cde38de3ee9e2da428d192486c3e3d7b`, kaynak: `1b70fddb40a2de0ece2765ab22ce7bd48bba45e67616046a9266098e7460ac01`.

Bu sürümde yapılan kod değişikliklerinin yaması: `changes-0.35.patch` (yalnız bu çalışmanın farkları; 1 Ekim değişiklikleri hariç).
