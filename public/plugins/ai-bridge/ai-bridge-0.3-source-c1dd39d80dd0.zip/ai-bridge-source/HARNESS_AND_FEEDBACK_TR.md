# Geri bildirim düzeltmeleri, OpenCode / DeepSeek Harness ve computer use

16 Ekim 2026. Temel: 0.39 kaynağı. Sürüm numarası değiştirilmedi. Ayarlar (`~/.ai-bridge`) ve mevcut Claude konuşmaları olduğu gibi kalır.

Bu not beş isteği kapsıyor:
- yavaşlık / düşünme düzeyi,
- sekme değişiminden sonra pikselleşme,
- OpenCode ve DeepSeek Harness desteği,
- computer use,
- Çince/Korece temizliği.

## 1. "Biraz yavaş": düşünme düzeyi gerçekten uygulanıyor mu?

**Ölçüm yöntemi.** Kurulu Claude CLI 2.1.300 yerel bir sahte API sunucusuna yönlendirildi (`ANTHROPIC_BASE_URL`). CLI'ın gönderdiği her `/v1/messages` isteğinin gövdesindeki `output_config.effort` değeri okundu. Eklentinin kullandığı `-p` kipi kullanıldı. Ücretli istek ve model üretimi yok.

| Durum | API'ye giden düzey |
|---|---|
| Hiçbir seçim yok (eklentide **Otomatik**) | `medium` |
| `--effort low` | `low` |
| `CLAUDE_CODE_EFFORT_LEVEL=high` | `high` |
| `--effort max` + ortamda `CLAUDE_CODE_EFFORT_LEVEL=low` | `low`. Ortam değişkeni bayrağı geçersiz kılıyor. |
| Haiku + `--effort low` | `low` |
| Claude `settings.json`'da `effortLevel: "low"`, eklentide **Maks.** seçili | `max` |
| Claude `settings.json`'da `effortLevel: "low"`, eklentide **Otomatik** | `medium`. Bu CLI sürümü `-p` kipinde dosyadaki değeri uygulamadı. |

Bütün isteklerde `thinking: {type: "adaptive"}` vardı.

**Sonuç.** Ayar çalışıyor: seçilen düzey API'ye aynen gidiyor.

Eklenti açık bir seçimde hem `--effort` bayrağını hem de aynı değerli `CLAUDE_CODE_EFFORT_LEVEL` değişkenini veriyor. Bu bilinçli bir tercih: tabloya göre ortam değişkeni bayrağı geçersiz kılıyor, bu yüzden yalnız bayrak yetmez. Kullanıcının ortamında kalmış bir değer seçimi gölgelemiyor.

**Yavaşlık için öneri.** Otomatik, CLI'ın varsayılanı olan `medium` anlamına geliyor. Claude ayar dosyasına `effortLevel: "low"` yazmak eklenti içinde etki etmiyor (son satır). Daha hızlı yanıt isteyen kullanıcı model menüsündeki **Düşünme düzeyi** bölümünden **Düşük**'ü açıkça seçmeli. Kod değişikliği gerekmedi.

## 2. Sekme değişimi / simge durumundan dönüşte gecikme ve pikselleşme

**Kök neden.** Panel ekran dışı (OSR) JCEF ile çiziliyor. Sekme gizlenip geri geldiğinde CEF'in elindeki son kare eski boyutta veya eski ölçek katsayısında olabiliyor. Swing bu kareyi yeni alana gererek gösteriyor; kullanıcının gördüğü bulanık, pikselli yazı bu. Mevcut "repaint nudge" düzeneği 2,5 sn aralıklı çalıştığından kare ancak bir sonraki dürtüde düzeliyordu.

**Düzeltme.**
- Yeni `PresentationRefreshListener` (Kotlin) paneli yeni bir tam kare gerektiren anları yakalıyor:
  - pencerenin simge durumundan çıkması (`windowDeiconified`, durum değişimi),
  - pencerenin etkinleşmesi,
  - bileşenin görünür olması veya yeniden boyutlanması,
  - pencerenin ölçek katsayısı farklı başka bir ekrana taşınması (`graphicsConfiguration`).
- Bu anlarda `ClaudeCodePanel` hemen bir yeniden çizim, ardından 80, 300 ve 800 ms'de üç yeniden çizim daha ister. Bunlar mevcut hız sınırına tabidir ve diğer kaynaklarla birleştirilir.
- 1,2 sn'lik bu pencerede her yeniden çizimden önce CEF'e ekran bilgisini (`notifyScreenInfoChanged`, varsa) ve görünüm boyutunu (`wasResized`) yeniden okutuluyor. Böylece eski boyutlu kare gerilmek yerine doğru boyutta yeniden üretiliyor.
- Sayfa tarafında `RepaintNudgeBridge` artık şu olaylarda da görünürlük bildiriyor: `visibilitychange`, `resize`, `focus` ve panelin kendi görünürlük olayı.
- WebView'de mesaj listesi görünürlüğe geçişi ertelenebilir bir güncelleme olarak işliyor (`useDeferredPageActivity` → `useDeferredValue`). Panel geri geldiğinde ilk kare hemen çiziliyor; ağır liste yeniden çizimi arayüzü bloke etmeden arkadan geliyor.

## 3. Yeni: OpenCode ve DeepSeek Harness

**Nerede.** Ayarlar → Model → **Agent harness**: Claude Code (varsayılan), OpenCode, DeepSeek Harness. Seçim **yeni** sohbetleri etkiler. Mevcut sohbet hangi ajanla başladıysa onunla devam eder; kayıtlı sohbet listesinde ikisi tek sırada, tarihe göre karışık görünür.

**Nasıl çalışıyor** (CLAUDE.md'deki CLI eşdeğerliği ilkesine uygun):
- Her iki araç da resmi **ACP** (Agent Client Protocol, stdio üzerinden JSON-RPC) komutlarıyla başlatılır:
  - OpenCode: `opencode acp`
  - DeepSeek Harness: `dsh --profile acp`
- Arka uçta yeni bir ara süreç (`agent-tools.mjs acp-bridge`) ACP'yi, eklentinin zaten konuştuğu Claude stream-json biçimine çevirir. Böylece sohbet ekranı, araç kartları, izin istekleri, durdurma ve kuyruk Claude ile aynı kodla çalışır. Bir SDK'ya veya belgelenmemiş bir protokole bağımlılık yok.
- Model menüsü harness'ın kendi bildirdiği model listesini gösterir. Düşünme düzeyleri modelin bildirdiği kadardır (ör. DeepSeek'te `low/high/max`).
  - Ayarlardaki "Varsayılan model" satırı ve "seçimi varsayılana eşitle" davranışı yalnız Claude Code'da geçerlidir; harness seçiliyken gizlenir, model sohbet başına seçilir.
  - OpenCode son kullanılan modeli kendisi hatırlar.
- **İzinler (OpenCode).** Eklenti `OPENCODE_CONFIG_CONTENT` (OpenCode'un belgelenmiş satır içi yapılandırması) ile varsayılan olarak her aracı `ask` yapar. Yalnız okuma araçları serbesttir: `read`, `glob`, `grep`, `list`, `todoread`, `todowrite`. Böylece dosya yazma ve komut çalıştırma eklentinin izin kartından geçer. Kullanıcının kendi `OPENCODE_CONFIG_CONTENT` içindeki `permission` ayarları önceliklidir.
- **Kayıtlar.** Harness sohbetlerinin dökümleri `~/.ai-bridge/harness-sessions/` altında, Claude'un JSONL biçiminde tutulur. Sohbet geçmişi, yeniden açma, adlandırma ve silme bu sayede aynı kodla çalışır.
- **Kurulum.** Araçlar kullanıcının kendisi tarafından kurulur. Bulunamazsa ekranda kurulum komutu gösterilir:
  - `npm install -g @opencode/cli`
  - `npm install -g @deepseek-ai/dsh`
  - PATH dışındaki bir kurulum için `AI_BRIDGE_HARNESS_COMMAND` (JSON dizi) kullanılabilir.
- **Windows.** npm araçları `.cmd` olarak kurduğu için başlatma kabuk üzerinden, Node 24'ün kabul ettiği tek satır biçiminde yapılır.

**Harness sohbetlerinde olmayanlar (açık mesajla reddedilir):**
- dallandırma (fork),
- dosya geri sarma (rewind).

Bunlar Claude CLI'ın kendi kontrol noktalarına dayanıyor; başka bir ajanın oturumunda anlamları yok. Dosya geri sarma bu turda eklendi; önceden Claude'a başka ajanın oturum kimliği gidip anlaşılmaz bir hata dönüyordu.

**Paketleme.** `agent-tools.mjs` IDE paketine eklendi ve ilk açılışta diske çıkarılıyor.

Bu sırada bulunan eski bir hata da düzeltildi: Windows'ta Bash aracının çıktısını UTF-8 yapan `win-bash-env.sh` pakete giriyordu ama IDE'de diske hiç çıkarılmıyordu. Bu yüzden Türkçe karakter bozulmasını önleyen bu ayar IDE kurulumlarında hiç devreye girmiyordu. Artık çıkarılıyor.

## 4. Yeni (deneysel): computer use

**Nerede.** Ayarlar → Genel → **Computer use (experimental)**. Varsayılan kapalı. Açılıp kapatılması sonraki mesajda uygulanır; sohbet `--resume` ile yeni süreçte devam eder.

**Nasıl çalışıyor.**
- Eklenti, ekranı ve fare/klavyeyi süren yerel bir **MCP sunucusu** (`ai-bridge-computer-use`, stdio) içerir.
- Claude'a CLI'ın belgelenmiş `--mcp-config` bayrağıyla verilir. Yapılandırma `~/.ai-bridge/mcp/computer-use.json` dosyasına yazılır; kullanıcının kendi MCP ayarlarına dokunulmaz.
- OpenCode ve DeepSeek Harness'a aynı sunucu ACP oturumunun `mcpServers` alanıyla verilir.

**Araçlar (13).** Hepsi ekran görüntüsünün piksel koordinatlarıyla çalışır:
- `screenshot`: birincil ekran, 1280×800'e sığacak şekilde ölçeklenir,
- `cursor_position`, `mouse_move`,
- `left_click`, `right_click`, `middle_click`, `double_click`, `triple_click`, `left_click_drag`,
- `scroll`, `type`, `key`, `wait`.

**Sürücüler.**
- **Windows:** Tek bir uzun ömürlü PowerShell, user32 köprüsünü bir kez derler. Süreç DPI farkındadır, ölçekli ekranlarda koordinatlar doğrudur.
- **macOS:** `screencapture` ve JXA (CoreGraphics ile System Events). Ekran Kaydı ve Erişilebilirlik izni gerekir.
- **Linux (X11):** `xdotool`. Ekran görüntüsü için `import`, `gnome-screenshot` veya `grim` kullanılır; ölçekleme için ImageMagick.

**İzinler.** Araçlar sohbetin izin moduna tabidir: varsayılan modda her işlem izin kartıyla sorulur. "İzinleri atla" modunda sormadan çalışır; bu özellik açıkken o mod dikkatle kullanılmalı.

## 5. Çince / Korece / Japonca temizliği

Kullanıcı kararlarına göre:
- **Arayüz dilleri kaldırıldı:** Korece, Çince (Basitleştirilmiş ve Geleneksel), Japonca. Kalan 9 dil: ar, de, en, es, fa, fr, pt, ru, tr. Kayıtlı dili bunlardan biri olan kullanıcı İngilizceye düşer.
- **CLI başlatıcısının (`ccg`) Korece dil dosyası** ve bu dillerdeki dokümanlar kaldırıldı.
- **Korece geliştirici dokümanları İngilizceye çevrildi.** Bunlara CLAUDE.md dosyaları ve `docs/` dahil.
- **Kod yorumları ve metinler İngilizceye çevrildi.** Kapsam: backend, webview, Kotlin, `build.gradle.kts` ve `scripts/build.sh`.

İlk taramada 373 dosyada CJK karakter vardı. Son taramada kaynakta (`node_modules`, `.git`, `.gradle` dışında her yer) **0**.

`webview/dist` içindeki 8 derleme dosyasında hâlâ CJK karakter geçiyor. Bunlar bizim kodumuz değil, sözdizimi renklendiricisinin (Shiki) dil tanımları:
- Wenyan dili,
- Gherkin'in çok dilli anahtar kelimeleri,
- HTML/Swift/Julia/Less dilbilgilerindeki Unicode aralıkları,
- HTML varlık çözümleme tablosu.

Bunları silmek o dillerin renklendirmesini bozar; bilinçli olarak bırakıldı.

## Doğrulama

| Kontrol | Sonuç |
|---|---|
| Backend TypeScript (`be-lint`) / WebView TypeScript (`wv-lint`) | temiz |
| Backend / WebView derleme (`be-build`, `wv-build`) | başarılı |
| Backend testleri | 195 dosya: 2.185 geçti, 38 atlandı, 9 başarısız. Başarısızların hepsi önceden var olan Windows ortamı testleri (bkz. Bilinen sınırlar). |
| WebView testleri | 358 dosya, 3.486 geçti |
| Düşünme düzeyi (gerçek CLI 2.1.300 + sahte API) | 9 senaryo, yukarıdaki tablo |
| OpenCode uçtan uca (gerçek `opencode` 2.0.28, ücretsiz modeller) | Model listesi 0,75 sn'de 11 model. Metin yanıtı ~8 sn. Araç kartları geldi. İzin isteği eklentinin kartına düştü. Computer use MCP bağlandı (13 araç), `cursor_position` çağrısı `deepseek-v4.1-flash-free` modeliyle çalıştı. |
| DeepSeek Harness (gerçek `dsh` 0.2.0-rc.2) | El sıkışma ve model listesi: 2,25 sn'de 3 model (`low/high/max`). API ücretli olduğu için mesaj gönderilmedi. |

## Bilinen sınırlar

- **Kotlin değişiklikleri derlenmedi ve IDE içinde denenmedi.**
  - Değişen dosyalar: pikselleşme düzeltmesi, `PresentationRefreshListener`, paket çıkarma.
  - Engel: bu makinede JDK 17 ve IntelliJ Platform Gradle eklentisi 2.10.4 yok.
  - Plugin Verifier da çalıştırılmadı.
  - Yayından önce `bash ./scripts/build.sh test` ve `dist` mutlaka çalıştırılmalı.
- **Pikselleşme düzeltmesi gerçek JCEF'te görsel olarak doğrulanmadı.** `notifyScreenInfoChanged` eski JCEF sürümlerinde yoksa yalnız `wasResized` uygulanır.
- **DeepSeek Harness bir aday sürüm (0.2.0-rc.2).** Yalnız bağlantı ve model listesi doğrulandı; gerçek bir sohbet turu denenmedi.
- **Computer use deneysel.**
  - Bu makinede gerçek masaüstünde yalnız `cursor_position` çağrıldı. Kullanıcının faresini oynatmamak için tıklama ve yazma gerçek masaüstünde denenmedi. Koordinat dönüşümü, sürükleme, tuş eşlemesi ve girdi doğrulamaları sahte sürücüyle birim testlerinde kapsandı.
  - macOS ve Linux sürücüleri gerçek makinede denenmedi.
  - Yalnız birincil ekran desteklenir.
  - Wayland'de `grim` ile ekran görüntüsü alınabilir ama `xdotool` girdisi çalışmaz.
- **Harness sohbetlerinde dallandırma ve dosya geri sarma yok** (bkz. bölüm 3).
- **Önceden var olan 9 backend testi bu Windows makinesinde başarısız.**
  - İlgili kod orijinal 0.39 ile aynı ve Windows'a özgü ortam varsayımlarına dayanıyor: sembolik bağlantı izni, `chmod`, job-object sarmalayıcı, dosya izleyici zamanlaması.
  - Bu değişikliklerle ilgileri yok.
