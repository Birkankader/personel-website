# Bağlam kullanımı ve ardışık mesajlar — 0.1

9 Eylül 2026. İncelenen geri bildirim: bağlamın hızla dolması ve üçüncü mesajın dikkate alınmaması.

Kullanıcının Windows/IntelliJ ortamındaki olayın kesin nedeni henüz doğrulanmadı. Aşağıdaki hatalar kaynak kodda ve kontrollü testlerde üretildi. Sahte CLI testleri mesajların iletimini ve arayüzde gösterilmesini doğrular; gerçek modelin talimatları anlamsal olarak takip ettiğini kanıtlamaz.

## Düzeltilen davranışlar

- **Bağlam yüzdesi:** Önceki hesap, model kapasitesinden azami yanıt boyutunu ve ayrıca 13.000 token düşürüyordu. Örneğin 200.000 kapasiteli, 64.000 azami yanıtlı modelde 100.000 giriş tokenı %81 görünüyordu; artık %50 görünür. Son ana model isteğinin giriş ve önbellek tokenları kullanılır. Üretilen yanıt tokenları, alt ajan kullanımı ve kümülatif faturalama değerleri bu yüzdeye eklenmez. Boş sohbet yüklenirken önceki sayaç temizlenir. Hesap [Claude Code durum satırı tanımıyla](https://code.claude.com/docs/en/statusline#context-window-fields) uyumludur.
- **Dosya önizlemesi:** Eklenti dosya ve klasör eklerinde yalnızca yolları gönderir. Önizleme artık tüm dosya boyutunu anında gönderilen bağlama eklemez. Dosya boyutu, Claude tamamını sonradan okursa oluşabilecek ayrı bir tahmin olarak gösterilir. Seçili kod metni, editör seçeneği açıkken taslağa dahil olur.
- **Yeni sohbette hızlı mesajlar:** Arayüz yönlendirmesi tamamlanmadan art arda üç gönderim eski kodda üç ayrı sohbet kimliği üretebiliyordu. Kimlik ilk gönderimde hemen ayrılır ve sonraki gönderimler aynı oturumu kullanır. Bu senaryo normal klavye gönderiminden daha sıkışık bir zamanlamadır; kullanıcıdaki kaybın kesin nedeni olduğu iddia edilmez.
- **Gereksiz bekleme satırları:** Aynı arayüz güncellemesinden önce tetiklenen üç mesaj üç etkin asistan satırı oluşturabiliyordu. Eşzamanlı akış kaydı artık tek etkin bekleme satırını korur; üç ayrı yanıt ve kullanıcı mesajı saklanır.
- **Seçili kodun kaybolması:** Tekrarı önleyen kayıt sohbet/proje ile sınırlandı. Reddedilen gönderim, sonradan bildirilen gönderim hatası ve iptal sonrasında seçim tekrar gönderilebilir. Eski sohbetten geciken onay yeni sohbetin kaydını değiştiremez. Henüz başlamamış kuyruk mesajlarında seçim ihtiyatlı biçimde korunur; bu durumda tekrar edebilir, ancak iptal nedeniyle sonraki talimatın bağlamı sessizce eksilmez.
- **CLI yazma ve kapanış:** Mesaj yazımı pipe callback'ini bekler; backpressure normal kabul edilir, yazma hatası görünür olur. Takılan yazma 30 saniyede sonlandırılır ve otomatik tekrar gönderilmez. Çıkmış ancak çıktı kanalları henüz kapanmamış süreç yeniden kullanılmaz; kapanış en fazla 5 saniye beklenir. Geciken eski kapanış yeni süreci silemez. Normal üç ardışık ve üç kuyruklu backend gönderimi başlangıçta da geçiyordu; yeni korumalar hata/kapanış senaryolarını düzeltir.
- **Tur sonuna bekletilen mesajlar:** Kullanıcı mesajı yanıtından önce gösterilir. Çok hızlı tamamlanan görev için sonradan akış başlatma olayı gönderilmez; bitmiş yanıtta bekleme göstergesi yeniden açılmaz. Bu sıra ayrı bir regresyon testiyle doğrulandı.

## Gönderilen içerik

Gerçek stdin biçimiyle yapılan kontrollü testte `selam`, `ikinci`, `üçüncü` metinleri sırasıyla 5, 6 ve 10 UTF-8 bayt olarak birer kez gönderildi. Sohbet geçmişi veya sistem metni her mesajda yeniden eklenmedi. Dosya/klasör yolları ve görsel yalnızca eklendikleri mesajda bulundu. Değişmeyen seçili kodun olağan ardışık gönderimde tekrar eklenmediği doğrulandı.

Bu çalışma gerçek Claude oturumlarının token tüketimini ölçmedi. Dosya okumaları, araç çıktıları, proje talimatları ve seçili kod gerçek bağlama eklenebilir. Taslak önizlemesi yaklaşık gönderim boyutudur; sohbetin mevcut bağlam yüzdesi değildir.

## Gerçek sohbet arayüzüyle doğrulama

macOS Chrome üzerinde derlenmiş WebView/backend ve izole sahte CLI kullanıldı. Harici trafik engellendi; gerçek sağlayıcıya istek atılmadı.

| Akış | Gözlenen sonuç |
|---|---|
| Her yanıtı bekleyerek üç mesaj | 3 gönderim, aynı oturumda 3 CLI girdisi, sırayla 3 görünür yanıt |
| İlk yanıt sürerken üç mesaj | Yanıttan önce üç kullanıcı mesajı görünür; 1 çalışan + 2 bekleyen görev; ardından sırayla 3 görünür yanıt |
| Her iki akış | Birer sohbet süreci; fazladan START_SESSION, STOP_SESSION veya MCP sorgusu yok |
| 100.000 giriş / 200.000 kapasite, ayrıca 20.000 yanıt tokenı | Her iki akışta %50 |
| Tarayıcı hataları / 50 ms üzeri JS görevleri | Bu kontrollü koşuda 0 / 0 |

İlk tarayıcı denemesinde test sürücüsünün çakışan koşuları yinelenen yazı ve durdurma tıklaması üretti. O koşu ürün sonucu sayılmadı; yeni tarayıcı/backend ile tek koşuda yinelenme veya durdurma görülmedi. İlk mesajın metin eşleşmesi iki yerde bulunur: sekme başlığında ve tek kullanıcı mesajında; yinelenen sohbet satırı değildir.

Arayüz kanıtları `../validation/windows-first-send-verification/three-prompts/` altındadır. Son tur-sonu mesaj düzeltmesi bu arayüz koşusundan sonra eklendi ve ayrı backend regresyonuyla doğrulandı; sıradan üç mesaj akışını değiştirmez.

## Son kaynak üzerindeki kontroller

| Kontrol | Sonuç |
|---|---|
| Backend tam paket | 178 dosya; 2.015 başarılı, mevcut 8 atlanan test |
| WebView tam paket | 340 dosya; 3.362 başarılı |
| Backend ve WebView TypeScript kontrolleri | Başarılı |
| Üretim dağıtımı (`dist`) ve sürüm eşitliği | Başarılı; tüm bileşenler 0.1 |
| Paket CRC, kimlik/yayıncı, gömülü backend ve içerik özeti | Başarılı |
| JetBrains Plugin Verifier | IC 242.26775.15 ve IU 262.8117.19: Compatible |
| `git diff --check` | Başarılı |

Önce/sonra regresyonları bağlam hesabında 6 hatalı beklentiyi, hızlı yeni oturum kimliklerini, fazla bekleme satırlarını, seçim tekrarını, üçüncü pipe yazma hatasını, süreç çıkış/kapanış sırasını ve bekletilen mesajın erken sonucunu kapsar. Yeni testlerde gerçek sağlayıcı kullanılmadı. Native repaint kodu bu çalışmada değiştirilmedi.

Verifier mevcut iki deneysel `FileEditorManager.requestOpenFile` kullanımı için uyarı verdi; uyumluluk hatası vermedi. Bu statik kontroller gerçek Windows IntelliJ IDEA 2026.1 çalıştırması değildir.

Kurulum paketi SHA-256: `acdd6427b0791504013aa60faaf3369ba52a08bc9a521e789139841c3e5e7787`.

Paket içerik sürümü (`bundleRevision`): `be087678e5061f2fe7cc907bdc90c46b8603e0b60cdf108570a9164c12410493`. Aynı 0.1 sürümü yeniden kurulsa da yeni backend/arayüz bu içerik özetiyle ayrılır.

Son kontrol logları `../validation/context-prompt-verification/`, hata ve kapanış regresyonları `../validation/windows-send-freeze/` altındadır. Önceki paket `../output/archive/0.1-first-send/` altında saklandı. IDE'ye kurulum veya Marketplace yayını yapılmadı.
