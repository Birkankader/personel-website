# AGENTS.md

This file provides guidance to AI coding agents when working with code in this repository.

## Definition of the Term "Agent"

In this document, **"Agent"** means a general-purpose AI coding agent that is not tied to any specific tool.
Representative examples include Claude Code (Anthropic), Codex (OpenAI), Gemini CLI (Google), Cline, and others.
This document is written so that it can be used as a reference from any agent tool.

## Project Overview

A Claude Code GUI plugin for JetBrains IDEs. The goal is to provide the same UX as Cursor's Claude Code extension inside the JetBrains environment.

## Architecture

Consists of 3 layers:

1. **Node.js Backend (the only backend)** - Runs the Agent CLI, session/settings/file I/O, WebSocket server
2. **WebView UI** - Chat/session/diff card UI, a faithful implementation of the Cursor UX (communicates with Node.js over WebSocket)
3. **Bridge (per-environment adapter)** - BrowserBridge (browser) / KotlinBridge (JetBrains IDE native APIs)

## Implementation Criteria

When implementation options diverge, Cursor UX is the primary criterion. Priority: Cursor UX > JetBrains conventions

## Technical Constraints

- The WebView uses JCEF (Swing UI is forbidden, except for permission dialogs)
- The agent runtime is separated into a process outside the IDE
- Event-driven, streaming-first design

## Single-Backend Architecture

Regardless of the client's runtime environment, the WebView always communicates with the Node.js backend over WebSocket.

| Client environment | Bootstrap | Backend | Bridge |
|----------------|-----------|--------|--------|
| Browser | Vite dev server | Node.js WebSocket server | BrowserBridge (no-op, etc.) |
| JetBrains IDE | Kotlin spawns Node.js → localhost:PORT | Node.js WebSocket server | KotlinBridge (IDE API) |

**Both environments are environments where the real product runs.** The browser environment is not development-only; it is a standalone distribution target.

### Core Principles

- **Node.js is the only backend**: All business logic (sessions, settings, Agent CLI, file I/O) is handled in Node.js
- **Bridge is an ORM adapter**: Only features that must differ per environment (editor tabs, diff viewer, etc.) are abstracted behind the Bridge interface
- **Kotlin is an implementation that sits behind Node.js**: The WebView does not communicate with Kotlin directly. When Node.js needs an IDE-native feature, it calls the Bridge (Kotlin)

### No Code Duplication

Since Node.js is the only backend, there is no need for dual implementations of business logic. Do not implement business logic in Kotlin.

## Original Data Preservation Principle

The original data structures produced by the Agent CLI (JSONL entries, session metadata, etc.) must **keep their structure as-is all the way to the WebView end**.

### Rules

1. **No renaming of keys/values**: Do not rename original field names in intermediate layers. (e.g. `title` → ~~`firstPrompt`~~, `createdAt` → ~~`created`~~)
2. **No intermediate filtering**: The intermediate forwarding layer (the Node.js backend) must not filter or drop original data. Filtering is the responsibility of the WebView, the final consumer.
3. **No information loss**: Do not remove fields from the forwarding path, even if the current UI does not use them. Preserve their potential for future use.
4. **Data type conversion is allowed**: Type mapping between languages (e.g. JSON → Kotlin data class → JSON) is allowed, but key names and structure must not change in the process.

### Rationale

- The project does not yet make full use of the Agent's original data. If an intermediate layer edits the information, it later causes unnecessary cost to re-learn the original structure.
- **Looking at the data in any layer, you must be able to tell "what the Agent original looks like", and you must be able to trust that content.**

### Scope

| Layer | Role | Allowed | Not allowed |
|------|------|-------------|---------------|
| Node.js backend (dev-bridge) | Forward the original | Type conversion, serialization | Field renaming, filtering, omission |
| WebView (React) | Final consumer | Filtering, sorting, processing for display | — |

## Consistent Naming Principle

Names that refer to the same purpose and the same action use **the same word** consistently, regardless of layer and language.

### Rules

1. **One word per action.** Use the same verb everywhere for the same operation — method names, IPC message types, variable names, RPC handler names, and so on. When reading along a pipeline, a change of word leads readers to mistake it for a different operation. (e.g. ~~`create()` → `NEW_SESSION`~~ → `create()` → `CREATE_SESSION`)
2. **Different words for different actions.** Operations with different meanings, such as "reset the session in the current tab" and "open a new editor tab", must not share the same name.
3. **Use clear verbs.** Use CRUD verbs (`create`, `get`, `update`, `delete`) or clear action verbs (`load`, `clear`, `open`, `stop`). Avoid ambiguous words such as `new` and `change`.

## State Machine

Idle → Streaming → Waiting Permission → Has Diff → Error

## UI Term Definitions

| Term | Description |
|------|------|
| **Top bar** | The area element at the top of the chat screen that contains the new tab button and the session dropdown toggle button |
| **Session dropdown toggle button** | The dropdown toggle button on the left side of the top bar that shows the current session's title |
| **Session dropdown** | The dropdown menu that opens when the session dropdown toggle button is clicked |
| **New tab button** | The plus button on the right side of the top bar. When clicked, it opens a new Agent editor tab in the IDE |
| **Initialized session** | The state in which not even the first message has been started yet, so no session has been created |

## Build Commands

All builds are run through `bash ./scripts/build.sh <command>`. Do not compose `cd`, `pnpm`, or `./gradlew` commands directly.

> **Important**: Run `bash ./scripts/build.sh -h` to see the full list of commands.

### Main Commands

| Command | Purpose |
|------|------|
| `bash ./scripts/build.sh be-build` | Build the backend |
| `bash ./scripts/build.sh wv-build` | Build the webview |
| `bash ./scripts/build.sh build` | Build the plugin |
| `bash ./scripts/build.sh full-build` | Full build (be + wv + plugin) |
| `bash ./scripts/build.sh dist` | Build for distribution (be + wv + buildPlugin) |
| `bash ./scripts/build.sh run-ide` | Run the IDE for testing |
| `bash ./scripts/build.sh clear-cache` | Reset build caches/outputs |
| `bash ./scripts/build.sh wv-lint` | WebView TypeScript check |
| `bash ./scripts/build.sh wv-test` | WebView tests |
| `bash ./scripts/build.sh all` | Full build + run the IDE |

### Agent Behavior Guidelines

1. **When building/testing**: always use `bash ./scripts/build.sh`
2. **No `cd`**: the script handles paths internally with `pnpm -C` and `gradlew -p`
3. **When a new command is needed**: propose adding a case to `scripts/build.sh`
4. **Prefix every shell command with `bash`**: e.g. `bash ./scripts/build.sh build`, `bash -c "ls -la"`, etc.

## Local Skills

Project-local skills live in `.claude/skills/`. Prefer **project-local skills** over oh-my-claudecode skills.

| Skill | File path | Trigger keywords |
|------|-----------|--------------|
| `/deploy` | `.claude/skills/deploy.md` | "deploy", "release", "publish", "publish to marketplace", "yayınla", "sürüm çıkar" |
| `/build` | `.claude/skills/build.md` | "build", "compile", "derle" |
| `/precheck` | `.claude/skills/precheck.md` | "precheck", "pre-deploy check", "pre-release review", "ön kontrol" |

## JetBrains SDK API Usage Cautions

When publishing to the JetBrains Marketplace, the **Plugin Verifier** automatically validates API usage.

- Using a **Deprecated API** → warning
- Using an **Internal API** → error, publication may be rejected
- Be careful with classes that may be internal/deprecated, such as `EnvironmentUtil`
- Never use `@ApiStatus.Internal` or classes inside `impl` packages
- Before publishing, always build with `bash ./scripts/build.sh dist` and check the Plugin Verifier results

## Logging System

See [logging.md](./logging.md).

## Work Plan

Before starting work, you must read `ignore/plan.md` and follow the agent instructions in it. When "the plan file" is mentioned in conversation, it means this file. If the user asks about the next task, answer first based on this plan file.
