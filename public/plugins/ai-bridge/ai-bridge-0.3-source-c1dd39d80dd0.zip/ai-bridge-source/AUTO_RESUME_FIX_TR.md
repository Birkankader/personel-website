# Limit sonrası otomatik devam — 0.1 düzeltmesi

Mesaj kutusundaki **/** menüsünün **Model** bölümünde yer alan **Toggle auto-resume on limit** düğmesi ilk mesaj gönderilmeden önce de çalışır. Taslakta yapılan seçim o sekmede başlatılan yeni sohbete aktarılır; başka bir eski sohbeti açınca ona taşınmaz. Mevcut sohbetin tercihi proje ve sohbet kimliğiyle saklanır, aynı WebView kaynağında yeniden yüklemede korunur. Yeni sekme genel varsayılanı kullanır.

Düğme kapatıldığında bekleyen otomatik devam iptal edilir. Yeniden açmak aynı limit için tekrar zamanlamaya izin verir. Genel tercih kapalıyken elle zamanlama yapılabilir. Elle iptal edilen işlem, limit saati geçtiğinde kendiliğinden yeniden başlamaz.

## Düzeltilen nedenler

- Önceki düğme, sohbet kimliği oluşmadan devre dışıydı ve yalnızca bellekte tutulan seçim yeniden yüklemede kayboluyordu.
- `PROCEEDING`, gönderimden önce yayımlandığı halde başarı gibi işlenip rezervasyonu iptal edebiliyordu. Artık mesajın backend görev kuyruğuna kabul edildiği doğrulanmadan teslim edilmiş sayılmaz.
- Başarısız kabul, rezervasyonu korur ve hata bildirir; yeniden bağlantı mevcut CLI sürecini kullansa da zamanlamayı geri yükler. Arka arkaya otomatik hata denemeleri başlatılmaz.
- Teslim bildirimi yanıt beklemeyen kanal üzerinden gönderilir. Aynı bildirimin tekrarı, yanlış sohbet ve yanlış sekmeden gelen teslim onayları kontrol edilir.
- Eski rezervasyon sorguları yeni durum bildirimini veya başka sohbetin listesini ezmez. Mesajlar yüklenmeden bekleyen işlem silinmez.
- Limit yanıtında yenilenme saati yoksa otomatik bir istek döngüsü başlatılmaz; **Şimdi devam et** elle kullanılabilir.

Otomatik devam, sağlayıcının bildirdiği yenilenme saatinden 30 saniye sonra normal bir `continue` mesajı göndermeyi dener. Kota durumunu dış servislerden sorgulamaz. Sağlayıcı limitin devam ettiğini bildirirse normal limit yanıtı görünür.

## Doğrulama

- Backend tam takım: **169 dosyada 1956 test geçti**, 8 mevcut test atlandı. Yeniden bağlantı ve teslim sahipliği için gerçek zamanlayıcıyla regresyon testleri eklendi.
- Arayüz tam takım: **336 dosyada 3330 test geçti**. Düğme/oturum/limit akışı için 71 hedef test; teslimat ve gerçek mesaj UUID kaynağı için 100 hedef test de geçti. Bu hedef sayılar tam takımın alt kümeleridir.
- Backend ve arayüz TypeScript kontrolleri temiz. Düğmenin kapalı kaldığı ve rezervasyonun erken silindiği eski davranışlar düzeltme öncesi testlerle tekrarlandı.
- Üretim `0.1` paketi başarıyla derlendi. Plugin Verifier, **IC 242.26775.15** ve **IU 262.8117.19** için **Compatible** sonucu verdi. Mevcut iki `requestOpenFile` deneysel API uyarısı devam ediyor; isteğe bağlı JCEF modülü IC kontrolünde doğrulanmadı. Gerçek IDE çalışma testi yapılmadı.
- JAR kimliği, Birkan Kader yayıncısı, sürüm, backend içeriği ve lisans bildirimleri kontrol edildi. Yeniden hesaplanan kaynak özeti `bundleRevision` ile eşleşiyor ve önceki `0.1` paketinden farklı; yeni içerik eski kaynak önbelleğini kullanmaz.
- Tarayıcıda eski pakette ilk mesaj öncesi anahtarın devre dışı olduğu doğrulandı. Güncel pakette ilk mesaj öncesi açıldı; kontrollü limit yanıtından 33 saniye sonra (3 saniyelik örnek yenilenme + 30 saniye bekleme) aynı sohbete tam bir kez `continue` iletildi. İkinci limitte anahtar kapatıldı: rezervasyon dosyası boşaldı ve 70 saniye boyunca yeni `continue` gönderilmedi. Hem açık hem kapalı seçimin sayfayı yeniden yüklemede korunduğu ayrıca doğrulandı.

Bu doğrulamada gerçek sağlayıcıya model isteği gönderilmedi. Tarayıcı senaryosu izole yerel CLI ile çalıştırıldı; test verileri kullanıcı ayarlarından ve sohbetlerinden ayrıdır. IDE'ye kurulum veya Marketplace yayını yapılmadı.
