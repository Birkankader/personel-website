import { EventEmitter } from 'node:events';
import { execFile, type ChildProcess } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdtemp, readFile, writeFile, rm, stat } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { afterEach, describe, expect, it, vi } from 'vitest';
import { createCliLaunchSettings, spawnWithCliLaunchSettings } from '../cli-launch-settings';
import { buildWin32CmdLine } from '../../win-job';

const budget = { CLAUDE_CODE_MAX_OUTPUT_TOKENS: '8192', CLAUDE_CODE_AUTO_COMPACT_WINDOW: '126000', CLAUDE_AUTOCOMPACT_PCT_OVERRIDE: '75' };
const cleanups: Array<() => Promise<void>> = [];
afterEach(async () => { await Promise.all(cleanups.splice(0).map(cleanup => cleanup())); });

describe('CLI settings file transport', () => {
  it('writes valid UTF-8 JSON and keeps inline JSON out of both launch paths', async () => {
    for (const platform of ['linux', 'win32'] as const) {
      const settings = await createCliLaunchSettings(budget, platform);
      cleanups.push(settings.cleanup);
      expect(JSON.parse(await readFile(settings.file, 'utf8'))).toEqual({ env: budget });
      expect(settings.args[0]).toBe('--settings');
      expect(settings.args[1]).not.toContain('{');
      if (platform === 'win32') {
        expect(buildWin32CmdLine('claude', settings.args)).toBe('claude --settings "%AI_BRIDGE_CLI_SETTINGS_FILE%"');
        expect(settings.env.AI_BRIDGE_CLI_SETTINGS_FILE).toBe(settings.file);
      } else {
        expect(settings.args[1]).toBe(settings.file);
        expect(settings.env).toEqual({});
      }
      if (process.platform !== 'win32') expect((await stat(settings.file)).mode & 0o777).toBe(0o600);
    }
  });

  it('isolates concurrent launches and keeps their settings until each process closes', async () => {
    const first = new EventEmitter() as ChildProcess;
    const second = new EventEmitter() as ChildProcess;
    let firstFile = '', secondFile = '';
    await spawnWithCliLaunchSettings(budget, async settings => { firstFile = settings.file; cleanups.push(settings.cleanup); return first; });
    await spawnWithCliLaunchSettings({ ...budget, CLAUDE_CODE_MAX_OUTPUT_TOKENS: '4096' }, async settings => {
      secondFile = settings.file; cleanups.push(settings.cleanup); return second;
    });
    expect(firstFile).not.toBe(secondFile);
    first.emit('spawn');
    expect(JSON.parse(await readFile(firstFile, 'utf8')).env).toEqual(budget);
    first.emit('close', 0);
    await vi.waitFor(async () => { await expect(readFile(firstFile)).rejects.toMatchObject({ code: 'ENOENT' }); });
    expect(JSON.parse(await readFile(secondFile, 'utf8')).env.CLAUDE_CODE_MAX_OUTPUT_TOKENS).toBe('4096');
    second.emit('close', 0);
    await vi.waitFor(async () => { await expect(readFile(secondFile)).rejects.toMatchObject({ code: 'ENOENT' }); });
  });

  it('removes files on a rejected spawn and on an asynchronous launch error', async () => {
    let failedFile = '';
    await expect(spawnWithCliLaunchSettings(budget, async settings => {
      failedFile = settings.file; throw new Error('spawn failed');
    })).rejects.toThrow('spawn failed');
    await expect(readFile(failedFile)).rejects.toMatchObject({ code: 'ENOENT' });
    const child = new EventEmitter() as ChildProcess;
    await spawnWithCliLaunchSettings(budget, async settings => { failedFile = settings.file; cleanups.push(settings.cleanup); return child; });
    child.emit('error', new Error('ENOENT'));
    await vi.waitFor(async () => { await expect(readFile(failedFile)).rejects.toMatchObject({ code: 'ENOENT' }); });
    child.emit('close', -1);
  });

  it.runIf(process.platform === 'win32').each(['native', 'cmd'])('passes spaces, Unicode and percent characters through real cmd.exe (%s launcher)', async launcher => {
    const directory = await mkdtemp(join(tmpdir(), 'ai-bridge settings ç & %PATH%-'));
    cleanups.push(() => rm(directory, { recursive: true, force: true }));
    const settings = await createCliLaunchSettings(budget, 'win32');
    cleanups.push(settings.cleanup);
    const file = join(directory, 'settings.json');
    await writeFile(file, await readFile(settings.file));
    const reader = join(directory, 'reader.cjs');
    await writeFile(reader, 'const fs = require("fs"); process.stdout.write(fs.readFileSync(process.argv[process.argv.indexOf("--settings") + 1], "utf8"));');
    const shim = join(directory, 'reader.cmd');
    await writeFile(shim, `@"${process.execPath}" "%AI_BRIDGE_TEST_READER%" %*\r\n`);
    const command = launcher === 'native' ? '"%AI_BRIDGE_TEST_NODE%"' : '"%AI_BRIDGE_TEST_SHIM%"';
    const args = launcher === 'native' ? ['"%AI_BRIDGE_TEST_READER%"', ...settings.args] : settings.args;
    const { stdout } = await promisify(execFile)(process.env.ComSpec || 'cmd.exe', ['/d', '/v:off', '/s', '/c', `"${buildWin32CmdLine(command, args)}"`], {
      windowsVerbatimArguments: true,
      env: { ...process.env, AI_BRIDGE_CLI_SETTINGS_FILE: file, AI_BRIDGE_TEST_NODE: process.execPath, AI_BRIDGE_TEST_READER: reader, AI_BRIDGE_TEST_SHIM: shim },
    });
    expect(JSON.parse(stdout)).toEqual({ env: budget });
  });
});
