/**
 * Agent runtimes ("harnesses") a chat can run on.
 *
 * `claude` is the Claude Code CLI itself. The others are third-party agents that
 * speak the Agent Client Protocol (ACP) over stdio; the backend runs them through
 * its ACP bridge, which presents them to the rest of the plugin as a Claude-style
 * stream-json process. Each one is started with the official command its own
 * users would type in a terminal — nothing here depends on an SDK.
 *
 * Mirrored 1:1 between backend/src/shared and webview/src/shared.
 */
export const HARNESS_IDS = ['claude', 'opencode', 'deepseek'] as const;
export type HarnessId = typeof HARNESS_IDS[number];
export type AcpHarnessId = Exclude<HarnessId, 'claude'>;

export const DEFAULT_HARNESS: HarnessId = 'claude';

export function isHarnessId(value: unknown): value is HarnessId {
  return typeof value === 'string' && (HARNESS_IDS as readonly string[]).includes(value);
}

export function isAcpHarness(value: unknown): value is AcpHarnessId {
  return isHarnessId(value) && value !== 'claude';
}

/** Product names, shown as-is in every UI language. */
export const HARNESS_LABELS: Record<HarnessId, string> = {
  claude: 'Claude Code',
  opencode: 'OpenCode',
  deepseek: 'DeepSeek Harness',
};

/** The command that serves each harness over ACP stdio, as documented by its project. */
export const HARNESS_ACP_COMMANDS: Record<AcpHarnessId, readonly string[]> = {
  opencode: ['opencode', 'acp'],
  deepseek: ['dsh', '--profile', 'acp'],
};

/** Where users install each harness from, for "not found" guidance. */
export const HARNESS_INSTALL_HINTS: Record<AcpHarnessId, string> = {
  opencode: 'npm install -g @opencode/cli',
  deepseek: 'npm install -g @deepseek-ai/dsh',
};
